#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#   
#   @@RPT
#   LINE 1 Report definition and sorts?
#   History section
#       two lines each
#   end of section marker?  
#   Fields section
#       F{field#}
#       {fieldname,??,??,rptname,length,L}
#       F{field#,"C",ATTR}
#       attrValue
#   Picture section
#       FI{line#,startCol#}
#       {width,field#}
#   Report line attributes
#       L{line#}
#       {linetype,??,..}
#   Footnotes section
#       N{noteline#}
#       footnote
#   Picture layout section
#       P{line#}
#       picture of line
#   Select section
#       T{line#}
#       {subscript,??,"NONE","N",??,??,??,"ASC"}
#   Updates section
#       U{timeinsecs}
#       {user,directory}
#
class PkgRWReader:
#    from sys import sys
    from shutil import copyfile
#    from zipfile import *

        
    #FNAME = ''
    RPATH = ''
    macros = ''
    screens = ''
    reports = ''
    procs = ''
    reportHead = ''
    rptlist = ''
    basedir='C:/IATRIC Systems/Visual Smartboard/ftpsite'
    procdpms ={}

    def __init__(self, initargs=[]):
        if len(initargs)>0:
            self.top=initargs[0]
        self.initConstants()
        self.run()
        
    def initConstants(self):
        pass

    def writelog(self, s,logger=False):
    #        global logfile

        if logger: pass
        elif self.logfile: logger = self.logfile
        else: pass
        
        if logger :
            logger.write(s+'\n')
        elif logger == 'print' or logger =='stdio':
            print s
        else: pass

#    def getfile(self):
#        from tkFileDialog import askopenfilename
        
        
#        FNAME = askopenfilename(initialdir=self.basedir, filetypes=[("", "*.rw")])
#        print 'Importing RW package:', FNAME
#        return FNAME

    def getfile(self,mask="*.rw"):
    #    global tmpname, alines, fmode, tname, _isCompressed
        from tkFileDialog import askopenfilename
        from os import path
        import _winreg
        FNAME=''
        
        if True:
            zt=_winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,"Software"),"ztools")
            ztr=_winreg.OpenKey(zt,"reports")
            mode=_winreg.QueryValueEx(ztr,"LastArchiveType")[0]
            ztm=_winreg.OpenKey(ztr,mode,0,_winreg.KEY_ALL_ACCESS)
            last=_winreg.QueryValueEx(ztm,"LastDir")[0]
            lastfn=_winreg.QueryValueEx(ztm,"LastArchive")[0]
            lastfn=lastfn.split('.')
            lastfn='*.'+lastfn[len(lastfn)-1]

            if len(last)>0:
                self.basedir=last
#            getfile(base,lastfn)

#            FNAME = tkFileDialog.askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", "*.pkg")])
            FNAME = askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", mask)])
#            self.writelog('Importing '+mask.split('.')[1]+' package: '+ FNAME)
            print 'Importing',mask.split('.')[1],'package:', FNAME
            if FNAME != '':
                try :
                    pp = path.dirname(FNAME)
                    newmode=mode[2:];
                    mode_ch=False
                    if "Iatriscan" in pp:
                        newmode="Iatriscan"
                        mode_ch = True
                    elif "Visual" in pp:
                        newmode="vsb"
                        mode_ch = True
                    if mode_ch:
#                        print "Closing ztr"
                        _winreg.CloseKey(ztr)
#                        print 'opening ztr for writing'
                        ztr=_winreg.OpenKey(zt,"reports",0,_winreg.KEY_WRITE)
#                        print 'updating lastarchivetype'
                        _winreg.SetValueEx(ztr,"LastArchiveType",0,_winreg.REG_SZ,newmode)
                        _winreg.CloseKey(ztm)
                        ztm = _winreg.OpenKey(ztr,newmode,0,_winreg.KEY_WRITE)

#                    print "Saving LastDir:", path.dirname(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastDir",0,_winreg.REG_SZ,pp)
#                     print "Saving LastArchive:",path.basename(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastArchive",0,_winreg.REG_SZ,path.basename(FNAME))
                except:
#                    self.writelog('Error writing keys')
                    print 'Error writing keys'
            _winreg.CloseKey(ztm)
            _winreg.CloseKey(ztr)
            _winreg.CloseKey(zt)
        else:
            print 'Error Reading file or reg keys'
            pass

        
        return FNAME

    def convertQueuedString(self,s, slist):
        count = ord(s[0])

        slist.append(s[1:count+1])
        if len(s)>(count+1):
            self.convertQueuedString(s[count+1:],slist)

    def convertQueuedStringEx(self, s, slist):
        count = ord(s[0])
        notFound = True
    #    print 'Top', s, slist, count    
        if count == 30:
            c = 1
            count = 0
            while len(s)>c and notFound:
                if ord(s[c])<32: notFound = False
                else:
                    count += 1
                    c += 1
    #        print s[1:], slist, count, c, notFound
            if notFound: count = ord(s[0])
                
        slist.append(s[1:count+1])
    #    print 'Middle', s[count+1:], slist, count    
        if len(s)>(count+1):
            self.convertQueuedStringEx(s[count+1:],slist)
            
    def isQstring(self, s):

        count = i = 0
        while len(s)> count:
            count += ord(s[count]) + 1

        return len(s) == count

    def parseInput(self, fin, fout=''):
    #    global self.macros, self.screens, self.reports, self.procs, self.reportHead, self.rptlist
        
        done = 0 
        RPTLIST = 1
        MACRO = 2
        SCREEN = 3
        REPORT = 4
        PROC = 5
        VERSION = 6
        UNKNOWN = 7
        
        STATE = 0

        newstate = 0
        
        self.reports = []
        self.macros = []
        self.screens = []
        self.procs = []
        lines = []
        self.rptlist = []
        
        currentMacro = ''
        currentScreen = ''
        currentReport = ''
        currentProc = ''
        currentVersion = ''
        lastProc = ''

        sline = fin.readline()
        if len(sline)>0:
            lines = sline.strip('\r\n').split('^')
            self.reportHead = "|".join(lines)
        lines = []
                              
        while not done:
            sline = fin.readline()
    #        print sline
            if sline.startswith('@@'):
                if sline.startswith('@@MACRO'):
                    newstate = MACRO
                elif sline.startswith('@@SCRN'):
                    newstate = SCREEN
                elif sline.startswith('@@RPT'):
                    newstate = REPORT
                elif sline.startswith('@@PROC'):
                    newstate = PROC
                elif sline.startswith('@@VERSION'):
                    newstate = VERSION
                else: pass

                if currentMacro != '': self.macros.append((currentMacro,lines))
                if currentScreen != '': self.screens.append((currentScreen,lines))
                if currentProc != '': self.procs.append((currentProc,lines))
                if currentVersion != '':
                    for line in lines: self.rptlist.append(line.strip('\r\n'))
                if currentReport != '': self.reports.append((currentReport,lines))

                STATE = newstate
                lines = []
                currentReport = ''
                currentMacro = ''
                currentScreen = ''
                currentProc = ''
                currentVersion = ''

            elif STATE:
                if newstate :
                    if STATE == MACRO:
                        currentMacro = (sline,lastProc)
                    elif STATE == SCREEN: 
    #                    print sline
                        Info = []
                        self.convertQueuedString(sline.strip('\n'),Info)
                        try:
                            currentScreen = Info[2]+ '.'+Info[1]
                        except:
                            currentScreen = currentProc
                        lines.append(sline)
                    elif STATE == PROC: 
    #                    print sline
    #                    Info = []
    #                    convertQueuedString(sline.strip('\n'),Info)
                        currentProc = sline = sline.strip('\r\n')
                        lastProc = sline
    #                    lines.append(sline)
                    elif STATE == VERSION: 
    #                    Info = []
    #                    convertQueuedString(sline.strip('\n'),Info)
                        currentVersion = 'Version'
                        lines.append(sline)
                    elif STATE == REPORT:
    #                    print sline
                        Info = []
                        if sline=='\n' or sline=='\r':
                            sline=sline+fin.readline().strip('\r\n')
                        else:
                            sline.strip('\r\n')
                        self.convertQueuedString(sline,Info)
                        try:
                            currentReport = Info[2]+ '.'+Info[1]
                        except:
                            currentReport = currentProc
                        lines.append(sline)
                    else: pass
                    newstate = 0
                else: lines.append(sline)
            else: pass
            if sline == "" : done=1
        if currentMacro != '': self.macros.append((currentMacro,lines))
        elif currentScreen != '': self.screens.append((currentScreen,lines))
        elif currentProc != '': self.procs.append((currentProc,lines))
        elif currentVersion != '':
            for line in lines: self.rptlist.append(line.strip('\r\n'))
        elif currentReport != '': self.reports.append((currentReport,lines))
        else: pass

        self.procdpms={}
        for pr in self.procs:
            procInfo =[]
            prinfo=pr[1][0]
            if len(prinfo)==1:
                prinfo=prinfo+pr[1].pop(1).strip('\r\n')
                pr[1][0]=prinfo
            else:
                prinfo=prinfo.strip('\r\n')
            
            self.convertQueuedString(prinfo,procInfo)
            print pr, procInfo
            self.procdpms[pr[0]]=procInfo[0]

#        print self.procdpms
#        print 'Finished parsing. Package includes',len(self.rptlist),'self.reports'
#        print 'Report Header',self.reportHead

        if False:
            print 'Self.procs count =', len(self.procs)
            for item in self.procs:
                print '\t'+item[0], len(item[1])
            print 'Self.screens count =', len(self.screens), self.screens[:][0][0]
            for item in self.screens:
                print '\t'+item[0], len(item[1])
        

    #    for screen in self.screens:
    #    	print 'Screen', screen[0]
    #    for report in self.reports:
    #    	print 'Report', report[0]

    # __main__()

    def fileMacros(self):
    #    global self.macros

        fout = ''

        for macro in self.macros:
            key = macro[0][1]
            mpath=self.RPATH
            mname=macro[0][0].strip('\r\n')+'.magic'
            try:
                dpm = self.procdpms[key]
                mpath=mpath+'/'+dpm
                mname=mname[len(dpm)+1:]
            except:
                pass
            fout = file(mpath+'/'+mname,'wb')
#            print macro[0]
            macrotext = macro[1][1::2]

            for line in macrotext:
                fout.write(line)
            fout.close()

    def fileRptSegment(self, fout,segment,keywords,sectionIdName):

#        print 'Filing segment ..', sectionIdName, len( segment )
        
        knownKeys = []
        for kwords in keywords:
            for kword in kwords:
                knownKeys.append(kword)

        for section in segment:
            sectiontext = []

            slist = []


            sectionName = section[0]
            if len(section[1])>0:
                body = section[1]

                mainNode = body.pop(0)
                self.convertQueuedString(mainNode.strip(), slist)
                queline = slist

                sectiontext.append('{'+sectionIdName+'|'+sectionName+'}|{'+'|'.join(queline)+'}')

                index = 0

                test = ''.join(body)
                test = test.replace('\r\n',chr(254))

                body = test.split(chr(254))

                flag =''
                flag0 = ''
                flag1 = ''
                while len(body)>0:
                    topnode = body.pop(0)
                    if len(topnode)>0:
                        slist = []

                        
                        flag0 = topnode[0]
                        flag1 = topnode[0:2]
                        if flag1 in knownKeys:
                            flag = flag1
                        elif flag0 in knownKeys:
                            flag = flag0
                        else:
                            flag = topnode

                        flagout = flag
                        if len(topnode)>len(flag):
                            self.convertQueuedStringEx(topnode[len(flag):],slist)
                            if flag=='F' and len(slist)>1:
                                if slist[1]=='C':
                                    flag = 'FC'
                                    

                        key = flagout+'|'+'|'.join(slist)
                        topnode = body.pop(0)
                        
                        if flag not in keywords[0]:
                            sectiontext.append('{'+key+'}|{'+topnode +'}')
                        else:
                            slist=[]
                            queline = ''
                            self.convertQueuedString(topnode, slist)
                            sectiontext.append('{'+key+'}|{'+'|'.join(slist)+'}')

    #        print str(len(sectiontext)), 'lines processed'            
            for line in sectiontext:
                fout.write(line+'\n')


    def run(self):
    #    global self.reportHead, self.rptlist, self.procs, self.reports, self.screens, versions
        from os import path, mkdir
        
        FNAME = self.getfile()
        if not FNAME == '':
           fa = file(FNAME,'rb')

           self.parseInput(fa)
           fa.close()

           self.RPATH = FNAME[:len(FNAME)-3].strip()
           if path.isdir(self.RPATH): pass
           else: mkdir(self.RPATH)

           for dpm in self.procdpms.keys():
               if path.isdir(self.RPATH+'/'+self.procdpms[dpm]): pass
               else: mkdir(self.RPATH+'/'+self.procdpms[dpm])
               
           fout = file(self.RPATH+'/'+'self.reports-rw.fsl'+'.magic','wb')
           fout.write( '{@@HEAD|'+self.reportHead.rsplit('|',1)[1]+'}|{'+self.reportHead+'}\n' )
           fout.write('{@@VERSION:1}\n')      
           for item in self.rptlist:
               fout.write('{'+str(item)+'}\n')

#           self.fileRptSegment(fout,self.procs, [['R','S']],'@@PROC')
#           self.fileRptSegment(fout,self.reports, [['AT','AL','FI','F','I','T','U','L'],['N','P','FC']],'@@RPT')
#           self.fileRptSegment(fout,self.screens, [['CS','P']],'@@SCRN')
           fout.close()

           self.fileMacros()
           
        else:
           print 'ABORTED BY USER'

    def test():
        tests = []
        tests.append( chr(1)+'1'+chr(30)+'SE'+chr(1)+'1' )
        tests.append( chr(1)+'1'+chr(30)+'C'+chr(30)+'DAT' )
        mystr = []
        for test in tests:
            mystr = []
            convertQueuedStringEx(test,mystr)
            print mystr
'''    try:
    #    test()
        main()
    except :
        errno, errstr = sys.exc_info()
        
        print str(errno), errstr
'''

