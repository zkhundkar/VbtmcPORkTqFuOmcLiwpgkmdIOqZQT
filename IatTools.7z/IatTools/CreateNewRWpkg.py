#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#   
#   @@RPT
#   LINE 1 Report definition and sorts?
#   History section
#       two lines each
#   end of section marker?  
#   Fields section
#       F{field#}
#       {fieldname,??,??,rptname,length,L}
#       F{field#,"C",ATTR}
#       attrValue
#   Picture section
#       FI{line#,startCol#}
#       {width,field#}
#   Report line attributes
#       L{line#}
#       {linetype,??,..}
#   Footnotes section
#       N{noteline#}
#       footnote
#   Picture layout section
#       P{line#}
#       picture of line
#   Select section
#       T{line#}
#       {subscript,??,"NONE","N",??,??,??,"ASC"}
#   Updates section
#       U{timeinsecs}
#       {user,directory}
#   
import sys
from shutil import copyfile
from os import *
from zipfile import *
from tkFileDialog import *
    
FNAME = ''
RPATH = ''
macros = ''
screens = ''
reports = ''
procs = ''
reportHead = ''
rptlist = ''
fout = ''

PROC_INFO =['DPM','Name','Responsible','Active','Access',
            'Arguments','Menu Logic','unknown']

SCRN_INFO = ['Y','Name','DPM','Procedure Name','Screen Type','unknown']

HDR_ELEMS = ['Hospital','MIS','Directory','User','Date','Segment','Description']

reportKeyMap = {'F':'field', 'P':'picLine', 'AT':'audit', 'N':'footnote', 'FI':'fieldIndex',
                'U':'update','T':'subscript'}    
def getfile():
    global FNAME, tmpname, alines, fmode, tname, _isCompressed
    
    basedir='C:/IATRIC Systems/Iatriscan/ftpsite'
    
    FNAME = askopenfilename(initialdir=basedir, filetypes=[("", "*.rw")])
    print 'Importing RW package:', FNAME

def convertQueuedString(s, slist):
    count = ord(s[0])

    slist.append(s[1:count+1])
    if len(s)>(count+1):
        convertQueuedString(s[count+1:],slist)

def convertQueuedStringEx(s, slist):
    count = ord(s[0])
    notFound = True
#    print 'Top', s, slist, count    
    if count == 30:
        c = 1
        count = 0
        while len(s)>c and notFound:
            if ord(s[c])<32: notFound = False
            else:
                count += 1
                c += 1
#        print s[1:], slist, count, c, notFound
        if notFound: count = ord(s[0])
            
    slist.append(s[1:count+1])
#    print 'Middle', s[count+1:], slist, count    
    if len(s)>(count+1):
        convertQueuedStringEx(s[count+1:],slist)
        
def isQstring(s):

    count = i = 0
    while len(s)> count:
        count += ord(s[count]) + 1

    return len(s) == count

def parseInput(fin, fout=''):
    global macros, screens, reports, procs, reportHead, rptlist
    
    done = 0 
    RPTLIST = 1
    MACRO = 2
    SCREEN = 3
    REPORT = 4
    PROC = 5
    VERSION = 6
    UNKNOWN = 7
    APPHEADER = 8
    
    STATE = 8

    newstate = 0
    
    reports = []
    macros = []
    screens = []
    procs = []
    lines = []
    rptlist = []
    appheader = []
    
    currentMacro = ''
    currentScreen = ''
    currentReport = ''
    currentProc = ''
    currentVersion = ''
    currentHeader = 'AppHeader'

    sline = fin.readline()
    if len(sline)>0:
        lines = sline.strip('\r\n')
        reportHead=sline.strip('\r\n')
    lines = []
                          
    while not done:
        sline = fin.readline()
#        print sline
        if sline.startswith('@@'):
            if sline.startswith('@@MACRO'):
                newstate = MACRO
            elif sline.startswith('@@PROC'):
                newstate = PROC
            elif sline.startswith('@@SCRN'):
                newstate = SCREEN
            elif sline.startswith('@@RPT'):
                newstate = REPORT
            elif sline.startswith('@@VERSION'):
                newstate = VERSION
            else: pass

            if currentMacro != '': macros.append((currentMacro,lines))
            if currentScreen != '': screens.append((currentScreen,lines))
            if currentProc != '': procs.append((currentProc,lines))
            if currentVersion != '':
                for line in lines: rptlist.append(line.strip('\r\n'))
            if currentReport != '': reports.append((currentReport,lines))

            STATE = newstate
            lines = []
            currentReport = ''
            currentMacro = ''
            currentScreen = ''
            currentProc = ''
            currentVersion = ''
            currentHeader = ''

        elif STATE:
            if newstate :
                if STATE == MACRO: currentMacro = sline
                elif STATE == SCREEN: 
#                    print sline
                    Info = []
                    convertQueuedString(sline.strip('\n'),Info)
                    currentScreen = Info[3]
                    lines.append(sline)
                elif STATE == PROC: 
#                    print sline
#                    Info = []
#                    convertQueuedString(sline.strip('\n'),Info)
                    currentProc = sline = sline.strip('\r\n')
#                    lines.append(sline)
                elif STATE == VERSION: 
#                    Info = []
#                    convertQueuedString(sline.strip('\n'),Info)
                    currentVersion = 'Version'
                    lines.append(sline)
                elif STATE == REPORT:
#                    print sline
                    Info = []
                    convertQueuedString(sline.strip('\n'),Info)
                    currentReport = Info[2]+ '.'+Info[1]
                    lines.append(sline)
                else: pass
                newstate = 0
            else: lines.append(sline)
        else: pass
        if sline == "" : done=1
    if currentMacro != '': macros.append((currentMacro,lines))
    elif currentScreen != '': screens.append((currentScreen,lines))
    elif currentProc != '': procs.append((currentProc,lines))
    elif currentVersion != '':
        for line in lines: rptlist.append(line.strip('\r\n'))
    elif currentReport != '': reports.append((currentReport,lines))
    elif currentReport != '': reports.append((currentReport,lines))
    elif currentHeader != '': procs.append((appheader,lines))
    else: pass

#    print 'Finished parsing. Package includes',len(rptlist),'reports'

    if False:
        print 'Procs count =', len(procs)
        for item in procs:
            print '\t'+item[0], item[1]
        print 'Screens count =', len(screens), screens[:][0][0]
        for item in screens:
            print '\t'+item[0], item[1]
        print 'Reports count =', len(reports)
        for item in reports:
            print '\t'+item[0], item[1]
    

#    for screen in screens:
#    	print 'Screen', screen[0]
#    for report in reports:
#    	print 'Report', report[0]

# __main__()

def fileMacros():
    global macros, RPATH, fout

#    fout = ''

    fout.write('<macros>\n')
    for macro in macros:
#        fout = file(RPATH+'/'+macro[0].strip('\r\n')+'.magic','wb')
        macrotext = macro[1][1::2]

        fout.write('<macro name=\"'+macro[0].strip('\r\n')+'\">\n')
        for line in macrotext:
            htmlline = line.replace('&','&amp;')
            htmlline = htmlline.replace('<','&lt;')
            htmlline = htmlline.replace('>','&gt;')
            fout.write('<line>'+htmlline+'</line>\n')
        fout.write('</macro>\n')
#        fout.close()
    fout.write('</macros>\n')

def fileRptSegment(fout,segment,keywords, sectionIdName):
    global PROC_INFO, SCRN_INFO, reportKeyMap

    print 'Filing segment ..', sectionIdName, len( segment )
    
    knownKeys = []
    for kwords in keywords:
        for kword in kwords:
            knownKeys.append(kword)

    for section in segment:
        sectiontext = []

        slist = []


        fout.write('<sections name=\"'+sectionIdName+'\">\n')
        sectionName = section[0]
        if len(section[1])>0:
            body = section[1]

            mainNode = body.pop(0)
            convertQueuedString(mainNode.strip(), slist)
            queline = slist

#            sectiontext.append('{'+sectionIdName+'|'+sectionName+'}|{'+'|'.join(queline)+'}')
            if sectionIdName in ('procInfo','screens'):
                LABELS = ['unknown']
                if sectionIdName == 'procInfo':
                    LABELS = PROC_INFO
                elif sectionIdName == 'screens':
                    LABELS = SCRN_INFO
                else:
                    pass 
                i=0
                irange = len(LABELS)
                fout.write('<sectionInfo>')
                for infoEle in queline:
                    fout.write('<secInfoItem name=\"'+LABELS[i]+'\">'+infoEle+'</secInfoItem>\n')
                    if i+1 < irange: i += 1
                fout.write('</sectionInfo>\n')
                

            index = 0

            test = ''.join(body)
            test = test.replace('\r\n',chr(254))

            body = test.split(chr(254))

            flag =''
            flag0 = ''
            flag1 = ''
            while len(body)>0:
                topnode = body.pop(0)
                if len(topnode)>0:
                    slist = []

                    
                    flag0 = topnode[0]
                    flag1 = topnode[0:2]
                    if flag1 in knownKeys:
                        flag = flag1
                    elif flag0 in knownKeys:
                        flag = flag0
                    else:
                        flag = topnode

                    flagout = flag
                    if len(topnode)>len(flag):
                        convertQueuedStringEx(topnode[len(flag):],slist)
                        if flag=='F' and len(slist)>1:
                            if slist[1]=='C':
                                flag = 'FC'
                                

                    key = flagout+'|'+'|'.join(slist)
                    topnode = body.pop(0)
                    
                    if flag not in keywords[0]:
                        sectiontext.append('{'+key+'}|{'+topnode +'}')
                    else:
                        slist=[]
                        queline = ''
                        convertQueuedString(topnode, slist)
                        sectiontext.append('{'+key+'}|{'+'|'.join(slist)+'}')

#        print str(len(sectiontext)), 'lines processed'
        if sectionIdName == 'reports':
            group = ''
            grplabel = ''
            rank = 0
            for line in sectiontext:
                key, value = line.split('}|{')
                keynodes = key.strip('}').strip('{').split('|')
                if keynodes[0] == group:
                    pass
                elif keynodes[0] in reportKeyMap.keys():
                    if not grplabel == '':
                        if grplabel == 'field':
                            fout.write('</'+grplabel+'>\n')
                        fout.write('</'+grplabel+'s>\n')
                    group=keynodes[0]
                    grplabel = reportKeyMap[group]
                    fout.write('<'+grplabel+'s>\n')
                else:
                    grplabel == 'line'
                    group = keynodes[0]
                if group == 'F':
                    if keynodes[1] == rank:
                        if keynodes[2] == 'C':
                            fout.write('<attribute type=\"'+keynodes[3]+'\">'+value.strip('}')+'</attribute>\n')
                        elif keynodes[2] == 'SE':
                            fout.write('<sortElement type=\"'+keynodes[3]+'\">'+value.strip('}')+'</sortElement>\n')
                        else:
                            fout.write('<line>'+line+'</line>\n')
                            
                    else:
                        if rank == 0: pass
                        else : fout.write('</'+grplabel+'>\n')
                        rank = keynodes[1]
                        fout.write('<'+grplabel +' rank=\"'+rank+'\">'+line+'\n')
                elif group == 'AT':
                    valnodes = value.strip('}').strip('{').split('|')
                    fout.write('<'+grplabel+' activity=\"'+valnodes[1]+'\"><time>'+keynodes[1]+'</time>\n')
                    fout.write('<user>'+valnodes[0]+'</user>')
                    if len(valnodes)>2: fout.write('<line>'+','.join(valnodes[1:])+'</line>')
                    fout.write('</'+grplabel+'>\n')
                
                elif group == 'P':
                    valnodes = value.strip('}').strip('{').split('|')
                    fout.write('<'+grplabel+' linenum=\"'+keynodes[1]+'\">'+value.strip('{').strip('}')+'</'+grplabel+'>\n')
                elif group == 'U':
                    valnodes = value.strip('}').strip('{').split('|')
                    fout.write('<'+grplabel+'><updateTime>'+keynodes[1]+'</updateTime>')
                    fout.write('<user>'+valnodes[0]+'</user><activity>'+valnodes[1]+'</activity></'+grplabel+'>\n')
                else:
                    fout.write('<'+grplabel+'><key>'+key.strip('{')+'</key>\n')
                    fout.write('<values>'+value.strip('{').strip('}')+'</values></'+grplabel+'>\n')
            if not grplabel == '':
                fout.write('</'+grplabel+'s>\n')
                
                    
        else:
            for line in sectiontext:
                fout.write('<line>'+line+'</line>\n')
        fout.write('</sections>')

def macroLogic(rpath, fname, fw):

    fm = file(rpath+'/'+fname,'r')
    lnum = 0
    lines = fm.readlines()
    fm.close()
    
    for line in lines:
        fw.write( str(lnum)+'\r\n'+line.strip('\r\n')+'\r\n')
        lnum += 1
    lines = []

def writeReportHeader(fa):
    header = ["MEDITECH.CUST.RPTS","Iatric Systems App Development",
              "IAT",            #  MIS
              "TEST.5.5.MIS",    #  directory
              "IATRICS",         #  user
              "20081218",        #  date last modified
              "A",               #  machine
              "Iatriscan Scanning Macros v1.8"]  # comment field
    fa.write( "^".join(header)+'\r\n')
    fa.write( "@@VERSION:1\r\n")

def writeProcInfo(name,fa):
    fa.write("@@PROC\r\n")
    
    fa.write(name+'\n')
    dpm = name.split('.zcus')[0]
    prInfo = [dpm,name[len(dpm)+1:],"U","Y","Y","","@Inquiry","","Y","","",""]
    for ele in prInfo:
        fa.write(chr(len(ele))+ele)
    fa.write('\r\n')

def writeMacro(name, fa):
    global FNAME, RPATH
    fa.write("@@MACRO\r\n")
                 
    fa.write(name+'\r\n')
    fb=file(RPATH+'/'+name+'.magic','r')
    lines = fb.readlines()
    fb.close()
    linenum=0
    for line in lines:
        fa.write(str(linenum)+'\r\n'+line)
        linenum+=1
    readlines = []

def writeReportInfo(name, fa):
    fa.write('@@RPT\r\n')
    dpm = name.split('.zcus')[0]
                 
#    rptInfo = ["Y",name[len(dpm):],dpm,name,"2","N","","","","","","N","Y","","@Inquiry","","Y"]
    rptInfo = ["Y",name[len(dpm)+1:],dpm,"","","* IATRISCAN LIBRARIES *","REG","12","92","6",
               "60","","66","","N","N","N","Y","N","","","0","1","","","Y","",""]
    for ele in rptInfo:
        fa.write(chr(len(ele))+ele)           
    fa.write('\r\n')
    fa.write("AT"+chr(9)+'671031177\r\n')
    fa.write(chr(len('MEDITECH'))+"MEDITECH"+chr(1)+"E\r\n")
    fa.write('L'+chr(1)+'1\r\n')
    fa.write(chr(1)+'D'+chr(0)+'\r\n')
    fa.write('P'+chr(1)+'1\r\n \r\n')
    rptInfo=[]
    
def writeScreenInfo(name, fa):
    fa.write('@@SCRN\r\n')
    dpm = name.split('.zcus')[0]
    scrInfo = ["Y",name[len(dpm)+1:],dpm,name,"2","N","","","","","","N","","","","",""]
    for ele in scrInfo:
        fa.write(chr(len(ele))+ele)

    fa.write('\r\n')
    fa.write('CS\r\n')
    fa.write(chr(len('4648'))+"4648"+chr(0)+"\r\n")
    fa.write('P'+chr(1)+'1\r\n')
    fa.write(chr(len('* IATRISCAN LIBRARIES *'))+'* IATRISCAN LIBRARIES *')
    fa.write(chr(len('%Z.on.device'))+'%Z.on.device\r\n')
    scrInfo = []
    

def main():
    global FNAME, RPATH, reportHead, rptlist, procs, reports, screens, versions, macros, fout
    global HDR_ELEMS
    
    getfile()
    if FNAME !='':

        RPATH = FNAME[:len(FNAME)-3].strip()

        mfiles = listdir(RPATH)
        proclist=[]
        macrolist = []
        for f in mfiles:
            if f.endswith(".magic"):
                froot = f.split(".M.")
                if froot[0] in proclist: pass
                else: proclist.append(froot[0])
                macrolist.append((froot[0],f.split('.magic')[0]))
                               
        if True:

            fout = file(RPATH+'/'+'new.rw','wb')
           

            writeReportHeader(fout)
            for item in proclist:
                 fout.write(item+'\r\n')
            for item in proclist:
                 writeProcInfo(item,fout)
                 for macro in macrolist:
                     if macro[0] == item:
                         writeMacro(macro[1],fout)
                 writeReportInfo(item,fout)
                 writeScreenInfo(item,fout)

            fout.close()
        else: pass
       
    else:
       print 'ABORTED BY USER'

def test():
    tests = []
    tests.append( chr(1)+'1'+chr(30)+'SE'+chr(1)+'1' )
    tests.append( chr(1)+'1'+chr(30)+'C'+chr(30)+'DAT' )
    mystr = []
    for test in tests:
        mystr = []
        convertQueuedStringEx(test,mystr)
        print mystr

def testregistry():
    import _winreg

    openk = _winreg.OpenKey(_winreg.HKEY_USERS,".DEFAULT")
    keyi = 0
    try:
        while True:
            nextKey = _winreg.EnumKey(openk,keyi)
            print nextKey
            keyi += 1
    except EnvironmentError :
    
#        print str(errno), errstr
        print 'Done'
        
    _winreg.CloseKey(openk)
    
#try:
#    test()
#testregistry()
main()

#except :
#    errno, errstr = sys.exc_info()
    
#    print str(errno), errstr

