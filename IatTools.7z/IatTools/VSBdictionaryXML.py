from PackageReports import PkgRWReader
class VSBdictXML(PkgRWReader):
#    import sys
#    from shutil import copyfile
#    from os import path

    classname = 'VSBdictXML'
    worklists = []
    menus = []
    routines = []
    cds = []
    screens = []
    responses = []
    queries = []
    csmode = False
    setting={}
    

    nodelist = ['WKL','VMNU', 'RTN', 'GGV', 'GXX', 'GGL','VRTN','UNK']
    nodepatterns ={'WKL' : [('WKL','*'),('WKL','*','A'),('WKL','*','F','*'),('WKL','*','U*'),
                            ('WKL','*','C','*'),('WKL','*','SF*'),
                            ('WKL','*','UF','*'),('WKL','*','VB'),
                            ('WKL','*','VB','FLD*'),('WKL','*','VB','FLD*','A'),
                            ('WKL','*','VB','FLD*','M')],
                   'VMNU' : [('VMNU','*'),('VMNU','*','R*')],
                   'RTN' : [('RTN','*'),('RTN','*','A'),('RTN','*','VB')],
                   'GXX'  : [('GXX','*'),('GXX','*','E*'),('GXX','*','E*','AT*'),
                             ('GXX','*','F','*'),('GXX','*','F','*','C','*'),
                             ('GXX','*','M*'), ('GXX','*','S**')],
                   'GGL' : [('GGL','*'),('GGL','*','E','*')],
                   'VRTN' : [('VRTN','*'),('VRTN','*','A'),('VRTN','*','A')] }
    xmlElements = [{'root': 'worklist',
                    ('WKL'):('main',{'root':('active','description','index-rpt','detail-rpt',
                                     'cds')}),
                    ('WKL','A'):('main2',{'root':('appl-db','unk1','unk2','unk3','unk', 'master','filter')}),
                    ('WKL','F'):('filter',{'root':('flt-active','flt-name','flt-type','flt-label',
                                                   'unk','bind-to','fltproc','unk0','unk0-1','unk0-2','unk0-3',
                                                   'unk0-4','flt-mode'),
                                           'keys':('','','','name')}),
                    ('WKL','C'):('colors',{'root':('color-val','description','color-index'),
                                           'keys':('','','','name')}),
                    ('WKL','SF'):('sort-field',{'root':('sort-fld','sort-dir'),
                                                'keys':('','', 'sort-rank')}),
                    ('WKL','UF'):('user-field',{}),
                    ('WKL','U'):('urns',{}),
                    ('WKL','FLD'):('field',{}),
                    ('WKL','VB'):('vbinfo',{'root':('tab-name','unk1','width-unit','subrows','maxrows', 'rowcolor')}),
                    ('WKL','VB','FLD'):('vbfield',{'root':('fld-name','caption','size','row','unk-1', 'column'),
                                                   'keys':('','', "",'fld-rank')}),
                    ('WKL','VB','FLD','A'):('vbfield-attrs',{'root':('mark','hover','rtclick','fld-color','disp-mult','type','just',
                                                                     'udef-1','udef-2','disp-multrow','hover-sub','hover-multrow'),
                                                             'keys':('','', "",'fld-rank')}),
                    ('WKL','VB','FLD','M'):('vbfield-mult',{'root':('disp','color','hover'),
                                                            'keys':('','', "",'fld-rank')})},
 #
                   {'root': 'menu',
                    ('VMNU'):('main',{'root':('active','description','default-rtn','stdbtns')}),
                    ('VMNU','R'):('menu-rtn',{'root':('rtn','rtn-type')}) },
 #
                   {'root': 'routine',
                    ('RTN'):('main',{'root':('active','description','link-ext','appl-db','refresh','label','proc-logic'),
                                     'keys':('','name')}),
                    ('RTN','A'):('main2',{'root':('req1','req2','multirow','unk4','unk5')}),
                    ('RTN','VB'):('vb-info',{'root':('btn-label','inc','icon','unk4','unk5')})},

                   {'root': 'query',
                    ('GGV'):('main',{'root':('active','description',"type",'','','','','','','','','','','','','','','type-name')})},

                   {'root': 'screen',
                    ('GXX'):('main',{'root':('active','description')}),
                    ('GXX','E'):('element',{'root':('qry-mnemonic','row','column','unk1','unk-2',
                                                    'resp-row','resp-col'),
                                            'keys':('','','ele-rank')}),
                    ('GXX','E','AT'):('attr',{'root':('attr-line',""),
                                              'keys':("","","ele-rank","line-num")}),
                    ('GXX','F'):('field',{'root':('query-num','qry-row','qry-col','qry-text','qry-len',
                                                  'resp-row','resp-col','resp-req','resp-len'),
                                          'keys':("","",'',"mne")}),
                    ('GXX','F','C'):('field-attr',{'root':('fld-attr-line',""),
                                          'keys':("","",'','mne','',"type")}),
                    ('GXX','M'):('main',{'root':('active','description')}),
                    ('GXX','S'):('sections',{'root':('sect-query','description'),
                                             'keys':("","",'name','page','sect-num')})},
 #
                   {'root': 'grp-response',
                    ('GGL'):('main',{'root':('active','description')}),
                    ('GGL','E'):('element',{'root':('ele-response',''),
                                            'keys':('','','','ele-mnemonic')}) },
 #
                   {'root': 'magic-routine',
                    ('VRTN'):('main',{'root':('active','description','link-ext','appl-db','refresh','label'),
                                     'keys':('','name')}),
                    ('VRTN','A'):('main2',{'root':('req1','req2','multirow','unk4','unk5')}),
                    ('VRTN','VB'):('vb-info',{'root':('btn-label','inc','icon','unk4','unk5')})} ]
    
    datasegments = [('GXX','E','AT'),('GXX','F','C')]

    csElements = [ {'root':'worklist',
                    ('WKL','VB','FLD','A'):('vbfield-attrs',{'root':('mark','rtclick','disp-mult','disp'),
                                                             'keys':('','', "",'fld-rank')}),
                   ('WKL','VB','FLD','M'):('vbfield-mult',{'root':('show','disp','color','hover'),
                                                            'keys':('','', "",'fld-rank')})} ]


    def __init__(self, initargs=[]):

        self.csmode=False
        self.logging=False
        if len(initargs)>0:
            self.top=initargs[0]
        if len(initargs)>1:
            self.settings = initargs[1]
#        self.setdebuglog()
        try:
            self.csmode=self.settings['csm']
        except KeyError:
            pass
        print 'running vsb dict cs mode', self.csmode
        self.run()

    def getfile(self,mask="*.dict"):
    #    global tmpname, alines, fmode, tname, _isCompressed
        from tkFileDialog import askopenfilename
        from os import path
        import _winreg
        FNAME=''
 
        lastfn=mask
        try:
            self.basedir=self.settings['LastDict']
        except KeyError:
            self.basedir='C:/IATRIC Systems/Visual Smartboard/Code Repository'
        try:
            lastfn=self.settings["LastDict"]
            mask='*.'+lastfn.split('.')[-1]
        except KeyError:
            pass

        FNAME = askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", mask)])
        print 'Converting dictionary: '+mask.split('.')[1]+': ' + FNAME
       
        if True:
            if FNAME != '':
                try :
                    pp = path.dirname(FNAME)
                    newmode=mode[2:];
                    mode_ch=False
                    if "Iatriscan" in pp:
                        newmode="Iatriscan"
                        mode_ch = True
                    elif "Visual" in pp:
                        newmode="vsb"
                        mode_ch = True
                    if mode_ch:
                        self.settings['LastArchiveType']=newmode
                        self.settings['LastDict']=FNAME
                    
#                        print "Closing ztr"
#                        _winreg.CloseKey(ztr)
#                        print 'opening ztr for writing'
#                        ztr=_winreg.OpenKey(zt,"reports",0,_winreg.KEY_WRITE)
#                        print 'updating lastarchivetype'
#                        _winreg.SetValueEx(ztr,"LastArchiveType",0,_winreg.REG_SZ,newmode)
#                        _winreg.CloseKey(ztm)
#                        ztm = _winreg.OpenKey(ztr,newmode,0,_winreg.KEY_WRITE)

#                    print "Saving LastDir:", path.dirname(FNAME),'to',ztm
#                    _winreg.SetValueEx(ztm,"LastDir",0,_winreg.REG_SZ,pp)
##                     print "Saving LastArchive:",path.basename(FNAME),'to',ztm
#                    _winreg.SetValueEx(ztm,"LastArchive",0,_winreg.REG_SZ,path.basename(FNAME))
                except:
#                    self.writelog('Error writing keys')
                    print 'Error writing keys'
        else:
            print 'Error Reading file or reg keys'
            pass

        
        return FNAME

    def parseInput(self, fin, fout=''):
        from operator import indexOf
    #    global self.macros, self.screens, self.reports, self.procs, self.reportHead, self.rptlist
        
        done = 0 
        WORKLIST = 1
        MENU = 2
        ROUTINE= 3
        SCREEN = 4
        RESPONSE = 5
        QUERY = 6
        VERSION = 7
        UNKNOWN = 8
        
        STATE = 0

        newstate = 0
        
        self.worklists = []
        self.menus = []
        self.routines = []
        self.screens = []
        responses = []
        queries = []
        lines = []
        parsedItems = []
        self.rptlist = []

        for item in self.nodelist:
            lines.append([])
            parsedItems.append([])
        currentItem = []
        currentScreen = ''
        currentReport = ''
        currentProc = ''
        currentVersion = ''

#        sline = fin.readline()
#        if len(sline)>0:
#            lines = sline.strip('\r\n').split('^')
#            self.reportHead = "|".join(lines)
#        lines = []

        STATE = len(self.nodelist)
        rline = ''
        self.csmode = False

        if self.csmode and False:
            for item in self.xmlElements:
                for newitem in self.csElements:
                    if item['root'] == newitem['root']:
                        keylist = newitem.keys()
                        for akey in keylist:
                            if akey == 'root': pass
                            else:
                                item[akey]=newitem[akey]
                    else: pass
                

        
# Read and group the nodes from a magic dictionary                             
        while not done and not self.csmode:
            sline = fin.readline()
            if sline.endswith('\r\n'):
                sline=sline[:len(sline)-2]
            if len(sline)>0:
                rline = rline + sline
                dlines = rline.split('\xfc')
                if rline[len(rline)-1] == '\xfc':
                    rline = ''
                elif dlines[len(dlines)-1] == '\r\n':
                    dlines.pop(len(dlines)-1)
                    rline = ''
                else:
                    rline = dlines.pop(len(dlines)-1)
                for sline in dlines:
                    sline = sline+'\xfc'
                    s = sline.split(chr(30))[0]
                    s1=sline.split(chr(0)+'.')[0]
                    if len(s)>len(s1) :
                        print s, s1
                        if s1 in self.nodelist:
                            s=s1
                            sline=sline.replace(chr(0)+'.',chr(30)+'.')
            #        print sline
                    if s in self.nodelist:
                        STATE=indexOf(self.nodelist,s)
                        lines[STATE].append(sline)
                    elif len(s)>0 and STATE<len(self.nodelist):
                        lines[STATE].append(sline)
                    else:
                        lines[len(self.nodelist)-1].append(sline)
            else:
                done = True

# Read and group the nodes from a CS magic dictionary                             
        while not done and self.csmode:
            sline = fin.readline()
            if len(sline)>0:
                s = sline.split(chr(30))[0]
                s1=sline.split(chr(0)+'.')[0]
                if len(s)>len(s1) :
                    print s, s1
                    if s1 in self.nodelist:
                        s=s1
                        sline=sline.replace(chr(0)+'.',chr(30)+'.')
        #        print sline
                if s in self.nodelist:
                    STATE=indexOf(self.nodelist,s)
                    lines[STATE].append(sline)
                elif len(s)>0 and STATE<len(self.nodelist):
                    lines[STATE].append(sline)
                else:
                    lines[len(self.nodelist)-1].append(sline)
            else:
                done = True

        nodename = ''
        for item in lines:
            if len(item)>0:
                grp = "".join(item)
                label=item[0].split(chr(30))[0]

                if label in self.nodelist:
                    newstate =indexOf(self.nodelist, label)
                else: newstate = indexOf(self.nodelist,'UNK')

                STATE = newstate
                currentItem=[]
                grp = grp.split(chr(252))
                for node in grp:
                    # process each node
                    keyvalpair = node.split(chr(251))
                    key=keyvalpair[0].strip('\r\n').split(chr(30))
                    if key[0]=="GGL" and len(key)==3:
                        key.append(key[2][2:])
                        key[2]=key[2][0]
                    if nodename =='': nodename=key[1]
                    qstring = ''
                    if len(keyvalpair)>1:
                        qstring=keyvalpair[1]
                    else: pass
                    try :
                        if newstate == STATE and nodename==key[1]:
                            currentItem.append((key,qstring))
                        elif newstate==STATE:
                            if len(currentItem)>1:
                                parsedItems[STATE].append((nodename,currentItem))
                                currentItem=[]
                            STATE = newstate
                            currentItem.append((key,qstring))
                            nodename = key[1]
                    except :
                        pass
                if len(currentItem)>0:
                    parsedItems[STATE].append((nodename,currentItem))
                    
        
        for item in parsedItems:
            itype  = self.nodelist[indexOf(parsedItems,item)]
            print 'Added items to segment',itype,len(item)
            if itype == 'WKL':
                self.worklists = item
            elif itype == 'RTN' and self.csmode:
                self.routines = item
            elif itype == 'VRTN' and not self.csmode:
                self.routines = item
            elif itype == 'VMNU':
                self.menus = item
            elif itype == 'GGV':
                self.queries = item
            elif itype == 'GGL':
                self.responses = item
            elif itype == 'GXX':
                self.screens= item
                
        print 'Finished parsing. Package includes',len(parsedItems),'sections'
        print 'Worklists',len(self.worklists)

        print 'Menus',len(self.menus)
        print 'Routines',len(self.routines)
        print 'Screens',len(self.screens)
        print 'Queries',len(self.queries)
        print 'Group Responses',len(self.responses)


    def initConstants(self):
        self.PROC_INFO =['DPM','Name','Responsible','Active','Access',
                    'Arguments','Menu Logic','unknown']

        self.SCRN_INFO = ['Y','Name','DPM','Procedure Name','Screen Type','unknown']

        self.HDR_ELEMS = ['Hospital','MIS','Directory','User','Date','Segment','Description']

        self.reportKeyMap = {'F':'field', 'P':'picLine', 'AT':'audit', 'N':'footnote', 'FI':'fieldIndex',
                    'L':'line-attrib','U':'update','T':'subscript'}    



    def fileSegment(self, fout, segment, sectionIdName):
#        global self.PROC_INFO, self.SCRN_INFO, self.reportKeyMap
        from operator import indexOf

        print 'Filing segment ..', sectionIdName, len( segment )
        
        pattern = []
        if sectionIdName in self.nodepatterns:
            pattern = self.nodepatterns[sectionIdName]
        keydict = self.xmlElements[indexOf(self.nodelist,sectionIdName)]
        segmentName = keydict['root']
        fout.write('<'+segmentName+'s>')
        elementList = []
        
#        print segment
        for section in segment:
#            fout.write('<'+segmentName+'>')
            fout.write('<'+segmentName+' name=\"'+section[0]+'\">\n')
            sectionName = section[0]
            if sectionName == 'RAC.STATUS' and sectionIdName == 'GGL':
                print section
            elif sectionName == 'RAC.OUTCOM' and sectionIdName == 'GGL':
                print section
#            print 'Filing', segmentName, sectionName, section[1][0]
            if len(section[1])>0 :
                body = section[1]

                nodeKey, mainNode = body.pop(0)
                
                slist = []
                self.convertQueuedString(mainNode.strip(), slist)
                queline = slist
                segdict = keydict[sectionIdName]
                self.writenode(fout,segdict,nodeKey,slist)
            for item in body:
                nodeKey, mainNode = item
                slist = []
                self.convertQueuedString(mainNode, slist)
                match = False
                segdict = []
                reducedKey = []
                matchKey = []
                if len(pattern) > 0:
                    for nitem in pattern:
                        if match: break
                        else:
                            if len(nitem) != len(nodeKey): pass
                            else:
                                reducedKey = []
                                matchKey = []
                                for i in range(0,len(nitem)):
                                    if nitem[i]=='*': matchKey.append(nodeKey[i])
                                    elif '*' in nitem[i]:
                                        lenpart = indexOf(nitem[i],'*')
                                        matchpart = nodeKey[i][:lenpart]
                                        if matchpart == nitem[i][:lenpart]:
                                            reducedKey.append(matchpart)
                                            keyl=[]
                                            if len(nodeKey[i])>lenpart:
                                                self.convertQueuedString(nodeKey[i][lenpart:],keyl)
                                            else:
                                                keyl.append('999')
                                            matchKey.append(keyl[0])
                                        elif '+' in nitem[i]: pass
                                        else: reducedKey.append('??*-')
                                        if nitem[i]=='S*':
                                            pass
                                    elif nitem[i]==nodeKey[i]:
                                        reducedKey.append(nodeKey[i])
                                        matchKey.append(nodeKey[i])
                                    else: reducedKey.append('??+')
                                reducedKey = tuple(reducedKey)
                                if reducedKey in keydict:
                                    segdict = keydict[reducedKey]
                                    match = True
                                    if reducedKey in self.datasegments:
                                        slist=[mainNode]
                                else: pass
                else: pass
                if len(reducedKey)>0 :
#                    print nodeKey, matchKey, reducedKey
                    pass
                self.writenode(fout,segdict,matchKey,slist)
                   
                                    
                            
            fout.write('</'+segmentName+'>\n')
        fout.write('</'+segmentName+'s>\n')

    def escapedhtmString(self, s):
        return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
        

    def writenode(self, fout, sdict, keys, values):
        namelist = ()
        if len(sdict)>1:
            segname =sdict[0]
            sdict=sdict[1]
            keylist =[]
            try:
                namelist=sdict['root']
                if 'keys' in sdict:
                    keylist = sdict['keys']
            except :
                type(sdict), sdict
            i=0
            if len(keylist)>0:
                fout.write('<'+segname)
                while i < len(keylist):
                    if keylist[i] == '': pass
                    else: 
                        try:
                            fout.write(" "+keylist[i]+'=\"'+self.escapedhtmString(keys[i])+'\"')
                        except:
                            pass
                    i += 1
                fout.write('>')
                
            else:
                fout.write('<'+segname+'>')

            i=0
            while i<len(values):
                if i<len(namelist):
                    keyname = namelist[i]
                    if keyname != '':
                        fout.write('<'+keyname+'>'+self.escapedhtmString(values[i])+'</'+keyname+'>')
                i += 1
            if len(sdict)==0:
                keyname= ''.join(keys)
                fout.write('<key type=\"'+'seg'+'\" >'+self.escapedhtmString('|'.join(values))+'</key>')
            fout.write('</'+segname+'>\n')
        elif len(sdict)>0:
            keyname= ''.join(keys)
            fout.write('<'+sdict[0]+'>')
            fout.write('<key type=\"'+", ".join(sdict.keys())+'\" >'+self.escapedhtmString('|'.join(values))+'</key>')
            fout.write('</'+sdict[0]+'>\n')
        else:
            fout.write('<unknown>')
            fout.write('<key>'+", ".join(keys)+'</key><value>'+self.escapedhtmString('|'.join(values))+'</value>')
            fout.write('</unknown>\n')
                
        
    def run(self):
#        global FNAME, self.RPATH, self.reportHead, self.rptlist, self.procs, self.reports, self.screens, versions, fout
#        global self.HDR_ELEMS
        from os import path, mkdir
        
        FNAME=self.getfile('*.dict')
        if FNAME !='':
           fa = file(FNAME,'rb')

           self.parseInput(fa)
           fa.close()
           
            
           self.RPATH = FNAME[:len(FNAME)-3].strip()
#           if path.isdir(self.RPATH): pass
#           else: mkdir(self.RPATH)

    #       fout = file(self.RPATH+'/'+'self.reports-rw.xml','wb')
           xfile = FNAME.split('.')
           xfile[len(xfile)-1]='xml'
           fout = file(".".join(xfile),'wb')
#           fout = file(FPATH+'.xml','wb')
           fout.write('<?xml version="1.0"?>\n')
#           fout.write('<?xml-stylesheet type="text/xsl" href="./vsbdict.xsl" ?>\n')
           fout.write('<!-- ?xml-stylesheet type="text/xsl" href="c:/iatric/vsbdict.xsl" ? -->\n')
           fout.write('\n<VSBDictpkg file=\"'+path.basename(FNAME)+'\">\n')
           
           
           self.fileSegment(fout,self.worklists,'WKL')
           self.fileSegment(fout,self.menus,'VMNU')
           if "RTN" in self.nodelist:
               self.fileSegment(fout,self.routines,'RTN')
           elif "VRTN" in self.nodelist:
               self.fileSegment(fout,self.routines,'VRTN')
           self.fileSegment(fout,self.screens,'GXX')
           self.fileSegment(fout,self.queries,'GGV')
           self.fileSegment(fout,self.responses,'GGL')



#           self.fileRptSegment(fout,self.reports, [['AT','AL','FI','F','I','T','U','CI'],['N','P','FC','L']],'reports')
#           self.fileRptSegment(fout,self.screens, [['CS','P']],'screens')


#           self.fileMacros(fout)
           fout.write('</VSBDictpkg>\n')
           fout.close()
           print 'done'
           
        else:
           print 'ABORTED BY USER',self.classname

    def test():
        tests = []
        tests.append( chr(1)+'1'+chr(30)+'SE'+chr(1)+'1' )
        tests.append( chr(1)+'1'+chr(30)+'C'+chr(30)+'DAT' )
        mystr = []
        for test in tests:
            mystr = []
            convertQueuedStringEx(test,mystr)
            print mystr

if __name__ == '__main__':
#    main(sys.argv[1:])
    app=VSBdictXML()
