
class pkgDiff():
    source = []
    home = '../'
    settings = {}
    basepkg = ''
    newpkg = ''
    BASEHOME = ''
    basedir = 'C:/Iatric Systems'
    compdir = 'C:/Iatric Systems'
    printdiff = True
    
    def __init__(self, initargs=[], basepkg='', newpkg=''):
        if len(initargs) > 0:
            self.top = initargs[0]
        if len(initargs) > 1:
            self.settings = initargs[1]
        if 'XSLHOME' in self.settings["main"]:
            self.home = self.settings["main"]['XSLHOME'] + '/'
        self.basepkg = basepkg
        self.newpkg = newpkg
        self.run()

    def writelog(self, s, logger=False):
#        global logfile

        if logger: pass
        elif self.logfile: logger = self.logfile
        else: pass
        
        if logger == 'print' or logger == 'stdio':
            print s
        elif logger :
            logger.write(s + '\n')
        else: pass

    def getdir(self, initialdir=''):
        import tkFileDialog
        import _winreg
        from os import path
        
        if True:
            zt = _winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER, "Software"), "ztools")
#            ztr=_winreg.OpenKey(zt,"compares")
            ztm = _winreg.OpenKey(zt, "compares", 0, _winreg.KEY_ALL_ACCESS)
            last = _winreg.QueryValueEx(ztm, "LastBaseDir")[0]
#            lastfn=_winreg.QueryValueEx(ztm,"LastCompDir")[0]
            if len(last) > 0:
                self.basedir = last

            FNAME = tkFileDialog.askdirectory(initialdir=self.basedir)
#            self.writelog('Importing package: '+ FNAME)
            if FNAME != '':
                try:
                    print "Saving LastDir:", path.dirname(FNAME), 'to', ztm
                    _winreg.SetValueEx(ztm, "LastBaseDir", 0, _winreg.REG_SZ, path.dirname(FNAME))
                except:
#                    self.writelog('Error writing keys')
                    print 'Error writing keys'
                    pass
            _winreg.CloseKey(ztm)
#            _winreg.CloseKey(ztr)
            _winreg.CloseKey(zt)
        else:
            print 'Error Reading file or reg keys'
            pass

        return FNAME

    def getfile(self):
        import tkFileDialog
        global tmpname, alines, fmode, tname, _isCompressed
        import _winreg
        from os import path
        
        try:
            zt = _winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER, "Software"), "ztools")
            ztm = _winreg.OpenKey(zt, "compares", 0, _winreg.KEY_ALL_ACCESS)
            last = _winreg.QueryValueEx(ztm, "LastCompDir")[0]
            if len(last) > 0:
                self.compdir = last
            else:
                self.compdir = self.basedir

            FNAME = tkFileialog.askopenfilename(initialdir=self.compdir, filetypes=[("", "*.pkg")])
            self.writelog('Importing package: ' + FNAME)
            if FNAME != '':
                if True:
                    print "Saving LastDir:", path.dirname(FNAME), 'to', ztm
                    _winreg.SetValueEx(ztm, "LastCompDir", 0, _winreg.REG_SZ, path.dirname(FNAME))
                else:
                    self.writelog('Error writing keys')
                    print 'Error writing keys'
            _winreg.CloseKey(ztm)
            _winreg.CloseKey(zt)
        except:
            print 'Error Reading file or reg keys'
            pass

        return FNAME

        
    def compDpms(self, differ, out):
        
        import os.path 
        print '----------- New in new package ----------'
        for f in differ.right_only:
            if os.path.isdir(self.newpkg + '/' + f):
                print f

        print '----------- Deleted in new package ----------'
        for f in differ.left_only:
            if os.path.isdir(self.basepkg + '/' + f):
                print f

    def escapedhtmString(self, s):
        return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


    def parseXML(self, fldtypes, vals):
#        global fout
        retStr = ''
        fldtype = fldtypes[0]
        if fldtype == 'F' :
            nvals = vals.split('|')
            if len(nvals) > 4:
                retStr = '<name>' + nvals[0] + '</name><field-id>' + fldtypes[1] + '</field-id><row>' + nvals[3] + '</row>'
                retStr = retStr + '<column>' + nvals[4] + '</column><section>' + nvals[2] + '</section>'
        elif fldtype == 'screen' :
            nvals = vals.split('|')
            if len(nvals) > 11:
                retStr = '<name active=\"' + nvals[0] + '\">' + nvals[3] + '</name><dpm idx=\"' + str(self.dpmNames.index(nvals[2]) + 1) + '\">' + nvals[2] + '</dpm><audit-name>' + nvals[1] + '</audit-name><screen-type>' + nvals[4] + '</screen-type>'
                retStr = retStr + '<dataseg>' + nvals[6] + '</dataseg><multi-page>' + nvals[7] + '</multi-page><fragment>' + nvals[11] + '</fragment>\n'
        elif fldtype == 'title' :
            nvals = vals.split('|')
            if len(nvals) > 1:
                retStr = '<title>' + nvals[0] + '</title><file-prompt>' + nvals[1] + '</file-prompt>\n'
        else:
            if len(fldtypes) == 2: pass
            else: print type(fldtypes), fldtypes
            retStr = vals

        return retStr

    def printHtmlDiff(self, folder, fname):
        import difflib
        import os.path

        if not self.printdiff: return
        else:
            print folder, fname
            fnameroot = fname.split('.')
            fnameroot = ".".join(fnameroot[:len(fnameroot) - 1])
#            fnameroot=fname[:len(fname)-6]
            
            fromfile = self.basepkg + '/' + folder + '/' + fname
            fromname = self.basepkg.split('/')
            fromname = fromname[len(fromname) - 1] + '/' + folder + '.' + fnameroot
            fn = open(fromfile, 'r')
            fromlines = fn.readlines()
            fn.close()
            tofile = self.newpkg + '/' + folder + '/' + fname
            toname = self.newpkg.split('/')
            toname = toname[len(toname) - 1] + '/' + folder + '.' + fnameroot
            fn = open(tofile, 'r')
            tolines = fn.readlines()
            fn.close()

            if fname.endswith('.magic'):
                fn = open(self.newpkg + '/diff ' + os.path.basename(self.basepkg) + '/' + folder + '.' + fnameroot + '.htm', 'w')
                fn.write(difflib.HtmlDiff().make_file(fromlines, tolines, fromname, toname, context=True, numlines=3))
                fn.flush()
                fn.close()
            elif fname.endswith('.xml'):
                fn = open(self.newpkg + '/diff ' + os.path.basename(self.basepkg) + '/' + folder + '.' + fnameroot + '.xml', 'w')
                self.printxmlDiff(fn, fromfile, tofile, fromname, toname)
                fn.flush()
                fn.close()
            else:
                pass

            fromlines = []
            tolines = []
            
        return

    def getKeyToMatch(self,s,match,matchtype):
        key=[]
        MATCHATTRIB, MATCHNODE = matchtype
        if MATCHATTRIB:
            for at in match:
                key.append(str(s.getAttribute(at)))
        elif MATCHNODE:
            for at in match:
                mnode=s.getElementsByTagName(at)
                key.append(str(mnode[0].firstChild.nodeValue))
        else:
            key.append(str(s.firstChild.nodeValue))
                    
        return ".".join(key)        

    def compareNodesets(self, src, tgt, match=["name"], nodes=[], tgtval=[], children=[]):
        segNames = {}
        gmodflag = False
        matchval = ""
        MATCHNODE = False
        MATCHORDER = True
        MATCHATTRIB = False
        
        if len(match) > 1:
            MATCHATTRIB = True
            matchval = match[1]
        elif len(match) > 0:
            MATCHNODE = True
            matchval = match[0]
        else:
            pass
        matchval=matchval.split(",")
        
        for s in src:
            s.setAttribute('diff', 'Deleted')
            try:
                keymatch = self.getKeyToMatch(s,matchval,(MATCHATTRIB,MATCHNODE))
                segNames[keymatch] = s
#                if MATCHATTRIB:
#                    for at in matchval:
#                        keytomatch.append(str(s.getAttribute(at)))
#                    segNames[".".join(keymatch)] = s
#                elif MATCHNODE:
#                    for at in matchval:
#                        mnode=s.getElementsByTagName(at)
#                        keytomatch.append(str(mnode[0].firstChild.nodeValue))
#                    segNames[".".join(keymatch)] = s
#                else:
#                    segNames[str(s.firstChild.nodeValue)] = s
            except:
                pass
                
        for s in tgt:
            s.setAttribute('diff', 'New')
            kv = s
            modflag = False
            try:
                keymatch = self.getKeyToMatch(s,matchval,(MATCHATTRIB,MATCHNODE))
                kv = segNames[keymatch]
#                if MATCHATTRIB:
#                    kv = segNames[str(s.getAttribute(matchval))] 
#                elif MATCHNODE:
#                    kv = segNames[str(s.getElementsByTagName(matchval)[0].firstChild.nodeValue)]
#                elif MATCHORDER:
#                    kv=src[tgt.index(s)]
#                else:
#                    kv = segNames[str(s.firstChild.nodeValue)]

                if not str(kv.firstChild.nodeValue)==str(s.firstChild.nodeValue):
                    modflag=True
#            kv = segNames[str(s.getAttribute('name'))]
 #           nodes = ('active', 'physBase', 'parent', 'constant', 'segType')
                for name in nodes:
                    src_nodeValue = ""
                    c = ""
                    cval = ""
                    try:
                        c = str(s.getElementsByTagName(name)[0].firstChild.nodeValue)
                        srcNode = kv.getElementsByTagName(name)[0]
                        src_nodeValue = str(srcNode.firstChild.nodeValue)                    
                    except:
                        pass
                    try:
                        if len(tgtval) > 0:
                            if len(tgtval[0]) > 0:
                                cval = str(srcNode.getElementsByTagName(tgtval[0])[0].firstChild.nodeValue)
                            else:
                                cval = str(srcNode.getAttribute(tgtval[1]))
                        else:
                            cval = src_nodeValue
                        
                    except:
                        kv.setAttribute('cmp-err1',src_nodeValue)
                    if c == str(src_nodeValue):
                        pass
                    else:
                        modflag = True
                        srcNode.setAttribute('diff', 'Modified')
                        srcNode.setAttribute('tgt-value', cval)
            # Check fields list in this segment
                for c in children:
                    c_match, c_id, c_tag = c
                    fldS = kv.getElementsByTagName(c_tag)
                    fldT = s.getElementsByTagName(c_tag)
                    nflag=False
                    try:
                        nflag = self.compareNodesets(fldS, fldT, c_match, c_id)
                    except:
                        kv.setAttribute('cmp-err','children-loop')
                    if not modflag and nflag:
                        modflag = True
                        
                if modflag:
                    gmodflag = True
                    kv.setAttribute('diff', 'Modified')
                 
                else:
                    kv.setAttribute('diff', 'Same')
                  
            except KeyError:
                modflag = True
                gmodflag=True
                
                src[0].parentNode.appendChild(s)
                pass            
            except :
                modflag = True
                gmodflag=True            
                        

        return gmodflag


    def printxmlDiff(self, output, base, target, basename, tname):
        from xml.dom import minidom

        try:
            xt_src = minidom.parse(base)
            xt_cmp = minidom.parse(target)
            rootN = xt_src.childNodes[1]
            tgtN = xt_cmp.childNodes[1]
            treeType = str(rootN.nodeName)
            if treeType == 'datadef':
                seglistS = rootN.getElementsByTagName('segment')
                seglistT = tgtN.getElementsByTagName('segment')
                
                nflag = self.compareNodesets(seglistS, seglistT, ["","name"], ('active', 'dpm','physBase', 'extname','parent', 'constant', 'segType','mapsTo','localSubscripts','elemCount'), "", 
                                             [(["","rank"], ["fldname"], "field"), (["","rank"], ["fldname","physName"], "subscript")])
                nflag = self.compareNodesets(rootN.getElementsByTagName('fld-def'),
                                        tgtN.getElementsByTagName('fld-def'),
                                        ["", "element"], ('dpm','pointer', 'DataType', 'physName', 'offset', 'locName', 'length', 'rank'))
                
                output.write(xt_src.toxml())
                                                     
                                                     
                pass
            elif treeType == 'screens':
                if "ee1.new_S" in base:
                    print base
                nflag = self.compareNodesets(rootN.getElementsByTagName('screen'),
                                        tgtN.getElementsByTagName('screen'),
#                                        ["name"], ('active', 'audit-name', 'screen-type', 'multi-page', 'dataseg', 'length', 'rank'), "", [(["","p"],[],'picLine')])
                                        ["name"], ('active', 'audit-name', 'screen-type', 'multi-page', 'dataseg', 'length', 'rank'))
                nflag = self.compareNodesets(rootN.getElementsByTagName('picLine'),
                                        tgtN.getElementsByTagName('picLine'),
                                        [], (""))
                nflag = self.compareNodesets(rootN.getElementsByTagName('field'),
                                        tgtN.getElementsByTagName('field'),
                                        ["field-id"], ("name","row","column"), "", [([],[],"attrib")])
                output.write(xt_src.toxml())
                
            elif treeType == 'Reports':
                nflag = self.compareNodesets(rootN.getElementsByTagName('report'),
                                        tgtN.getElementsByTagName('report'),
#                                        ["name"], ('active', 'audit-name', 'screen-type', 'multi-page', 'dataseg', 'length', 'rank'), "", [(["","p"],[],'picLine')])
                                        ["name"], ('active', 'name', 'dpm', 'dataseg', 'rptTitle', 'rpt-header'))
                nflag = self.compareNodesets(rootN.getElementsByTagName('picLine'),
                                        tgtN.getElementsByTagName('picLine'),
                                        [], (""))
                nflag = self.compareNodesets(rootN.getElementsByTagName('regLine'),
                                        tgtN.getElementsByTagName('regLine'),
                                        ["","num"], (""))
                nflag = self.compareNodesets(rootN.getElementsByTagName('fldproperties'),
                                        tgtN.getElementsByTagName('fldproperties'),
                                        ["","num"], (""),"",[(["",'type'],(""),"attribute")])
                nflag = self.compareNodesets(rootN.getElementsByTagName('footnote'),
                                        tgtN.getElementsByTagName('footnote'),
                                        [], (""),"",[([],(""),'qualifier')])
                nflag = self.compareNodesets(rootN.getElementsByTagName('field'),
                                        tgtN.getElementsByTagName('field'),
                                        ["num"], ("fldname","row","linenum"), "", [([],[],"attrib")])
                output.write(xt_src.toxml())
                
        except:
            pass
    

    def addXMLNodes(self, fout, nodeType='', nattrs={}, hdr=''):
        if nodeType == "":
            return
        if nodeType == "header":
            fout.write('<?xml version="1.0" encoding="Windows-1252" ?>\n')
            fout.write('<?xml-stylesheet type="text/xsl" href="' + "C:/Iatric/" + 'cdiff.xsl" ?>\n')
            return
        if nodeType == "root":
            fout.write("<Report>\n")
            if hdr == '':
                base = self.basepkg.split("/")
                if not len(base) > 1:
                    base = self.basepkg.split('\\')
                base = base[len(base) - 1]
                comp = self.newpkg.split("/")
                if not len(base) > 1:
                    comp = self.newpkg.split('\\')
                comp = comp[len(comp) - 1]
                hdr = base + ' to ' + comp
            fout.write('<Base> ' + base + '</Base><Compared>' + comp + '</Compared>\n')
            return
        if nodeType == "end":
            fout.write("</Report>\n")
            return
        if nodeType == "row":
            fout.write("<FileRow>\n")
            elements = ['DocumentName', 'FolderName', 'Status', 'Overwrite', 'Completed','Target']
            for ele in elements:
                if ele in nattrs:
                    fout.write("<" + ele + "><![CDATA[" + nattrs[ele] + "]]></" + ele + ">\n")
            fout.write("</FileRow>\n")
        
    # __main__()

    def run(self):
#	import sys
        import filecmp
        import os.path
        self.basepkg = self.getdir()
        if self.basepkg != '':
            print self.basepkg
            self.basedir = os.path.dirname(self.basepkg)
            self.newpkg = self.getdir(initialdir=self.basedir)
            if self.newpkg != '':
               if self.printdiff and not os.path.isdir(self.newpkg + '/diff ' + os.path.basename(self.basepkg)):
                   os.mkdir(self.newpkg + '/diff ' + os.path.basename(self.basepkg))
                   
               fb = open(self.newpkg + '/' + 'pkgdiff ' + os.path.basename(self.basepkg) + ' vs. ' + os.path.basename(self.newpkg) + '.xml', 'w')
               self.logfile = open('pkgreader.log', 'a+')
               self.logfile.write('\n\n  ------------------------------- \n')
               print self.logfile.tell()

               fcp = filecmp.dircmp(self.basepkg, self.newpkg, ignore=['diff*'])
               self.compDpms(differ=fcp, out=fb)

               self.addXMLNodes(nodeType="header", fout=fb)
               self.addXMLNodes(nodeType="root", fout=fb)

               att = {}
               elements = ['DocumentName', 'FolderName', 'Status', 'Overwrite', 'Completed','Target']
               for ele in elements:
                   att[ele] = ' '
                
               for d in fcp.subdirs:
                   if d.startswith('diff'):
                       pass
                   else:
                       att["FolderName"] = d
                       att['Status'] = "Modified"
                       items = fcp.subdirs[d]
                       for f in items.diff_files:
                           if os.path.isfile(self.newpkg + '/' + d + '/' + f):
                               dname = f.split('.')
                               att["DocumentName"] = ".".join(dname[:len(dname) - 1])
                               if dname[-1]=='xml':
                                   att["Target"] = "xml"
                               elif dname[-1]=='htm':
                                   att["Target"] = "htm" 
                               else:
                                   att["Target"] = "htm" 
                               self.printHtmlDiff(d, f)
                               self.addXMLNodes(fout=fb, nodeType='row', nattrs=att)
                           else:
                               att["DocumentName"] = ' '

                       att['Status'] = "Deleted"
                       for f in items.left_only:
                           if os.path.isfile(self.basepkg + '/' + d + '/' + f):
                               dname = f.split('.')
                               att["Target"] = dname[-1]

                               att["DocumentName"] = ".".join(dname[:len(dname) - 1])
                               self.addXMLNodes(fout=fb, nodeType='row', nattrs=att)
                           else:
                               att["DocumentName"] = ' '

                       att['Status'] = "New"
                       for f in items.right_only:
                           if os.path.isfile(self.newpkg + '/' + d + '/' + f):
                               dname = f.split('.')
                               att["Target"] = dname[-1]
                               att["DocumentName"] = ".".join(dname[:len(dname) - 1])
                               self.addXMLNodes(fout=fb, nodeType='row', nattrs=att)
                           else:
                               att["DocumentName"] = ' '

                       att['Status'] = "Deleted"
               for dd in fcp.left_only:
                   if os.path.isdir(self.basepkg + '/' + dd):
                       att["FolderName"] = dd
                       att["DocumentName"] = ' '
                       self.addXMLNodes(fout=fb, nodeType='row', nattrs=att)


               self.addXMLNodes(nodeType="end", fout=fb)
                    
               fb.close()
               self.logfile.close()
               print 'Done'
            else:
               self.writelog('ABORTED BY USER', 'print')
        else:
            self.writelog('ABORTED BY USER', 'print')

