import PackageReader

PackageReader.FNAME="./MDEV CQM2 v1.2.43b.pkg"

A=PackageReader.PkgReader()
M=PackageReader.Magic2Xml()
