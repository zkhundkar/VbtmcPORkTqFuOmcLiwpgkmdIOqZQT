#!ztools/IatTools

class MagicNodes:
    
    menu = {"name":"menu",
            "xslt":"../menus.xsl",

            "menu":([".urn"],["appl",".name",'responsible','linkable','active','unk','title']),

            "routine":(["",".rlink"],["title","proc","menu-proc","proc-args"]),
            "picLine":(["",".linenum"],"VALUE"),
            "segmentKeys":{"toplevel": ("menu"),
                           "menu":(["IM","*"],('routine,picLine')),
                           "routine":(["O","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "picLine":(["P","*"],None)},

            "print" : {'Menus':0, 'menu':1, 'routine':1, 'picLine':1},
            "container-tags":{},

            "keySize" : {"2":["routine","picLine"]} }

    ddef = {"name":"datadef",
            "xslt":"../../datadefs_v2.xsl",
            
            "segment":(['','dpm',"name"],["active","dpmLetters",'physBase','physRoot','parent','segType',
                                        'mapsTo','constant','localSubscripts','pc9','pc10','elemCount']),
            "dpmList":(['','name'],['dpm-active', "detail",'letters','dict']),
            "dpm-apps":([".app"],"VALUE"),
            "dpm-desc":([".num"],"doc"),
            "dpm-resp":(["resp"],"VALUE"),
            "seg-value":(None,'segment-value'),

            "field":([".rank"],"fldName"),
            "subscript":([".rank"],["fldname","physName","proc-args"]),
            "index":([".rank"],"VALUE"),
            "child":([".rank"],["title","menu-proc","proc-args"]),

            'fld-def': (["",".dpm",".element"],['Pointer','DataType','offset','physName','localName','length','jfy','.dataseg','rank']),
            "fld-attrib":([".type"],"VALUE"),
            "fld-attrib-map":([".type",".num"],"VALUE"),
            "segmentKeys":{"toplevel": ("dpmList"),
                           "dpmList":(["IF","*"],['dpm-apps', 'dpm-desc', 'dpm-resp']),
                           "dpm-apps":(["A","*"],None),
                           "dpm-desc":(["D","*"],None),
                           "dpm-resp":(["U","*"],None),

                           "segment":(["IE","*","*"],('field','subscript','index','child','seg-value')),
                           "seg-value":(["V"],None),
                           "fld-def":(["IEE","*","*"],('fld-attrib','fld-attrib-map')),
                           "fld-attrib":(["C","*"],None),
                           "fld-attrib-map":(["CL","*","*"],None),

                           "field":(["E","*"],None),
                           "subscript":(["S","*"],None),
                           "index":(["I","*"],None),
                           "child":(["C","*"],None),
                           "picLine":(["P","*"],None)},
        

            "print" : {"Datadefs":0, "dpmList":1, 'dpm-apps':2, 'dataSegments':1, 'segment':2, 'seg-value':3, 'field':3, 'subscript':3,
                       'index':3, 'child':3, 'elements':1, 'fld-def':2, 'fld-attrib':3, 'fld-attrib-map':4},
            "container-tags":{"segment":"dataSegments", "fld-def":"elements"},

            "keySize" : {"2":["dpm", "dpmList"],
                         "3":["segment","fld-def"],
                         "4":["segment/seg-value", "dpmList/dpm-apps", "dpmList/dpm-desc", "dpmList/dpm-resp"],
                         "5":["segment/field", "segment/subscript", 'segment/index', 'segment/child', 'fld-def/fld-attrib'],
                         "6":['fld-def/fld-attrib-map']} }

    report={"name":"report",
            "xslt":"../../reports_v2.xsl",
            "index":([".urn"],["name","dpm"]),
            "report":(None,[".active","name","dpm","procedure","type","refresh","data-seg","mult-pages","mult-page-no",
                          "window","graph-selects","fragment","rpt-sched","audit-trail","exit-show","exit-prompt",
                          "source-ship","cms-dictionary","repeat-cust"]),

            "doc-text":([".num"],"VALUE"),
            "field":(["",".num"],["field-ele-name","field-ele-dpm","row","marker","length","justify","fld-name"]),
            "fld-index":(["row","col"],["fld-length","fld-field"]),
            "fld-select":([".num"],["oper","value-1","value-2","sel-ele-name","sel-ele-dpm",".sel-scrn","prompt","default"]),
            "select":([".num"],["sel-oper","sel-value-1","sel-value-2","tsel-ele-name","tsel-ele-dpm",".scrn",
                                "sel-prompt","sel-default","sel-field"]),
            "sort-temp":([".num"],["sort-ele-name","sort-ele-dpm",".header",".trailer",".renumber","order"]),

            "footnote":(["",".num"],"VALUE"),
            "line":(["",".num"],[".region",".pg-break"]),

            "appl-doc":([".num"],"VALUE"),

            "tech-doc":([".num"],"VALUE"),
            "line-attrib":([".type"],"VALUE"),
            "attribute":([".type"],"VALUE"),
            "attrib-map":([".type",".num"],"VALUE"),
            "line-attrib-map":([".type",".num"],"VALUE"),
            "phi":(None,"VALUE"),
            "picLine":(["",".num"],"VALUE"),
            "section":([".id"],["sect-id","sect-rows-per-entry","sect-top-row","sect-visible-cnt","sect-table-name",
                             "sect-fields","sect-id-repeat"]),
            "segmentKeys":{"toplevel": ("report","picLine"),
                           "report":["IR","*"],
                           "field":(["F","*"],('attribute','attrib-map','appl-doc','tech-doc',"fld-select")),
                           "fld-index":(["FI","*","*"],None),
                           "fld-select":(["SE","*"],None),
                           "footnote":(["N","*"],None),
                           "index":(["I","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "line":(["L","*"],("line-attrib",'line-attrib-map')),
                           "phi":(["PHI"],None),
                           "picLine":(["P","*"],None),
                           "select":(["SE","*"],None),
                           "appl-doc":(["DA","*"],None),
                           "tech-doc":(["DT","*"],None),
                           "doc-text":(["DC","*"],None),
                           "sort-temp":(["T","*"],None),
                           "attribute":(["C","*"],("attrib-map")),
                           "attrib-map":(["CL","*"],None),
                           "line-attrib":(["C","*"],None),
                           "line-attrib-map":(["CL","*","*"],None)},

            "print" : {'Reports':0, 'report':1, 'field':2, 'attribute':3,  'attrib-map':4, 
                       'footnote':2, 'line':2, 'line-attrib':3, 'line-attrib-map':4, 'picLine':2, 'section':2},
            "container-tags":{},
            "keySize" : {"1":["phi"],
                         "2":["doc-text","field","footnote","index","picLine","select","sort-temp",
                              "line"],
                         "3":["fld-index"],
                         "4":["line/line-attrib","field/attribute","field/appl-doc","field/tech-doc",
                              "field/fld-select"],
                         "5":["line/line-attrib-map"],
                         "6":["field/attribute/attrib-map"]} }


    screen={"name":"screen",
            "xslt":"../../screens_v2.xsl",
            "screen":(None,[".active","name","dpm","procedure","type","refresh","data-seg","mult-pages","mult-page-no",
                          "window","graph-selects","fragment","rpt-sched","audit-trail","exit-show","exit-prompt",
                          "source-ship","cms-dictionary","repeat-cust"]),
            "chk-sum":(None,['orig-cs','alt-cs']),
            "page":([".num"],["page-title","page-ok-prompt","page-exit-logic"]),
            "field":([".num"],["field-ele-name","field-ele-dpm","field-section","row","column","physical",
                           "length","pre-edit","justify","required","help","phy-base","mult-access-type",
                           "default-value","data-def-seg","data-def-ele","display-override","int-to-ext",
                           "ext-to-int","id-lookup"]),
            "appl-doc":([".num"],"VALUE"),
            "tech-doc":([".num"],"VALUE"),
            "attribute":([".type"],"VALUE"),
            "attrib-map":([".type",".num"],"VALUE"),
            "picLine":([".num"],"VALUE"),
            "section":([".id"],["sect-control","sect-rows-per-entry","sect-top-row","sect-visible-cnt","sect-table-name",
                             "sect-fields","sect-repeat"]),
            "segmentKeys":{"toplevel": ("screen"),
                           "screen":["IS","*"],
                           "chk-sum":(["CS"], None),
                           "page":(["P","*"],("field","picLine","section")),
                           "field":(["F","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "picLine":(["P","*"],None),
                           "section":(["S","*"],None),
                           "appl-doc":(["DA","*"],None),
                           "tech-doc":(["DT","*"],None),
                           "attribute":(["C","*"],None),
                           "attrib-map":(["CL","*","*"],None)},
            "print" : {'Screens':0, 'screen':1, 'page':2, 'field':3,'attribute':4,'attrib-map':5, 'chk-sum':2,
                       'picLine':3, 'section':3, 'sect-fields':4},
            "container-tags":{},

            "keySize" : {"1":["chk-sum"],
                         "2":["page"],
                         "4":["page/field","page/picLine","page/section"],
                         "6":["page/field/attribute","page/field/appl-doc","page/field/tech-doc"],
                         "7":["page/field/attrib-map"]} }
                    
    nsets={"menu":menu, "screen":screen, "report":report, "ddef":ddef,
           "IM":menu, "IS":screen, "IR":report,"IF":ddef}
    def __init__(self):
        return


class Magic2Xml:
    global ET
    import xml.etree.ElementTree as ET
    import sys
    def __init__(self, **kwargs):
        self.logging=False
        self.nodemap=MagicNodes().nsets
        if "settings" in kwargs:
            self.settings = kwargs['settings']
        return

    def queuedStringToList(self,s):
        subX=[]
        try:
            while len(s)>0:
                l=ord(s[0])
                subX.append(s[1:l+1])
                s=s[l+1:]
        except:
            pass
        return subX

    def escapedhtmString(self, s):
        return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')


    def datasegToXml(self,tag,key,value,xmap,xt,ctags):
        global ET

        klist,vlist=xmap
        myparent=xt
        if tag in ctags.keys():
            ttag=ctags[tag]
            myparent=xt.find(ttag)
            if myparent is None:
                myparent=ET.Element(ttag)
                xt.append(myparent)
        else: pass
        e=ET.Element(tag)
        if klist is not None and type(key) is list:
            for k in klist:
                subs = key.pop(0)
                if k.startswith('.'): e.attrib[k[1:]]=subs
                elif k=="": pass
                else:

                    x=ET.Element(k)
                    x.text=subs
                    e.append(x)
        if type(vlist) is list:
            v2=self.queuedStringToList(value)
            #print klist, vlist, '\n',v2
            for v in vlist:
                if len(v2)>0:
                    subs = v2.pop(0)
                    if v.startswith('.'): e.attrib[v[1:]]=subs
                    else:
                        x=ET.Element(v)
                        x.text=subs
                        e.append(x)

        elif not vlist=="VALUE":
            x=ET.Element(vlist)
            x.text=value
            e.append(x)
        else: e.text=value
        myparent.append(e)
        return e

    def convertMagictoXml(self,f,P=None,PATH=""):
        global ET
        import os
        fs=""
        fn=None
        if P:
            k=self.formKey(f[0].split('=')[0].strip(' '))
            if P in ('screen','report'):
                name=k[1].split('.')
                dpm=[]
                ucase=True
                for i in range(len(name)):
                    if ucase and name[i]==name[i].upper() and ord(name[i][0])>60: dpm.append(name[i])
                    else:
                        ucase=False
                        
                        
                dpm=".".join(dpm)
                fn=PATH+'/'+dpm+"/"+k[1][len(dpm)+1:]+"_"+P[0].upper()+".xml"
            elif P == 'menu':
                fn=PATH+"/"+".".join(k[1].split('.')[1:])+'.xml'
            elif P == 'datadef' or P=='ddef':
                fn=PATH+'/'+k[1]+'/datadef.xml'
            self.xslt=self.nodemap[P]["xslt"]
            if 'XSLHOME' in self.settings:
                self.xslt=os.path.join(self.settings['XSLHOME'],os.path.basename(self.xslt))
            P=self.nodemap[P]["print"]
            fs=f

        else:
            fa=open(f,"r")
            fs=fa.readlines()
            fn=".".join(f.split(".")[:-1])+".xml"
            if ".S" in f :
                P=self.nodemap['screen']["print"]
            elif ".R." in f:
                P=self.nodemap['report']["print"]
        xt=self.toXml(fs,len(fs))
        if xt is not None:
            pass
        else:
            print "Could not convert %s" % fn
            return
        fa=open(fn,"w")
        fa.write('<?xml version=\"1.0\"?>\n')
        try:
            fa.write('<?xml-stylesheet type=\"text/xsl\" href=\"'+self.xslt+'\" ?>\n')
            self.printTree("",xt,ET,fa,P)
        except: 
            print "Error producing tree %s" % type(xt)
        fa.close()
        return
    

    def formKey(self,k,ev=False):
        if ev:
            k=eval(k)
        return self.parseKeys(k.strip(' '))
    def formValue(self,v,ev=False):
        if ev:
            v=eval(v)
        return v.rstrip(' ')

    def toXml(self,ll,limit=None):
        global ET
        import sys
        if limit: pass
        else: limit=len(ll)
#        classes={"IS":(screen,"screen"),"IR":(report,"report")}
        ln=topnode=ll.pop(0)
        n=ln.index('=')
        k=self.formKey(ln[:n].strip(' '))
        v=self.formValue(ln[n+2:])
        
        xt=None
#        print k, v
        if k[0] in self.nodemap.keys():
            segmap=self.nodemap[k[0]]
            topseg=segmap["segmentKeys"]["toplevel"]
            if type(topseg) is tuple or type(topseg) is list:
                topseg=topseg[0]
            
    #        print segmap["name"], topseg
            try:
                xt= ET.Element(segmap["container-tags"]["root"])
            except KeyError:
                xt= ET.Element(segmap["name"].title()+'s')
            nodepath=[xt]
            key_top=None
            if segmap[topseg]:
                key_top=k
            
            cnode=self.datasegToXml(topseg,key_top,v,segmap[topseg],xt,segmap["container-tags"])
            parentNodes={"root":(topseg,"",xt)}
            segs=segmap["segmentKeys"]
            keySize=segmap["keySize"]
            lncnt=0
            lastparent=(None,None,None)
            for ln in ll[:limit]:
                lncnt+=1
                n=ln.index('=')
                k=self.formKey(ln[:n].strip(' '))
                v=self.formValue(ln[n+2:])
                isChild=False
                if str(len(k)) in keySize :
                    keySet=keySize[str(len(k))]
                    match=False
                    keyseg=""
                    for keyS in keySet:
                        if match:
                           break
                        kmatch=True
                        key_PP=[]
                        dseg=keyS
                        if "/" in keyS:
                            for kxx in keyS.split('/'):
                                key_PP.extend(segs[kxx][0])
                                dseg=kxx

                        else: key_PP=segs[keyS][0]

                       # sys.stdout.write(keyS+" "+str(key_PP)+" "+str(k)+': ')
                        for i in range(len(key_PP)):
                            keyP=key_PP[i]
                            if i< len(k) :
                                if keyP=="*" : pass

                                elif k[i]==keyP: pass
                                else:
                                    kmatch=False

                            else: kmatch=False
                        if kmatch:
                            match=True
         #                   sys.stdout.write(" "+str(match))
                            n=0
                            if "/" in keyS:
                                dk=segs[dseg][0]
                                n=-1
                                if dk[0] == "*": n=0-len(dk)
                                else: n=1-len(dk)
                                #k=k[n:]
                            else: pass
                            pkeyS,pk,cnode=parentNodes["root"]
                            ii=0
                            subKeys=keyS.split('/')
                            dseg=subKeys[-1]
                            subKeys=subKeys[:-1]
                            try:
                                while ii < len(subKeys):
                                    dk=segs[subKeys[ii]][0]
                                    pkeyS,pk,pnode=parentNodes["/".join(subKeys[:ii+1])]
                                    if pk==k[:len(pk)]:
                                        cnode=pnode
                                    ii+=1
                                   # sys.stdout.write("\n\t"+pkeyS+" "+str(ii)+" "+str(k)+" ?= "+str(pk)+", "+str(cnode))
                            except KeyError:
                                sys.stdout.write("not in parents list ")

                           # sys.stdout.write("\n  "+str(k[n:])+" "+keyS+" "+str(k)+", "+pkeyS+str(pk)+" -> "+str(cnode)+'\n')
                            cx=self.datasegToXml(dseg,k[n:],v,segmap[dseg],cnode,segmap['container-tags'])
                            lastparent=(keyS,k)
                            parentNodes[keyS]=(dseg,k,cx)

                            break
                        else: pass
    #                        sys.stdout.write(" "+str(match)+'\n')
                else:
                    #sys.stdout.write("key not matched "+str(k)+" ("+repr(ln)+")")
                    pass
                    #basher()
            ll.insert(0,topnode)

        return xt

    def printTree(self,top,e,M,fout=sys.stdout, P=None):
        global ET
        if M: pass
        else: M=ET
        s=M.tostring(e)
        sout=""
        tab=""

        sout=sout+self.printSub(P,s,tab)

        fout.write(sout)
        return

    def printSub(self,P,s,tab):
        for item in P.keys():
            i1=i2=-1
            tag='<'+item+' />'
            tag1="<"+item+">"
            tag2="<"+item+" "
            tc="</"+item+">"
            if tag1 in s : tag=tag1
            elif tag2 in s : tag=tag2
            else: tc=""
            sout=""

            while tag in s:
                i1=s.index(tag)
#                sout=sout+s[:i1]+'\n'+tab+tag
                sout=sout+s[:i1]+'\n'+"".join([" " for ii in range(3*P[item])])+tag
                s=s[i1+len(tag):]
                pass
            s=sout+s
        return s

    def parseKeys(self,s):
        p1=s.split('\x1e')
        p2=[]
        for x in p1:
            self.parseKey2(x,p2)
        return p2

    def parseKey2(self,x,p2):
        i=0
        pc=''
        while len(x)>0:
            xx,x=(x[0],x[1:])
            pp=ord(xx)
            if pp<31:
                p2.append(pc)
                pc=x[:pp]
                x=x[pp:]
                if pp==0:
                    p2.append(pc)
                    pc=''
                
            else:
                pc=pc+xx
        if len(pc)>0: p2.append(pc)
        return

