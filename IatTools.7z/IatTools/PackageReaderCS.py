class PkgReaderCS:
    from shutil import copyfile
    from os import path, mkdir, remove
    import logging

    SECTION_DEL = chr(255)
    SEGMENT_DEL = chr(254)
    logfile = ''
    basedir = ''
    packageInfo = []
    dpmNames = []
    procedureNames = []
    definitions = []
    applicationInfo = []
    source = []

    def __init__(self, initargs=[]):
        if len(initargs)>0:
            self.top=initargs[0]
            self.applname = ""
        self.logger = self.top.logger
        self.run()

    def writelog(self, s,logger=False):
        if logger == 'print' or logger =='stdio':
            print s
        elif logger :
            logger(s+'\n')
        else: 
            self.logger.info(s.strip('\n')+'\n')
        return

    def getfile(self):
        from tkFileDialog import askopenfilename
        import _winreg
        from os import path
        FNAME=''
    #        global tmpname, alines, fmode, tname, _isCompressed
        
        self.basedir='C:/IATRIC Systems/Visual Smartboard/ftpsite'
        if True:
            zt=_winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,"Software"),"ztools")
            ztr=_winreg.OpenKey(zt,"packages")
            mode="cs"+_winreg.QueryValueEx(ztr,"LastArchiveType")[0]
            ztm=_winreg.OpenKey(ztr,mode,0,_winreg.KEY_ALL_ACCESS)
            last=_winreg.QueryValueEx(ztm,"LastDir")[0]
            lastfn=_winreg.QueryValueEx(ztm,"LastArchive")[0]
#            print mode, ztm, last, lastfn
            if len(last)>0:
                self.basedir=last
#            getfile(base,lastfn)

            FNAME = askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", "*.zip")])
            self.writelog('Importing package: '+ FNAME)
            if FNAME != '':
                try :
                    pp = path.dirname(FNAME)
                    newmode=mode[2:];
                    mode_ch=False
                    if "Iatriscan" in pp:
                        newmode="Iatriscan"
                        mode_ch = True
                    elif "Visual" in pp:
                        newmode="vsb"
                        mode_ch = True
                    if mode_ch:
                        _winreg.CloseKey(ztr)
                        ztr=_winreg.OpenKey(zt,"packages",0,_winreg.KEY_WRITE)
#                        print ztr
                        _winreg.SetValueEx(ztr,"LastArchiveType",0,_winreg.REG_SZ,newmode)
                        _winreg.CloseKey(ztm)
                        ztm = _winreg.OpenKey(ztr,"cs"+newmode,0,_winreg.KEY_WRITE)
#                     print "Saving LastDir:", path.dirname(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastDir",0,_winreg.REG_SZ,pp)
#                     print "Saving LastArchive:",path.basename(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastArchive",0,_winreg.REG_SZ,path.basename(FNAME))
                except:
                    self.writelog('Error writing keys')
            _winreg.CloseKey(ztm)
            _winreg.CloseKey(ztr)
            _winreg.CloseKey(zt)
        else:
            self.writelog('Error Reading file or reg keys',self.logger.error)
            pass

        return FNAME
    
    def convertQueuedString(self, s, slist):
        count = ord(s[0])

        slist.append(s[1:count+1])
        if len(s)>(count+1):
            self.convertQueuedString(s[count+1:],slist)
        
    def extractFiles(self, tza, aname, zpath):
        from os import path, mkdir
        from zipfile import ZipFile
        import logging
        rootpath = zpath+"/" + self.applname + "." + aname.split('-')[0]
        print( 'Extracting %s ... to %s',aname,rootpath)
        
        if path.isdir(rootpath): pass
        else: mkdir(rootpath)
        ta=file(zpath+'/unpackb.zip','wb')
        ta.write(tza.read(aname))
        ta.flush()
        ta.close()

        tzb=ZipFile(zpath+'/unpackb.zip','r')

        for name in tzb.infolist():
    #        print getattr(name,'filename'),getattr(name,'internal_attr'),getattr(name,'external_attr')
            if getattr(name,'internal_attr') == 1:
                iname = getattr(name,'filename')
                mname = '.'.join(iname.split('/'))+'.magic'
                ta=file(rootpath+'/'+mname,'wb')
                ta.write(tzb.read(iname))
                ta.flush()
                ta.close()

        tzb.close()  
    #    tfo.flush()
    #    tfo.close()
        

    def extractSource(self, tza, path):
        from zipfile import ZipFile
        from os import remove
        import logging
        
        tfo=file(path+'/unpack.zip','wb')
        done = False

        zipnames = filter(lambda x: True if 'NPRRAD/' in x and '.zip' in x else False, tza.namelist())
        for fname in zipnames :
            if 'NPRRAD/Z' in fname: pass
            else:
                self.applname = fname.split('/')[1].split("-")[0]
                logging.debug('Extracting %s ...',fname)
                try:
                    tfo.write(tza.read(fname))
                except:
                    logging.warning("Error extracting %s",fname)
            done = True
        tfo.flush()
        tfo.close()

        tzb = ZipFile(path+'/unpack.zip','r')
    #    tfo=file(path+'/unpackb.zip','wb')
        done = False

        for fname in tzb.namelist():
            if '.zip' in fname:
                self.extractFiles(tzb, fname, path)

        tzb.close()
        try:
            remove(path+'/unpackb.zip')
        except:
            pass
        try:
            remove(path+'/unpack.zip')
        except: pass
    #    tfo.flush()
    #    tfo.close()

    # __main__()
    def run(self):
        import time
        import sys
        from zipfile import ZipFile
        from os import path, mkdir

#        try:
        FNAME=self.getfile()
        if FNAME !='':
           fa = ZipFile(FNAME,'r')

           self.RPATH = FNAME[:len(FNAME)-4].strip()
           if path.isdir(self.RPATH): pass
           else: mkdir(self.RPATH)

    #       print fb
           self.extractSource(fa,self.RPATH)

           fa.close()
           self.writelog('Done')
#           self.logfile.close()
           self.top.tbox.insert(0,"CS: "+path.basename(FNAME)+" - Done")
           
        else:
           self.writelog( 'ABORTED BY USER','print')
#        except :
#            errinfo = sys.exc_info()
#            errno, errstr = errinfo[:2]
            
#        #    if errMsg.split('|')[0]=='ERROR': errMsg=errMsg[6:]
#        #    else: errMsg = str(errstr)+' (ansi835pre exception)'
#            print str(errno)+', '+str(errstr)
#            print str( errinfo )

