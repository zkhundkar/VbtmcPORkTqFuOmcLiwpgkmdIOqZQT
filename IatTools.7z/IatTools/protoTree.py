import os
import sys
import xml.dom.minidom as tree

class MagicNode():

    keynames = {"IE":("segment",".dpm",".name"),"IE/E":("field","rank"),
                "IE/S":("subscript","rank"),"IE/C":("child",".name"),
                "IE/DT":("tech-doc","num"),
                "IE/M":("more"),"IE/V":("index-seg"),
                "IE/I":("index",".name"),
                "IEE":("fld-def",".dpm",".name"),
                "IEE/D":("description"),
                "IEE/DA":("doc","number"),
                "IEE/C":("attrib",".type"),"IEE/CL":("attrib-index","*type",".rank"),

                "IR":('report',"urn"),
                "IR/DC":('cust-doc','doc-num'),
                'IR/L':('region','line-num'),'IR/L/C':("attrib","type"),
                'IR/P':("pic-line","line-num"),
                'IR/N':('footnote','num'),
                'IR/I':('run-index','index'),
                'IR/SE':('temp-selects','set'),
                'IR/SEG':["rpt-dataseg"],
                'IR/FI':('fld-index','line-num','fld-rank'),
                'IR/F/S':('sort','rank'),
                'IR/F/SE':('sort-field','rank'),
                'IR/F/S/SE':('sort-element','srank'),
                'IR/F':("field","num"),'IR/F/DA':('user-doc','doc-q'),'IR/F/C':("fld-attrib",'.type'),
                'IR/F/CL':("attrib-line","type","rank"),'IR/F/DT':('tech-doc','doc-q'),
                'IR/F/SE':('se','se-rank'),
                'IR/P/S':(5,6),
                'IR/AT':("cust-audit","stamp"),
                "IR/T":("rpt-cust-doc",".no"),
                'IR/U':("usage","stamp"),
                "IRI":("screen-index",".name",".proc",".oname"),
		        "IS":("screen",".name"),'IS/P':('page','page-num'),
                'IS/P/F':("field","field-id"),'IS/P/F/DA':('scrnfld-doc','dq'),
                'IS/P/F/C':("attrib","type"),'IS/P/F/CL':("attrib-idx","type","seq"),
                'IS/P/F/DT':('tech-doc','doc-q'),
                'IS/P/P':('picLine','p'),
                'IS/P/S':('section','section-num'),
                'IS/P/MF':('multi-func','fld-num'),
                'IS/P/B':('block','block-num'),'IS/P/B/F':('block-field','fld-num'),
                "ISI":("screen-index",".name",".proc",".oname")}
    
    offsets = {"IE":0,"IE/E":3,"IE/S":3,"IE/C":3,
                "IE/M":3,"IE/V":3,"IE/I":3,"IE/DT":3,
                "IEE":0,"IEE/D":3,"IEE/DA":3,"IEE/C":3,"IEE/CL":3,
                "IRI":0,
                "IR":0,"IR/P":2,"IR/F":2,"IR/FI":2,"IR/F/S":2,"IR/F/S/SE":4,
                'IR/F/DA':5,'IR/F/C':4,'IR/F/CL':4,'IR/F/DT':4,'IR/F/SE':4,
                'IR/L':2,'IR/L/C':4,
#                'IR/P':(3,4),
                'IR/N':2,'IR/T':2,'IR/I':2,'IR/SE':2,
                'IR/SEG':3,
                'IR/AT':2,'IR/U':2,
                'IR/DC':2,
                "ISI":0,
                "IS":0,'IS/P':2,
                'IS/P/F':4,'IS/P/F/DA':6,'IS/P/F/C':6,'IS/P/F/CL':6,'IS/P/F/DT':6,
                'IS/P/P':4,'IS/P/MF':4,'IS/P/B':4,'IS/P/B/F':6,
                'IS/P/S':4}
    keyvalues = {"IE":("active","dpmLetters","physBase","physRoot",
                       "parent","constant","extname","segType","mapsTo"),
                 "IE/E":"fldname",
                 "IE/DT":"doc-line",
                 "IE/I":"index",
                 "IE/V":"index-value",
                 "IE/S":("fldname","physName","sub-dpm","sub-urnx"),
                 "IE/M":("prefix","letters","oaf"),
                 "IE/C":"fldname",
                 "IEE/C":"attrib-val",
                 "IEE":('pointer','DataType','offset','physName','locName','length','jfy','dataseg','rank'),
                 "IEE/D":('description'),"IEE/DA":"docvalue",
                 "IEE/C":"attrib-val","IEE/CL":("length"),

		         "IRI":"active",'IR/T':'techdoc',
                 "IR":('active','name','dpm','oldproc','segname','title','header-type','char-per-in',
                       'cpl','lpi','lpp','seg-dpm','page-size','log-name','page-tr','rpt-head','rpt-tr',
                       'detail','page-head','acc-path','sort-mod','left-mgn','rw-version'),
                 "IR/F":('ele-name','ele-dpm','row','marker','length','jfy','label','ee-name','yn-attrib',
                         'yn-doc','tech-doc','edit','column'),
#                 'IR/F':(3,4),
                 'IR/F/DA':"appl-doc-text",'IR/F/C':"attrib-val",'IR/F/CL':('attrib-index','attr-length'),
                 'IR/F/DT':"tech-doc-text",
                 'IR/F/S':["sort-field"], 'IR/F/S/SE':("criteria","crt-label","crt-label2"),
                 'IR/F/SE':("sel-oper","sel-val1",'sel-val2','sel-ele-name','eel-ele-dpm','sel-screen',
                            'sel-prompt','sel-default','sel-cust.edit'),
                 "IR/FI":('start','width','end'),
                 "IR/I":('index-name','index-dpm','index-ee-name'),
                 "IR/AT":('user','code','copy'),"IR/T":("subscript","index","active"),
                 "IR/U":('user','date'),
                 "IR/DC":"text",
                 'IR/L':('rpt-reg','line-reg','line-pg-break'),
                 'IR/L/C':'line-attrib',
                 'IR/SE':("temp-sel-oper","temp-sel-val1",'temp-sel-val2','temp-sel-ele-name',
                          'temp-eel-ele-dpm','temp-sel-screen','temp-sel-prompt','temp-sel-default',
                          'temp-sel-cust.edit'),

                 'IR/P':"pic",
                 'IR/N':'note',
                 'IR/SEG':["det-seg"],

                 "ISI":"active",
                 "IS":('active','audit-name','dpm','name','screen-type','multi-page','dataseg','fragment'),
                 'IS/P':('title','file-prompt','height','width','other'),
                 'IS/P/F':("name",'unk','row','column','section','height'),
                 'IS/P/F/DA':"field-doc",'IS/P/F/C':"screen-attrib-val",
                 'IS/P/F/CL':'screen-fld-index','IS/P/F/DT':'screen-fld-tech-dco',
                 'IS/P/P':'screen-page-page',
                 'IS/P/B':"block-val",'IS/P/B/F':'block-fieldval',
                 'IS/P/MF':["mfunc"],
                 'IS/P/S':("control","unk1","unk2","unk3","unk4","fld-list","repeat") }
    
    hr = {"IE":("DT","E","C","S","I","M","V"),
          "IEE":("DA","D","CL","C"),
          "IS":('P'),"IS/P":('MF','B','F','P','S'),'IS/P/F':('DA','DT','CL','C'),"IS/P/B":("F"),
          "IR":("SEG","AT","DC","FI","SE","F/S","F","L","P","N",'T',"U","I"),"IR/F":('DA','DT','CL','SE','C'),
          "IR/F/S":("SE"),"IR/L":("C","CL") }

    '''    keymatch = {"IE":(1,3), "IE/E":(4,5),"IE/S":(4,5),"IE/M":(4,5),
                        "IE/I":(4,5),"IE/C":(4,5),"IE/V":(4,5),"IE/DT":(4,5),
                        "IEE":(1,3),"IEE/DA":(4,5),"IEE/D":(4,4),"IEE/C":(3,5),"IEE/CL":(3,6),
                        "IRI":(1,4),
                        "IR":(1,2),'IR/P':(3,4),'IR/SEG':3,'IR/L':(3,4),'IR/N':(3,4),
                        "IR/AT":(3,4),"IR/U":(3,4),"IR/FI":(3,5),
                        'IR/F':(3,4),'IR/F/DA':(5,6),'IR/F/C':(5,6),'IR/F/CL':(5,7),'IR/F/DT':(5,6),
                        "ISI":(1,4),
                        "IS":(1,2),'IS/P':(3,4),
                        'IS/P/F':(5,6),'IS/P/F/DA':(7,8),'IS/P/F/C':(7,8),'IS/P/F/CL':(7,9),'IS/P/F/DT':(7,8),
                        'IS/P/P':(5,7),
                        'IS/P/S':(5,6)}
    '''
    
    cptr = 0
    lastinsert=''
    
    def __init__(self, initargs=[]):
        
        self.keys=[]
        self.keystring=''
        self.parent=''
        self.nodevalue = ''
        self.children=[]
        self.insertdepth=0
        self.keytype=''
        self.xmlname=''
        self.xmlvalue=''
        self.xmlfamily=''
        self.closure=''

    def escapedhtmString(self, s):
        if len(s)>0:
            return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        else:
            return ""

    def isNode(self):
        if len(self.keys)>0:
            return True
        else:
            return False
        
    def appendChild(self,c):
        self.children.append(c)
        c.parent=self

    def setParent(self,p):
        self.parent(p)

    def getParent(self):
        return self.parent

    def getNodevalue(self):
        return self.nodevalue

    def setNodevalue(self, n):
        self.nodevalue = n

    def setstring(self):
        self.keystring = '\x1e'.join(self.keys)

    def setkeys(self, k):
        self.keys = k
        self.keystring = '\x1e'.join(k)

    def setNode(self,k,n,kt):
        self.nodevalue=n
        self.keys=k
        self.keytype=kt
        self.keystring='\x1e'.join(k)

    def hasChildren(self):
        return len(self.children)>0

    def getChildren(self):
        return self.children

    def keysMatch(self, t):
        match = True
        if type(t) == type(self):
            k=t.getKeys()
            if not len(k) == len(keys):
                match=False
            else:
                for kc in range(len(k)):
                    if not k[kc] == keys[kc]:
                        match=False
                        break
        else:
            match=False
        return match

    def addToRoot(self,n):
        if self.parent.keystring=='':
            if self.parent=='':
                self.appendChild(n)
                n.parent=self
            else:
                self.parent.appendChild(n)
        else:
            self.parent.insertNode(n)
        

    def insertNode(self, n):
        
        if True:
#            if not n.isNode():
#                print "object is not a node", type(n), n
#                return
            if True:
# This is the root node        
                c = 0
                found = False
                ch=''
                n.insertdepth+=1
#                print 'insert',n, 'in',self, c,len(self.children), len(n.children)
                while not found and c<len(self.children):
                    ch=self.children[c]
                    lk=len(ch.keys)
                    if '\x1e'.join(n.keys[:lk])==ch.keystring:
#                        print "found match", lk,ch
                        found=True
                    c+=1
                if found:
#                    print "inserting in",ch
                    ch.insertNode(n)
                    return
                else:
                    self.appendChild(n)
#                    print 'appended as child \n'
                    return
            else:
                print "InsertNode error", n.keys, self.keys
                
        else :
            print "Exception", type(n), n
        

    def printnode(self):
        print self.insertdepth, self.keytype, self.keys,'=',self.nodevalue

    def printTree(self):
        self.printnode()
#        print "children", self.hasChildren(), len(self.children)
#        self.insertdepth+=1
        for c in self.children:
            c.printTree()

    def nodevalueXml(self):
        try:
            valset=self.keyvalues[self.keytype]
#            print "nodevalue",valset, self.nodevalue
            if type(valset)==type("s"):
#                print '<'+valset+'>'+self.escapedhtmString(self.nodevalue)+'</'+valset+'>'
                print self.escapedhtmString(self.nodevalue)
            else:
                ele=''
#                print "nodevalue",valset, self.nodevalue
                for kc in range(len(valset)):
                    try:
                        if len(self.nodevalue)>0:
                            ele = ele + '<'+valset[kc]+'>'+self.escapedhtmString(self.nodevalue[kc])+'</'+valset[kc]+'>'
                        else:
                            ele = ele + '<'+valset[kc]+'/>'
#                        print ele
                    except:
                        pass
                print ele
        except:
            pass

    def printNodeStart(self):
        elem = 'Root'
        attrib=''
        try:
            kn=self.keynames[self.keytype]
            if type(kn)==type('s'):
                elem=kn
            else :
                elem = kn[0]
#            else:
                offset=self.offsets[self.keytype]
#                if self.keytype == 'IR/F/C':
#                    print kn, offset, self.keys
                for i in range(1,len(kn)):
                    aname = kn[i]
                    if aname[:1]=='.' or aname[:1]=="*":
    #                    print i, aname
                        aname=aname[1:]
                    attrib = attrib +' '+aname+'=\"'+self.keys[offset+i]+'\"'
            print '<'+elem, attrib,'depth=\"'+str(self.insertdepth)+'\">'
            self.closure='</'+elem+'>'
        except KeyError:
            print '<'+ self.keystring +'>'
            self.closure='</'+self.keystring + '>'
            
        except:
            errinfo = sys.exc_info()
            errno, errstr = errinfo[:2]
            
            
#            print elem, attrib, self.keytype, self.keys
            if len(elem)>0 and not elem=="Root":
                pass
            elif len(self.xmlname)>0:
                elem=self.xmlname
            else:
                elem="root"
            print '<'+elem+'>'
            print '<error>',errno, errstr,'</error>'
            self.closure='</'+elem+'>\n'
        

    def printNodeEnd(self):
        print self.closure

        
    def printTreeXmlold(self):
        self.printNodeStart()
        self.nodevalueXml()
        self.insertdepth+=1
        for c in self.children :
            c.printTreeXml()
#            self.nodevalueXml()
        self.printNodeEnd()

    def printTreeXml(self, depthLimit=-1):
        self.printNodeStart()
        self.nodevalueXml()
        self.insertdepth+=1
        if self.insertdepth <depthLimit or depthLimit==-1:
            for c in self.children:
                c.printTreeXml()
        self.printNodeEnd()

    def printNodeTreeXml(self):
        self.printNodeStart()
        self.nodevalueXml()
        self.insertdepth+=1
#        if self.insertdepth < depthLimit or depthLimit==-1 or True:
        cc = self.children
        if len(cc)>0:
            for c in cc:
                c.printTreeXml()
        cc=""
        self.printNodeEnd()

def convertQueuedString(s, slist):
    count = ord(s[0])

    slist.append(s[1:count+1])
    if len(s)>(count+1):
        convertQueuedString(s[count+1:],slist)
    

def splitkey(key,keychar):
    s=[]
    for i in range(0,len(key)):
#        if key[i]
        sk2 = key[i].split(keychar)
#        print 'key', keychar, key[i], sk2
        
        for sk in sk2:
            s.append(sk)
#    print 's',s
    return s
    
def findkeys(key,keynames,htree):
    keytype=key[0]
    subkey=[]
    if True:
        i=0
        subkey=splitkey(key,'\x01')
        subkey=splitkey(subkey,'\x02')
        subkey=splitkey(subkey,'\x03')
        subkey=splitkey(subkey,'\x09')
        keytype=key[0]
        found = False
        done = False
        keyset=keynames[keytype]
        keylength=len(keyset)
        while not found and not done:
            if len(subkey)==keylength:
                found=True
            else:
                lastkeylen = keylength
                progress = True
                while not done and len(subkey)>keylength and progress:
                    if True:
                        mt=htree[keytype]
                        if type(mt)==type('s'):
                            mt=[mt]
#                        print 'findkey', keytype, keylength,mt, key, subkey
                        thiskey=keytype
                        found=False
                        for sk in mt:
                            thiskey=keytype
                            rk=sk.split('/')
#                            if sk=='SEG':
#                                print 'testing', thiskey, keytype+'/'+sk, keylength, len(rk), subkey
                            for nk in range(0,len(rk)):
                                try:
                                    if len(subkey[keylength+nk])>len(rk[nk]):
                                        thiskey=thiskey+'/'+ subkey[keylength+nk][:len(rk[nk])]
                                    else:
                                        thiskey=thiskey+'/'+subkey[keylength+nk]
                                except IndexError:
                                    print "Index Error", thiskey, keylength, nk, rk[nk], sk, mt, subkey, key
#                            print 'testing', thiskey, keytype+'/'+sk, keylength, subkey
                            if thiskey==(keytype+'/'+sk):
                                if len(keynames[thiskey])+keylength==len(subkey):
                                    done=True
#                                print 'found match 1', thiskey, key, subkey, done
                                found=True
                                keytype=thiskey
                                keylength+=len(keynames[thiskey])
                                break
#                            else:
#                                print 'next subkey'
#                            if found:
#                                thiskey=keytype
#                                print 'found match 2', "Done=",done, keytype, subkey
#                                break
                        if not found:
                            print 'bad key', key, mt, keytype
                            done = True
                        else:
                            if keylength==lastkeylen:
                                progress=False
                                print "no progress", keytype, key, subkey
                                done=True
#                            else: print 'progress', keytype, subkey
                            
                             
                                        
                    else:
                        print 'excepted', thiskey, keytype, keylength, key, subkey
                        keytype='X+'+keytype
                        done=True
    else:
        print 'unknown error', keytype, thiskey, subkey, keylength
        keytype='X+'+keytype
    s=(keytype,subkey)
    return s
                
#                print testkey

def parseInput(l):
    global nclimit,root
    sections = []
    lines = l
#    print 'parse input', len(l)
#    keynames = MagicNode.keynames
#    offsets = MagicNode.offsets
#    keyvalues = MagicNode.keyvalues
    
#    hr = MagicNode.hr
#    keymatch = MagicNode.keymatch

#    xt=xml.dom.minidom.Document()
#    topnode=xt.createElement('datadefs')
#    xt.appendChild(topnode)

#    currentnode=topnode
#    parent=topnode
    keyarray=[]
    subkeys=[]
    ntypeList=[]
    nList=[]
#    nList.append(topnode)
    ln=''
    nct=0
    lastkey=""
    lastkeytype=""
    root=MagicNode()
    root.xmlname="dataSegments"
    nodelist = []
    dpmNames = {}
    for line in lines:
        if line.endswith('\r\n'):
            line = line.strip('\r\n')
        ln = ln+line
        while '\xfc' in ln:
            nodelist.append(ln.split('\xfc')[0])
#            print ln
#            print node
            ln=ln[ln.index('\xfc')+1:]
#            node=node[0]
    if len(ln)>0:
        if ln in nodelist: pass
        else: nodelist.append(ln)

    ddefs = {}
    reports = {}
    screens = {}
    rpt=''
    scrn=''
    indexes = []
    last = []
        
    for l in nodelist:
        mn=l.split('\xfb')[0].split('\x1e')
        if last == mn[:2]: 
            pass
        elif mn[0] in ['IE','IEE']:
            if not mn[1] in ddefs:
                ddefs[mn[1]]= []
            rpt=ddefs[mn[1]]
            
            rpt=ddefs[mn[1]]
        elif mn[0]=='IR':
            if not mn[1] in reports:
                reports[mn[1]]= []
            rpt=reports[mn[1]]
        elif mn[0]=='IS':
            if not mn[1] in screens:
                screens[mn[1]]= []
            rpt=screens[mn[1]]
        else:
            rpt=indexes
        rpt.append(l)
        last=mn[:2]
    x=MagicNode()
    x.setkeys(['reports'])
    makeTree(ddefs[ddefs.keys()[0]],x,nclimit)
    makeTree(ddefs[ddefs.keys()[1]],x,nclimit)
#    makeTree(screens[screens.keys()[0]],x,nclimit)
#    makeTree(screens[screens.keys()[1]],x,nclimit)
    x.printTreeXml()
    i=1
    return

def makeTree(lines,root,nclimit):            
    nct=0
    mnk=MagicNode.keynames
    mnh=MagicNode.hr
    for node in lines:
        if True:
            if True :
#                print node.split('\xfb')
                key,value=node.split('\xfb')
                key=key.split('\x1e')
                addNode = False
#                print key, value
                isChild=False
                isSibling=False
                if nct<nclimit:
                    nct+=1
                    keytype = ""
                    testkey=[]
                    addNode=True
                    keytype, testkey=findkeys(key, MagicNode.keynames, MagicNode.hr)
#                    print "found", keytype, testkey
                    i=0
    #                nodeprops = keynames[keytype]
                    if addNode:
                        new=MagicNode()
        #                new.setkeys(testkey)
                        valset='s'
                        try:
                            valset=MagicNode.keyvalues[keytype]
                        except:
                            pass
                        
                        if not type(valset)==type('s'):
                            ss=[]
                            convertQueuedString(value,ss)
                        else:
                            ss=value
                        new.setNode(testkey, ss, keytype)
#                        print new.printnode()
    #                new.printnode()
    #                print new
    #                print type(new), type(root), type(new)==type(root)
                        root.insertNode(new)

#                    print key, value, new.toxml()
                if nct==nclimit:
#                    fx=open('C:/Iatric/testcsout.xml',"w")
#                    fx.write(xt.toxml())
#                    fx.close()
                    pass
            else :
                print 'Error', node
                print keytype, keycheck, key, testkey
                pass               
#                print len(node.split('\x1b')),'\n'
#            root.printTreeXml()
#    root.printTreeXml()

def __test__():
    t=splitkey(['alpha'],'b')
    print 'split b', t
    t=splitkey(t,'l')
    print 'split l',t
    t=splitkey(t,'b')
    print 'split b',t
    t=splitkey(t,'a')
    print 'split a', t
            
nclimit=2000
nct=0

# fin=file("C:/Iatric Systems/Visual Smartboard CS/RW Repository/RAC frags dev 20110819/CS-56 DEV 20110825 ABS rac reports defs.dict","rb")
#fin=file("CS-56 DEV 20110825 ABS rac reports defs.dict","rb")
fin=file("C:/Users/Zeta.Khundkar/Downloads/VSB npr defs 20110717 (v1.2.89).ndef","rb")
# print fin
foo=file("C:/Users/Zeta.Khundkar/Downloads/testout.xml","w")
#print fin, nct
sys.stdout = foo
print '<?xml version="1.0"?>\n'
print '<!-- ?xml-stylesheet type="text/xsl" href="C:/Iatric/csdefs-scr.xsl" ? -->\n'

myroot=""
parseInput(fin.readlines())
sys.stdout = sys.__stdout__
foo.close()
fin.close()


        
