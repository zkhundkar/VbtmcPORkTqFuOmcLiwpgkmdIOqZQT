#!/usr/bin/env python

#include "c:/iatric/vsbtest/calendar.ico"
#import socket as socket_top
from time import time, ctime, sleep
from select import select
import sys, os

import threading

import socket

class RelayThread ( threading.Thread ):

    logger = None
    bufsize = 1024
    
    # Override Thread's __init__ method to accept the parameters needed:
    def __init__ ( self, logf='' ):
        self.RELAY = ''
#        if parent.logger:
#            self.logger=parent.logger
        self.relaysock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.logfile = None
                
        threading.Thread.__init__ ( self )

    def write ( self, *ss ):

        try:
            sss=" ".join(ss)
            self.logger.info(sss)
        except:
            pass
        return

    def getScriptSock(self,localport=8023):

        BUFSIZE = 8192
        ADDR = ('127.0.0.1', localport)

        print 'Starting up scriptable proxy ..',ADDR
        sock1 = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        sock1.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock1.bind(ADDR)
        sock1.listen(1) # one  time only
        # Have the server serve "forever":
        #       fa.write( 'waiting for local onnection: '+str(port)+'> \n')
        #  print  'waiting for local connection: ',port,'> '
        try:
            self.channel, self.details = sock1.accept() # channel is the socket for injecting scripts
            #           self.pool.queueTask(task,(channel,details))
            s= channel.recv(512)
            s=s.split(" ")
            r_ip=s[0]
            r_port=23
            try:
                r_port=s[1]
                r_port=int(r_port)
            except IndexError:
                print s
            self.setRelay((r_ip,r_port))
#            RelayThread ( self, channel, details, self.RELAY, logger ).start()
#            if self._is_shutdown.isSet():
#                self.__RUN_FOREVER = False
        except IOError:
            print "error"

        print 'Connected scripting port', details
        return 
    
    def setRelay(self, relay=None):
        if relay:
            self.RELAY=relay
        return
            
    def run ( self ):
        self.getScriptSock()
#        remote=relayAddr
#        remote_port = port
            
#        RELAY = (remote,remote_port)
        NODES = []

        scr_listener = self.channel
        sock1=socket(AF_INET,SOCK_STREAM)
        sock1.bind(("127.0.0.1",23))
        sock1.listen(1)
        listener,ldetails = sock1.accept()
        self.write( 'Listener connected: ', ldetails )

        talker = self.relaysock
        talker.connect(self.RELAY)
        self.write( 'Talker connected:', self.RELAY )
        connAlive = True

        errs = []
        PASS =0
        listenerState = True
        talkerState = True
        while connAlive:
            # read from inputs
            inps,outp,errs = select([talker,listener,scr_listener],[],[talker,listener,scr_listener],0.5)
            #print len(inps), len(outp), len(errs)
            hang = True
            label=""
            out=""
            SCRIPT_ACTIVE = False
            if len(errs)>0:
                print "Select error", errs
                break
            if len(inps)>0:
                for i in inps:
                    if i is talker:
                        out=listener
#                        label="Remote (MAGIC)<"
                    elif i is scr_listener:
                        out=talker
                        SCRIPT_ACTIVE = True
#                        label="script (inject)>"
                    else:
                        out=talker
#                        label="Local Client>"
                    lbuf = i.recv(self.bufsize)
                    if len(lbuf)>0:
                        if SCRIPT_ACTIVE:
                            if i is talker:
                                scr_listener.send(lbuf)
                            elif i is scr_listener and "DONE" in lbuf:
                                SCRIPT_ACTIVE = False
                                break
                        out.send(lbuf)
                        self.write(label+lbuf)
#                        print "\n"+label+" > ", len(lbuf), lbuf[:30]
                    else:
                        i.close()
                        connAlive=False

        try: listener.close()
        except: pass
        try: talker.close()
        except: pass

#---------------------------------------------------------------------------

class MTRWPool(threading.Thread):
    pool=None
    
    def __init__(self,localport=8023):
        threading.Thread.__init__(self)
        self.localport=localport
        self.localaddr='127.0.0.1'
        #self.pool = ThreadPool(10)
        self.__RUN_FOREVER = False
        self.daemon=False
        self._is_shutdown =  threading.Event ()

        self.RELAY = ('172.17.2.181',23) # default in the Elk Connection
        self.run()
        
    def setRelay(self, relay=None):
        if relay:
            self.RELAY=relay
        return
    def shutdown(self):
        self.__RUN_FOREVER = False
        return
        
    def run(self):


        BUFSIZE = 8192
        ADDR = (self.localaddr, self.localport)

        print 'Starting up scriptable proxy ..',ADDR
        sock1 = socket(AF_INET,SOCK_STREAM)
        sock1.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        sock1.bind(ADDR)
        sock1.listen(1) # one  time only
        # Have the server serve "forever":
        #       fa.write( 'waiting for local onnection: '+str(port)+'> \n')
        #  print  'waiting for local connection: ',port,'> '
        try:
            channel, details = sock1.accept() # channel is the socket for injecting scripts
            #           self.pool.queueTask(task,(channel,details))
            s= channel.recv(512)
            s=s.split(" ")
            r_ip=s[0]
            r_port=23
            try:
                r_port=s[1]
                r_port=int(r_port)
            except IndexError:
                print s
            self.setRelay((r_ip,r_port))
            RelayThread ( self, channel, details, self.RELAY, logger ).start()
#            if self._is_shutdown.isSet():
#                self.__RUN_FOREVER = False
        except IOError:
            print "error"

        print 'Closing original listening socket', sock1
        sock1.close()


def main():
    logfile = None
    daemon  = False
    max_log_size = 20
    port = 23
    allowed = []
    run_event = threading.Event ()
    local_hostname = socket.gethostname ()
    remote_ip=None
    RUN_FOREVER=False
    print "strting MTRWPool.."
    sleep(5)
    MTRWPool()


if __name__ == '__main__':
    ''' invoke this like pythonw MTRWRelay.py <local-port|8023>'''
    print 'ipportrelay'
    
    main ()


