class RWPkgReaderCS:
    from shutil import copyfile
    from os import path, mkdir, remove

    SECTION_DEL = chr(255)
    SEGMENT_DEL = chr(254)
    logfile = ''
    basedir = ''
    packageInfo = []
    dpmNames = []
    procedureNames = []
    definitions = []
    applicationInfo = []
    source = []

    def __init__(self, initargs=[]):
        if len(initargs)>0:
            self.top=initargs[0]
        self.run()
        

    def writelog(self, s,logger=False):
#        global logfile

        if logger: pass
        elif self.logfile: logger = self.logfile
        else: pass
        
        if logger == 'print' or logger =='stdio':
            print s
        elif logger :
            logger.write(s+'\n')
        else: pass

    def getfile(self):
        from tkFileDialog import askopenfilename
        import _winreg
        from os import path
        FNAME=''
    #        global tmpname, alines, fmode, tname, _isCompressed
        
        self.basedir='C:/IATRIC Systems/Visual Smartboard/ftpsite'
        if True:
            zt=_winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,"Software"),"ztools")
            ztr=_winreg.OpenKey(zt,"packages")
            mode="cs"+_winreg.QueryValueEx(ztr,"LastArchiveType")[0]
            ztm=_winreg.OpenKey(ztr,mode,0,_winreg.KEY_ALL_ACCESS)
            last=_winreg.QueryValueEx(ztm,"LastDir")[0]
            lastfn=_winreg.QueryValueEx(ztm,"LastArchive")[0]
#            print mode, ztm, last, lastfn
            if len(last)>0:
                self.basedir=last
#            getfile(base,lastfn)

            FNAME = askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", "*.zip")])
            self.writelog('Importing report package: '+ FNAME)
            if FNAME != '':
                try :
                    pp = path.dirname(FNAME)
                    newmode=mode[2:];
                    mode_ch=False
                    if "Iatriscan" in pp:
                        newmode="Iatriscan"
                        mode_ch = True
                    elif "Visual" in pp:
                        newmode="vsb"
                        mode_ch = True
                    if mode_ch:
                        _winreg.CloseKey(ztr)
                        ztr=_winreg.OpenKey(zt,"reports",0,_winreg.KEY_WRITE)
#                        print ztr
                        _winreg.SetValueEx(ztr,"LastArchiveType",0,_winreg.REG_SZ,newmode)
                        _winreg.CloseKey(ztm)
                        ztm = _winreg.OpenKey(ztr,"cs"+newmode,0,_winreg.KEY_WRITE)
#                     print "Saving LastDir:", path.dirname(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastDir",0,_winreg.REG_SZ,pp)
#                     print "Saving LastArchive:",path.basename(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastArchive",0,_winreg.REG_SZ,path.basename(FNAME))
                except:
                    self.writelog('Error writing keys')
            _winreg.CloseKey(ztm)
            _winreg.CloseKey(ztr)
            _winreg.CloseKey(zt)
        else:
            print 'Error Reading file or reg keys'
            pass

        return FNAME
	
    def convertQueuedString(self, s, slist):
        count = ord(s[0])

        slist.append(s[1:count+1])
        if len(s)>(count+1):
            self.convertQueuedString(s[count+1:],slist)
        
    def extractFiles(self, tza, aname, fout, zpath):
        from os import path, mkdir
        from zipfile import ZipFile
        rootpath = zpath+"/"+aname.split('-')[0]
        print 'Extracting ',aname,'... to ',rootpath
        
        if path.isdir(rootpath): pass
        else: mkdir(rootpath)
        ta=file(zpath+'/unpackb.zip','wb')
        ta.write(tza.read(aname))
        ta.flush()
        ta.close()

        tzb=ZipFile(zpath+'/unpackb.zip','r')

        for name in tzb.infolist():
    #        print getattr(name,'filename'),getattr(name,'internal_attr'),getattr(name,'external_attr')
            if getattr(name,'internal_attr') == 1:
                iname = getattr(name,'filename')
                mname = '.'.join(iname.split('/'))+'.magic'
                ta=file(rootpath+'/'+mname,'wb')
                ta.write(tzb.read(iname))
                ta.flush()
                ta.close()

        tzb.close()  
    #    tfo.flush()
    #    tfo.close()
        

    def extractSource(self, tza, fout, apath):
        from zipfile import ZipFile
        from os import remove
        from os import path, mkdir

        
#        tfo=file(apath+'/unpack.zip','wb')
        done = False

        print apath, type(apath)
        zipnames = tza.namelist()
        for fname in zipnames :
            if 'NPRRAD/' in fname and '.zip' in fname and not done:
                print 'Extracting ',fname,'...'
                tfo.write(tza.read(fname))
                done = True
            elif fname.endswith('/') or '!D' in fname:
                pass
            elif 'NPRRAD/' in fname :
                f1=fname.split('/')
                f1.pop(0)
                fdir='.'.join(f1[:2])
                f1.pop(0)
                f1.pop(0)
#                print 'Extracting ',fname,'...'
                rootpath = apath+"/"+fdir
                if path.isdir(rootpath): pass
                else: mkdir(rootpath)
                mname=".".join(f1)+'.magic'
# 2.6 only                tza.extract(fname,rootpath+".".join(f1)+'.magic')
                ta=file(rootpath+'/'+mname,'wb')
                ta.write(tza.read(fname))
                ta.flush()
                ta.close()
                
                print 'Extracting ',fname,' to ',rootpath,">",".".join(f1)+'.magic'
                
                
#        tfo.flush()
#        tfo.close()

#        tzb = ZipFile(path+'/unpack.zip','r')
    #    tfo=file(path+'/unpackb.zip','wb')
#        done = False
#        print tzb.namelist() 
#        for fname in tzb.namelist():
#            if '.zip' in fname:
#                self.extractFiles(tzb, fname, fout, path)

#        tzb.close()
#        remove(path+'/unpackb.zip')
   #     remove(apath+'/unpack.zip')
    #    tfo.flush()
    #    tfo.close()

    # __main__()
    def run(self):
        import time
        import sys
        from zipfile import ZipFile
        from os import path, mkdir
#        try:
        FNAME=self.getfile()
        if FNAME !='':
           fa = ZipFile(FNAME,'r')
           fb = file(path.dirname(FNAME)+'/'+'out.pkg.txt','wb')
           self.logfile = file('pkgreader.log','a+')

           self.logfile.write('\n\n  ------------------------------- \n')
           print self.logfile.tell()

           self.RPATH = FNAME[:len(FNAME)-4].strip()
           if path.isdir(self.RPATH): pass
           else: mkdir(self.RPATH)

    #       print fb
           self.extractSource(fa,fb,self.RPATH)

           fb.close()
           fa.close()
           self.logfile.close()
           print 'Done'
        else:
           self.writelog( 'ABORTED BY USER','print')
#        except :
#            errinfo = sys.exc_info()
#            errno, errstr = errinfo[:2]
            
#        #    if errMsg.split('|')[0]=='ERROR': errMsg=errMsg[6:]
#        #    else: errMsg = str(errstr)+' (ansi835pre exception)'
#            print str(errno)+', '+str(errstr)
#            print str( errinfo )

