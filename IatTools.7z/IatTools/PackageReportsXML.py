#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#   
#   @@RPT
#   LINE 1 Report definition and sorts?
#   History section
#       two lines each
#   end of section marker?  
#   Fields section
#       F{field#}
#       {fieldname,??,??,rptname,length,L}
#       F{field#,"C",ATTR}
#       attrValue
#   Picture section
#       FI{line#,startCol#}
#       {width,field#}
#   Report line attributes
#       L{line#}
#       {linetype,??,..}
#   Footnotes section
#       N{noteline#}
#       footnote
#   Picture layout section
#       P{line#}
#       picture of line
#   Select section
#       T{line#}
#       {subscript,??,"NONE","N",??,??,??,"ASC"}
#   Updates section
#       U{timeinsecs}
#       {user,directory}
#
from PackageReports import PkgRWReader

class PkgRW2XML(PkgRWReader):
#    import sys
#    from shutil import copyfile
#    from os import path
#    from zipfile import *
        
    def initConstants(self):
        self.PROC_INFO =['DPM','Name','Responsible','Access','Active',
                         'Arguments','Menu Logic','translate-as','switch-appl',
                         'interruptable','undef','source-ship','unknown']
        self.PROC_INFO_55 =['DPM','Name','Responsible','Active','Access',
                    'Arguments','Menu Logic','unknown']

        self.SCRN_INFO = ['active','Name','DPM','Procedure Name','Screen Type','scrn-refresh','scrn-dataseg',
                          "scrn-mult-pages","scrn-mult-page-no","scrn-window","scrn-graph-selects","scrn-fragment",
                          "scrn-rpt-sched","scrn-audit-trail","scrn-exit-show","scrn-exit-prompt","scrn-source-ship",
                          'unknown']
        self.SCRN_INFO_55 = ['Y','Name','DPM','Procedure Name','Screen Type','unknown']

        self.RPT_INFO_55 = ['Active','rptname','segDPM','detailSeg','title','hdrType','fontsize','lineWidth',
                         'topMargin','pageHeight','unk']
        self.RPT_INFO = ['Active','rptname','segDPM','detailSeg','title','hdrType','fontsize','lineWidth',
                         'lines-per-inch','pageHeight','oseg-dpm','pageSize','logical-name','hasPgTrailer',
                         'hasrptHdr','hasrptTrailer','hasDetail','hasPgHdr','acc-path','sort-modify','left-margin',
                         'rw.version','graph','report.convert.flag','report.translate.flag','report.pay.secure.fail','report.source.ship','unk']
        self.HDR_ELEMS = ['Hospital','MIS','Directory','User','Date','Segment','Description']


        self.procKeyMap = {'RN':'rev','R':'rev-2','S':'parse-section'}
        self.procNumKeys = ['RN','R','S']
        self.procKeyNames = {'RN':(('rev-seq'),('rev-note')), 'R':(('rev2-seq'),('rev2-note')),
                             'S':(('par-sec'),('par-inc-child','par-segtype','par-seg-slash','par-last-line'))}


        self.scrnKeyMap = {'CS':'cs-seg','P':'line'}
        self.scrnNumKeys = []
        self.scrnKeyNames = {'CS':(('key'),('cs-val')) }

        self.reportKeyMap = {'F':'field', 'P':'picLine', 'AT':'audit', 'N':'footnote', 'FI':'fieldIndex','CI':'compile',
                             'L':'line-attrib','U':'usage-log','T':'sort-temp','I':'index', 'DC':'rpt-doc',
                             'F\x02\SISE':'select-key'}
        self.reportNumKeys = ['F','FI','P','SE','AT','U','DC','N','CI','T']
        self.reportParentSeg = { 'F':('\x02S1','\x02S1\x02SE') }
        self.reportKeyNames = {'P':(('pic-seq'),('pic-line')),
                               'N':(('f-seq'),('note')),
                               'F':(('rank'),('fldname','fld-eledpm','fld-row','fld-marker','fld-length','jfy','field-name')),
                               'T':(('sort-seq'),('sort-ele','sort-ele-dpm','sort-hdr','sort-trlr','sort-renum',
                                                  'sort-label','sort-order','sort-view')),
                               'CI':('',('comp-file','comp-rep')),
                               'AT':(('upd-secs'),('user','activity','copy')),
                               'FI':(('row','col'),('length','field')),
                               'U':(('run-secs'),('r-user','r-dir')),
                               'DC':(('doc-seq-no'),('doc-text')),
                               'SE':(('select-key'),('sel-oper','sel-val-1','sel-value-2','sel-ele-name','sel-ele-dpm'))}

        self.attrMap = {'DA':'appl-doc', 'DT':'tech-doc', 'C':'attrs'}    

    def escapedhtmString(self, s):
        return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    def fileMacros(self,fout,text):
    #global self.macros, self.RPATH, fout

    #    fout = ''

        fout.write('<macros>\n')
        for macro in self.macros:
    #        fout = file(self.RPATH+'/'+macro[0].strip('\r\n')+'.magic','wb')
            macrotext = macro[1][1::2]

            mname=macro[0][0].strip('\r\n').split('.M.')
            fout.write('<macro><rptname>')
            fout.write(mname[0]+'</rptname>')
            fout.write('<name>'+mname[1]+'</name>\n')
            if text:
                for line in macrotext:
                    htmlline = line.replace('&','&amp;')
                    htmlline = htmlline.replace('<','&lt;')
                    htmlline = htmlline.replace('>','&gt;')
                    fout.write('<line>'+htmlline+'</line>\n')
            fout.write('</macro>\n')
    #        fout.close()
        fout.write('</macros>\n')

    def fileRptSegment(self, fout,segment,keywords, sectionIdName):
#        global self.PROC_INFO, self.SCRN_INFO, self.reportKeyMap

        print 'Filing segment ..', sectionIdName, len( segment )
        
        knownKeys = []
        for kwords in keywords:
            for kword in kwords:
                knownKeys.append(kword)

        for section in segment:
            sectiontext = []

            slist = []


            fout.write('<sections name=\"'+sectionIdName+'\">\n')
            sectionName = section[0]
            if len(section[1])>0:
                body = section[1]

                mainNode = body.pop(0)
                if mainNode.endswith('\r\n'):
                    mainNode.strip('\r\n')
                elif mainNode=='\r' or mainNode=='\n':
                    mainNode = mainNode+body.pop(0).strip('\r\n')
                elif mainNode.endswith('\r') or mainNode.endswith('\n'):
                    mainNode = mainNode+body.pop(0).strip('\r\n')
                    mainNode = mainNode.strip('\r\n')
                self.convertQueuedString(mainNode, slist)
                queline = slist
#                print sectionIdName, queline
    #            sectiontext.append('{'+sectionIdName+'|'+sectionName+'}|{'+'|'.join(queline)+'}')
                if sectionIdName in ('procInfo','screens','reports'):
                    LABELS = ['unknown']
                    if sectionIdName == 'procInfo':
                        LABELS = self.PROC_INFO
                    elif sectionIdName == 'screens':
                        LABELS = self.SCRN_INFO
                    elif sectionIdName == 'reports':
                        LABELS = self.RPT_INFO
                    else:
                        pass 
                    i=0
                    irange = len(LABELS)
                    fout.write('<sectionInfo>')
                    for infoEle in queline:
                        fout.write('<secInfoItem name=\"'+LABELS[i]+'\">'+infoEle+'</secInfoItem>\n')
                        if i+1 < irange: i += 1
                    fout.write('</sectionInfo>\n')
                    

                index = 0

                test = ''.join(body)
                test = test.replace('\r\n',chr(254))

                body = test.split(chr(254))

                flag =''
                flag0 = ''
                flag1 = ''
                while len(body)>0:
                    topnode = body.pop(0)
                    if len(topnode)>0:
                        slist = []

                        
                        flag0 = topnode[0]
                        flag1 = topnode[0:2]
                        if flag1 in knownKeys:
                            flag = flag1
                        elif flag0 in knownKeys:
                            flag = flag0
                        else:
                            flag = topnode

                        flagout = flag
                        if len(topnode)>len(flag):
                            self.convertQueuedStringEx(topnode[len(flag):],slist)
                            if flag=='F' and len(slist)>1:
                                if slist[1]=='C':
                                    flag = 'FC'
                                    

                        key = flagout+'|'+'|'.join(slist)
                        topnode = body.pop(0)
                        
                        if flag not in keywords[0]:
                            sectiontext.append('{'+key+'}|{'+topnode +'}')
                        else:
                            slist=[]
                            queline = ''
                            self.convertQueuedString(topnode, slist)
                            sectiontext.append('{'+key+'}|{'+'|'.join(slist)+'}')

    #        print str(len(sectiontext)), 'lines processed'

            if sectionIdName in ('reports','procInfo','screens'):
                group = ''
                grplabel = ''
                rank = 0
                if sectionIdName == 'procInfo':
                    keyMap=self.procKeyMap
                    keyNames=self.procKeyNames
                    numKeys=self.procNumKeys
                    printflag=True
                elif sectionIdName == 'screens':
                    keyMap=self.scrnKeyMap
                    keyNames=self.scrnKeyNames
                    numKeys=self.scrnNumKeys
                else :
                    keyMap=self.reportKeyMap
                    keyNames=self.reportKeyNames
                    numKeys=self.reportNumKeys
                    
                    
                for line in sectiontext:
                    key, value = line.split('}|{')
                    keynodes = key.strip('}').strip('{').split('|')

                    if keynodes[0] == group:
                        pass
                    elif keynodes[0] in keyMap.keys():
                        if not grplabel == '':
                            if grplabel == 'field':
                                fout.write('</'+grplabel+'>')
                            fout.write('</'+grplabel+'s>\n')
                        group=keynodes[0]
                        grplabel = keyMap[group]
                        fout.write('<'+grplabel+'s>\n')
                    else:
                        grplabel == 'line'
                        group = keynodes[0]
                    if group == 'F':
                        fldeletags=keyNames[group][1]
                        if keynodes[1] == rank:
#                            if keynodes[1] == '70' :
#                                print keynodes, value+'\r',value[len(value)-1],self.escapedhtmString(value[:len(value)-1])
                            if keynodes[2] == 'C':
                                fout.write('<attribute type=\"'+keynodes[3]+'\">'+self.escapedhtmString(value[:len(value)-1])+'</attribute>\n')
                            elif keynodes[2] == 'SE':
                                fout.write('<sortElement seq=\"'+keynodes[3]+'\">'+value.strip('}')+'</sortElement>\n')
                            else:
                                fout.write('<line>'+self.escapedhtmString(line)+'</line>\n')
                                
                        else:
                            if rank == 0: pass
                            else : fout.write('</'+grplabel+'>\n')
                            rank = keynodes[1]
                            fout.write('<'+grplabel +' rank=\"'+rank+'\">')
                            fldelements = line[:len(line)-1].split('}|{')[1].split('|')
                            flx=0
                            for fle in fldelements:
                                tag=fldeletags[flx]
                                fout.write('<'+tag+'>'+fle+'</'+tag+'>')
                                flx+=1
#                    elif group == 'L':
#                        if len(keynodes) > 2 and keynodes[2]=='C':
#                            valnodes = value.strip('}').strip('{').split('|')
#                            fout.write('<'+grplabel+' linenum=\"'+keynodes[1]+'\" attr-class=\"'+keynodes[3]+'\">'+self.escapedhtmString(value.strip('{').strip('}'))+'</'+grplabel+'>\n')
                    elif group in numKeys:
                        grplabel = keyMap[group] 
                        xline='<'+grplabel
                        mykeys, myvalues = keyNames[group]
                        if type(mykeys)==type('a'):
                            mykeys= [mykeys]
                        if type(myvalues)==type('a'):
                            myvalues= [myvalues]
                        valnodes = value.strip('}').strip('{').split('|')
#                        print self.reportKeyNames
#                        print 'Group:',group,' Keys:',mykeys, keynodes, '\nValues:',myvalues, valnodes
                        n=0
                        if len(mykeys)>0:
                            for k in mykeys:
                                if len(k)>0:
                                    n+=1
                                    xline = xline+ ' '+k+'=\"'+keynodes[n]+'\"'
                            xline = xline+' >'
                            n=0
                            valnodes = value.strip('}').strip('{').split('|')
                            for v in myvalues:
#                                print n, v, valnodes[n]
                                xline = xline + '<'+v+'>'+valnodes[n]+'</'+v+'>'
                                n+=1
                                if n<len(valnodes):
                                    pass
                                else: break
                        
                        fout.write(xline+'</'+grplabel+'>\n')
                    else:
                        fout.write('<'+grplabel+'><key>'+key.strip('{')+'</key>\n')
                        fout.write('<values>'+self.escapedhtmString(value.strip('{').strip('}'))+'</values></'+grplabel+'>\n')
                if not grplabel == '':
                    fout.write('</'+grplabel+'s>\n')
                    
                        
            else:
                for line in sectiontext:
                    fout.write('<line>'+line.replace(chr(30),'|')+'</line>\n')
            fout.write('</sections>')

    
    def run(self):
    #        global FNAME, self.RPATH, self.reportHead, self.rptlist, self.procs, self.reports, self.screens, versions, fout
    #        global self.HDR_ELEMS
        from os import path, mkdir
        
        FNAME=self.getfile()
        if FNAME !='':
           fa = file(FNAME,'rb')

           self.parseInput(fa)
           fa.close()

    #           self.RPATH = FNAME[:len(FNAME)-3].strip()
    #           if path.isdir(self.RPATH): pass
    #           else: mkdir(self.RPATH)

    #       fout = file(self.RPATH+'/'+'self.reports-rw.xml','wb')
           xfile = FNAME.split('.')
           xfile[len(xfile)-1]='xml'
           fout = file(".".join(xfile),'wb')
           fout.write('<?xml version="1.0"?>\n')
    #           fout.write('<?xml-stylesheet type="text/xsl" href="./rptw-full.xsl" ?>\n')
           fout.write('<?xml-stylesheet type="text/xsl" href="c:/iatric/rptw-full.xsl" ?>\n')
           fout.write('\n<rwpackage>\n')
           
           
           rptHeader=self.reportHead.rsplit('|')
           fout.write( '<header><hdrElement name=\"mt\">'+rptHeader.pop(0).strip('\r\n')+'</hdrElement>\n')
           i = 0
           fout.write('<hdrElement name=\"Filename\">'+path.basename(FNAME)+'</hdrElement>\n')

           irange = len(self.HDR_ELEMS)
           for headerElement in rptHeader:
               fout.write('<hdrElement name=\"'+self.HDR_ELEMS[i]+'\">'+headerElement+'</hdrElement>\n')
               if i+1 < irange : i += 1
           fout.write('</header>\n' )
           fout.write('<procedures>')      
           for item in self.rptlist:
               fout.write('<procedure>'+str(item)+'</procedure>\n')
           fout.write('</procedures>\n\n')

           self.fileRptSegment(fout,self.procs, [['RN','R','S'],[]], 'procInfo')
           self.fileRptSegment(fout,self.reports, [['AT','AL','FI','F','I','T','U','CI','L'],['N','P','FC','DC']],'reports')
           self.fileRptSegment(fout,self.screens, [['CS','P']],'screens')


           self.fileMacros(fout,False)
           fout.write('</rwpackage>\n')
#           self.writelog("Created "+fout.name)
           fout.close()
           print 'done'
           
        else:
           print 'ABORTED BY USER'

    def test():
        tests = []
        tests.append( chr(1)+'1'+chr(30)+'SE'+chr(1)+'1' )
        tests.append( chr(1)+'1'+chr(30)+'C'+chr(30)+'DAT' )
        mystr = []
        for test in tests:
            mystr = []
            convertQueuedStringEx(test,mystr)
            print mystr
    #try:
    #    test()
    #    main()

    #except :
    #    errno, errstr = sys.exc_info()
        
    #    print str(errno), errstr

