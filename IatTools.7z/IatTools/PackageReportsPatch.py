#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#   
#   @@RPT
#   LINE 1 Report definition and sorts?
#   History section
#       two lines each
#   end of section marker?  
#   Fields section
#       F{field#}
#       {fieldname,??,??,rptname,length,L}
#       F{field#,"C",ATTR}
#       attrValue
#   Picture section
#       FI{line#,startCol#}
#       {width,field#}
#   Report line attributes
#       L{line#}
#       {linetype,??,..}
#   Footnotes section
#       N{noteline#}
#       footnote
#   Picture layout section
#       P{line#}
#       picture of line
#   Select section
#       T{line#}
#       {subscript,??,"NONE","N",??,??,??,"ASC"}
#   Updates section
#       U{timeinsecs}
#       {user,directory}
#   
import sys
from shutil import copyfile
from os import *
from os.path import *
from zipfile import *
from tkFileDialog import *
    
FNAME = ''
RPATH = ''
macros = ''
screens = ''
reports = ''
procs = ''
reportHead = ''
rptlist = ''
basedir='C:/IATRIC Systems/Visual Smartboard/ftpsite'


def getfile(startdir=basedir,dlist=False):
    global basedir

    if dlist:
        name = askdirectory(initialdir=startdir)
    else:
        name = askopenfilename(initialdir=startdir, filetypes=[("", "*.rw")])

    return name

def convertQueuedString(s, slist):
    count = ord(s[0])

    slist.append(s[1:count+1])
    if len(s)>(count+1):
        convertQueuedString(s[count+1:],slist)

def convertQueuedStringEx(s, slist):
    count = ord(s[0])
    notFound = True
#    print 'Top', s, slist, count    
    if count == 30:
        c = 1
        count = 0
        while len(s)>c and notFound:
            if ord(s[c])<32: notFound = False
            else:
                count += 1
                c += 1
#        print s[1:], slist, count, c, notFound
        if notFound: count = ord(s[0])
            
    slist.append(s[1:count+1])
#    print 'Middle', s[count+1:], slist, count    
    if len(s)>(count+1):
        convertQueuedStringEx(s[count+1:],slist)
        
def isQstring(s):

    count = i = 0
    while len(s)> count:
        count += ord(s[count]) + 1

    return len(s) == count

def parseInput(fin, fout=''):
    global macros, screens, reports, procs, reportHead, rptlist
    
    done = 0 
    RPTLIST = 1
    MACRO = 2
    SCREEN = 3
    REPORT = 4
    PROC = 5
    VERSION = 6
    UNKNOWN = 7
    
    STATE = 0

    newstate = 0
    
    reports = []
    macros = []
    screens = []
    procs = []
    lines = []
    rptlist = []
    
    currentMacro = ''
    currentScreen = ''
    currentReport = ''
    currentProc = ''
    currentVersion = ''

    reportHead = fin.readline()

    lines = []
                          
    while not done:
        sline = fin.readline()
#        print sline
        if sline.startswith('@@'):
            if sline.startswith('@@MACRO'):
                newstate = MACRO
            elif sline.startswith('@@SCRN'):
                newstate = SCREEN
            elif sline.startswith('@@RPT'):
                newstate = REPORT
            elif sline.startswith('@@PROC'):
                newstate = PROC
            elif sline.startswith('@@VERSION'):
                newstate = VERSION
            else: pass

            if currentMacro != '': macros.append((currentMacro,lines))
            if currentScreen != '': screens.append((currentScreen,lines))
            if currentProc != '': procs.append((currentProc,lines))
            if currentVersion != '':
                for line in lines: rptlist.append(line.strip('\r\n'))
            if currentReport != '': reports.append((currentReport,lines))

            STATE = newstate
            lines = []
            currentReport = ''
            currentMacro = ''
            currentScreen = ''
            currentProc = ''
            currentVersion = ''

        elif STATE:
            if newstate :
                if STATE == MACRO: currentMacro = sline
                elif STATE == SCREEN: 
#                    print sline
                    Info = []
                    convertQueuedString(sline.strip('\n'),Info)
                    currentScreen = Info[2]+ '.'+Info[1]
                    lines.append(sline)
                elif STATE == PROC: 
#                    print sline
#                    Info = []
#                    convertQueuedString(sline.strip('\n'),Info)
                    currentProc = sline = sline.strip('\r\n')
#                    lines.append(sline)
                elif STATE == VERSION: 
#                    Info = []
#                    convertQueuedString(sline.strip('\n'),Info)
                    currentVersion = 'Version'
                    lines.append(sline)
                elif STATE == REPORT:
#                    print sline
                    Info = []
                    convertQueuedString(sline.strip('\n'),Info)
                    currentReport = Info[2]+ '.'+Info[1]
                    lines.append(sline)
                else: pass
                newstate = 0
            else: lines.append(sline)
        else: pass
        if sline == "" : done=1
    if currentMacro != '': macros.append((currentMacro,lines))
    elif currentScreen != '': screens.append((currentScreen,lines))
    elif currentProc != '': procs.append((currentProc,lines))
    elif currentVersion != '':
        for line in lines: rptlist.append(line.strip('\r\n'))
    elif currentReport != '': reports.append((currentReport,lines))
    else: pass

    print 'Finished parsing. Package includes',len(rptlist),'reports'
    print 'Report Header',reportHead

    if False:
        print 'Procs count =', len(procs)
        for item in procs:
            print '\t'+item[0], len(item[1])
        print 'Screens count =', len(screens), screens[:][0][0]
        for item in screens:
            print '\t'+item[0], len(item[1])
    


def main():
    global FNAME, basedir, RPATH
    global macros, screens, reports, procs, reportHead, rptlist
    
    FNAME = getfile()
    print 'Patching RW package:\n', '\tBase Package:', FNAME

    if FNAME != '':
        patchDir = getfile(dirname(FNAME),True)
        if patchDir != '':
            patchfilelist = listdir(patchDir+'/') 
            print '\tPatch files:',patchDir, len(patchfilelist), 'files'
            patchfiles = []
            for item in patchfilelist:
                if isfile(patchDir+'/'+item):
                    patchfiles.append(item)
                    print '\t\t'+item
            RPATH = FNAME[:len(FNAME)-3].strip()
            targetF = asksaveasfilename(initialdir=dirname(FNAME),initialfile=RPATH+' patched.rw')
            print '\tTarget package:',targetF

    if FNAME != '' and targetF and len(patchfiles)>0 and True:
       fa = file(FNAME,'rb')

       parseInput(fa)
       fa.close()

       target = file(targetF,'wb')
       i = 0
       target.write(reportHead)
       target.write("@@VERSION:1\r\n")
       for rpt in rptlist:
           target.write(rpt+'\r\n')
       for rpt in rptlist:
           target.write("@@PROC\r\n")
           target.write(procs[i][0]+'\r\n')
           for item in procs[i][1]:
               target.write(item)
           for item in patchfiles:
               if item.startswith(rpt):
                   target.write("@@MACRO\r\n")
                   macroname= item.split('.')
                   macroname = '.'.join(macroname[:len(macroname)-1])
                   target.write(macroname+'\r\n')
                   fpatch = file(patchDir+'/'+item,'r+')
                   linenum=-1
                   for sline in fpatch:
                       linenum += 1
                       target.write(str(linenum)+'\r\n')
                       target.write(sline.strip('\n')+'\r\n')
                   fpatch.close()
           target.write("@@RPT\r\n")
           for item in reports[i][1]:
               target.write(item)
           target.write("@@SCRN\r\n")
           for item in screens[i][1]:
               target.write(item)
           i += 1

       target.close()

    else:
       print 'ABORTED BY USER'

def test():
    tests = []
    tests.append( chr(1)+'1'+chr(30)+'SE'+chr(1)+'1' )
    tests.append( chr(1)+'1'+chr(30)+'C'+chr(30)+'DAT' )
    mystr = []
    for test in tests:
        mystr = []
        convertQueuedStringEx(test,mystr)
        print mystr
#try:
#    test()
main()
#except :
#    errno, errstr = sys.exc_info()
    
#    print str(errno), errstr

