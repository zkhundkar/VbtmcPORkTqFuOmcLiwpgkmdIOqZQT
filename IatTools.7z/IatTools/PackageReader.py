#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#
#   Section #1
#       Package info and menus
#   Section #2
#   DPM names, one per line
#   Section #3
#       procedure names
#   Section #4
#       Application data
#   Section #5
#       Definitions (IA, IE, IEE, .. )
#   Section #6
#   procedures and macros (source files)
#


#---------------------------------------------------------------

FNAME=None
import logging

class SettingsManager:
    def __init__(self):
        return

class FileIO:
    def __init__(self):
        return

class pkgManager:
    def __init__(self):
        return


class MagicNodesOld:
    
    menu = {"name":"menu",
            "xslt":"c:/Iatric/menus.xsl",

            "menu":([".urn"],["appl",".name",'responsible','linkable','active','unk','title']),

            "routine":(["",".rlink"],["title","proc","menu-proc","proc-args"]),
            "picLine":(["",".linenum"],"VALUE"),
            "segmentKeys":{"toplevel": ("menu"),
                           "menu":(["IM","*"],('routine,picLine')),
                           "routine":(["O","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "picLine":(["P","*"],None)},

            "print" : ['menu'],
            "container-tags":{},

            "keySize" : {"2":["routine","picLine"]} }

    ddef = {"name":"datadef",
            "xslt":"C:/Iatric/datadefs_v2.xsl",
            
            "segment":(['','dpm',"name"],["active","dpmLetters",'physBase','physRoot','parent','segType',
                                        'mapsTo','constant','localSubscripts','pc9','pc10','elemCount']),
            "dpmList":(None,["name"]),
          

            "field":([".rank"],"fldName"),
            "subscript":([".rank"],["fldname","physName","proc-args"]),
            "index":([".rank"],"VALUE"),
            "child":([".rank"],["title","menu-proc","proc-args"]),

            'fld-def': (["",".dpm",".element"],['Pointer','DataType','offset','physName','localName','length','jfy','.dataseg','rank']),
            "fld-attrib":([".type"],"VALUE"),
            "fld-attrib-map":([".type",".num"],"VALUE"),
            "segmentKeys":{"toplevel": ("dpmList"),
                           "dpmList":(["IF","*"],("segment","fld-def")),
                           "segment":(["IE","*","*"],('field','subscript','index','child')),
                           "fld-def":(["IEE","*","*"],('fld-attrib','fld-attrib-map')),
                           "fld-attrib":(["C","*"],None),
                           "fld-attrib-map":(["CL","*","*"],None),

                           "field":(["E","*"],None),
                           "subscript":(["S","*"],None),
                           "index":(["I","*"],None),
                           "child":(["C","*"],None),
                           "picLine":(["P","*"],None)},
        

            "print" : ["dpmList",[['dataSegment',['segment',['field'],['subscript'],['index'],['child']]],
                                  ['elements',['fld-def',['fld-attrib','fld-attrib-map']]]]],
            "container-tags":{"segment":"dataSegments","fld-def":"elements"},

            "keySize" : {"2":["dpm"],
                         "3":["segment","fld-def"],
                         "5":["segment/field","segment/subscript",'segment/index','segment/child','fld-def/fld-attrib'],
                         "6":['fld-def/fld-attrib-map']} }

    report={"name":"report",
            "xslt":"C:/Iatric/reports_v2.xsl",
            "index":([".urn"],["name","dpm"]),
            "report":(None,[".active","name","dpm","procedure","type","refresh","data-seg","mult-pages","mult-page-no",
                          "window","graph-selects","fragment","rpt-sched","audit-trail","exit-show","exit-prompt",
                          "source-ship","cms-dictionary","repeat-cust"]),

            "doc-text":([".num"],"VALUE"),
            "field":(["",".num"],["field-ele-name","field-ele-dpm","row","marker","length","justify","fld-name"]),
            "fld-index":(["row","col"],["fld-length","fld-field"]),
            "fld-select":([".num"],["oper","value-1","value-2","sel-ele-name","sel-ele-dpm",".sel-scrn","prompt","default"]),
            "select":([".num"],["sel-oper","sel-value-1","sel-value-2","tsel-ele-name","tsel-ele-dpm",".scrn",
                                "sel-prompt","sel-default","sel-field"]),
            "sort-temp":([".num"],["sort-ele-name","sort-ele-dpm",".header",".trailer",".renumber","order"]),

            "footnote":(["",".num"],"VALUE"),
            "line":(["",".num"],[".region",".pg-break"]),

            "appl-doc":([".num"],"VALUE"),

            "tech-doc":([".num"],"VALUE"),
            "line-attrib":([".type"],"VALUE"),
            "attribute":([".type"],"VALUE"),
            "attrib-map":([".type",".num"],"VALUE"),
            "line-attrib-map":([".type",".num"],"VALUE"),
            "phi":(None,"VALUE"),
            "picLine":(["",".num"],"VALUE"),
            "section":([".id"],["sect-id","sect-rows-per-entry","sect-top-row","sect-visible-cnt","sect-table-name",
                             "sect-fields","sect-id-repeat"]),
            "segmentKeys":{"toplevel": ("report"),
                           "report":["IR","*"],
                           "field":(["F","*"],('attribute','attrib-map','appl-doc','tech-doc',"fld-select")),
                           "field-index":(["FI","*","*"],None),
                           "fld-select":(["SE","*"],None),
                           "footnote":(["N","*"],None),
                           "index":(["I","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "line":(["L","*"],("line-attrib",'line-attrib-map')),
                           "phi":(["PHI"],None),
                           "picLine":(["P","*"],None),
                           "select":(["SE","*"],None),
                           "appl-doc":(["DA","*"],None),
                           "tech-doc":(["DT","*"],None),
                           "doc-text":(["DC","*"],None),
                           "sort-temp":(["T","*"],None),
                           "attribute":(["C","*"],("attrib-map")),
                           "attrib-map":(["CL","*"],None),
                           "line-attrib":(["C","*"],None),
                           "line-attrib-map":(["CL","*","*"],None)},

            "print" : ['report',['field',['attribute','attrib-map']],
                       ['footnote'],['line',['line-attrib',['line-attrib-map']]],['picLine'],['section']],
            "container-tags":{},
            "keySize" : {"1":["phi"],
                         "2":["doc-text","field","footnote","index","picLine","select","sort-temp",
                              "line"],
                         "3":["fieid-index"],
                         "4":["line/line-attrib","field/attribute","field/appl-doc","field/tech-doc",
                              "field/fld-select"],
                         "5":["line/line-attrib-map"],
                         "6":["field/attribute/attrib-map"]} }


    screen={"name":"screen",
            "xslt":"C:/IATRIC/screens_v2.xsl",
            "screen":(None,[".active","name","dpm","procedure","type","refresh","data-seg","mult-pages","mult-page-no",
                          "window","graph-selects","fragment","rpt-sched","audit-trail","exit-show","exit-prompt",
                          "source-ship","cms-dictionary","repeat-cust"]),
            "page":([".num"],["page-title","page-ok-prompt","page-exit-logic"]),
            "field":([".num"],["field-ele-name","field-ele-dpm","field-section","row","column","physical",
                           "length","pre-edit","justify","required","help","phy-base","mult-access-type",
                           "default-value","data-def-seg","data-def-ele","display-override","int-to-ext",
                           "ext-to-int","id-lookup"]),
            "appl-doc":([".num"],"VALUE"),
            "tech-doc":([".num"],"VALUE"),
            "attribute":([".type"],"VALUE"),
            "attrib-map":([".type",".num"],"VALUE"),
            "picLine":([".num"],"VALUE"),
            "section":([".id"],["sect-control","sect-rows-per-entry","sect-top-row","sect-visible-cnt","sect-table-name",
                             "sect-fields","sect-repeat"]),
            "segmentKeys":{"toplevel": ("screen","page"),
                           "screen":["IS","*"],
                           "page":(["P","*"],("field","picLine","section")),
                           "field":(["F","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "picLine":(["P","*"],None),
                           "section":(["S","*"],None),
                           "appl-doc":(["DA","*"],None),
                           "tech-doc":(["DT","*"],None),
                           "attribute":(["C","*"],None),
                           "attrib-map":(["CL","*","*"],None)},
            "print" : ['screen',['page',['field',['attribute','attrib-map']],
                       ['picLine'],['section']]],
            "container-tags":{},

            "keySize" : {"2":["page"],
                         "4":["page/field","page/picLine","page/section"],
                         "6":["page/field/attribute","page/field/appl-doc","page/field/tech-doc"],
                         "7":["page/field/attrib-map"]} }
                    
    nsets={"menu":menu, "screen":screen, "report":report, "ddef":ddef,
           "IM":menu, "IS":screen, "IR":report,"IF":ddef}
    def __init__(self):
        return


class Magic2XmlOld:
    global ET
    import xml.etree.ElementTree as ET
    import sys
    def __init__(self, initargs=[]):
        self.logging=False
        self.nodemap=MagicNodes().nsets
        if len(initargs)>0:
            self.top=initargs[0]
        if len(initargs)>1:
            self.settings = initargs[1]
        return

    def queuedStringToList(self,s):
        subX=[]
        try:
            while len(s)>0:
                l=ord(s[0])
                subX.append(s[1:l+1])
                s=s[l+1:]
        except:
            pass
        return subX

    def escapedhtmString(self, s):
        return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')


    def datasegToXml(self,tag,key,value,xmap,xt,ctags):
        global ET

        klist,vlist=xmap
        myparent=xt
        if tag in ctags.keys():
            ttag=ctags[tag]
            myparent=xt.find(ttag)
            if myparent is None:
                myparent=ET.Element(ttag)
                xt.append(myparent)
        else: pass
        e=ET.Element(tag)
        if klist is not None and type(key) is list:
            for k in klist:
                subs = key.pop(0)
                if k.startswith('.'): e.attrib[k[1:]]=subs
                elif k=="": pass
                else:

                    x=ET.Element(k)
                    x.text=subs
                    e.append(x)
        if type(vlist) is list:
            v2=self.queuedStringToList(value)
            #print klist, vlist, '\n',v2
            for v in vlist:
                if len(v2)>0:
                    subs = v2.pop(0)
                    if v.startswith('.'): e.attrib[v[1:]]=subs
                    else:
                        x=ET.Element(v)
                        x.text=subs
                        e.append(x)

        elif not vlist=="VALUE":
            x=ET.Element(vlist)
            x.text=value
            e.append(x)
        else: e.text=value
        myparent.append(e)
        return e

    def convertMagictoXml(self,f,P=None,PATH=""):
        global ET
        import os
        fs=""
        fn=None
        if P:
            k=self.formKey(f[0].split('=')[0].strip(' '))
            if P in ('screen','report'):
                name=k[1].split('.')
                dpm=[]
                ucase=True
                for i in range(len(name)):
                    if ucase and name[i]==name[i].upper() and ord(name[i][0])>60: dpm.append(name[i])
                    else:
                        ucase=False
                        
                        
                dpm=".".join(dpm)
                fn=PATH+'/'+dpm+"/"+k[1][len(dpm)+1:]+"_"+P[0].upper()+".xml"
                ss=1
            elif P == 'menu':
                fn=PATH+"/"+".".join(k[1].split('.')[1:])+'.xml'
            elif P == 'datadef' or P=='ddef':
                fn=PATH+'/'+k[1]+'/datadef.xml'
            self.xslt=self.nodemap[P]["xslt"]
            P=self.nodemap[P]["print"]
            fs=f

        else:
            fa=open(f,"r")
            fs=fa.readlines()
            fn=".".join(f.split(".")[:-1])+".xml"
            if ".S" in f :
                P=self.nodemap['screen']["print"]
            elif ".R." in f:
                P=self.nodemap['report']["print"]
        xt=self.toXml(fs,len(fs))
        fa=open(fn,"w")
        fa.write('<?xml version=\"1.0\"?>\n')
        try:
            fa.write('<?xml-stylesheet type=\"text/xsl\" href=\"'+self.xslt+'\" ?>\n')
        except: pass

        self.printTree("",xt,ET,fa,P)
        fa.close()
        return
    

    def formKey(self,k,ev=False):
        if ev:
            k=eval(k)
        return self.parseKeys(k.strip(' '))
    def formValue(self,v,ev=False):
        if ev:
            v=eval(v)
        return v.strip(' ')

    def toXml(self,ll,limit=None):
        import sys
        if limit: pass
        else: limit=len(ll)
#        classes={"IS":(screen,"screen"),"IR":(report,"report")}
        ln=topnode=ll.pop(0)
        n=ln.index('=')
        k=self.formKey(ln[:n].strip(' '))
        v=self.formValue(ln[n+1:].strip(' '))
        
        xt=None
#        print k, v
        if k[0] in self.nodemap.keys():
            segmap=self.nodemap[k[0]]
            topseg=segmap["segmentKeys"]["toplevel"]
            if type(topseg) is tuple or type(topseg) is list:
                topseg=topseg[0]
            
    #        print segmap["name"], topseg
            try:
                xt= ET.Element(segmap["container-tags"]["root"])
            except KeyError:
                xt= ET.Element(segmap["name"].title()+'s')
            nodepath=[xt]
            cnode=self.datasegToXml(topseg,"",v,segmap[topseg],xt,segmap["container-tags"])
            parentNodes={"root":(topseg,"",xt)}
            segs=segmap["segmentKeys"]
            keySize=segmap["keySize"]
            lncnt=0
            lastparent=(None,None,None)
            for ln in ll[:limit]:
                lncnt+=1
                n=ln.index('=')
                k=self.formKey(ln[:n].strip(' '))
                v=self.formValue(ln[n+1:].strip(' '))
                isChild=False
                if str(len(k)) in keySize :
                    keySet=keySize[str(len(k))]
                    match=False
                    keyseg=""
                    for keyS in keySet:
                        if match:
                           break
                        kmatch=True
                        key_PP=[]
                        dseg=keyS
                        if "/" in keyS:
                            for kxx in keyS.split('/'):
                                key_PP.extend(segs[kxx][0])
                                dseg=kxx

                        else: key_PP=segs[keyS][0]

                       # sys.stdout.write(keyS+" "+str(key_PP)+" "+str(k)+': ')
                        for i in range(len(key_PP)):
                            keyP=key_PP[i]
                            if i< len(k) :
                                if keyP=="*" : pass

                                elif k[i]==keyP: pass
                                else:
                                    kmatch=False

                            else: kmatch=False
                        if kmatch:
                            match=True
         #                   sys.stdout.write(" "+str(match))
                            n=0
                            if "/" in keyS:
                                dk=segs[dseg][0]
                                n=-1
                                if dk[0] == "*": n=0-len(dk)
                                else: n=1-len(dk)
                                #k=k[n:]
                            else: pass
                            pkeyS,pk,cnode=parentNodes["root"]
                            ii=0
                            subKeys=keyS.split('/')
                            dseg=subKeys[-1]
                            subKeys=subKeys[:-1]
                            try:
                                while ii < len(subKeys):
                                    dk=segs[subKeys[ii]][0]
                                    pkeyS,pk,pnode=parentNodes["/".join(subKeys[:ii+1])]
                                    if pk==k[:len(pk)]:
                                        cnode=pnode
                                    ii+=1
                                   # sys.stdout.write("\n\t"+pkeyS+" "+str(ii)+" "+str(k)+" ?= "+str(pk)+", "+str(cnode))
                            except KeyError:
                                sys.stdout.write("not in parents list ")

                           # sys.stdout.write("\n  "+str(k[n:])+" "+keyS+" "+str(k)+", "+pkeyS+str(pk)+" -> "+str(cnode)+'\n')
                            cx=self.datasegToXml(dseg,k[n:],v,segmap[dseg],cnode,segmap['container-tags'])
                            lastparent=(keyS,k)
                            parentNodes[keyS]=(dseg,k,cx)

                            break
                        else: pass
    #                        sys.stdout.write(" "+str(match)+'\n')
                else:
                    sys.stdout.write("key not matched "+str(k))
                    #basher()
            ll.insert(0,topnode)

        return xt

    def printTree(self,top,e,M,fout=sys.stdout, P=None):
        s=M.tostring(e)
        sout=""
        tab=""
        sout=self.printSub(P,s,tab)
        fout.write(sout)
        return

    def printSub(self,P,s,tab):
        sout=""
        if type(P) is list:
            tab=tab+"   "
            for item in P:
                s=self.printSub(item,s,tab)
            tab=tab[:-3]
            sout=s
        else:
            i1=i2=-1
            item=P
            tag='<'+item+' />'
            tag1="<"+item+">"
            tag2="<"+item+" "
            tc="</"+item+">"
            if tag1 in s : tag=tag1
            elif tag2 in s : tag=tag2
            else: tc=""

            while tag in s:
                i1=s.index(tag)
                sout=sout+s[:i1]+'\n'+tab+tag
                s=s[i1+len(tag):]
    #               if len(tc)>0 and tc in s:
    #                   i1=s.index(tc)
    #                   sout=s[:i1]+'\n'+tab+tc
    #                   s=s[i1+len(tc):]
            sout=sout+s
        return sout

    def parseKeys(self,s):
        p1=s.split('\x1e')
        p2=[]
        for x in p1:
            self.parseKey2(x,p2)
        return p2

    def parseKey2(self,x,p2):
        i=0
        pc=''
        while len(x)>0:
            xx,x=(x[0],x[1:])
            pp=ord(xx)
            if pp<31:
                p2.append(pc)
                pc=x[:pp]
                x=x[pp:]
                if pp==0:
                    p2.append(pc)
                    pc=''
                
            else:
                pc=pc+xx
        if len(pc)>0: p2.append(pc)
        return


class PkgReader:
    import sys
    from shutil import copyfile
    import os
    import logging
#    from zipfile import *

    SECTION_DEL = chr(255)
    SEGMENT_DEL = chr(254)
    logfile = ''
    packageInfo = []
    dpmNames = []
    procedureNames = []
    definitions = []
    applicationInfo = []
    source = []
    settings = {}
    elements={"IS":{}, "IR":{}, "IM":{}, "IE":{}, "IF":{}}


    def __init__(self, initargs=[]):
        self.logging=True
        if len(initargs)>0:
            self.top=initargs[0]
        if len(initargs)>1:
            self.settings = initargs[1]
        self.logger = None
        try:
            self.logger = self.top.logger
        except: pass
        self.run()

    def setdebuglog(self):
        pass
 #       try:
 #           if self.settings['debug']['logging'].lower()=='true':
 #               self.logging=True
 #           else:
 #               pass
 #       except:
        return

#    def openlogfile(self, start):
        pass
    #       import time
    #       if self.logging:
    #           fn=self.settings['debug']['logfile']
    #           self.logfile = file(fn,'a+')
    #           self.logfile.write('\n\n  ------ '+start+' ------------------------- \n')
    #           self.logfile.write('  ------ '+time.asctime(time.localtime(time.time()))+' ------------------------- \n')
 #       return

    def closelogfile(self):
#        if self.logging:
#            self.logfile.close()
        return

    def writelog(self, s,logger=None):
#        global logfile

        if logger == 'print' or logger =='stdio':
            print s
        elif logger :
            logger(s.strip('\n')+'\n')
        else: 
            self.logger.info(s.strip('\n')+'\n')
        return

    def getfile(self, mask='*.pkg'):
        from tkFileDialog import askopenfilename
#        global tmpname, alines, fmode, tname, _isCompressed
        FNAME = ''
        lastfn=mask
        if 'LastDir' in self.settings["main"]:
            self.basedir=self.settings["main"]['LastDir']
        elif 'ARCH_DFTDIR' in self.settings["main"]:
            self.basedir=self.settings["main"]['ARCH_DFTDIR']
        else:
            self.basedir='C:/IATRIC Systems/Visual Smartboard/Code Repository'
        if "LastArchive" in self.settings["main"]:
            lastfn=self.settings["main"]["LastArchive"]
            mask='*.'+lastfn.split('.')[-1]
        else:
            pass
#            getfile(base,lastfn)

        FNAME = askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", mask)])
        self.writelog('Importing package: '+ FNAME)
        if FNAME != '':
            try:
                pp = os.path.dirname(FNAME)
                newmode=mode[2:];
                mode_ch=False
                if "Iatriscan" in pp:
                    newmode="Iatriscan"
                    mode_ch = True
                elif "Visual" in pp:
                    newmode="vsb"
                    mode_ch = True
                if ch:
                    self.settings["main"]['LastArchiveType']=newmode
                self.settings["main"]['LastDir']=pp
                self.settings["main"]['LastArchive']=os.path.basename(FNAME)
            except:
                pass
        else:
            self.writelog( 'Error Reading file \n')
            pass

        return FNAME

    def parseInput(self,fin):
#        global self.packageInfo, self.dpmNames, self.procedureNames, self.definitions, self.applicationInfo, source

        done = 0
        RPTLIST = 1
        MACRO = 2
        SCREEN = 3
        REPORT = 4

        STATE = 0

        sections = []
        segments = []

        screens = []
        lines = []
        secptr=0
        segptr=0
        currentSegment = []
        currentSection = []
        currentMacro = ''
        currentScreen = ''
        currentReport = ''

        self.packageInfo = []
        self.dpmNames = []
        self.procedureNames = []
        self.definitions = []
        self.applicationInfo = []
        self.elements={"IS":{}, "IR":{}, "IM":{}, "IE":{}, "IF":{}}
        self.source=[]

        while not done:
            sline = fin.readline()
    #        print sline
            if self.SECTION_DEL in sline:
                slineSection = sline.split(self.SECTION_DEL)
                for term in slineSection:
                    currentSection.append(term)
                    sections.append(currentSection)
                    currentSection = []

            else:
                currentSection.append(sline)
            if sline == "" : done=1

        if currentSection!=[]:
            sections.append(currentSection)

    #    print 'Finished parsing sections ..'

    #    print sections[2]
        sectionNumber = 0

        for section in sections:
            sectionNumber += 1
            segments = []
            currentSegment = []

            for line in section:

                if self.SEGMENT_DEL in line:
                    secLines = line.split(self.SEGMENT_DEL)
                    for segment in secLines:
                        currentSegment.append(segment)
                        if (currentSegment != []): segments.append(currentSegment)
                        currentSegment = []
                else:
                    currentSegment.append(line)

            if (currentSegment != []):
                segments.append(currentSegment)

            if sectionNumber==1:
                self.packageInfo = segments
            elif sectionNumber==2:
                self.dpmNames = segments
            elif sectionNumber==3:
                self.procedureNames = segments
            elif sectionNumber==4:
                self.applicationInfo  = segments
            elif sectionNumber==5:
                self.definitions  = segments
            else:
                self.source.append(segments)

    #    for info in self.packageInfo:
    #        print info
        self.writelog("Package Info: " + self.packageInfo[0][0][1:])

    #    for info in self.applicationInfo:
        self.applicationInfo.pop(0)
    #    print "DPMs",self.dpmNames
        self.dpmNames.pop(0)
        self.dpmNames.pop()
        sect = []
        for dpm in self.dpmNames:
            if dpm[0]!='' : sect.append(dpm[0])
        self.dpmNames = sect

    #    print "DPMs cleaned up",self.dpmNames
    #    self.writelog( "Processing Program Source files ..")

        sect = []
        try:
            for pgm in self.source:
                try:
                    x=pgm.pop(0)
                except:
                    print 'Nothing to pop from pgm in self.source'

                src = []
                for line in pgm:
                    src.append(line[0])
                sect.append(src)
        except:
            print 'Nothing in self.source'

        self.source = sect

        self.source.pop()
    #    self.writelog( 'Done parsing')

    def convertQueuedString(self,s, slist):
        ''' convert Magic queued string to list'''
        count = ord(s[0])

        slist.append(s[1:count+1])
        if len(s)>(count+1):
            self.convertQueuedString(s[count+1:],slist)

    def fileDatadefs(self):
#        global self.definitions, self.RPATH

        fout = file(self.RPATH+'/'+'datadefs.fsl2','wb')

        nodeFlag = 0
        nodeKeys = ''
        elementQ = ''
        nodeValList = []
        crflag = ''

        for nprNode in self.definitions:
    #        if len(nprNode)>1: self.writelog( str(nprNode) )
            nodeType = nprNode[0].split(chr(30))[0]
    #        if nodeFlag==1 and nodeType not in ['IE','IEE','IP','IR','IM','IS','IRI']:
    #            self.writelog(nodeKeys+', '+crflag+', '+nprNode)
            if nodeType == 'IE':
                nodeFlag = 1
                nodeKeys = nprNode[0]
                crflag = ''
            elif nodeFlag==1 and nprNode[len(nprNode)-1].endswith('\n'):
                crflag += "".join(nprNode)
    #            print 'trap1', nodeKeys, crflag
            elif nodeFlag==1:
                nodeFlag = 0

    #            if len(crflag)>0: print nodeKeys, crflag
                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
    #               if len(nodeKeys)>2 and len(nodeKeys[2])>0:
    #                   elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ = nodeKeys[3][0]
    #               if len(nodeKeys)>4 and len(nodeKeys[4])>0:
    #                   elementQ += nodeKeys[4][0]
    #               if elementQ in ['P','PP','PF','PFC','PS','PM']:
    #                   nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]
                if elementQ in ['E','C','S']:
                    nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
                nodeKeys = "|".join(nodeKeys)

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['','S']:
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)
                    nprNode = '|'.join(nodeValList)

    #               nodeValList = []
    #               self.convertQueuedString(nprNode[0],nodeValList)
    #               fb.write( '{'+nodeKeys+'}|{' + '|'.join(nodeValList)+'}\n')

                fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
            else: nodeFlag = 0

        elementQ = ''
        nodeValList = []

        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType == 'IEE':
                nodeFlag = 1
                nodeKeys = nprNode[0]
                crflag = ''
            elif nodeFlag==1 and nprNode[len(nprNode)-1].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ = nodeKeys[3][0:2]
                if elementQ in ['DA']:
                    nodeKeys[3] = nodeKeys[3][:len(elementQ)] + '|' + nodeKeys[3][len(elementQ)+1:]
    #                elif elementQ == 'E' or elementQ == 'D' or elementQ=='S':
    #                    nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
                nodeKeys = "|".join(nodeKeys)
    #                else:
    #                    nodeKeys = nodeKeys[0]+chr(30) + nodeKeys[1]
    #                    nodeKeys = nodeKeys.replace(chr(30),'|')

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['']:
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)

                    newnodeValues =[]
                    for piece in nodeValList:
                        newnodeValues.append(piece.replace('|',""))

                    nprNode = '|'.join(newnodeValues)

    #                nodeValList = []
    #                self.convertQueuedString(nprNode[0],nodeValList)
    #                fb.write( '{'+nodeKeys+'}|{' + '|'.join(nodeValList)+'}\n')

                fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
            else: nodeFlag = 0
        fout.close()


    def fileReports(self):
#        global self.definitions, self.RPATH

        fout = file(self.RPATH+'/'+'reports.fsl2','wb')

        nodeFlag = 0
        nodeKeys = ''

        elementQ = ''
        nodeValList = []
        crflag = ''

        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType == 'IR':
                nodeFlag = 1
                crflag = ''
                nodeKeys = nprNode[0]
            elif nodeFlag==1 and nprNode[0].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
                if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                    elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ += nodeKeys[3][0]
                if elementQ in ['F','FS','FC','L','LC','N','P']:
                    nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]

                nodeKeys = "|".join(nodeKeys)

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['','FS','F','L']:
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)
                    nprNode = '|'.join(nodeValList)

                fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
            else: nodeFlag = 0

        fout.close()

    def fileMenus(self):
#        global self.definitions, self.RPATH

        fout = file(self.RPATH+'/'+'menus.fsl2','wb')

        nodeFlag = 0
        nodeKeys = ''

        elementQ = ''
        nodeValList = []
        crflag = ''

        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType in ['IM','IMI']:
                nodeFlag = 1
                crflag = ''
                nodeKeys = nprNode[0]
            elif nodeFlag==1 and nprNode[0].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
                if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                    elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ += nodeKeys[3][0]
                if elementQ in ['O','P']:
                    nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]

                nodeKeys = "|".join(nodeKeys)

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['','O']:
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)
                    nprNode = '|'.join(nodeValList)

                fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
            else: nodeFlag = 0

        fout.close()

    def fileNprElements(self):
        from MagicXml import MagicNodes, Magic2Xml
        M=Magic2Xml(settings=self.settings['main'], other=1, name='m2x')
        for t in ('IS','IR','IE','IM'):
            tt=self.elements[t]
            ptype=None
            if t == 'IS': ptype="screen"
            elif t == 'IR': ptype="report"
            elif t=='IE': ptype='ddef'
            elif t=='IM': ptype='menu'
            if ptype is not None:
                for a in tt:
                    xf=tt[a]
                    if t=="IE":
                        try:
                            xf=self.elements['IF'][a]
                            xf.extend(tt[a])
                        except KeyError:
                            pass
                    M.convertMagictoXml(xf,ptype,self.RPATH)

    def groupNprElements(self):
#        global self.definitions,self.RPATH

#        fout = file(self.RPATH+'/'+'screens.fsl2','wb')

        nodeFlag = 0
        nodeKeys = ''

        scrname=""
        nodevalue=""
        nodetr=""
        lastElement=None
        screens=[]
        for nprNode in self.definitions:
             nodecheck=nprNode[0].split(chr(30))
             nodeType = nodecheck[0]
             if nodeType in ('IS','IM','IR','IE','IEE','IF'):
                nodeFlag = 1
                if nodeType[:2] == lastElement: pass
                else:
                    screens=self.elements[nodeType[:2]]
                    lastElement=nodeType[:2]
                if len(nodecheck)>1:
                    try:
                        if lastElement == 'IE':
                            nodestr="".join(nprNode)
                        elif lastElement == 'IF':
                            nodestr="".join(nprNode)
                        else:
                            nodestr=str(chr(30)).join(nodecheck[2:])+"".join(nprNode[1:])
                        screens[nodecheck[1]].append(nodestr +' = ')
                    except KeyError:
                        if lastElement=='IE' and False:
                            dpm=nprNode[0].split(chr(30))[1]
                            screens[nodecheck[1]]=["IF"+chr(30)+dpm+" = "+str(len(dpm))+dpm,
                                                   "".join(nprNode) + ' = ']
                                                   
                        else:
                            screens[nodecheck[1]]=["".join(nprNode) + ' = ']
                    nodevalue="".join(nprNode)
                    scrname=nodecheck[1]
                notscreen=False
                nodeKey=nprNode[0]
             elif nodeType in ['ISI','IRI','IP','IPI','IMI', 'IEL', 'IEP', 'IMDX', 'IMPX', 'IMRPX', 'ISDC', 'ISRF', 'IFI', 'IF.ACT'] and not notscreen:
                 nodeFlag=0
             elif nodeFlag==1:
                 try:
                     screens[scrname].append(screens[scrname].pop()+"".join(nprNode))
                 except KeyError, IndexError: print scrname, nprNode,nodeKey
                 
             else:
                nodeFlag = 0
        ss=1
        return
#        if True: return                 
#
#       fout.close()

    def extractSource(self):
        import sys
        import os
        from os import path
#        for fname in tzb.namelist():
#            if '.zip' in fname:
#                self.extractFiles(tzb, fname, fout, path)

        try:
           for dpm in self.dpmNames:
              if 1:
                  if path.isdir(self.RPATH+'/'+dpm): pass
                  else: 
                      os.mkdir(self.RPATH+'/'+dpm)
                      self.writelog("Created new folder - "+self.RPATH+'/'+dpm, self.logger.debug)
                  self.writelog(str( dpm ))

           count = 0
           for pgm in self.source:
               dpm = ''

               procName = pgm.pop(0)
               fm=''
               for nextDpm in self.dpmNames:
                   if procName.startswith(nextDpm):
                       dpm=nextDpm
                       break
    #           print dpm,':',RPATH+'/'+dpm+'/'+procName[len(dpm)+1:]+'.magic'
               if len(procName)>0:
                   try:
                       filechk = procName[len(dpm)+1:]
                       if filechk.startswith('con.'): filechk='-'+filechk
                       elif filechk.startswith('com.'): filechk='-'+filechk
                       elif filechk.startswith('lpt.'): filechk='-'+filechk
                       else: pass
                       fm = file(self.RPATH+'/'+dpm+'/'+filechk+'.magic','w')
                       for line in pgm:
                           fm.write(line+'\n')
                       fm.close()
                   except:
                       errinfo = sys.exc_info()
                       errno, errstr = errinfo[:2]
                       self.writelog(str(type(self.logfile))+" "+self.logfile.name+" is closed",self.logger.warning)
                       self.writelog(errinfo +" "+ type(fm) + " " + fm.name, self.logger.warning)


                       self.writelog( errinfo, self.logger.warning)
                       self.writelog(str(errno)+', '+errstr, self.logger.warning)
                       self.writelog( procName, self.logger.warning )
                       self.writelog( self.RPATH+'/'+dpm+'/'+procName[len(dpm)+1:]+'.magic'+', '+fm+'\n\n', self.logger.warning)
                       fm.close()
        except:
            errinfo = sys.exc_info()
            errno, errstr = errinfo[:2]

            self.writelog( errinfo )
            self.writelog(str(errno)+', '+str(errstr))


    def run(self):

        import time
        import os
        import sys
        from os import path
        global FNAME
        FNAME=self.getfile()
        if FNAME !='':
            fa = file(FNAME,'rb')
            try:
                self.settings['main']['LastArchive']=path.basename(FNAME)
                self.settings['main']['LastDir']=path.dirname(FNAME)
                if path.basename(FNAME) in self.settings['recent']:
                    self.settings["recent"].pop(self.settings["recent"].index(path.basename(FNAME)))
                self.settings["recent"].append(path.basename(FNAME))    
            except: pass
#           fb = file(path.dirname(FNAME)+'/'+'out.pkg.txt','wb')
#           self.openlogfile('Std form: '+FNAME)

#           self.logfile.write('\n\n  ------------------------------- \n')
#           print self.logfile.tell()
            lpath=FNAME.split('.')

            self.RPATH = ".".join(lpath[:len(lpath)-1])
            if path.isdir(self.RPATH): pass
            else: os.mkdir(self.RPATH)

            #       print fb
            self.parseInput(fa)
            self.groupNprElements()
            sss=1
            self.extractSource()

            #          self.fileDatadefs()
            #          self.fileScreens()
            #          self.fileReports()
            #          self.fileMenus()
            self.fileNprElements()

            #       print programNames
            #                   print procName

            #           fb.close()
            fa.close()
            self.writelog( 'Done')
            #          self.closelogfile()
            self.top.tbox.insert(0,path.basename(FNAME)+" - Done")
        else:
            self.writelog( 'ABORTED BY USER','print')

#d = PackageReader(sys.argv[1:])
