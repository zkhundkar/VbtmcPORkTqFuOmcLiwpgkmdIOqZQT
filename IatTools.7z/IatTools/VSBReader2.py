#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#   
#   Section #1
#       Package info and menus
#   Section #2
#   DPM names, one per line
#   Section #3
#       procedure names
#   Section #4
#       Application data
#   Section #5
#       tabheaders (IA, IE, IEE, .. )
#   Section #6
#   procedures and macros (source files)
#   

class VSBReader:
#    from shutil import copyfile
#    from zipfile import *
#    from tkFileDialog import *
            
    FNAME = ''
    MODE='NORMAL'

    basedir = ''
    SECTION_DEL = chr(8)
    SEGMENT_DEL = chr(254)
    logfile = ''
    packageInfo = []
    dpmNames = []
    procedureNames = []
    tabheaders = []
    applicationInfo = []
    source = []

    def __init__(self, parent, cmdargs=[]):
        
        self.initialize(cmdargs)
        self.run()


    def initialize(self, initargs):
        self.logfile = ''
        self.FNAME = ''
        return
    
    def writelog(self, s,logger=False):

        if logger: pass
        elif self.logfile: logger = self.logfile
        else: pass

        if logger == 'print' or logger =='stdio':
            print s
        elif logger :
            logger.write(s+'\n')
        else: pass

    def getfile(self,fmask=[("","*.*")]):

        from tkFileDialog import askopenfilename
        import os, os.path
        defaults = []
        if os.path.exists('iattools.ini'):
            inifile = file('iattools.ini','rb')
            defaults = inifile.readlines()
            self.basedir = "C:/iatric"
            for item in defaults:
                namval = item.split("=")
                if len(namval)>1 and namval[0]=="VSBReader" and len(namval[1].strip())>1:
                    self.basedir = os.path.dirname(namval[1])
                    break
            inifile.close()
        else: pass
            
        self.FNAME = askopenfilename(initialdir=self.basedir, filetypes=fmask)
        if len(self.FNAME)>0:
            inifile = file('iattools.ini','w+')
            self.writelog('Importing command file: '+ self.FNAME)
            newdir = os.path.dirname(self.FNAME)
            hasVSBReader = False
            for item in defaults:
                namval = item.split("=")
                if namval[0]=="VSBReader":
                    item = 'VSBReader=\"'+newdir+'\"'
                    hasVSBReader = True
                inifile.write(item+'\n')
            if not hasVSBReader:
                inifile.write('VSBReader=\"'+newdir+'\"\n')
            inifile.close()
            print newdir, self.FNAME
        else: pass
        

    def parseInput(self,fin,fout):
#        global packageInfo, dpmNames, procedureNames, tabheaders, applicationInfo, source

        done = 0 
        RPTLIST = 1
        MACRO = 2
        SCREEN = 3
        REPORT = 4
        
        STATE = 0
        
        sections = []
        segments = []
        
        screens = []
        lines = []
        secptr=0
        segptr=0
        currentSegment = []
        currentSection = []
        currentMacro = ''
        currentScreen = ''
        currentReport = ''
        
        while not done:
            sline = fin.readline()
    #        print sline
            if sline == "" : done=1
            elif self.SECTION_DEL in sline:
                slineSection = sline.split(self.SECTION_DEL)
                for term in slineSection:
                    currentSection.append(term)
                    sections.append(currentSection)
                    currentSection = []

            elif len(sline)>0: 
                currentSection.append(sline)
            else: pass

        if currentSection!=[]:
            sections.append(currentSection)
            
#        self.writelog ('Finished parsing sections .. '+ str(len(sections)) )
        
    #    print sections[2]
        sectionNumber = 0
        
        tabsections = []
        currentSegment = []
        CMDTYPE = 'unknown'
        for section in sections:
            sectionNumber += 1
    #        print sectionNumber, len(section[0])

            if sectionNumber==1:
                packageinfo = section[0].split(chr(1))
                applicationInfo = packageinfo.pop(0).strip(chr(0))
                if applicationInfo.split(chr(1))[0] in ('INIT','INITTAB'):
                    CMDTYPE=applicationInfo.split(chr(1))[0]
                elif applicationInfo.split(chr(9))[0] in ('INIT','INITTAB'):
                    CMDTYPE=applicationInfo.split(chr(9))[0]
                else: print applicationInfo[:10]
    #            print len(CMDTYPE), CMDTYPE
                if CMDTYPE =='INIT':
                    tabsections.append(packageinfo[0])
                if CMDTYPE=='INITTAB':
                    applicationInfo=packageinfo[0]
                
            elif len(section[0])>0:
                tabsections.append(section[0])
            elif CMDTYPE=='INITTAB':
                tabsections.append(section[0])

    #    printTabHdr( packageinfo[0] )

        print 'Command type',CMDTYPE
        if CMDTYPE== 'INIT':
            for tab in tabsections:
                self.writelog('<vsbMessage type=\"INIT\">')
                self.printAppHdr(applicationInfo)
                self.printTabHdr(tab)
                self.writelog('</vsbMessage >')
        elif CMDTYPE == 'INITTAB':
            s=""+chr(8)
    #        sections = "".join(sections)
            tabsections = str(chr(8)).join(tabsections)
            self.writelog('Tabsections '+str(len(sections))+", "+str(len(tabsections)))
            tabsections = [tabsections]
            self.writelog('<vsbMessage type=\"INITTAB\">')
            for tab in tabsections:
                self.printTabData(applicationInfo,tab)
            self.writelog('</vsbMessage >')

    def printSegment(self, nodedelim,subnodes,hdrs,rep):
        import copy
        nodes = subnodes.split(nodedelim)
        localhdrs = copy.copy(hdrs)
        repeat = len(nodes) > len(hdrs) and rep
        repCount=0
        qualifier = ''
        for node in nodes:
            if len(localhdrs)>0:
                hdrnode = localhdrs.pop(0)          
            else:
                repCount += 1
                if not repeat:
                    hdrnode="unk"
                qualifier = ' count="'+str(repCount)+'"'
            if type(hdrnode) == type('str'):
                self.writelog('<'+hdrnode+qualifier+'>'+node+'</'+hdrnode+'>')
            else:
                self.writelog('<'+hdrnode[0]+qualifier+'>')
                self.printSegment(hdrnode[1],node,hdrnode[2],hdrnode[3])
                self.writelog('</'+hdrnode[0]+'>')
        
    def printAppHdr(self, appInfo):
        self.writelog("Application Header")
        sec = ('cmdtype','title','unk','unk','unk','unk','unk')
        headers = ['appHeader','cmdtype','appinfo',
                   'gcs',
                   'datetimeinfo']
        appinfo = ['Hospital','PatientName','Account','MedrecNum','Age','Sex',
                   ('NameValuePair',chr(128),['Name','Value'],False)]
                   
        segments = appInfo.split(chr(9))
        mainnode=headers.pop(0)
        self.writelog('<'+mainnode+'>')
        for item in segments:
            hdritem=headers.pop(0)
            if hdritem == 'appinfo':
                self.writelog('<'+hdritem+'>')
                self.printSegment(chr(127),item,appinfo,True)
                self.writelog('</'+hdritem+'>')
            else:
                self.writelog('<'+hdritem+'>'+item+'</'+hdritem+'>')
        self.writelog('</'+mainnode+'>')

    def printTabHdr(self, tabhdr):
        headers = ["Tab URN","Type","Caption","Compile Date",
                   "Compile Time","User Routines","User Buttons",
                   "Tab Default Function","Rows Per Record","Number of Columns",
                   "Column Definitions","Color Palette","Anchor","URL","Alert Text","unk1","unk2","unk3","unk4","unk5"]
        structHdrs = ["User Buttons","Tab Default Function","Column Definitions","Color Palette"]
                   
        xhdrs = ["tab-urn","tab-type","label","compDate",
                   "compTime","user-rtns","Buttons",
                   "dbl-click","num-subrows","numColumns",
                   "Columns","Colors","anchor","url","alert-text","unk1","unk2","unk3","unk4","unk5"]

        segments = tabhdr.split(chr(9))
        print "Tab Header ("+ str(len(segments)) + ") items"
    #    self.writelog("Tab Header ("+ str(len(segments)) + ") items")
        self.writelog("<tabHeader>")
        
        for item in segments:
            plabel = label=headers.pop(0)
            xlabel=xhdrs.pop(0)
            if label in structHdrs: plabel = label +'\n'
            else: plabel = label+":\t"
            
            if label == 'User Buttons':
                self.writelog('<'+xlabel+'>')
                self.printUserBtns(plabel,item)
                self.writelog('</'+xlabel+'>')
            elif label == 'Tab Default Function':
                self.writelog('<'+xlabel+'><button>')
    #            printUserBtns(plabel,item)
                self.printSegment(chr(128),item,["btn-id","btn-text","icon","script","reqFlag",'unk','btn-type'],True)
                self.writelog('</button></'+xlabel+'>')
            elif label == 'Column Definitions':
                self.writelog('<'+xlabel+'>')
                self.printCols(plabel,item)
                self.writelog('</'+xlabel+'>')
            elif label == 'Color Palette':
                self.writelog('<'+xlabel+'>')
                self.printColors(plabel,item)
                self.writelog('</'+xlabel+'>')
            else:
    #            self.writelog(plabel+" "+ item)
                self.writelog('<'+xlabel+'>'+item+'</'+xlabel+'>')
        self.writelog("</tabHeader>\n")
                
    def printUserBtns(self,label,Item):
        btns = Item.split(chr(127))

        btnheaders = ["Button ID","Text","Icon","Script","ReqFlag",'unk','type']
        xhdrs = ["btn-id","btn-text","icon","script","reqFlag",'unk','btn-type']

    #    self.writelog(label)
        xlabel=''
        for btn in btns:
            btnpars = btn.split(chr(128))
            i = 0
            maxheaders = len(btnheaders)
            self.writelog('<'+'button' + '>')
            for par in btnpars:
                parlabel = ''
                if i<maxheaders:
                    parlabel=btnheaders[i]
                    xlabel=xhdrs[i]
                i+=1

    #            self.writelog( '  '+parlabel+'\t'+par)
                self.writelog('<'+xlabel+'>'+par+'</'+xlabel+'>')
            self.writelog('</'+'button' + '>')
    #        self.writelog('')
        
    def printCols(self, label,Item):
        btns = Item.split(chr(127))

        btnheaders = ["Row Index","Column Index",
                   "Caption","Width","Data Type",
                   "Right Click Function","Popup Desc",
                      "Icon file","Script String","Mark Dups","Justify","Extra","extra"]

        xhdrs = ["subrow","colid",
                   "caption","width","data-type",
                   "rt-click","desc",
                      "icon","script","markDups","jfy","Extra","extra"]
    #    self.writelog( label )
        xlabel=''
        for btn in btns:
            btnpars = btn.split(chr(128))
            i = 0
            maxheaders = len(btnheaders)
    #        self.writelog('  '+'Cell defn has '+str(len(btnpars)) + ' components')
            self.writelog('<'+'column' + '>')
            for par in btnpars:
                parlabel = ''
                if i<maxheaders:
                    parlabel=btnheaders[i]
                    xlabel=xhdrs[i]
                i+=1
    #            self.writelog('  '+parlabel+'\t'+par)
                self.writelog('<'+xlabel+'>'+par+'</'+xlabel+'>')
            self.writelog('</'+'column' + '>')
    #        self.writelog('')
        
    def printColors(self, label,Item):
        btns = Item.split(chr(127))

        btnheaders = ["Color Index","Color Desc",
                      "Color Value"]

        xhdrs = ["color-idx","legend","color-val"]
        self.writelog(label)
        xlabel=''
        for btn in btns:
            btnpars = btn.split(chr(128))
            i = 0
            maxheaders = len(btnheaders)
            self.writelog('<'+'color' + '>')
            for par in btnpars:
                parlabel = ''
                if i<maxheaders:
                    parlabel=btnheaders[i]
                    xlabel=xhdrs[i]
                i+=1
    #            self.writelog('  '+parlabel+'\t'+par)
                self.writelog('<'+xlabel+'>'+par+'</'+xlabel+'>')
            self.writelog('</'+'color' + '>')
    #        self.writelog('')

    def printTabData(self, rowinfo,tabhdr):
        headers = ["Tab URN","Type","Caption","Compile Date",
                   "Compile Time","User Routines","User Buttons",
                   "Tab Default Function","Rows Per Record","Number of Columns",
                   "Column Definitions","Color Palette","Anchor","URL","Alert Text","unk1",
                   "unk2","unk3","unk4","unk5"]
        structHdrs = ["User Buttons","Column Definitions","Color Palette"]

        self.writelog( rowinfo )
        tabrows = tabhdr.split(chr(255))
        print type(tabrows), len(tabrows)

        for tab in tabrows:
            if not len(tab)>0: break

            segments = tab.split(chr(4))
            self.writelog("<Rows >" )
            
            
            for item in segments:
    #            self.writelog(item)
        #        plabel = label=headers.pop(0)
                if not (len(item) > 0): break
                rowhdr = item.split(chr(6))[0]
                ROWLABEL=rowhdr.split(chr(9))
        #        print type(item)
    #            rowlabel='<row urn=\"' + ROWLABEL[0]+'\"><subrows>'+ROWLABEL[1]+'</subrows><row-color>'+ROWLABEL[2]+'</row-color>'
                rowlabel='<row urn=\"' + ROWLABEL[0]+'\">'
                self.printColData(rowlabel,item[len(rowhdr)+1:])
        #        printColData(rowlabel,item[len(rowhdr)+1:])
                self.writelog('</row>')
            self.writelog("</Rows >" )
                
        
    def printColData(self, label,Item):
        btns = Item.split(chr(5))

        btnheaders = ["Cell Urn","Color Index",
                      "Row Index","ColIndex","Value","Hover Value"]
        xhdrs = ["cellUrn","cell-color",
                      "subRow","column","cell-value","hover"]

        self.writelog(label)
        coldef = ''
        xlabel=''
        if len(btns)>0:
            coldef=coldef+'<cells>'
        for btn in btns:
            btnpars = btn.split(chr(9))
            i = 0
            maxheaders = len(btnheaders)
            if len(btnpars)>4:
                btnvals = btnpars[4].split(chr(11))
                if len(btnvals)>1:
                    btnpars[4]=btnvals[0]
                    btnpars.append(btnvals[1])
            coldef = coldef+'<cell>'
            for par in btnpars:
                parlabel = ''
                if i<maxheaders:
                    parlabel=btnheaders[i]
                    xlabel=xhdrs[i]
                i+=1
    #            coldef = coldef + '<'+parlabel+'>'+str(par)+'</'+parlabel+'>'
                coldef = coldef + '<'+xlabel+'>'+str(par)+'</'+xlabel+'>'
            coldef=coldef+'</cell>\n'
        if len(btns)>0:
            self.writelog(coldef+'</cells>\n')
        

    def convertQueuedString(self, s, slist):
        count = ord(s[0])

        slist.append(s[1:count+1])
        if len(s)>(count+1):
            convertQueuedString(s[count+1:],slist)
        
    #    for macro in macros:
    #       writelog 'Macro '+ macro[0]
    #    for screen in screens:
    #       print 'Screen', screen[0]
    #    for report in reports:
    #       print 'Report', report[0]



    # __main__()

    def run(self):
#        global logfile
        import time
        import os, os.path
        self.getfile(fmask=[("","*.isd")])
        if self.FNAME !='':
           fa = file(self.FNAME,'rb')
           fb = file(os.path.dirname(self.FNAME)+'/'+'out.pkg.txt','wb')
           self.logfile = file(self.FNAME+'.xml','w+')
           self.writelog('<?xml version="1.0"?>')
           self.writelog('<?xml-stylesheet type="text/xsl" href="c:/iatric/vsbmsg.xsl" ?>')


    #       logfile.write('\n\n  ------------------------------- \n')
    #       print logfile.tell()

           RPATH = self.FNAME[:len(self.FNAME)-4].strip()
    #       if path.isdir(RPATH): pass
    #       else: mkdir(RPATH)

    #       print fb
           self.parseInput(fa,fb)
          
    #       print programNames
           if False:
               for dpm in dpmNames:
                  if 1:
                      if path.isdir(RPATH+'/'+dpm): pass
                      else: mkdir(RPATH+'/'+dpm)
                      self.writelog(str( dpm ))

               count = 0
               for pgm in source:
                   dpm = ''
                   
                   procName = pgm.pop(0)
                   for nextDpm in dpmNames:
                       if procName.startswith(nextDpm): dpm=nextDpm
        #           print dpm,':',RPATH+'/'+dpm+'/'+procName[len(dpm)+1:]+'.magic'
                   if len(procName)>0:
                       try:
                           filechk = procName[len(dpm)+1:]
                           if filechk.startswith('con.'): filechk='-'+filechk
                           elif filechk.startswith('com.'): filechk='-'+filechk
                           elif filechk.startswith('lpt.'): filechk='-'+filechk
                           else: pass
                           fm = file(RPATH+'/'+dpm+'/'+filechk+'.magic','w')         
                           for line in pgm:
                               fm.write(line+'\n')
                           fm.close()
                       except:
                           errinfo = sys.exc_info()
                           errno, errstr = errinfo[:2]

                           self.writelog( errinfo )
                           self.writelog(str(errno)+', '+errstr)
                           self.writelog( procName )
                           self.writelog( RPATH+'/'+dpm+'/'+procName[len(dpm)+1:]+'.magic'+', '+fm+'\n\n')
                           fm.close()
                            
    #                   print procName

           fb.close()
           fa.close()
           self.logfile.close()
           print 'Done'
        else:
           self.writelog( 'ABORTED BY USER','print')

