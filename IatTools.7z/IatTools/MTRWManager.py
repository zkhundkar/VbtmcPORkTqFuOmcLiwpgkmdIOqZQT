try:
    import win32com.client
    import win32api
except:
    pass

from Tkinter import *
from socket import *
import tkMessageBox
import ttk
import os
import subprocess
import os.path
import xml.etree.ElementTree as ET

from time import time, ctime, sleep
from select import select
import threading
from MTRWRelay import RelayThread as RelaySock

class magicConnections(Tk):
    settings = {}

    def __init__(self, parent, cmdargs=[]):
        
        self.top = self
        Tk.__init__(self,parent)
        self.parent=parent
        self.connlist=''
        self.allConnections = {}
        self.connectionSet={}
        self.activeConnections = []
        self.readSettings()
        self.initialize(cmdargs)
        self.allActives = []
        self.activeLabels = []
        self.shell=win32com.client.Dispatch("WScript.Shell")

    def initialize(self, initargs):
        self.status = self.parent
#        self.mys = socket(AF_INET,SOCK_STREAM)
        self.title('Magic Connections')
        self.pid=os.getpid()
        self.scriptfile = 'C:/Iatric/Scantest/scriptIMPSVC.txt'

        for item in initargs:
            pass
        ttk.Style().theme_use('winnative')            
        self.frame = ttk.Frame(self, borderwidth=2) #main window
        self.frame.pack(fill=BOTH,expand=5)

        self.cfm = ttk.Frame(self.frame) #output window
        self.yscrlbr = ttk.Scrollbar(self.cfm)
        self.yscrlbr.pack(side=RIGHT, fill=Y)
        self.xscrlbr = ttk.Scrollbar(self.cfm, orient=HORIZONTAL)
        self.xscrlbr.pack(side=BOTTOM, fill=X)
        self.tbox = Listbox(self.cfm,relief=GROOVE, height=10,width=60, background='lightgray', yscrollcommand=self.yscrlbr, xscrollcommand=self.xscrlbr)
        self.tbox.config(font='verdana 8',yscrollcommand=self.yscrlbr.set,
                         xscrollcommand=self.xscrlbr.set)
        self.yscrlbr.config(command=self.tbox.yview)
        self.xscrlbr.config(command=self.tbox.xview)
        self.tbox.pack(side=LEFT,fill=BOTH, expand=5)
        self.cfm.pack(fill=BOTH,expand=5)
        
    # display the menu
        self.menubar=Menu(self.top)
        self.setupMenu()
        self.top.config(menu=self.menubar)
        self.top.wm_resizable(width=200, height=120)

    def writeTbox(self,s):
        self.tbox.insert(END,s)
        return

    def setupMenu(self):
        #    global connections, __sites
        #global __wkConn, __wktype

        #    wksparams =Menu(menubar, tearoff=0)
        s = 'setupmenu'
        self.last=None
        self.recentlist=[]
        #Create our Python menu
        self.mainmenu=Menu(self.menubar, tearoff=0)
        self.connlist = Menu(self.mainmenu, tearoff=0)
        self.recentmenu = Menu(self.mainmenu, tearoff=0)
        self.mainmenu.add_cascade(label="Connect To",menu=self.connlist)
        self.mainmenu.add_command(label="Connect Last",command=lambda x=self.last: self.addConnection(x))
        self.mainmenu.add_cascade(label="Recent",menu=self.recentmenu)
        self.mainmenu.add_separator()
        self.mainmenu.add_command(label="Reload",command=self.reloadConnections)
        self.mainmenu.add_separator()
        self.mainmenu.add_command(label="Exit",command=self.destroy)
        self.activeConnections = Menu(self.menubar, tearoff=0)
        #Add our Menu to the Base Menu
        self.menubar.add_cascade(label="Connections", menu=self.mainmenu)
        self.menubar.add_cascade(label="Active", menu=self.activeConnections, state=DISABLED)
        self.activeConnections.add_cascade(label="Refresh", command=self.checkActives)
        self.activeConnections.add_cascade(label="Reload", command=self.reloadConnections)
        self.activeConnections.add_separator()
        i=0
        keyset=self.connectionSet.keys()
        keyset.sort()
        for c in keyset:
            if type(self.connectionSet[c]) is list:
                newmenu=Menu(self.connlist,tearoff=0)
                self.connlist.add_cascade(label=c,menu=newmenu)
                #emkeyset=c.keys()
                #emkeyset.sort()
                for cc in self.connectionSet[c]:
                    newmenu.add_command(label=cc[0],command=lambda x=cc[0]: self.addConnection(x))
            else:
                self.connlist.add_command(label=c, command= lambda x=c: self.addConnection(x) )

    def reloadConnections(self):
        self.connlist = Menu(self.mainmenu, tearoff=0)
        self.readSetings()
        i=0
        keyset=self.connectionSet.keys()
        keyset.sort()
        for c in keyset:
            if type(self.connectionSet[c]) is list:
                newmenu=Menu(self.connlist,tearoff=0)
                self.connlist.add_cascade(label=c,menu=newmenu)
                #emkeyset=c.keys()
                #emkeyset.sort()
                for cc in self.connectionSet[c]:
                    newmenu.add_command(label=cc[0],command=lambda x=cc[0]: self.addConnection(x))
            else:
                self.connlist.add_command(label=c, command= lambda x=c: self.addConnection(x) )
            i+=1
        
    def readSettings(self):
        xtpath="connections.xml"
        if os.path.isfile(os.path.abspath(xtpath)): pass
        elif os.path.isfile("../connections.xml"):
            xtpath="../connections.xml"
        elif os.path.isfile("../../connections.xml"):
            xtpath="../../connections.xml"
        elif os.path.isfile("./ztools/connections.xml"):
            xtpath="./ztools/connections.xml"

        if os.path.isfile(xtpath): pass
        elif os.path.isfile(os.path.join("./",xtpath)):
            xtpath=os.path.join("./",xtpath)
        
        xt = ET.parse(xtpath)

        conns=xt.findall('Connection')
        counts={}
        for item in conns:
            node=item.find('name').text.title()
            self.allConnections[node]=item
            try:
                counts[node[0]]+=1
            except KeyError:
                counts[node[0]]=1
        ct= len(self.allConnections)
        print "# connection"
        self.connectionSet={}
        rk=[(counts[x],x) for x in counts if counts[x]>1]
        rk.sort(reverse=True)
        for a in rk:
            if ct>30 :
                ct=ct-a[0]+1
            else:
                rk.pop(rk.index(a))
        print ct, rk
        rk=[a[1] for a in rk]
                
        for a in self.allConnections:
            if a[0] in rk:
                try:
                    self.connectionSet[a[0]].append((a,self.allConnections[a]))
                except:
                    self.connectionSet[a[0]]=[(a,self.allConnections[a])]
            else:
                self.connectionSet[a]=self.allConnections[a]
        counts=rev=rk=None
        #else: pass
        xt=None
        xtpath=None


    def addConnection(self, idx):
        xs = self.allConnections[idx]
        ms=magicshell()
        ms.setshell(self.shell)
        ms.setvalues(xs)
        #print ms.params['ip'], ms.params['name'], ms.scripts
        scrs=ms.scripts.keys()
        actScripts = Menu(self.activeConnections, tearoff=0)
        self.allActives.append(ms)
        
        self.menubar.entryconfig(2,state=NORMAL)
        ac = self.activeConnections.add_cascade(label=idx, menu=actScripts)
#        actScripts
        i=0
        keyset=scrs
        keyset.sort()
#        print keyset
        for c in keyset:
            if c=="start": pass
            else:
                actScripts.add_command(label=c, command= lambda x=ms, y=c: self.scriptAction(x,y) )
                i+=1
        ms.launchVLAN()
        if "start" in keyset:
            self.scriptAction(ms, "start")
#        print xs.toxml(), type(idx), idx
        pass

    def scriptAction(self, mitem, idx):
        mitem.injectScript(idx)
#        self.writeTbox(idx)

    def checkActives(self):
        i=0
#        print self.allActives, self.activeConnections
        while i < len(self.allActives):
#            print i
            try:
                ms=self.allActives[i];
                if ms.pid:
#                    print 'checking',ms.params['name'], repr(ms.process), ms.pid
                    poll_result = ms.process.poll()
                    if poll_result is None : pass
                    else:
                        self.activeConnections.delete(i+3,i+3)
                        self.allActives.pop(i)
                else:
#                    print 'no pid',i
                    self.activeConnections.delete(i+3,i+3)
                    self.allActives.pop(i)
                    
            except:
                pass
            i+=1
        if len(self.allActives)>0:
            self.menubar.entryconfig(2,state=NORMAL)
        else:
            self.menubar.entryconfig(2,state=NORMAL)
        pass

class magicshell ():
    
    def __init__ (self,io=None):
        self.pid=''
        self.ip=''
        self.name="Elk Regional"
        self.shell = ''
        self.delay=200
        self.process=''
        self.scripts = {}
        self.params = {}
        self.scripter=socket(AF_INET,SOCK_STREAM)

    def setvalues(self,xstr):
        varx = ('ip','name','loginuser','loginpw','startseg','opcode','startdir','startprog','pref-ver')
        print type(xstr), xstr
        #node2=xstr.firstChild
        for x in varx:
            try:
                self.params[x]=xstr.find(x).text
            except AttributeError:
                pass
        ss = xstr.findall("scripts/script")
        for script in ss:
            a = script.attrib['id']
            self.scripts[str(a)]= script.findall('sln')
            
        print self.scripts.keys()
        
    def setshell(self, sh):
        self.shell=sh
  
    def setshellG(self):
        self.shell=win32com.client.Dispatch("WScript.Shell")

    def sendkeys(self,s):
        self.shell.AppActivate(self.pid)
        win32api.Sleep(500)
        self.shell.Sendkeys(s)
        return
    
    def setVLAN(self,addr,async_port=None):
    #    global tmpname, alines, fmode, tname, _isCompressed
        import _winreg
        
        if True:
            zt=_winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,"Software"),"Meditech")
            ztm=_winreg.OpenKey(zt,"Wrkstn")
            ztr=_winreg.OpenKey(ztm,"VLAN",0,_winreg.KEY_ALL_ACCESS)
            try:
                _winreg.SetValueEx(ztr,"I",0,_winreg.REG_SZ, addr )
                if asunch_port:
                    _winreg.SetValueEx(ztr,"TP",0,_winreg.REG_SZ, asynch_port )
                    
            except:
                print 'Error reading reg keys'
                
            _winreg.CloseKey(ztr)
            _winreg.CloseKey(ztm)
            _winreg.CloseKey(zt)
        else:
            print 'Error Reading file or reg keys'
            pass

        return


    def launch(self):
        print 'launching', self.params["name"]
        p=subprocess.Popen(['C:/Program Files (x86)/Meditech/Workstation3.x/T.exe', self.params["name"]])
        self.process=p
        self.pid = p.pid
#        if len(self.opcode)>0 and self.shell:
#            win32api.Sleep(3000)
#            self.send_logopcode()
        return p

    def launchVLAN(self):
        print 'launching', self.params["name"]
#        self.setVLAN(self.params["ip"])
        p=subprocess.Popen(['C:/Program Files (x86)/Meditech/Workstation3.x/T.exe', "zLocal"])
        self.process=p
        self.pid = p.pid
#        if len(self.opcode)>0 and self.shell:
#            win32api.Sleep(3000)
#            self.send_logopcode()
        RelaySock()
        self.scripter.connect(('127.0.0.1',8023))
        print "Connect script socket on 8023 ("+self.params['ip']+')'
        win32api.Sleep(500)
        self.sendkeys("~")
        return p

    def send_logopcode(self):
        if self.pid:
            self.sendkeys(self.opcode)
            win32api.Sleep(500)
            self.sendkeys(self.startseg)
            win32api.Sleep(500)
            self.sendkeys(self.startdir)
            win32api.Sleep(500)
            self.sendkeys(self.startprog)
            win32api.Sleep(500)
            self.sendkeys("~")

    def injectScript(self,s_id):
        try:
            scoll=self.scripts[s_id]
            delay=''
            for sitem in scoll:
                delay=self.delay
                try:
                    if sitem.hasAttribute('delay'):
                        delay=int(str(sitem.getAttribute("delay")) )
                except:
                    pass
                try:
                    sc = str(sitem.firstChild.nodeValue)
                    win32api.Sleep(delay)
#                    try:
#                        print str(self.pid), delay, sc
#                    except:
#                   print "no pid", delay, sc
                    self.sendkeys(sc)
#                    self.logger(delay+": "+sc)
                except:
                    pass
        except:
            pass
            
    def set_pid(self,p):
        self.pid = p

if __name__ == "__main__":
    a=magicConnections(None).mainloop()
