#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#   
#   @@RPT
#   LINE 1 Report definition and sorts?
#   History section
#       two lines each
#   end of section marker?  
#   Fields section
#       F{field#}
#       {fieldname,??,??,rptname,length,L}
#       F{field#,"C",ATTR}
#       attrValue
#   Picture section
#       FI{line#,startCol#}
#       {width,field#}
#   Report line attributes
#       L{line#}
#       {linetype,??,..}
#   Footnotes section
#       N{noteline#}
#       footnote
#   Picture layout section
#       P{line#}
#       picture of line
#   Select section
#       T{line#}
#       {subscript,??,"NONE","N",??,??,??,"ASC"}
#   Updates section
#       U{timeinsecs}
#       {user,directory}
#   
import sys
from shutil import copyfile
from os import *
from zipfile import *
from tkFileDialog import *
    
FNAME = ''
RPATH = ''
macros = ''
screens = ''
reports = ''
procs = ''
reportHead = ''
rptlist = ''
fout = ''

PROC_INFO =['DPM','Name','Responsible','Active','Access',
            'Arguments','Menu Logic','unknown']

SCRN_INFO = ['Y','Name','DPM','Procedure Name','Screen Type','unknown']

HDR_ELEMS = ['Hospital','MIS','Directory','User','Date','Segment','Description']

reportKeyMap = {'F':'field', 'P':'picLine', 'AT':'audit', 'N':'footnote', 'FI':'fieldIndex',
                'U':'update','T':'subscript'}    
def getfile():
    global FNAME, tmpname, alines, fmode, tname, _isCompressed
    
    basedir='C:/IATRIC Systems/Visual Smartboard/ftpsite'
    
    FNAME = askopenfilename(initialdir=basedir, filetypes=[("", "*.rw")])
    print 'Importing RW package:', FNAME

def getfile(bd,df=""):
    global FNAME, tmpname, alines, fmode, tname, _isCompressed
    
    basedir=bd
    
    FNAME = askopenfilename(initialdir=basedir, initialfile=df, filetypes=[("RW archives", "*.rw")])
    print 'Importing RW package:', FNAME

def convertQueuedString(s, slist):
    count = ord(s[0])

    slist.append(s[1:count+1])
    if len(s)>(count+1):
        convertQueuedString(s[count+1:],slist)

def convertQueuedStringEx(s, slist):
    count = ord(s[0])
    notFound = True
#    print 'Top', s, slist, count    
    if count == 30:
        c = 1
        count = 0
        while len(s)>c and notFound:
            if ord(s[c])<32: notFound = False
            else:
                count += 1
                c += 1
#        print s[1:], slist, count, c, notFound
        if notFound: count = ord(s[0])
            
    slist.append(s[1:count+1])
#    print 'Middle', s[count+1:], slist, count    
    if len(s)>(count+1):
        convertQueuedStringEx(s[count+1:],slist)
        
def isQstring(s):

    count = i = 0
    while len(s)> count:
        count += ord(s[count]) + 1

    return len(s) == count

def parseInput(fin, fout=''):
    global macros, screens, reports, procs, reportHead, rptlist
    
    done = 0 
    RPTLIST = 1
    MACRO = 2
    SCREEN = 3
    REPORT = 4
    PROC = 5
    VERSION = 6
    UNKNOWN = 7
    APPHEADER = 8
    
    STATE = 8

    newstate = 0
    
    reports = []
    macros = []
    screens = []
    procs = []
    lines = []
    rptlist = []
    appheader = []
    
    currentMacro = ''
    currentScreen = ''
    currentReport = ''
    currentProc = ''
    currentVersion = ''
    currentHeader = 'AppHeader'

    sline = fin.readline()
    if len(sline)>0:
        lines = sline.strip('\r\n')
        reportHead=sline.strip('\r\n')
    lines = []
                          
    while not done:
        sline = fin.readline()
#        print sline
        if sline.startswith('@@'):
            if sline.startswith('@@MACRO'):
                newstate = MACRO
            elif sline.startswith('@@PROC'):
                newstate = PROC
            elif sline.startswith('@@SCRN'):
                newstate = SCREEN
            elif sline.startswith('@@RPT'):
                newstate = REPORT
            elif sline.startswith('@@VERSION'):
                newstate = VERSION
            else: pass

            if currentMacro != '': macros.append((currentMacro,lines))
            if currentScreen != '': screens.append((currentScreen,lines))
            if currentProc != '': procs.append((currentProc,lines))
            if currentVersion != '':
                for line in lines: rptlist.append(line.strip('\r\n'))
            if currentReport != '': reports.append((currentReport,lines))

            STATE = newstate
            lines = []
            currentReport = ''
            currentMacro = ''
            currentScreen = ''
            currentProc = ''
            currentVersion = ''
            currentHeader = ''

        elif STATE:
            if newstate :
                if STATE == MACRO: currentMacro = sline
                elif STATE == SCREEN: 
#                    print sline
                    Info = []
                    convertQueuedString(sline.strip('\n'),Info)
                    currentScreen = Info[3]
                    lines.append(sline)
                elif STATE == PROC: 
#                    print sline
#                    Info = []
#                    convertQueuedString(sline.strip('\n'),Info)
                    currentProc = sline = sline.strip('\r\n')
#                    lines.append(sline)
                elif STATE == VERSION: 
#                    Info = []
#                    convertQueuedString(sline.strip('\n'),Info)
                    currentVersion = 'Version'
                    lines.append(sline)
                elif STATE == REPORT:
#                    print sline
                    Info = []
                    convertQueuedString(sline.strip('\n'),Info)
                    currentReport = Info[2]+ '.'+Info[1]
                    lines.append(sline)
                else: pass
                newstate = 0
            else: lines.append(sline)
        else: pass
        if sline == "" : done=1
    if currentMacro != '': macros.append((currentMacro,lines))
    elif currentScreen != '': screens.append((currentScreen,lines))
    elif currentProc != '': procs.append((currentProc,lines))
    elif currentVersion != '':
        for line in lines: rptlist.append(line.strip('\r\n'))
    elif currentReport != '': reports.append((currentReport,lines))
    elif currentReport != '': reports.append((currentReport,lines))
    elif currentHeader != '': procs.append((appheader,lines))
    else: pass

#    print 'Finished parsing. Package includes',len(rptlist),'reports'

    if False:
        print 'Procs count =', len(procs)
        for item in procs:
            print '\t'+item[0], item[1]
        print 'Screens count =', len(screens), screens[:][0][0]
        for item in screens:
            print '\t'+item[0], item[1]
        print 'Reports count =', len(reports)
        for item in reports:
            print '\t'+item[0], item[1]
    

#    for screen in screens:
#    	print 'Screen', screen[0]
#    for report in reports:
#    	print 'Report', report[0]

# __main__()

def fileMacros():
    global macros, RPATH, fout

#    fout = ''

    fout.write('<macros>\n')
    for macro in macros:
#        fout = file(RPATH+'/'+macro[0].strip('\r\n')+'.magic','wb')
        macrotext = macro[1][1::2]

        fout.write('<macro name=\"'+macro[0].strip('\r\n')+'\">\n')
        for line in macrotext:
            htmlline = line.replace('&','&amp;')
            htmlline = htmlline.replace('<','&lt;')
            htmlline = htmlline.replace('>','&gt;')
            fout.write('<line>'+htmlline+'</line>\n')
        fout.write('</macro>\n')
#        fout.close()
    fout.write('</macros>\n')

def fileRptSegment(fout,segment,keywords, sectionIdName):
    global PROC_INFO, SCRN_INFO, reportKeyMap

    print 'Filing segment ..', sectionIdName, len( segment )
    
    knownKeys = []
    for kwords in keywords:
        for kword in kwords:
            knownKeys.append(kword)

    for section in segment:
        sectiontext = []

        slist = []


        fout.write('<sections name=\"'+sectionIdName+'\">\n')
        sectionName = section[0]
        if len(section[1])>0:
            body = section[1]

            mainNode = body.pop(0)
            convertQueuedString(mainNode.strip(), slist)
            queline = slist

#            sectiontext.append('{'+sectionIdName+'|'+sectionName+'}|{'+'|'.join(queline)+'}')
            if sectionIdName in ('procInfo','screens'):
                LABELS = ['unknown']
                if sectionIdName == 'procInfo':
                    LABELS = PROC_INFO
                elif sectionIdName == 'screens':
                    LABELS = SCRN_INFO
                else:
                    pass 
                i=0
                irange = len(LABELS)
                fout.write('<sectionInfo>')
                for infoEle in queline:
                    fout.write('<secInfoItem name=\"'+LABELS[i]+'\">'+infoEle+'</secInfoItem>\n')
                    if i+1 < irange: i += 1
                fout.write('</sectionInfo>\n')
                

            index = 0

            test = ''.join(body)
            test = test.replace('\r\n',chr(254))

            body = test.split(chr(254))

            flag =''
            flag0 = ''
            flag1 = ''
            while len(body)>0:
                topnode = body.pop(0)
                if len(topnode)>0:
                    slist = []

                    
                    flag0 = topnode[0]
                    flag1 = topnode[0:2]
                    if flag1 in knownKeys:
                        flag = flag1
                    elif flag0 in knownKeys:
                        flag = flag0
                    else:
                        flag = topnode

                    flagout = flag
                    if len(topnode)>len(flag):
                        convertQueuedStringEx(topnode[len(flag):],slist)
                        if flag=='F' and len(slist)>1:
                            if slist[1]=='C':
                                flag = 'FC'
                                

                    key = flagout+'|'+'|'.join(slist)
                    topnode = body.pop(0)
                    
                    if flag not in keywords[0]:
                        sectiontext.append('{'+key+'}|{'+topnode +'}')
                    else:
                        slist=[]
                        queline = ''
                        convertQueuedString(topnode, slist)
                        sectiontext.append('{'+key+'}|{'+'|'.join(slist)+'}')

#        print str(len(sectiontext)), 'lines processed'
        if sectionIdName == 'reports':
            group = ''
            grplabel = ''
            rank = 0
            for line in sectiontext:
                key, value = line.split('}|{')
                keynodes = key.strip('}').strip('{').split('|')
                if keynodes[0] == group:
                    pass
                elif keynodes[0] in reportKeyMap.keys():
                    if not grplabel == '':
                        if grplabel == 'field':
                            fout.write('</'+grplabel+'>\n')
                        fout.write('</'+grplabel+'s>\n')
                    group=keynodes[0]
                    grplabel = reportKeyMap[group]
                    fout.write('<'+grplabel+'s>\n')
                else:
                    grplabel == 'line'
                    group = keynodes[0]
                if group == 'F':
                    if keynodes[1] == rank:
                        if keynodes[2] == 'C':
                            fout.write('<attribute type=\"'+keynodes[3]+'\">'+value.strip('}')+'</attribute>\n')
                        elif keynodes[2] == 'SE':
                            fout.write('<sortElement type=\"'+keynodes[3]+'\">'+value.strip('}')+'</sortElement>\n')
                        else:
                            fout.write('<line>'+line+'</line>\n')
                            
                    else:
                        if rank == 0: pass
                        else : fout.write('</'+grplabel+'>\n')
                        rank = keynodes[1]
                        fout.write('<'+grplabel +' rank=\"'+rank+'\">'+line+'\n')
                elif group == 'AT':
                    valnodes = value.strip('}').strip('{').split('|')
                    fout.write('<'+grplabel+' activity=\"'+valnodes[1]+'\"><time>'+keynodes[1]+'</time>\n')
                    fout.write('<user>'+valnodes[0]+'</user>')
                    if len(valnodes)>2: fout.write('<line>'+','.join(valnodes[1:])+'</line>')
                    fout.write('</'+grplabel+'>\n')
                
                elif group == 'P':
                    valnodes = value.strip('}').strip('{').split('|')
                    fout.write('<'+grplabel+' linenum=\"'+keynodes[1]+'\">'+value.strip('{').strip('}')+'</'+grplabel+'>\n')
                elif group == 'U':
                    valnodes = value.strip('}').strip('{').split('|')
                    fout.write('<'+grplabel+'><updateTime>'+keynodes[1]+'</updateTime>')
                    fout.write('<user>'+valnodes[0]+'</user><activity>'+valnodes[1]+'</activity></'+grplabel+'>\n')
                else:
                    fout.write('<'+grplabel+'><key>'+key.strip('{')+'</key>\n')
                    fout.write('<values>'+value.strip('{').strip('}')+'</values></'+grplabel+'>\n')
            if not grplabel == '':
                fout.write('</'+grplabel+'s>\n')
                
                    
        else:
            for line in sectiontext:
                fout.write('<line>'+line+'</line>\n')
        fout.write('</sections>')

def macroLogic(rpath, fname, fw):

    fm = file(rpath+'/'+fname,'r')
    lnum = 0
    lines = fm.readlines()
    fm.close()
    
    for line in lines:
        fw.write( str(lnum)+'\r\n'+line.strip('\r\n').strip()+'\r\n')
        lnum += 1
    lines = []

def main():
    import _winreg
    global FNAME, RPATH, reportHead, rptlist, procs, reports, screens, versions, macros, fout
    global HDR_ELEMS

    base = "C:/Iatric Systems"
    try:
        zt=_winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,"Software"),"ztools")
        ztr=_winreg.OpenKey(zt,"reports")
        mode=_winreg.QueryValueEx(ztr,"LastArchiveType")[0]
        ztm=_winreg.OpenKey(ztr,mode)
        last=_winreg.QueryValueEx(ztm,"LastDir")[0]
        lastfn=_winreg.QueryValueEx(ztm,"LastArchive")[0]
        if len(last)>0:
            base=last
        getfile(base,lastfn)

        if FNAME != '':
            try:
#                print "Saving LastDir:", path.dirname(FNAME),'to',ztm
                _winreg.SetValueEx(ztm,"LastDir",0,_winreg.REG_SZ,path.dirname(FNAME))
                print "Saving LastArchive:",path.basename(FNAME),'to',ztm
#                _winreg.SetValueEx(ztm,"LastArchive",0,_winreg.REG_SZ,path.basename(FNAME))
            except:
                print 'Error writing keys'
        print "Closing ",ztm
        _winreg.CloseKey(ztm)
        print "Closing ",ztr
        _winreg.CloseKey(ztr)
        print "Closing ",zt
        _winreg.CloseKey(zt)
    except:
        print 'Error Reading file or reg keys'
        pass
    
    if FNAME !='':

        RPATH = FNAME[:len(FNAME)-3].strip()
#        if path.isdir(RPATH):
        fa = file(FNAME,'rb')
        parseInput(fa)
        fa.close()

        mfiles = listdir(RPATH)
        proclist=[]
        for item in procs:
            proclist.append(item[0])
        macrolist = []
        for f in mfiles:
            if f.endswith(".magic"):
                froot = f.split(".M.")
                if froot[0] in rptlist:
                    macrolist.append((froot[0],f))
                               
        if True:

            #       fout = file(RPATH+'/'+'reports-rw.xml','wb')
            fout = file(RPATH+'/'+path.basename(FNAME[:len(FNAME)-3])+'.new','wb')

            fout.write(reportHead+'\r\n')
            fout.write( '@@VERSION:1\r\n')
            for rpt in rptlist:
                fout.write( rpt +'\r\n')
            for proc in procs:
                if proc[0] in rptlist:
                    fout.write( '@@PROC\r\n' )
                    fout.write( proc[0]+'\r\n' )
                    fout.write( proc[1][0] )
                    print 'Writing proc:',proc[0]
                    for macroname in macrolist:
                        if macroname[0] == proc[0]:
                            print '   macro:',macroname[1]
                            fout.write( '@@MACRO\r\n' )
                            fout.write(macroname[1][:len(macroname[1])-6]+'\r\n')
                            macroLogic(RPATH, macroname[1],fout)
                    for rptfields in reports:
                        if rptfields[0] == proc[0]:
#                            print '   report:',macroname[1]
                            fout.write( '@@RPT\r\n')
                            for rptline in rptfields[1]:
                                fout.write( rptline )
                    for scrn in screens:
                        if scrn[0] == proc[0]:
                            fout.write( '@@SCRN\r\n')
                            for scrline in scrn[1]:
                                fout.write( scrline )
                        else:
                            pass
#                            print scrn[0],'not in',proc[0]
            fout.close()
        else: pass
       
    else:
       print 'ABORTED BY USER'

def test():
    tests = []
    tests.append( chr(1)+'1'+chr(30)+'SE'+chr(1)+'1' )
    tests.append( chr(1)+'1'+chr(30)+'C'+chr(30)+'DAT' )
    mystr = []
    for test in tests:
        mystr = []
        convertQueuedStringEx(test,mystr)
        print mystr
#try:
#    test()
main()

#except :
#    errno, errstr = sys.exc_info()
    
#    print str(errno), errstr

