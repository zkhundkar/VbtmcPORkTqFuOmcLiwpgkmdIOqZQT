#!/usr/bin/env python

from Tkinter import *
import tkMessageBox
import logging
#from os import *
from socket import *
from time import time, ctime, sleep
import os
import os.path
import sys
from PackageReader import PkgReader
from PackageReaderCS import PkgReaderCS
from PackageReaderCSdefs import PkgReaderCSXML
from PackageReports import PkgRWReader
from PackageReportsXML import PkgRW2XML
from PackageReaderXML import PkgReaderXML
from VSBReader2 import VSBReader
from PackageDiff import pkgDiff
from VSBdictionaryXML import VSBdictXML
import xml.etree.ElementTree as ET

BUFSIZ = 1024

#---------------------------------------------------------------------------

class NPRPkgtools(Tk):

    settings = {}

    def __init__(self, parent, cmdargs=[]):
        global ET

        
        self.top = self
        Tk.__init__(self,parent)
        self.parent=parent
        self.initialize(cmdargs)
        self.readSettings()
        logging.basicConfig(filename='out.log',format='%(levelname)s: [%(asctime)s] %(message)s',level=logging.DEBUG)
        logging.info("NPR Tools started")
        self.logger = logging.getLogger()
        
        
    def close(self):
        try:
#            settings=self.settings['main']
            if os.path.isfile(self.settings["main"]["source"]):
                f_ini = open("./"+self.settings["main"]["source"],"w")
                for k in self.settings.keys():
                    f_ini.write('['+k+']\n')
                    settings = self.settings[k]
                    if k=='recent':
                        if len(settings)>10:
                            settings = settings[len(settings)-10:]
                        f_ini.write('\n'.join(settings))
                    else:
                        for kk in settings:
                            f_ini.write(kk+'='+settings[kk]+'\n')
                    f_ini.write('\n')
                f_ini.close()
        except:
            pass

        self.destroy()
        return 0
    
    def initialize(self, initargs):
        self.status = self.parent
#        self.mys = socket(AF_INET,SOCK_STREAM)
        self.title('NPR Package Tools')
        self.port=2238
        self.job=0
        self.ip='192.168.1.101'
        self.connMode = 'C'
        self.sendStrReady = False
        self.sstr=StringVar(self)
        self.scrfile = 'C:/Iatric/Scantest/scriptIMPSVC.txt'

        for item in initargs:
            if 'SCR=' in item:
                self.scrfile = 'C:/Iatric/Scantest/'+item[4:]
            elif 'J=' in item:
                self.job=item[2:]
            elif 'P=' in item:
                self.port = int(item[2:])
            elif 'I=' in item:
                self.ip = item[2:]
            else:
                pass
        if self.port>1024:
            if len(self.ip)>1 and self.job>0:
                self.connMode = "S"
            else:
                self.connMode = 'C'
            
#        print self.scrfile, self.job, self.port, self.ip

        self.frame = Frame(self, borderwidth=2)
        self.frame.pack(fill=BOTH,expand=5)

        self.cfm = Frame(self.frame)
        self.yscrlbr = Scrollbar(self.cfm)
        self.yscrlbr.pack(side=RIGHT, fill=Y)
        self.xscrlbr = Scrollbar(self.cfm, orient=HORIZONTAL)
        self.xscrlbr.pack(side=BOTTOM, fill=X)
        self.tbox = Listbox(self.cfm,relief=GROOVE, height=10,width=60, background='lightgray', yscrollcommand=self.yscrlbr, xscrollcommand=self.xscrlbr)
        self.tbox.config(font='verdana 8')
        self.yscrlbr.config(command=self.tbox.yview)
        self.xscrlbr.config(command=self.tbox.xview)
        self.tbox.pack(side=LEFT,fill=BOTH, expand=5)
        self.cfm.pack(fill=BOTH,expand=5)
        

#        self.sbox = Entry(self.frame,relief=GROOVE, background='white', foreground='blue', textvariable=self.sstr)
#        self.sbox.config(font='verdana 8')
#        self.sbox.bind('<Return>',self.sendStr)
#        self.sbox.pack(fill=X,expand=0)

#        self.bfm=Frame(self.frame, borderwidth=2)
#        self.b0 = Button(self.bfm,text="NPR Package",command=self.pkgRead)
#        self.b0.pack(side=LEFT)
#        b = Button(self.bfm,text="NPR RW Package",command=self.pkgRW)
#        b.pack(side=LEFT)
#        self.b1 = Button(self.bfm,text="Clear",command=self.clearText)
#        self.b1.pack(side=LEFT)
#        self.b2 = Button(self.bfm, text="Quit", command=self.top.destroy)
#        self.b2.pack(side=LEFT)
#        self.bfm.pack()

    #setStatus('')

    # display the menu
        self.menubar=Menu(self.top)
        self.setupMenu()
        self.top.config(menu=self.menubar)
        self.top.wm_resizable(width=200, height=120)

    def defaultsettings(self):
        dft={ 'CSSHOME':'C:/Iatric', 'JSHOME':'C:/Iatric', 'XSLHOME':'C:/Iatric', 'LastDir':"C:/Iatric Systems"}
        try:
            sm = self.settings['main']
            for k in dft:
                if k not in self.settings['main'].keys():
                    self.settings['main'][k]=dft[k]
                                           
        except KeyError:
            self.settings['main']=dft
        

    def readSettings(self):
        test = os.path.abspath('.')
        self.settings["main"]={}
        self.settings["recent"]=[]
        self.settings["debug"]={}
        if os.path.isfile("./iattools.ini"):
            f_ini = open("./iattools.ini","r")
        
            lines=f_ini.readlines()
            f_ini.close()
            
            section_name='junk'
            section = self.settings[section_name]={}

           
            for line in lines:
                line=line.strip()
                if line.startswith('['): 
                    newname=line.split('[')[1].split(']')[0]
                    if newname==section_name:
                        pass
                    else:
                        self.settings[section_name]=section
                        section_name=newname
                        if section_name=='recent':
                            self.settings[section_name]=[]
                        else:
                            self.settings[section_name]={}
                        section = self.settings[section_name]
                        
                elif line.startswith(';'): pass
                elif not len(line)>0: pass
                else:
                    line=line.split('//')[0]
                    if "=" in line:
                        k,v=line.split('=')
                        k=k.strip()
                        v=v.strip()
                        if len(k)>0:
                            if section_name=='recent':
                                section.append(k.strip().strip('\r\n'))
                            else:
                                section[k]=v
                        else: pass
                    elif len(line)>0 and section_name=='recent':
                        section.append(line.strip().strip('\r\n'))
                    else: pass
                        
            try:
                self.settings[section_name]=section
            except:
                pass
#            for y in self.settings.keys():
#                print y, self.settings[y] 
            self.settings['main']['source']='iattools.ini'
        elif os.path.isfile("./iattools.xml"):
            f_ini = open("./iattools.xml","r")
            lines=f_ini.readlines()
            f_ini.close()

            for line in lines:
                line=line.strip()
                if line.startswith('['): pass
                elif line.startswith(';'): pass
                elif not len(line)>0: pass
                else:
                    line=line.split('//')[0]
                    k,v=line.split('=')
                    k=k.strip()
                    v=v.strip()
                    if len(k)>0:
                        self.settings[k]=v
                    else: pass
        else: pass
        self.defaultsettings()

    def selScript(self):
        from tkFileDialog import askopenfilename
        basedir='C:/IATRIC/SCANTEST/'
        fa = askopenfilename(initialdir=basedir, filetypes=[("", "*.*")])
        if len(fa)>0:
            self.scrfile = fa

    def clearText(self):
        self.tbox.delete(0,END)

    def pkgRead(self):
        PkgReader([self.top,self.settings])

    def pkgReadCS(self):
        PkgReaderCS([self.top])

    def pkgReadCSdefs(self):
        PkgReaderCSXML([self.top])

    def rwpkgCS(self):
        from RWPkgReaderCS import RWPkgReaderCS as rwCS
        rwCS([self.top])

    def nprW(self):
        from RWrewriter import RWrewriter as rwr
        rwr([self.top])

    def pkgxml(self):
        PkgReaderXML([self.top,self.settings])
        self.tbox.insert(END,'pkgReaderXML -- done')
        self.top.update()

    def pkgRW(self):
        PkgRWReader([self.top])

    def pkgRWX(self):
        PkgRW2XML([self.top])

    def compPkg(self):
        pkgDiff([self.top,self.settings])

    def compRWRAC(self):
        from RWcompare import RWcompare
        RWcompare([self.top,self.tbox,self.settings])

    def vsbMsgRead(self):
        VSBReader([self.top])
        self.tbox.insert(END,'VSBReader -- done')
        self.top.update()

    def vsbDictXml(self):
        VSBdictXML([self.top,self.settings])
        self.tbox.insert(END,'VSB Dictionary conversion -- done')
        self.top.update()

    def vsbDictCSXml(self):
        self.settings['csm']=True
        VSBdictXML([self.top,self.settings])
        self.tbox.insert(END,'VSB Dictionary conversion -- done')
        self.top.update()

    def openAsServer(self):
        print 'Not implemented', self.mys

    def openAsClient(self):
        print 'Not implemented', self.mys

    def sendok(self):
        print 'OK', self.mys

    def sendStr(self,ev=None):
        print "Send string",self.sstr.get()
        self.sendStrReady = True

    def unk(self):
            tkMessageBox.showinfo("Warning", "This option is not available")        

    def setupMenu(self):
    #    global connections, __sites
        #global __wkConn, __wktype

    #    wksparams =Menu(menubar, tearoff=0)
        s = 'setupmenu'
#Create our Python menu
        self.pkgmenu = Menu(self.menubar)
#Add our Menu to the Base Menu
        self.menubar.add_cascade(label="Package", menu=self.pkgmenu)
        self.pkgmenu.add_command(label="Magic - normal", command=self.pkgRead)
        self.pkgmenu.add_command(label="Magic - xml", command=self.pkgxml)
        self.pkgmenu.add_command(label="CS Magic - normal", command=self.pkgReadCS)
        self.pkgmenu.add_command(label="CS Magic - ddefs", command=self.pkgReadCSdefs)
#        self.menubar.add_separator()
        self.rptmenu = Menu(self.menubar)
        self.menubar.add_cascade(label="Reports", menu=self.rptmenu)
        self.rptmenu.add_command(label="Magic - normal", command=self.pkgRW)
        self.rptmenu.add_command(label="Magic - XML", command=self.pkgRWX)
        self.rptmenu.add_command(label="CS - normal", command=self.rwpkgCS)
        self.rptmenu.add_command(label="Magic - rewrite", command=self.nprW)
        
#Add VSBReader Menu to the Base Menu
        self.vsbmenu = Menu(self.menubar)
        self.menubar.add_cascade(label="VSB", menu=self.vsbmenu)
        self.vsbmenu.add_command(label="Reader", command=self.vsbMsgRead)
        self.vsbmenu.add_command(label="Convert Dictionary", command=self.vsbDictXml)
        self.vsbmenu.add_command(label="Convert CS Dictionary", command=self.vsbDictCSXml)
#        self.pkgmenu.add_command(label="Magic - xml", command=self.pkgxml)
#        self.pkgmenu.add_command(label="CS Magic - normal", command=self.pkgReadCS)

#Add compare Menu to the Base Menu
        self.comparemenu = Menu(self.menubar)
        self.menubar.add_cascade(label="Compare", menu=self.comparemenu)
        self.comparemenu.add_command(label="Compare Folders", command=self.compPkg)
        self.comparemenu.add_command(label="Compare RAC ABS Reports", command=self.compRWRAC)
    # setWktype(__wktype)
    # setConntype(__wkConn)

#def main(argv=[]):
#    app=NPRPkgtools(argv)
#    app.mainloop()

if __name__ == '__main__':
#    main(sys.argv[1:])
    app=NPRPkgtools(None, sys.argv[1:])
    app.protocol("WM_DELETE_WINDOW", app.close )     
    app.mainloop()

