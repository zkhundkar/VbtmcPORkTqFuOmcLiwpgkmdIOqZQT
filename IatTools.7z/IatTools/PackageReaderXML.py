#   "MEDITECH.CUST.RPTS^Hospital name^mis^directory^user^date^"A"(SEG??)^Comment for download report
#   @@VERSION:#
#   reportname
#   reportname
#   for each report
#   @@PROC
#   report  name
#   {dpm,abbrname,"U"ser(Responsible),"Y","Y","","@Inquiry","","Y","","",""}
#   @@MACRO (for each macro)
#   fullname
#   content section
#       line#
#       line
#   
#   Section #1
#       Package info and menus
#   Section #2
#   DPM names, one per line
#   Section #3
#       procedure names
#   Section #4
#       Application data
#   Section #5
#       Definitions (IA, IE, IEE, .. )
#   Section #6
#   procedures and macros (source files)
#   
from PackageReader import PkgReader

class PkgReaderXML(PkgReader):
    source = []
    home = '../'
    reportdef = []
    screendef=[]
    datadef=[]
    menudef=[]
    sectionNames = {0:"packageInfo", 1:'dpmList', 2:'procList', 3:'appl-data', 4:'nprNodes',
                5:'procedures'}
    settings = {}
    
    def __init__(self, initargs=[]):
        self.logging=False
        
        if len(initargs)>0:
            self.top=initargs[0]
        if len(initargs)>1:
            self.settings = initargs[1]
        if "XSLHOME" in self.settings:
            self.home=self.settings["XSLHOME"]+'/'
        self.run()
        
    def addDpmList(self, fout):
        fout.write('\n<dpmList>')
        for dpm in self.dpmNames:
            fout.write('<dpm name=\"'+dpm+'\" />\n')
        fout.write('</dpmList>')


    def parseInput4XML(self, fin,fout):
        global packageInfo, dpmNames, procedureNames, definitions, applicationInfo, source

        done = 0 
        RPTLIST = 1
        MACRO = 2
        SCREEN = 3
        REPORT = 4
        
        STATE = 0
        
        sections = []
        segments = []
        
        screens = []
        lines = []
        secptr=0
        segptr=0
        currentSegment = []
        currentSection = ''
        currentMacro = ''
        currentScreen = ''
        currentReport = ''
        
        while not done:
            sline = fin.readline()
    #        print sline
            if SECTION_DEL in sline:
                slineSection = sline.split(SECTION_DEL)
                for term in slineSection:
                    currentSection = currentSection+term
                    sections.append(currentSection)
                    currentSection = ''

            else: 
                currentSection = currentSection+sline
            if sline == "" : done=1

        if len(currentSection)>0:
            sections.append(currentSection)

        printnprNodes(sections[4])

    def printPackageInfo(self, pkg):
        global SEGMENT_DEL, fout

        i = 0
        MENU_STARTED = False
        pkgHeads = ["pkgName" , 'pkgAppl' , 'pkgDetail' , 'menu' ]
        segments = pkg.split(SEGMENT_DEL)
        print('<pkgInfo>')
        for segment in segments:
            segHdr = pkgHeads[i]
            if segHdr=='pkgDetail':
                print('<'+segHdr+'>')
                printpkgDetail(segment)
                print('</'+segHdr+'>')
            elif segHdr == 'pkgName' :
                qs = []
                convertQueuedString(segment,qs)
                print('<'+segHdr+'>'+qs[0]+'</'+segHdr+'>')
            elif segHdr == 'menu' and not MENU_STARTED :
                print('<'+segHdr+'s>'+'<'+segHdr+'>'+segment+'</'+segHdr+'>')
                MENU_STARTED = True
            else :
                print('<'+segHdr+'>'+segment+'</'+segHdr+'>')

            if i+1 < len(pkgHeads): i = i+1
            else: pass

        if MENU_STARTED:
            print('</menus>')
        print('</pkgInfo>')
        
    def printpkgDetail(self, detail):
        global fout
        pkgDetail = ['unk','unk', 'definitions', 'include-defs','unk','unk','unk','screens','reports','logic','macro','unk']
        qs=[]
        convertQueuedString(detail,qs)
        i=0
        for item in qs:
            segHdr = pkgDetail[i]
            print('<'+segHdr+'>'+item+'</'+segHdr+'>')
            if i+1< len(pkgDetail): i = i+1
            else: pass
        
    def printprocList(self, procl):
        global fout, SEGMENT_DEL
        
        print('<procList>')
        proclist = procl.split(SEGMENT_DEL)
        for pr in proclist:
            nodes = pr.split(chr(30))
            if len(nodes)>1:
                print('<proc dpm=\"'+nodes[0]+'\">'+nodes[1]+'</proc>')
            else:
                print('<proc node=\"nil\">'+pr+'</proc>')
        print('</procList>')

    def printApplData(self, appl):
        global fout, SEGMENT_DEL
        
        print('<applData>')
        dpmlist = appl.split(SEGMENT_DEL)
        for dpm in dpmlist:
            print('<appSeg name=\"'+dpm+'\" />')
        print('</applData>')

    def printdpmList(self, dpms):
        global fout, SEGMENT_DEL
        
        print('<dpmList>')
        dpmlist = dpms.split(SEGMENT_DEL)
        for dpm in dpmlist:
            print('<dpm name=\"'+dpm+'\" />')
        print('</dpmList>')

    def printnprNodes(self, npr):
        global fout, SEGMENT_DEL
        
        
        print('<nprNodes>')
        nprNodes = npr.split(SEGMENT_DEL)
        count = 0
        nodeiskey = False
        oktoprint = False
        for node in nprNodes:
            if node[:3]=='IS\x1e':
                oktoprint = True
                nodeiskey = True
            else: pass
            
            if count<100 and oktoprint:
                if nodeiskey:
                    print('<nprnode>'+node.replace('\x1e','|')+'</nprnode>')
                    nodeiskey = False
                else:
                    print('<nodeval>'+node+'</nodeval>')
                    nodeiskey=True
                count += 1
            else: pass
        print('</nprNodes>')

    #    for macro in macros:
    #       writelog 'Macro '+ macro[0]
    #    for screen in screens:
    #       print 'Screen', screen[0]
    #    for report in reports:
    #       print 'Report', report[0]

    def escapedhtmString(self, s):
        return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

    def fileDatadefs(self):

        fout = file(self.RPATH+'/'+'datadefs.xml','wb')

        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'datadefs.xsl" ?>\n\n')
        fout.write('<datadef>')

        self.addDpmList(fout)

        xmlnodes = []
        statenames = {'IE':'dataSegments', 'IEE':'elements'}
        nodeFlag = 0
        nodeKeys = ''
        elementQ = ''
        nodeValList = []
        crflag = ''
        elemstate = ''
        segName = ''

        for nprNode in self.definitions:
    #        if len(nprNode)>1: writelog( str(nprNode) )
            nodeType = nprNode[0].split(chr(30))[0]
    #        if nodeFlag==1 and nodeType not in ['IE','IEE','IP','IR','IM','IS','IRI']:
    #            writelog(nodeKeys+', '+crflag+', '+nprNode)

            if nodeType == 'IE':
                nodeFlag = 1
                nodeKeys = nprNode[0]
                crflag = ''
                if nodeType == elemstate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                elemstate = nodeType
            elif nodeFlag==1 and nprNode[len(nprNode)-1].endswith('\n'):
                crflag += "".join(nprNode)
    #            print 'trap1', nodeKeys, crflag
            elif nodeFlag==1:
                nodeFlag = 0

    #            if len(crflag)>0: print nodeKeys, crflag
                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
    #               if len(nodeKeys)>2 and len(nodeKeys[2])>0:
    #                   elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ = nodeKeys[3][0]
    #               if len(nodeKeys)>4 and len(nodeKeys[4])>0:
    #                   elementQ += nodeKeys[4][0]
    #               if elementQ in ['P','PP','PF','PFC','PS','PM']:
    #                   nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]
                if elementQ in ['E','C','S']:
                    nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
    #            nodeKeys = "|".join(nodeKeys)
                   
                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['','S']: 
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)
                    nprNode = '|'.join(nodeValList)

    #               nodeValList = []
    #               convertQueuedString(nprNode[0],nodeValList)
    #               fb.write( '{'+nodeKeys+'}|{' + '|'.join(nodeValList)+'}\n')
                   
    #            fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
                if len(nodeKeys)==3:
                    if len(segName)>0:
                        fout.write('</segment>\n')
                    fout.write('<segment name=\"'+nodeKeys[1]+'.'+nodeKeys[2]+'\" dpm=\"'+nodeKeys[1]+'\"><dpm>'+nodeKeys[1]+'</dpm><name>'+nodeKeys[2]+'</name>')
                    fout.write('<active>'+nodeValList[0]+'</active><dpmLetters>'+nodeValList[1].replace('&','&amp;')+'</dpmLetters>')
                    fout.write('<physBase>'+nodeValList[2].replace('&','&amp;')+'</physBase><physRoot>'+nodeValList[3].replace('&','&amp;')+'</physRoot>')
                    if len(nodeValList[4])>0: fout.write('<parent>'+nodeValList[4]+'</parent>')
                    if len(nodeValList[7])>0: fout.write('<constant>'+nodeValList[7]+'</constant>')
                    fout.write('<extname>'+nodeValList[10]+'</extname>')
                    if len(nodeValList[8])>0: fout.write('<localSubscripts>'+nodeValList[8]+'</localSubscripts>')
                    fout.write('<segType>'+nodeValList[5]+'</segType>')
                    fout.write('<mapsTo>'+nodeValList[6]+'</mapsTo>')
                    fout.write('<elemCount>'+nodeValList[11]+'</elemCount>')
                    fout.write('\n<nodevalue>'+nprNode.replace('&','&amp;')+'</nodevalue>\n')
                    segName = nodeKeys[2]
                if len(nodeKeys)>3:
                    nodekeytype = nodeKeys[3].split('|')
                    if nodekeytype[0]=='E':
                        fout.write('<field rank=\"'+nodekeytype[1]+'\"><fldname>'+nprNode.replace('&','&amp;')+'</fldname></field>\n')
                    elif nodekeytype[0]=='S':
                        fout.write('<subscript rank=\"'+nodekeytype[1]+'\"><fldname>'+nodeValList[0]+'</fldname><physName>'+nodeValList[1].replace('&','&amp;')+'</physName></subscript>\n')
                    elif nodekeytype[0]=='C':
                        fout.write('<child>'+nodeKeys[4]+'</child>\n')
                    elif nodekeytype[0]=='I':
                        fout.write('<index>'+nodeKeys[4]+'</index>\n')
                    else: pass
    #                    fout.write('<attrs><fldname>'+':'.join(nodeKeys[3:])+'</fldname><fldval>'+nprNode.replace('&','&amp;')+'</fldval></attrs>\n')
            else: nodeFlag = 0

        if len(segName)>0:
            fout.write('</segment>\n')
        elementQ = ''
        nodeValList = []
        keylabels = ['','dpm','elementName']
        elemName = ''
        nodelabels = ['Pointer','DataType','offset','physName','localName','length','jfy','dataseg','rank']
        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType == 'IEE':
                nodeFlag = 1
                nodeKeys = nprNode[0]
                crflag = ''
                if nodeType == elemstate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                elemstate = nodeType
            elif nodeFlag==1 and nprNode[len(nprNode)-1].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ = nodeKeys[3][0:2]
                if elementQ in ['DA']:
                    nodeKeys[3] = nodeKeys[3][:len(elementQ)] + '|' + nodeKeys[3][len(elementQ)+1:]
    #                elif elementQ == 'E' or elementQ == 'D' or elementQ=='S':
    #                    nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
    ##            nodeKeys = "|".join(nodeKeys)
    #                else:
    #                    nodeKeys = nodeKeys[0]+chr(30) + nodeKeys[1]
    #                    nodeKeys = nodeKeys.replace(chr(30),'|')
               
                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['']:
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)

                    newnodeValues =[]
                    for piece in nodeValList:
                        newnodeValues.append(piece.replace('|',""))
                       
                    nprNode = '|'.join(newnodeValues)

    #                nodeValList = []
    #                convertQueuedString(nprNode[0],nodeValList)
    #                fb.write( '{'+nodeKeys+'}|{' + '|'.join(nodeValList)+'}\n')
                if len(nodeKeys)==3:
    #                fout.write( '<keys>')
    #                i=1
    #                while i<len(nodeKeys):
    #                    fout.write('<'+keylabels[i]+'>'+nodeKeys[i]+'</'+keylabels[i]+'>')
    #                    i += 1
                    if len(elemName)>0: fout.write('</fld-def>\n')

                    elemName = nodeKeys[2]
                    fout.write('<fld-def element=\"'+elemName+'\" dpm=\"'+nodeKeys[1]+'\">')
                    fout.write('<dpm>'+nodeKeys[1]+'</dpm>')
                    i=0
                    lbl=''
                    while i<len(nodeValList):
                        try:
                            lbl=nodelabels[i]
                        except:
                            lbl="unk-"+str(i)
                            
                        if len(nodeValList[i])>0:
                            fout.write('<'+lbl+'>' + nodeValList[i].replace('&','&amp;')+'</'+lbl+'>')
                        i += 1
                elif len(nodeKeys)>3:
                    attribute = nodeKeys[3][0]
                    qualifier = ''
                    if attribute =='C':
                        attribute="attr"
                        qualifier = nodeKeys[4].replace('\x01','|')
                    elif attribute == 'D':
                        attribute="doc"
                        qualifier='DOC-'+nodeKeys[3][1]
                    fout.write('<fld-attr attr-type=\"'+attribute+'\">')
                    fout.write('<attr-qual>'+qualifier+'</attr-qual>')
                    fout.write('<attr>'+self.escapedhtmString(nprNode)+'</attr></fld-attr>')
                    
            else: nodeFlag = 0
        if len(elemName)>0: fout.write('</fld-def>\n')
        while len(xmlnodes)>0:
            fout.write('</'+xmlnodes.pop()+'>\n')
        fout.write('</datadef>')
        fout.close()
        

    def fileReports(self):
#        global definitions, RPATH

        HDR_ELEMS = ['active','name','dpm','old-proc','dataseg','rptTitle','type',
                     'points','charsperLine','linesperInch','prtlinesperpage','seg-dpm',
                     'page-size','logical-name','page-trailer','rpt-header','rpt-trailer',
                     'detail','page-header','path','unk']

        reportKeyMap = {'F':'field', 'P':'picLine', 'AT':'audit', 'N':'footnote', 'FI':'fieldIndex',
                        'U':'update','T':'subscript','I':'rptIndex'}    
        fout = file(self.RPATH+'/'+'reports.xml','wb')
        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'reports.xsl" ?>\n\n')
    #    fout.write('<Reports>')

        xmlnodes = []
        statenames = {'IR':'Reports'}
        nodeFlag = 0
        nodeKeys = ''

        rptstate = ''
        rptname =''

        elementQ = ''
        nodeValList = []
        crflag = ''
        fieldname=''

        print len(self.definitions)
        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType == 'IR':
                nodeFlag = 1
                crflag = ''
                nodeKeys = nprNode[0]
                if nodeType == rptstate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                rptstate = nodeType
            elif nodeFlag==1 and nprNode[0].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                testKey = nodeKeys.split(chr(30))
                subkeys=[]
                if len(testKey)>2:
                    if testKey[2][:2] in ['AT','DC','FI','SE']:
                        self.convertQueuedString(testKey[2][2:],subkeys)
                        testKey[2]=testKey[2][:2]
                        testKey.append(subkeys[0])

                    elif testKey[2][0] in ['F','N','I','L','P','U','T']:
                        if len(testKey[2])>1:
                               self.convertQueuedString(testKey[2][1:],subkeys)
                               testKey[2]=testKey[2][:1]
                        else:  pass


                if len(testKey)>3:
                    if testKey[3] in ['CL','LC']:
                        if '\x01' in testKey[4]:
                            subkeys.append(testKey[4].split('\x01')[1])
                            testKey[4]=testKey[4].split('\x01')[0]
                        elif '\x02' in testKey[4]:
                            subkeys.append(testKey[4].split('\x02')[1])
                            testKey[4]=testKey[4].split('\x02')[0]
                        else:
                            testKey[4]=testKey[4][:3]
                nodeKeys = testKey
                    
                elementQ = ''
                if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                    elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ += nodeKeys[3][0]
#                if elementQ in ['F','FS','FC','L','LC','N','P','FI']:
#                    nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]

    #            nodeKeys = "|".join(nodeKeys)

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                nodeValList = []
                try:
                    if nodeKeys[2] in ['','DC','N','P']:
                        pass
                    elif nodeKeys[3] in ['C','CL','DA','DT']:
                        pass
                    else:
                        self.convertQueuedString(nprNode,nodeValList)
                        nprNode = '|'.join(nodeValList)
                except:
                        self.convertQueuedString(nprNode,nodeValList)
                        nprNode = '|'.join(nodeValList)
                    
                if rptname == nodeKeys[1]:
                    pass
                elif rptstate == 'IR':
                    if len(rptname)>0:
                        fout.write('</'+xmlnodes.pop()+'>\n')
                        
                    fout.write('<report name=\"'+nodeKeys[1]+'\">')
                    xmlnodes.append('report')
                    rptname = nodeKeys[1]
                else:
    #                if len(menuname)>0:
    #                    fout.write('</'+xmlnodes.pop()+'>\n')
                    print nodeType, nodeKeys, nprNode
                    fout.write('<unknown name=\"'+nodeKeys[2]+'\" appl=\"'+nodeKeys[1]+'\" active=\"'+nprNode[0]+'\" />')
                    menuname = ''
    #                xmlnodes.append('index')
                if len(nodeKeys)==2:
                    i = 0
                    irange = len(HDR_ELEMS)
                    hdrlabel=''
                    rankId=''
                    rank=i
                    for headerElement in nodeValList:
                        hdrlabel=HDR_ELEMS[i]
                        if hdrlabel=='unk':
                            rankId=' offset=\"'+str(rank)+'\"'
                        else:
                            rankId=""
                            
                        fout.write('<'+HDR_ELEMS[i]+rankId+'>'+self.escapedhtmString(headerElement)+'</'+HDR_ELEMS[i]+'>\n')
                        if i+1 < irange : i += 1
                        rank += 1
                elif len(nodeKeys)>2 or len(nodeKeys)==2 and len(subkeys)>0:
#                    nodekeylist = nodeKeys[2]
                    nodekeyQ = nodeKeys[2]
#                    if len(nodekeylist)>1: nodeId=nodekeylist[1]
#                    else: nodeId="NaN"
                    
                    if nodekeyQ=='FI':
                        op=False
                        try:
                            fout.write( '<fieldIndex row=\"'+subkeys[0]+'\" col=\"'+subkeys[2]+'\" >')
                            op=True
                            fout.write( '<length>'+nodeValList[0]+'</length>')
                            fout.write( '<field-num>'+nodeValList[1]+'</field-num>')
                        except:
                            pass
                        if op:
                            fout.write('</fieldIndex>')
                    elif nodekeyQ == 'F':
                        if len(nodeKeys)==3:
                            fout.write( '<field num=\"'+subkeys[0]+'\">')
                            fout.write( '<fldname>'+nodeValList[0]+'</fldname>')
                            fout.write( '<physAddr>'+nodeValList[1]+'</physAddr>')
                            fout.write('<linenum>'+nodeValList[len(nodeValList)-1]+'</linenum>')
                            fout.write('</field>\n')
                        elif len(nodeKeys)>3:
                            if len(subkeys)>0:
                                fout.write('<fldproperties num=\"'+subkeys[0]+'\">')
                            else:
                                fout.write('<fldproperties >')
    #                    fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>')
                            if nodeKeys[3] == 'C':
                                if len(nodeKeys)==4:
                                    fout.write('<attribute type=\"'+nodeKeys[4]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                            elif nodeKeys[3] == 'CL':
                                if len(nodeKeys)>4:
                                        fout.write('<attrib-index type=\"'+nodeKeys[4]+'\" rank=\"'+subkeys[1]+'\">')
                                        fout.write(self.escapedhtmString(nprNode)+'</attrib-index>')
                                else: pass
                                
                            elif nodeKeys[3] == 'DA':
                                fout.write('<appl-doc num=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                            elif nodeKeys[3] == 'DT':
                                fout.write('<tech-doc num=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                            elif len(nodeKeys)>4 and nodeKeys[4] == 'SE':
                                try:
                                    fout.write('<fld-select rank=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                                except :
                                    pass
                            elif len(nodeKeys)>4 and nodeKeys[4][:2] == 'SE':
                                fout.write('<sortElement order=\"'+nodeKeys[3][1:]+'\">')
                                fout.write('<operator>'+nodeValList[0]+'</operator>')
                                fout.write('<selField>'+nodeValList[1]+'</selField>')
                                if len(nodeValList)>2:
                                    fout.write('<scrPrompt>'+nodeValList[2]+'</scrPrompt>')
                                fout.write('</sortElement>\n')
                            elif nodeKeys[3][:1] == 'S':
                                try:
                                    fout.write('<sortElement order=\"'+nodeKeys[4][3:]+'\">')
                                    fout.write('<operator>'+nodeValList[0]+'</operator>')
                                    fout.write('<selField>'+nodeValList[1]+'</selField>')
                                    if len(nodeValList)>2:
                                        fout.write('<scrPrompt>'+nodeValList[2]+'</scrPrompt>')
                                    fout.write('</sortElement>\n')
                                except:
                                    pass
                            else:
                                fout.write('<type>'+self.escapedhtmString('|'.join(nodeKeys))+'</type>')
                                fout.write('<values>' + self.escapedhtmString(nprNode)+'</values>')
                            fout.write('</fldproperties>\n')
                    elif nodekeyQ=='P':
                        fout.write( '<picLine num=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</picLine>\n')
                    elif nodekeyQ=='N':
                        noteq=nprNode.split(' ')
                        fout.write( '<footnote num=\"'+subkeys[0]+'\" type=\"'+noteq[0]+'\">')
                        if len(noteq)>2:
                            fout.write('<qualifier>'+noteq[1]+'</qualifier>')
                            offs=(len(noteq[0])+len(noteq[1])+2)
                            fout.write(self.escapedhtmString(nprNode[offs:])+'</footnote>\n')
                        else:
                            fout.write(self.escapedhtmString(nprNode[2:])+'</footnote>\n')
                    elif nodekeyQ=='L':
                        if len(nodeKeys)==3:
                            fout.write( '<regLine num=\"'+subkeys[0]+'\">')
                            fout.write(self.escapedhtmString(nprNode)+'</regLine>\n')
                        elif len(nodeKeys)>3:
                            fout.write('<line-properties num=\"'+subkeys[0]+'\">')
    #                    fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>')
                            if nodeKeys[3] == 'C':
                                fout.write('<line-attribute type=\"'+nodeKeys[4]+'\">'+self.escapedhtmString(nprNode)+'</line-attribute>\n')
                            elif nodeKeys[3][:2] == 'CL':
                                fout.write('<line-attrib-len type=\"'+nodeKeys[4]+'\">'+self.escapedhtmString(nprNode)+'</line-attrib-len>\n')
                            else: pass
                            fout.write('</line-properties>')
                                
                    elif nodekeyQ == 'I':
                        fout.write( '<rptIndex num=\"'+subkeys[0]+'\">')
                        fout.write(self.escapedhtmString(nprNode)+'</rptIndex>\n')
                    elif nodekeyQ == 'T':
                        fout.write( '<select-temp rank=\"'+subkeys[0]+'\">')
                        fout.write('<nodeVal>'+self.escapedhtmString(nprNode)+'</nodeVal>                                   </select-temp>\n')
                    elif nodekeyQ == 'AT':
                        fout.write( '<audit-log log=\"'+subkeys[0]+'\">')
                        fout.write('<user>'+nodeValList[0]+'</user><act-event>'+nodeValList[1]+'</act-event></audit-log>\n')
                    else:
                        nodeKeys = '|'.join(nodeKeys).join(subkeys)
                        fout.write( '<nodeQ>'+self.escapedhtmString(nodekeyQ)+'</nodeQ>')
                        fout.write( '<nprKey>'+self.escapedhtmString(nodeKeys)+'</nprKey>')
#                        if ord(nprNode[0])<32:
#                            nnode=[]
#                            self.convertQueuedString(nprNode,nnode)
#                            nprNode="|".join(nnode)
                        fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>\n')
                    
                else:
                    nodeKeys = '|'.join(nodeKeys)
                    fout.write( '<nprKey>'+self.escapedhtmString(nodeKeys)+'</nprKey>')
                    fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>\n')
            else: nodeFlag = 0
                   
        while len(xmlnodes)>0:
            fout.write('</'+xmlnodes.pop()+'>\n')
    #    fout.write('</Reports>')
        fout.close()

    def fileMenus(self):
#        global definitions, RPATH

        fout = file(self.RPATH+'/'+'menus.xml','wb')
        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'menus.xsl" ?>\n\n')
 #       fout.write('<menuList>')

        xmlnodes = []
        statenames = {'IM':'menus', 'IMI':'menuIndex'}
        nodeFlag = 0
        nodeKeys = ''

        elementQ = ''
        nodeValList = []
        crflag = ''

        menustate = ''
        menuname = ''

        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType in ['IM','IMI']:
                nodeFlag = 1
                crflag = ''
                nodeKeys = nprNode[0]
                if nodeType == menustate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                menustate = nodeType
                    
            elif nodeFlag==1 and nprNode[0].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
                if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                    elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ += nodeKeys[3][0]
                if elementQ in ['O','P']:
                    nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]

                nodeKeys = "|".join(nodeKeys)

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['','O']: 
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)
    #                nprNode = '|'.join(nodeValList)
                    nprNode = nodeValList
                    
                nodeKeys = nodeKeys.split('|')
                if menuname == nodeKeys[1]:
                    pass
                elif menustate == 'IM':
                    if len(menuname)>0:
                        fout.write('</'+xmlnodes.pop()+'>\n')
                        
                    fout.write('<menu name=\"'+nodeKeys[1]+'\">')
                    xmlnodes.append('menu')
                    menuname = nodeKeys[1]
                else:

                    fout.write('<index name=\"'+nodeKeys[2]+'\" appl=\"'+nodeKeys[1]+'\" active=\"'+nprNode[0]+'\" />')
                    menuname = ''
    #                xmlnodes.append('index')
                if elementQ =='P':
    #                print('<picLine linenum=\"'+str(nodeKeys)+'\">'+nprNode+'</picLine>')
                    fout.write('<picLine linenum=\"'+nodeKeys[3]+'\">'+self.escapedhtmString(nprNode)+'</picLine>')
                elif elementQ == 'O':
                    fout.write('<routine rlink=\"'+nodeKeys[3]+'\">')
                    fout.write('<title>'+self.escapedhtmString(nprNode[0])+'</title><proc>'+nprNode[1]+'</proc>')
                    fout.write('<menu-proc>'+nprNode[2]+'</menu-proc>')
                    fout.write('<proc-args>'+self.escapedhtmString(nprNode[3])+'</proc-args>')
                    fout.write('<piclink>'+nprNode[5]+'</piclink>')
                    fout.write('</routine>')
                elif elementQ == '':
                    fout.write('<appl access=\"'+nprNode[3]+'\">'+nprNode[0]+'</appl><name>'+nprNode[1]+'</name>')
                    fout.write('<responsible>'+nprNode[2]+'</responsible>')
                    fout.write('<description>'+self.escapedhtmString(nprNode[6])+'</description>')
                    
                    
            else: nodeFlag = 0
        
        while len(xmlnodes)>0:
            fout.write('</'+xmlnodes.pop()+'>\n')
#        fout.write('</menuList>')
        fout.close()

    def fileScreens(self):
#        global definitions, RPATH, fout

        fout = file(self.RPATH+'/'+'screens.xml','wb')
        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'screens.xsl" ?>\n\n')
        fout.write('<screens>')

        self.addDpmList(fout)
        nodeFlag = 0
        nodeKeys = ''

        elementQ = ''
        nodeValList = []
        crflag = 0

        nodeTypeList = {"U":"unknown", 'P':"picLine", 'S':"section",'F':"field"}
        ROOT, PICTURE, SECTION, FIELD = ('U','P','S','F')
        scrname = ''
        scrattr=''
        nodeClass = ROOT
        lasttype = ROOT

        for nprNode in self.definitions:
           nodeType = nprNode[0].split(chr(30))[0]
           if nodeType == 'IS':
               nodeFlag = 1
               crflag = ''
               nodeKeys = nprNode[0]
           elif nodeFlag==1 and nprNode[0].endswith('\n'):
               crflag += "".join(nprNode)
           elif nodeFlag==1:
               nodeFlag = 0

               nodeKeys = nodeKeys.split(chr(30))
               elementQ = ''
               if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                   elementQ = nodeKeys[2][0]
               if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                   elementQ += nodeKeys[3][0]
               if len(nodeKeys)>4 and len(nodeKeys[4])>0:
                   elementQ += nodeKeys[4][0]
               if elementQ in ['P','PP','PF','PFC','PS','PM']:
                   nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]
               if elementQ in ['PM']:
                   nodeKeys[3] = nodeKeys[3][0:2] + '|' + nodeKeys[3][3:]
               if elementQ in ['PF','PS','PFC','PP']:
                   nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
               if elementQ in ['PFC']:
                   if len(nodeKeys)>5:
                       if nodeKeys[5][:4]=='FCL0': nodeKeys[5] = 'SCL'
               nodeKeys = "|".join(nodeKeys)
               nodeKeys = nodeKeys.split('|')
               if len(nodeKeys) > 2:
                   if len(nodeKeys[-1])>0: pass
                   else:
                       nodeKeys.pop(len(nodeKeys)-1)
                       pass
                   
               
               nprNode = crflag + "".join(nprNode)
               crflag = ''

               if elementQ in ['','P','PF','PM','PS']: 
                   nodeValList = []
                   self.convertQueuedString(nprNode,nodeValList)
                   nprNode = '|'.join(nodeValList)

               nprNode = nprNode.replace('>','&gt;') 
               nprNode = nprNode.replace('<','&lt;') 
               nprNode = nprNode.replace('&','&amp;') 
               if len(nodeKeys)==2:
                   if scrname==nodeKeys[1]:
                       print "Error in logic"
                   elif len(scrname)>0:
                       scrname = nodeKeys[1]
                       if nodeClass == ROOT: 
                           pass
                       else:
                           fout.write('</'+nodeTypeList[nodeClass]+'s>')
                       fout.write('</screen><screen>')
                       nodeClass = ROOT
                   else:
                       scrname = nodeKeys[1]
                       fout.write('<screen>')
                   fout.write(self.parseXML(['screen'],nprNode))
               elif len(nodeKeys)==4:
                   fout.write(self.parseXML(['title'],nprNode.strip('\n')))
               elif len(nodeKeys)==6:
                   if nodeKeys[4] in nodeTypeList.keys():
    #                   fout.write('<!--'+nodeClass+'; '+str(nodeKeys)+'-->')
                       element = nodeTypeList[nodeKeys[4]]
                       if nodeClass == FIELD:
                           fout.write('</'+nodeTypeList[nodeClass]+'>')
                       if nodeClass == nodeKeys[4]:
                           pass
                       else:
                           if nodeClass == ROOT: 
    #                           fout.write('<!--(new)'+nodeClass+'; '+ROOT+', '+str(nodeKeys)+'-->')
                               fout.write('<'+element+'s>')
                           else:
                               fout.write('</'+nodeTypeList[nodeClass]+'s><'+element+'s>')
                       fout.write('<'+element+'>'+self.parseXML(nodeKeys[4:],nprNode))
                       nodeClass = nodeKeys[4]
                       if not nodeClass == FIELD:
                           fout.write('</'+element+'>\n')
                   else:
                       pass
               elif len(nodeKeys)==8 and nodeClass == FIELD :
                   if nodeKeys[6]=='C':
                       fout.write('<attrib type=\"'+nodeKeys[7]+'\">'+nprNode+'</attrib>')
               else:
                   pass
                    
    #           fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
           else: nodeFlag = 0
        if len(scrname)>0:
            if not nodeClass == ROOT:
                print nodeClass, nodeTypeList[nodeClass]
                fout.write('</'+nodeTypeList[nodeClass]+'s>\n')
            fout.write('</screen>')
            fout.write('</screens>')
        fout.close()
        
    def parseXML(self, fldtypes, vals):
#        global fout
        retStr = ''
        fldtype = fldtypes[0]
        if fldtype == 'F' :
            nvals = vals.split('|')
            if len(nvals)>4:
                retStr = '<name>'+nvals[0]+'</name><field-id>'+fldtypes[1]+'</field-id><row>'+nvals[3]+'</row>'
                retStr = retStr+'<column>'+nvals[4]+'</column><section>'+nvals[2]+'</section>'
        elif fldtype == 'screen' :
            nvals = vals.split('|')
            if len(nvals)>11:
                retStr = '<name active=\"'+nvals[0]+'\">'+nvals[3]+'</name><dpm idx=\"'+str(self.dpmNames.index(nvals[2])+1)+'\">'+nvals[2]+'</dpm><audit-name>'+nvals[1]+'</audit-name><screen-type>'+nvals[4]+'</screen-type>'
                retStr = retStr +'<dataseg>'+nvals[6]+'</dataseg><multi-page>'+nvals[7]+'</multi-page><fragment>'+nvals[11]+'</fragment>\n'
        elif fldtype == 'title' :
            nvals = vals.split('|')
            if len(nvals)>1:
                retStr = '<title>'+nvals[0]+'</title><file-prompt>'+nvals[1]+'</file-prompt>\n'
        else:
            if len(fldtypes) ==2: pass
            else: print type(fldtypes), fldtypes
            retStr = vals

        return retStr

    # __main__()

    def run(self):
        import time
        import sys
        from os import path, mkdir
        import xml.dom.minidom
        import xml.dom.NodeFilter
        FNAME=self.getfile()
        if FNAME !='':
           fa = file(FNAME,'rb')
           fb = file(path.dirname(FNAME)+'/'+'out.pkg.txt','wb')
           self.openlogfile('XML style output: '+FNAME)

#           print self.logfile.tell()

           self.RPATH = FNAME[:len(FNAME)-4].strip()
           if path.isdir(self.RPATH): pass
           else: mkdir(self.RPATH)

    #       print fb
           self.parseInput(fa)

           self.fileDatadefs()
           self.fileScreens()
           self.fileReports()
           self.fileMenus()
          
    #       print programNames
           if True:
               for dpm in self.dpmNames:
                  if 1:
                      if path.isdir(self.RPATH+'/'+dpm): pass
                      else: mkdir(self.RPATH+'/'+dpm)
#                      self.writelog(str( dpm ))

           fscr = self.RPATH+'/screens.xml'
           if path.isfile(fscr):
               scrns=[]
               try:
                   xt= xml.dom.minidom.parse(fscr)
                   scrns=xt.getElementsByTagName('screen')
               except:
                   pass
            
               for scr in scrns:
                   sname=scr.getElementsByTagName('name')[0]
                   dpm = scr.getElementsByTagName('dpm')[0]
                   dpm.setAttribute('idx','1')
#                   print dpm.firstChild.nodeValue,sname.firstChild.nodeValue
                   try:
                       dpmname=dpm.firstChild.nodeValue
                       s=sname.firstChild.nodeValue
                       s=s[len(dpmname)+1:]
                       if s.split('.')[0]=='con':
                           s='-'+s
                       fs = file(self.RPATH+'/'+dpmname+'/'+s+'_S.xml','w')
                       fs.write('<?xml version="1.0" ?>\n')
                       fs.write('<?xml-stylesheet type="text/xsl" href="C:/Iatric/screens2.xsl" ?>\n\n')
                       fs.write('<screens><dpmList><dpm name=\"'+dpmname+'\"/></dpmList>\n')
                       fs.write(scr.toxml())
                       fs.write('\n</screens>\n')
                       fs.close()
                   except:
#                       fs.close()
                       errinfo = sys.exc_info()
                       errno, errstr = errinfo[:2]
                       print errinfo

           xt="" 
           fscr = self.RPATH+'/reports.xml'
           print fscr, path.isfile(fscr)
           if path.isfile(fscr):
               rpts=[]
               if True:
                   xt= xml.dom.minidom.parse(fscr)
                   rpts=xt.getElementsByTagName('report')
#               except:
#                   pass
               print "Reports",len(rpts) 
               for rpt in rpts:
                   rname=rpt.getElementsByTagName('name')[0]
                   dpm = rpt.getElementsByTagName('dpm')[0]
#                   dpm.setAttribute('idx','1')
                   try:
                       dpmname=dpm.firstChild.nodeValue
                       s=rname.firstChild.nodeValue

                       fs = file(self.RPATH+'/'+dpmname+'/'+s+'_R.xml','w')
                       fs.write('<?xml version="1.0" ?>\n')
                       fs.write('<?xml-stylesheet type="text/xsl" href="C:/Iatric/reports2.xsl" ?>\n\n')
                       fs.write('<Reports>\n')
                       fs.write(rpt.toxml())
                       fs.write('\n</Reports>\n')
                       fs.close()
                   except:
#                       fs.close()
                       errinfo = sys.exc_info()
                       errno, errstr = errinfo[:2]
                       print errinfo

           xt="" 
           fscr = self.RPATH+'/datadefs.xml'
           print fscr, path.isfile(fscr)
           if path.isfile(fscr):
               rpts=[]
               try:
                   xt= xml.dom.minidom.parse(fscr)
                   dpmlist=xt.getElementsByTagName("dpmList")[0].getElementsByTagName("dpm")
                   dsegs=xt.getElementsByTagName('segment')
                   elements=xt.getElementsByTagName('fld-def')
               except:
                   print "Error chunking datadefs"
                   pass
               if len(elements)>0: 
                   for dpm in dpmlist:
                       dpmname=str(dpm.getAttribute('name'))
    #                   print dpmname, type(dpmname)
    #                   dpm = rpt.getElementsByTagName('dpm')[0]
    #                   dpm.setAttribute('idx','1')
                       try:
    #                       dpmname=dpm.firstChild.nodeValue
    #                       s=rname.firstChild.nodeValue

                           fs = file(self.RPATH+'/'+dpmname+'/datadef.xml','w')
                           fs.write('<?xml version="1.0" ?>\n')
                           fs.write('<?xml-stylesheet type="text/xsl" href="C:/Iatric/datadefs_v2.xsl" ?>\n\n')
                           fs.write('<datadef>\n')
                           fs.write('<dpmList><dpm name=\"'+dpmname+'\" /></dpmList>\n')
                           fs.write('<dataSegments>\n')
                           for dseg in dsegs:
                               if dseg.getElementsByTagName("dpm")[0].firstChild.nodeValue == dpmname:
                                   fs.write(dseg.toxml())
                           fs.write('\n</dataSegments>\n<elements>')
                           for fld in elements:
                               if fld.getElementsByTagName("dpm")[0].firstChild.nodeValue == dpmname:
                                   fs.write(fld.toxml())
                           fs.write('\n</elements></datadef>\n')
                           fs.close()
                       except:
    #                       fs.close()
                           errinfo = sys.exc_info()
                           errno, errstr = errinfo[:2]
                           print errinfo
               else:
                   pass

           fb.close()
           fa.close()
#           self.logfile.close()
           print 'Done'
        else:
           self.writelog( 'ABORTED BY USER','print')

