#   
from PackageReaderCS import PkgReaderCS

class MagicNode():
    import sys

    keynames = {"IE":("segment",".dpm",".name"),"IE/E":("field","rank"),
                "IE/S":("subscript","rank"),"IE/C":("child",".name"),
                "IE/DT":("tech-doc","num"),
                "IE/M":("more"),"IE/V":("index-seg"),
                "IE/I":("index",".name"),
                "IEE":("fld-def",".dpm",".name"),
                "IEE/D":("description"),
                "IEE/DA":("doc","number"),
                "IEE/C":("attrib",".type"),"IEE/CL":("attrib-index","*type",".rank"),

                "IR":('report',"urn"),
                "IR/DC":('cust-doc','doc-num'),
                'IR/L':('region','line-num'),'IR/L/C':("attrib","type"),'IR/L/CL':("attrib-line","type","num"),
                'IR/P':("pic-line","line-num"),
                'IR/N':('footnote','num'),
                'IR/I':('run-index','index'),
                'IR/SE':('temp-selects','set'),
                'IR/SEG':["rpt-dataseg"],
                'IR/FI':('fld-index','line-num','fld-rank'),
                'IR/F/S':('sort','rank'),
                'IR/F/SE':('sort-field','rank'),
                'IR/F/S/SE':('sort-element','srank'),
                'IR/F':("field","num"),'IR/F/DA':('user-doc','doc-q'),'IR/F/C':("fld-attrib",'.type'),
                'IR/F/CL':("attrib-line","type","rank"),'IR/F/DT':('tech-doc','doc-q'),
                'IR/F/SE':('se','se-rank'),
                'IR/P/S':(5,6),
                'IR/PHI':("p"),
                'IR/SEG':("dataseg"),
                'IR/AT':("cust-audit","stamp"),
                "IR/T":("rpt-cust-doc",".no"),
                'IR/U':("usage","stamp"),
                "IRI":("screen-index",".name",".proc",".oname"),
                "IS":("screen",".name"),'IS/P':('page','page-num'),
                'IS/OE':('ok-enable'),
                'IS/WS':('win-size'),
                'IS/AS':('sp-char'),
                'IS/P/F':("field","field-id"),'IS/P/F/DA':('scrnfld-doc','dq'),
                'IS/P/F/C':("attrib","type"),'IS/P/F/CL':("attrib-idx","type","seq"),
                'IS/P/F/DT':('tech-doc','doc-q'),
                'IS/P/P':('picLine','p'),
                'IS/P/S':('section','section-num'),
                'IS/P/MF':('multi-func','fld-num'),
                'IS/P/B':('block','block-num'),'IS/P/B/F':('block-field','fld-num'),
                "ISI":("screen-index",".name",".proc",".oname")}
    
    offsets = {"IE":0,"IE/E":3,"IE/S":3,"IE/C":3,
                "IE/M":3,"IE/V":3,"IE/I":3,"IE/DT":3,
                "IEE":0,"IEE/D":3,"IEE/DA":3,"IEE/C":3,"IEE/CL":3,
                "IRI":0,
                "IR":0,"IR/P":2,"IR/F":2,"IR/FI":2,"IR/F/S":2,"IR/F/S/SE":4,
                'IR/F/DA':5,'IR/F/C':4,'IR/F/CL':4,'IR/F/DT':4,'IR/F/SE':4,
                'IR/L':2,'IR/L/C':4,'IR/L/CL':4,'IR/PHI':2,'IR/SEG':2,
#                'IR/P':(3,4),
                'IR/N':2,'IR/T':2,'IR/I':2,'IR/SE':2,
                'IR/SEG':3,
                'IR/AT':2,'IR/U':2,
                'IR/DC':2,
                "ISI":0,
                "IS":0,'IS/P':2,
                "IS/AS":2,"IS/WS":2,"IS/OE":2,
                'IS/P/F':4,'IS/P/F/DA':6,'IS/P/F/C':6,'IS/P/F/CL':6,'IS/P/F/DT':6,
                'IS/P/P':4,'IS/P/MF':4,'IS/P/B':4,'IS/P/B/F':6,
                'IS/P/S':4}
    keyvalues = {"IE":("active","dpmLetters","physBase","physRoot",
                       "parent","constant","extname","segType","mapsTo"),
                 "IE/E":"fldname",
                 "IE/DT":"doc-line",
                 "IE/I":"index",
                 "IE/V":"index-value",
                 "IE/S":("fldname","physName","sub-dpm","sub-urnx"),
                 "IE/M":("prefix","letters","oaf"),
                 "IE/C":"fldname",
                 "IEE/C":"attrib-val",
                 "IEE":('pointer','DataType','offset','physName','locName','length','jfy','dataseg','rank'),
                 "IEE/D":('description'),"IEE/DA":"docvalue",
                 "IEE/C":"attrib-val","IEE/CL":("length"),

                 "IRI":"active",'IR/T':'techdoc',
                 "IR":('active','name','dpm','oldproc','segname','title','header-type','char-per-in',
                       'cpl','lpi','lpp','seg-dpm','page-size','log-name','page-tr','rpt-head','rpt-tr',
                       'detail','page-head','acc-path','sort-mod','left-mgn','rw-version'),
                 "IR/F":('ele-name','ele-dpm','row','marker','length','jfy','label','ee-name','yn-attrib',
                         'yn-doc','tech-doc','edit','column'),
#                 'IR/F':(3,4),
                 'IR/F/DA':"appl-doc-text",'IR/F/C':"attrib-val",'IR/F/CL':('attrib-index','attr-length'),
                 'IR/F/DT':"tech-doc-text",
                 'IR/F/S':["sort-field"], 'IR/F/S/SE':("criteria","crt-label","crt-label2"),
                 'IR/F/SE':("sel-oper","sel-val1",'sel-val2','sel-ele-name','eel-ele-dpm','sel-screen',
                            'sel-prompt','sel-default','sel-cust.edit'),
                 "IR/FI":('start','width','end'),
                 "IR/I":('index-name','index-dpm','index-ee-name'),
                 "IR/AT":('user','code','copy'),"IR/T":("subscript","index","active"),
                 "IR/U":('user','date'),
                 'IR/PHI':'phi-data','IR/SEG':('seg-name'),
                 "IR/DC":"text",
                 'IR/L':('rpt-reg','line-reg','line-pg-break'),
                 'IR/L/C':'line-attrib','IR/L/CL':'line-length',
                 'IR/SE':("temp-sel-oper","temp-sel-val1",'temp-sel-val2','temp-sel-ele-name',
                          'temp-eel-ele-dpm','temp-sel-screen','temp-sel-prompt','temp-sel-default',
                          'temp-sel-cust.edit'),

                 'IR/P':"pic",
                 'IR/N':'note',
                 'IR/SEG':["det-seg"],

                 "ISI":"active",
                 "IS":('active','audit-name','dpm','name','screen-type','multi-page','dataseg','fragment'),
                 "IS/OE":"ok","IS/WS":"winsize",
                 'IS/P':('title','file-prompt','height','width','other'),
                 'IS/P/F':("name",'unk','row','column','section','height'),
                 'IS/P/F/DA':"field-doc",'IS/P/F/C':"screen-attrib-val",
                 'IS/P/F/CL':'screen-fld-index','IS/P/F/DT':'screen-fld-tech-dco',
                 'IS/P/P':'screen-page-page',
                 'IS/P/B':('main-ht','main-wd','fields-done','blk-extend','blk-width','blk-height','blk-header','blk-head-yn',
                           'blk-head-ovr','blk-true-width'),
                 'IS/P/B/F':'block-fieldval',
                 'IS/P/MF':["mfunc"],
                 'IS/P/S':("control","unk1","unk2","unk3","unk4","fld-list","repeat") }
    
    hr = {"IE":("DT","E","C","S","I","M","V"),
          "IEE":("DA","D","CL","C"),
          "IS":('P','OE','WS','AS'),"IS/P":('MF','B','F','P','S'),'IS/P/F':('DA','DT','CL','C'),"IS/P/B":("F"),
          "IR":("SEG","AT","DC","FI","SE","F/S","F","L","PHI","P","N",'T',"U","I"),"IR/F":('DA','DT','CL','SE','C'),
          "IR/F/S":("SE"),"IR/L":("CL","C")}

    '''    keymatch = {"IE":(1,3), "IE/E":(4,5),"IE/S":(4,5),"IE/M":(4,5),
                        "IE/I":(4,5),"IE/C":(4,5),"IE/V":(4,5),"IE/DT":(4,5),
                        "IEE":(1,3),"IEE/DA":(4,5),"IEE/D":(4,4),"IEE/C":(3,5),"IEE/CL":(3,6),
                        "IRI":(1,4),
                        "IR":(1,2),'IR/P':(3,4),'IR/SEG':3,'IR/L':(3,4),'IR/N':(3,4),
                        "IR/AT":(3,4),"IR/U":(3,4),"IR/FI":(3,5),
                        'IR/F':(3,4),'IR/F/DA':(5,6),'IR/F/C':(5,6),'IR/F/CL':(5,7),'IR/F/DT':(5,6),
                        "ISI":(1,4),
                        "IS":(1,2),'IS/P':(3,4),
                        'IS/P/F':(5,6),'IS/P/F/DA':(7,8),'IS/P/F/C':(7,8),'IS/P/F/CL':(7,9),'IS/P/F/DT':(7,8),
                        'IS/P/P':(5,7),
                        'IS/P/S':(5,6)}
    '''
    
    cptr = 0
    lastinsert=''
    
    def __init__(self, initargs=[]):
        
        self.keys=[]
        self.keystring=''
        self.parent=''
        self.nodevalue = ''
        self.children=[]
        self.insertdepth=0
        self.keytype=''
        self.xmlname=''
        self.xmlvalue=''
        self.xmlfamily=''
        self.closure=''

    def escapedhtmString(self, s):
        if len(s)>0:
            return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
        else:
            return ""

    def isNode(self):
        if len(self.keys)>0:
            return True
        else:
            return False
        
    def appendChild(self,c):
        self.children.append(c)
        c.parent=self

    def setParent(self,p):
        self.parent(p)

    def getParent(self):
        return self.parent

    def getNodevalue(self):
        return self.nodevalue

    def setNodevalue(self, n):
        self.nodevalue = n

    def setstring(self):
        self.keystring = '\x1e'.join(self.keys)

    def setkeys(self, k):
        self.keys = k
        self.keystring = '\x1e'.join(k)

    def setNode(self,k,n,kt):
        self.nodevalue=n
        self.keys=k
        self.keytype=kt
        self.keystring='\x1e'.join(k)

    def hasChildren(self):
        return len(self.children)>0

    def getChildren(self):
        return self.children

    def keysMatch(self, t):
        match = True
        if type(t) == type(self):
            k=t.getKeys()
            if not len(k) == len(keys):
                match=False
            else:
                for kc in range(len(k)):
                    if not k[kc] == keys[kc]:
                        match=False
                        break
        else:
            match=False
        return match

    def addToRoot(self,n):
        if self.parent.keystring=='':
            if self.parent=='':
                self.appendChild(n)
                n.parent=self
            else:
                self.parent.appendChild(n)
        else:
            self.parent.insertNode(n)
        

    def insertNode(self, n):
        
        if True:
#            if not n.isNode():
#                print "object is not a node", type(n), n
#                return
            if True:
# This is the root node        
                c = 0
                found = False
                ch=''
                n.insertdepth+=1
#                print 'insert',n, 'in',self, c,len(self.children), len(n.children)
                while not found and c<len(self.children):
                    ch=self.children[c]
                    lk=len(ch.keys)
                    if '\x1e'.join(n.keys[:lk])==ch.keystring:
#                        print "found match", lk,ch
                        found=True
                    c+=1
                if found:
#                    print "inserting in",ch
                    ch.insertNode(n)
                    return
                else:
                    self.appendChild(n)
#                    print 'appended as child \n'
                    return
            else:
                print "InsertNode error", n.keys, self.keys
                
        else :
            print "Exception", type(n), n
        

    def printnode(self):
        print self.insertdepth, self.keytype, self.keys,'=',self.nodevalue

    def printTree(self):
        self.printnode()
#        print "children", self.hasChildren(), len(self.children)
#        self.insertdepth+=1
        for c in self.children:
            c.printTree()

    def nodevalueXml(self):
        try:
            valset=self.keyvalues[self.keytype]
#            print "nodevalue",valset, self.nodevalue
            if type(valset)==type("s"):
#                print '<'+valset+'>'+self.escapedhtmString(self.nodevalue)+'</'+valset+'>'
                print self.escapedhtmString(self.nodevalue)
            else:
                ele=''
#                print "nodevalue",valset, self.nodevalue
                for kc in range(len(valset)):
                    try:
                        if len(self.nodevalue)>0:
                            ele = ele + '<'+valset[kc]+'>'+self.escapedhtmString(self.nodevalue[kc])+'</'+valset[kc]+'>'
                        else:
                            ele = ele + '<'+valset[kc]+'/>'
#                        print ele
                    except:
                        pass
                print ele
        except:
            pass

    def printNodeStart(self):
        import sys
        elem = 'Root'
        attrib=''
        try:
            kn=self.keynames[self.keytype]
            if type(kn)==type('s'):
                elem=kn
            else :
                elem = kn[0]
#            else:
                offset=self.offsets[self.keytype]
#                if self.keytype == 'IR/F/C':
#                    print kn, offset, self.keys
                for i in range(1,len(kn)):
                    aname = kn[i]
                    if aname[:1]=='.' or aname[:1]=="*":
    #                    print i, aname
                        aname=aname[1:]
                    if offset+i<len(self.keys):
                        sk=self.escapedhtmString(self.keys[offset+i])
                        attrib = attrib +' '+aname+'=\"'+sk+'\"'
            print '<'+elem, attrib+'>'
            self.closure='</'+elem+'>'
        except KeyError:
            print '<'+ self.keystring +'>'
            self.closure='</'+self.keystring + '>'
            
        except:
            errinfo = sys.exc_info()
            errno, errstr = errinfo[:2]
            
            
#            print elem, attrib, self.keytype, self.keys
            if len(elem)>0 and not elem=="Root":
                pass
            elif len(self.xmlname)>0:
                elem=self.xmlname
            else:
                elem="root"
            print '<'+elem+'>'
            print '<error>', errstr,'</error>'
            self.closure='</'+elem+'>\n'
        

    def printNodeEnd(self):
        print self.closure

        
    def printTreeXmlold(self):
        self.printNodeStart()
        self.nodevalueXml()
        self.insertdepth+=1
        for c in self.children :
            c.printTreeXml()
#            self.nodevalueXml()
        self.printNodeEnd()

    def printTreeXml(self, depthLimit=-1):
        self.printNodeStart()
        self.nodevalueXml()
        self.insertdepth+=1
        if self.insertdepth <depthLimit or depthLimit==-1:
            for c in self.children:
                c.printTreeXml()
        self.printNodeEnd()

    def printNodeTreeXml(self):
        self.printNodeStart()
        self.nodevalueXml()
        self.insertdepth+=1
#        if self.insertdepth < depthLimit or depthLimit==-1 or True:
        cc = self.children
        if len(cc)>0:
            for c in cc:
                c.printTreeXml()
        cc=""
        self.printNodeEnd()

class PkgReaderCSXML(PkgReaderCS):
    source = []
    home = '../'
    reportdef = []
    screendef=[]
    datadef=[]
    menudef=[]
    sectionNames = {0:"packageInfo", 1:'dpmList', 2:'procList', 3:'appl-data', 4:'nprNodes',
                5:'procedures'}
    settings = {}
    
    def __init__(self, initargs=[]):
        if len(initargs)>0:
            self.top=initargs[0]
        if len(initargs)>1:
            self.settings = initargs[1]
        if "XSLHOME" in self.settings:
            self.home=self.settings["XSLHOME"]+'/'
        self.logger = self.top.logger
        self.run()
        
    def addDpmList(self, fout):
        fout.write('\n<dpmList>')
        for dpm in self.dpmNames:
            fout.write('<dpm name=\"'+dpm+'\" />\n')
        fout.write('</dpmList>')

    def convertQueuedString(self,s, slist):
        count = ord(s[0])

        slist.append(s[1:count+1])
        if len(s)>(count+1):
            self.convertQueuedString(s[count+1:],slist)
        

    def parseInputOld(self, fin,fout):
        global packageInfo, dpmNames, procedureNames, definitions, applicationInfo, source

        import xml.dom.minidom
        import xml.dom.NodeFilter
        sections = []
        lread = fin.readlines()
        lines=[]
        ln=''
        lflag=False
        for l in lread:
            if l.endswith('\xfc\r\n'):
                ln=ln+l[:len(l)-3]
                lflag=True
            else:
                ln=ln+l
                lflag=False
            if lflag:
                lflag=False
                pcs=ln.split('\xfc')
                for pc in pcs:
                    if pc[:2]=='\r\n':
                        lines.append(pc[2:]+'\xfc')
                    else:
                        lines.append(pc+'\xfc')
                ln=''
        if len(ln)>0:
            pcs=ln.split('\xfc')
            for pc in pcs:
                if pc[:2]=='\r\n':
                    lines.append(pc[2:]+'\xfc')
                else:
                    lines.append(pc+'\xfc')
        ln=''
        lntest=lines[:20]
            
            
        keynames = {"IE":("segment",".dpm",".name"),"IE/E":("field","rank"),
                    "IE/S":("subscript","rank"),"IE/C":("child","."),
                    "IE/M":("more"),"IE/V":("index-seg"),
                    "IE/I":("index",".")}
        offsets = {"IE":0,"IE/E":3,"IE/S":3,"IE/C":3,
                    "IE/M":3,"IE/V":3,"IE/I":3}
        hr = {"IE":("E","C","S","I","M","V")}
        keyvalues = {"IE":("active","dpmLetters","physBase","physRoot",
                           "parent","constant","extname","segType","mapsTo"),
                     "IE/E":"fldname",
                     "IE/I":"index",
                     "IE/V":"index-value",
                     "IE/S":("sub-element","sub-address","sub-dpm","sub-urnx"),
                     "IE/M":("prefix","letters","oaf"),
                     "IE/C":"fldname"}
        keymatch = {"IE":(1,3), "IE/E":(4,5),"IE/S":(4,5),"IE/M":(4,5),
                    "IE/I":(4,5),"IE/C":(4,5),"IE/V":(4,5)}

        xt=xml.dom.minidom.Document()
        topnode=xt.createElement('datadefs')
        xt.appendChild(topnode)

        currentnode=topnode
        parent=topnode
        keyarray=[]
        subkeys=[]
        ntypeList=[]
        nList=[]
        nList.append(topnode)
        ln=''
        nct=0
        lastkey=""
        lastkeytype=""
        for line in lines:
            if line.endswith('\xfc\r\n'):
                ln = ln+line.strip('\r\n')
            else:
                ln=ln+line
            if '\xfc' in ln:
                node = ln.split('\xfc')
                ln=node[1]
                node=node[0]
                key,value=node.split('\xfb')
                key=key.split('\x1e')
                isChild=False
                isSibling=False
                if key[0]=='IE' and nct<20:
                    nct+=1
                    keytype = ""
                    testkey=[]
                    i=0
                    while i<len(key):
                        if i==0:
                            keytype=key[i]
                            keyset=keynames[keytype]
                            testkey.append(key[i])
                            for k in range(1,len(keyset)):
                                if keyset[k][0]=='.':
                                    i+=1
                                    testkey.append(key[i])
                                    
                            if i==0:
                                print "bad match", key
                                i=len(key)
                            else: i+=1
                        else:
#                            print i, keytype, testkey, key
                            keycheck=hr[keytype]
                            found = False
                            subkeylength=0
#                            i+=1
                            for c in keycheck:
                                if not found:
                                    if key[i][:len(c)]==c:
                                        found=True
                                        keytype=keytype+"/"+c
                                        subkeylength=len(c)
                            ii=i
                            if found:
                                keyset=keynames[keytype]
                                
                                testkey.append(key[i][:subkeylength])
                                if type(keyset)==type("str"):
                                    i+=1
                                else:
                                    for k in range(1,len(keyset)):
                                        if keyset[k][0]=='.':
                                            i+=1
                                            testkey.append(key[i])
                                        elif len(keyset[k])>0:
                                            s=[]
                                            self.convertQueuedString(key[i][subkeylength:],s)
                                            i+=1
                                            for ss in s:
                                                testkey.append(ss)
#                                            print subkeylength, s, key, testkey
#                            print '<bot>', i, keytype, testkey, key
                            if ii==i:
                                print "not making progress",i,keyset,key, testkey
                                i=len(key)
                                keytype="X"
                            else: i+=1
                    nodeprops = keynames[keytype]
                    new = xt.createElement(nodeprops[0])
                    offset=offsets[keytype]
#                    len(testkey)-len(nodeprops)+2
                    
                    for i in range(1,len(nodeprops)):
                        if i+offset<len(testkey):
                            aname=""
                            try:
                                aname=nodeprops[i]
                                if aname[0]==".":
                                    aname=aname[1:]
                            except:
                                pass
                            if len(aname)>0:
                                new.setAttribute(aname,testkey[i+offset])
#                    print new.toxml(), testkey
#                        else:
#                            break
#                    print key, keytype, testkey
                    valset=keyvalues[keytype]
                    if type(valset)==type("str"):
                        pc=xt.createElement(valset)
                        pc.appendChild(xt.createTextNode(value))
                        new.appendChild(pc)
                    elif len(valset)>0:
                        s=[]
                        self.convertQueuedString(value,s)
                        for ss in valset:
                            pc = xt.createElement(ss)
                            pc.appendChild(xt.createTextNode(s.pop(0)))
                            new.appendChild(pc)
#                        print "seg defs",new.toxml()
                    kmatch=0
                    for k in range(min(len(lastkey),len(testkey))):
                        if lastkey[k]==testkey[k]:
                            kmatch+=1
                        else:
                            break
                    if len(nodeprops)==0:
                        print "not found", kmatch, keytype, lastkeytype, testkey, "lastkey:", lastkey
                    elif len(lastkeytype)==0:
                        print "first", kmatch, keytype, lastkeytype, testkey, "lastkey:", lastkey
                        parent.appendChild(new)
                        currentnode=new
                    elif kmatch==keymatch[lastkeytype][0]:
                        print "sibling", kmatch, keytype, lastkeytype, "lastkey:", testkey
                        parent.appendChild(new)
                        currentnode=new
                    elif kmatch==keymatch[lastkeytype][1]:
                        print "child", kmatch, keytype, lastkeytype, "lastkey:", testkey
                        currentnode.appendChild(new)
                        parent=currentnode
                        nList.append(currentnode)
                        currentnode=new
                    elif kmatch>0:
                        print "root", kmatch, keytype, lastkeytype, "lastkey:", testkey
                        parent=nList.pop()
                        if topnode:
                            pass
                        currentnode=new
                        nList=[topnode]
                        parent.appendChild(new)
                    else:
                        print "root", kmatch, keytype, lastkeytype, "lastkey:", testkey
                        parent=topnode
                        currentnode=new
                        nList=[topnode]
                        parent.appendChild(new)
                        
                    if len(nodeprops)>0:
                        lastkey=testkey
                        lastkeytype=keytype
#                    print key, value, new.toxml()
                    if nct==20:
                        fx=open('C:/Iatric/testcsout.xml',"w")
                        fx.write(xt.toxml())
                        fx.close()
        xt=""

        
    def parseInput(self,l):
        sections = []
        lines = l

        keyarray = []
        subkeys = []
        ntypeList = []
        nList = []
    #    nList.append(topnode)
        ln = ''
        nct = 0
        lastkey = ""
        lastkeytype = ""
        root = MagicNode()
        root.xmlname = "dataSegments"
        nodelist = []
        self.dpmNames = []
        for line in lines:
            if line.endswith('\r\n'):
                line = line.strip('\r\n')
            ln = ln + line
            while '\xfc' in ln:
                nodelist.append(ln.split('\xfc')[0])
    #            print ln
    #            print node
                ln = ln[ln.index('\xfc') + 1:]
    #            node=node[0]
        if len(ln) > 0:
            if ln in nodelist: pass
            else: nodelist.append(ln)
    
        ddefs = {}
        reports = {}
        screens = {}
        rpt = ''
        scrn = ''
        indexes = []
        last = []
            
        for l in nodelist:
            mn = l.split('\xfb')[0].split('\x1e')
            if last == mn[:2]: 
                pass
            elif mn[0] in ['IE', 'IEE']:
                if not mn[1] in ddefs:
                    ddefs[mn[1]] = []
                rpt = ddefs[mn[1]]
                dpm=self.finddpm(mn[1])
                if dpm in self.dpmNames: pass
                else:
                    self.dpmNames.append(dpm)
                
            elif mn[0] == 'IR':
                if not mn[1] in reports:
                    reports[mn[1]] = []
                rpt = reports[mn[1]]
                dpm=self.finddpm(mn[1])
                if dpm in self.dpmNames: pass
                else: 
                    self.dpmNames.append(dpm)
            elif mn[0] == 'IS':
                if not mn[1] in screens:
                    screens[mn[1]] = []
                rpt = screens[mn[1]]
                dpm=self.finddpm(mn[1])
                if dpm in self.dpmNames: pass
                else: 
                    self.dpmNames.append(dpm)
            else:
                rpt = indexes
            rpt.append(l)
            last = mn[:2]
#        x = MagicNode()
#        x.setkeys(['reports'])
    #    makeTree(ddefs[ddefs.keys()[0]],x,nclimit)
    #    makeTree(ddefs[ddefs.keys()[1]],x,nclimit)
    #    makeTree(screens[screens.keys()[0]],x,nclimit)
    #    makeTree(screens[screens.keys()[1]],x,nclimit)
    #    x.printTreeXml()
        i = 1
        return (ddefs,screens,reports)

    def splitkey(self,key,keychar):
        s=[]
        for i in range(0,len(key)):
    #        if key[i]
            sk2 = key[i].split(keychar)
    #        print 'key', keychar, key[i], sk2
            
            for sk in sk2:
                s.append(sk)
    #    print 's',s
        return s
        
    def findkeys(self,key,keynames,htree):
        keytype=key[0]
        subkey=[]
        if True:
            i=0
            subkey=self.splitkey(key,'\x01')
            subkey=self.splitkey(subkey,'\x02')
            subkey=self.splitkey(subkey,'\x03')
            subkey=self.splitkey(subkey,'\x09')
            keytype=key[0]
            found = False
            done = False
            keyset=keynames[keytype]
            keylength=len(keyset)

            while not found and not done:
                if len(subkey)==keylength:
                    found=True
                else:
                    lastkeylen = keylength
                    progress = True
                    while not done and len(subkey)>keylength and progress:
                        try:
                            mt=htree[keytype]
                            if type(mt)==type('s'):
                                mt=[mt]
    #                        print 'findkey', keytype, keylength,mt, key, subkey
                            thiskey=keytype
                            found=False
                            for sk in mt:
                                thiskey=keytype
                                rk=sk.split('/')
    #                            if sk=='SEG':
    #                                print 'testing', thiskey, keytype+'/'+sk, keylength, len(rk), subkey
                                for nk in range(0,len(rk)):
                                    try:
                                        if len(subkey[keylength+nk])>len(rk[nk]):
                                            thiskey=thiskey+'/'+ subkey[keylength+nk][:len(rk[nk])]
                                        else:
                                            thiskey=thiskey+'/'+subkey[keylength+nk]
                                    except IndexError:
#                                        print "Index Error", thiskey, keylength, nk, rk[nk], sk, mt, subkey, key
                                        pass
    #                            print 'testing', thiskey, keytype+'/'+sk, keylength, subkey
                                if thiskey==(keytype+'/'+sk):
                                    if len(keynames[thiskey])+keylength==len(subkey):
                                        done=True
    #                                print 'found match 1', thiskey, key, subkey, done
                                    found=True
                                    keytype=thiskey
                                    keylength+=len(keynames[thiskey])
                                    break
    #                            else:
    #                                print 'next subkey'
    #                            if found:
    #                                thiskey=keytype
    #                                print 'found match 2', "Done=",done, keytype, subkey
    #                                break
                            if not found:
                                print 'bad key', key, mt, keytype
                                done = True
                            else:
                                if keylength==lastkeylen:
                                    progress=False
                                    print "no progress", keytype, key, subkey
                                    done=True
    #                            else: print 'progress', keytype, subkey
                                
                                 
                                            
                        except:
                            print 'excepted', thiskey, keytype, keylength, key, subkey
                            keytype='X+'+keytype
                            done=True
        else:
            print 'unknown error', keytype, thiskey, subkey, keylength
            keytype='X+'+keytype
        s=(keytype,subkey)
        return s
                
#                print testkey

    def makeTree(self,lines,root,nclimit):            
        nct=0
        mnk=MagicNode.keynames
        mnh=MagicNode.hr
        for node in lines:
            if True:
                if True :
    #                print node.split('\xfb')
                    key,value=node.split('\xfb')
                    key=key.split('\x1e')
                    addNode = False
    #                print key, value
                    isChild=False
                    isSibling=False
                    if nct<nclimit:
                        nct+=1
                        keytype = ""
                        testkey=[]
                        addNode=True
                        keytype, testkey=self.findkeys(key, MagicNode.keynames, MagicNode.hr)
    #                    print "found", keytype, testkey
                        i=0
        #                nodeprops = keynames[keytype]
                        if addNode:
                            new=MagicNode()
            #                new.setkeys(testkey)
                            valset='s'
                            try:
                                valset=MagicNode.keyvalues[keytype]
                            except:
                                pass
                            
                            if not type(valset)==type('s'):
                                ss=[]
                                self.convertQueuedString(value,ss)
                            else:
                                ss=value
                            new.setNode(testkey, ss, keytype)
    #                        print new.printnode()
        #                new.printnode()
        #                print new
        #                print type(new), type(root), type(new)==type(root)
                            root.insertNode(new)
    
    #                    print key, value, new.toxml()
                    if nct==nclimit:
    #                    fx=open('C:/Iatric/testcsout.xml',"w")
    #                    fx.write(xt.toxml())
    #                    fx.close()
                        pass
                else :
                    print 'Error', node
                    print keytype, keycheck, key, testkey
                    pass               
    #                print len(node.split('\x1b')),'\n'
    #            root.printTreeXml()
#    root.printTreeXml()


    def printPackageInfo(self, pkg):
        global SEGMENT_DEL, fout

        i = 0
        MENU_STARTED = False
        pkgHeads = ["pkgName" , 'pkgAppl' , 'pkgDetail' , 'menu' ]
        segments = pkg.split(SEGMENT_DEL)
        print('<pkgInfo>')
        for segment in segments:
            segHdr = pkgHeads[i]
            if segHdr=='pkgDetail':
                print('<'+segHdr+'>')
                printpkgDetail(segment)
                print('</'+segHdr+'>')
            elif segHdr == 'pkgName' :
                qs = []
                convertQueuedString(segment,qs)
                print('<'+segHdr+'>'+qs[0]+'</'+segHdr+'>')
            elif segHdr == 'menu' and not MENU_STARTED :
                print('<'+segHdr+'s>'+'<'+segHdr+'>'+segment+'</'+segHdr+'>')
                MENU_STARTED = True
            else :
                print('<'+segHdr+'>'+segment+'</'+segHdr+'>')

            if i+1 < len(pkgHeads): i = i+1
            else: pass

        if MENU_STARTED:
            print('</menus>')
        print('</pkgInfo>')
        
    def printpkgDetail(self, detail):
        global fout
        pkgDetail = ['unk','unk', 'definitions', 'include-defs','unk','unk','unk','screens','reports','logic','macro','unk']
        qs=[]
        convertQueuedString(detail,qs)
        i=0
        for item in qs:
            segHdr = pkgDetail[i]
            print('<'+segHdr+'>'+item+'</'+segHdr+'>')
            if i+1< len(pkgDetail): i = i+1
            else: pass
        
    def printprocList(self, procl):
        global fout, SEGMENT_DEL
        
        print('<procList>')
        proclist = procl.split(SEGMENT_DEL)
        for pr in proclist:
            nodes = pr.split(chr(30))
            if len(nodes)>1:
                print('<proc dpm=\"'+nodes[0]+'\">'+nodes[1]+'</proc>')
            else:
                print('<proc node=\"nil\">'+pr+'</proc>')
        print('</procList>')

    def printApplData(self, appl):
        global fout, SEGMENT_DEL
        
        print('<applData>')
        dpmlist = appl.split(SEGMENT_DEL)
        for dpm in dpmlist:
            print('<appSeg name=\"'+dpm+'\" />')
        print('</applData>')

    def printdpmList(self, dpms):
        global fout, SEGMENT_DEL
        
        print('<dpmList>')
        dpmlist = dpms.split(SEGMENT_DEL)
        for dpm in dpmlist:
            print('<dpm name=\"'+dpm+'\" />')
        print('</dpmList>')

    def printnprNodes(self, npr):
        global fout, SEGMENT_DEL
        
        
        print('<nprNodes>')
        nprNodes = npr.split(SEGMENT_DEL)
        count = 0
        nodeiskey = False
        oktoprint = False
        for node in nprNodes:
            if node[:3]=='IS\x1e':
                oktoprint = True
                nodeiskey = True
            else: pass
            
            if count<100 and oktoprint:
                if nodeiskey:
                    print('<nprnode>'+node.replace('\x1e','|')+'</nprnode>')
                    nodeiskey = False
                else:
                    print('<nodeval>'+node+'</nodeval>')
                    nodeiskey=True
                count += 1
            else: pass
        print('</nprNodes>')

    #    for macro in macros:
    #       writelog 'Macro '+ macro[0]
    #    for screen in screens:
    #       print 'Screen', screen[0]
    #    for report in reports:
    #       print 'Report', report[0]

    def escapedhtmString(self, s):
        s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
#        s.replace(';','&amp;').replace('<','&lt;').replace('>','&gt;')
        return s

    def fileDatadefs(self):

        fout = file(self.RPATH+'/'+'datadefs.xml','wb')

        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'datadefs.xsl" ?>\n\n')
        fout.write('<datadef>')

        self.addDpmList(fout)

        xmlnodes = []
        statenames = {'IE':'dataSegments', 'IEE':'elements'}
        nodeFlag = 0
        nodeKeys = ''
        elementQ = ''
        nodeValList = []
        crflag = ''
        elemstate = ''
        segName = ''

        for nprNode in self.definitions:
    #        if len(nprNode)>1: writelog( str(nprNode) )
            nodeType = nprNode[0].split(chr(30))[0]
    #        if nodeFlag==1 and nodeType not in ['IE','IEE','IP','IR','IM','IS','IRI']:
    #            writelog(nodeKeys+', '+crflag+', '+nprNode)

            if nodeType == 'IE':
                nodeFlag = 1
                nodeKeys = nprNode[0]
                crflag = ''
                if nodeType == elemstate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                elemstate = nodeType
            elif nodeFlag==1 and nprNode[len(nprNode)-1].endswith('\n'):
                crflag += "".join(nprNode)
    #            print 'trap1', nodeKeys, crflag
            elif nodeFlag==1:
                nodeFlag = 0

    #            if len(crflag)>0: print nodeKeys, crflag
                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
    #               if len(nodeKeys)>2 and len(nodeKeys[2])>0:
    #                   elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ = nodeKeys[3][0]
    #               if len(nodeKeys)>4 and len(nodeKeys[4])>0:
    #                   elementQ += nodeKeys[4][0]
    #               if elementQ in ['P','PP','PF','PFC','PS','PM']:
    #                   nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]
                if elementQ in ['E','C','S']:
                    nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
    #            nodeKeys = "|".join(nodeKeys)
                   
                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['','S']: 
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)
                    nprNode = '|'.join(nodeValList)

    #               nodeValList = []
    #               convertQueuedString(nprNode[0],nodeValList)
    #               fb.write( '{'+nodeKeys+'}|{' + '|'.join(nodeValList)+'}\n')
                   
    #            fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
                if len(nodeKeys)==3:
                    if len(segName)>0:
                        fout.write('</segment>\n')
                    fout.write('<segment name=\"'+nodeKeys[1]+'.'+nodeKeys[2]+'\" dpm=\"'+nodeKeys[1]+'\"><dpm>'+nodeKeys[1]+'</dpm><name>'+nodeKeys[2]+'</name>')
                    fout.write('<active>'+nodeValList[0]+'</active><dpmLetters>'+nodeValList[1].replace('&','&amp;')+'</dpmLetters>')
                    fout.write('<physBase>'+nodeValList[2].replace('&','&amp;')+'</physBase><physRoot>'+nodeValList[3].replace('&','&amp;')+'</physRoot>')
                    if len(nodeValList[4])>0: fout.write('<parent>'+nodeValList[4]+'</parent>')
                    if len(nodeValList[7])>0: fout.write('<constant>'+nodeValList[7]+'</constant>')
                    fout.write('<extname>'+nodeValList[10]+'</extname>')
                    if len(nodeValList[8])>0: fout.write('<localSubscripts>'+nodeValList[8]+'</localSubscripts>')
                    fout.write('<segType>'+nodeValList[5]+'</segType>')
                    fout.write('<mapsTo>'+nodeValList[6]+'</mapsTo>')
                    fout.write('<elemCount>'+nodeValList[11]+'</elemCount>')
                    fout.write('\n<nodevalue>'+nprNode.replace('&','&amp;')+'</nodevalue>\n')
                    segName = nodeKeys[2]
                if len(nodeKeys)>3:
                    nodekeytype = nodeKeys[3].split('|')
                    if nodekeytype[0]=='E':
                        fout.write('<field rank=\"'+nodekeytype[1]+'\"><fldname>'+nprNode.replace('&','&amp;')+'</fldname></field>\n')
                    elif nodekeytype[0]=='S':
                        fout.write('<subscript rank=\"'+nodekeytype[1]+'\"><fldname>'+nodeValList[0]+'</fldname><physName>'+nodeValList[1].replace('&','&amp;')+'</physName></subscript>\n')
                    elif nodekeytype[0]=='C':
                        fout.write('<child>'+nodeKeys[4]+'</child>\n')
                    elif nodekeytype[0]=='I':
                        fout.write('<index>'+nodeKeys[4]+'</index>\n')
                    else: pass
    #                    fout.write('<attrs><fldname>'+':'.join(nodeKeys[3:])+'</fldname><fldval>'+nprNode.replace('&','&amp;')+'</fldval></attrs>\n')
            else: nodeFlag = 0

        if len(segName)>0:
            fout.write('</segment>\n')
        elementQ = ''
        nodeValList = []
        keylabels = ['','dpm','elementName']
        elemName = ''
        nodelabels = ['Pointer','DataType','offset','physName','localName','length','jfy','dataseg','rank']
        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType == 'IEE':
                nodeFlag = 1
                nodeKeys = nprNode[0]
                crflag = ''
                if nodeType == elemstate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                elemstate = nodeType
            elif nodeFlag==1 and nprNode[len(nprNode)-1].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ = nodeKeys[3][0:2]
                if elementQ in ['DA']:
                    nodeKeys[3] = nodeKeys[3][:len(elementQ)] + '|' + nodeKeys[3][len(elementQ)+1:]
    #                elif elementQ == 'E' or elementQ == 'D' or elementQ=='S':
    #                    nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
    ##            nodeKeys = "|".join(nodeKeys)
    #                else:
    #                    nodeKeys = nodeKeys[0]+chr(30) + nodeKeys[1]
    #                    nodeKeys = nodeKeys.replace(chr(30),'|')
               
                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['']:
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)

                    newnodeValues =[]
                    for piece in nodeValList:
                        newnodeValues.append(piece.replace('|',""))
                       
                    nprNode = '|'.join(newnodeValues)

    #                nodeValList = []
    #                convertQueuedString(nprNode[0],nodeValList)
    #                fb.write( '{'+nodeKeys+'}|{' + '|'.join(nodeValList)+'}\n')
                if len(nodeKeys)==3:
    #                fout.write( '<keys>')
    #                i=1
    #                while i<len(nodeKeys):
    #                    fout.write('<'+keylabels[i]+'>'+nodeKeys[i]+'</'+keylabels[i]+'>')
    #                    i += 1
                    if len(elemName)>0: fout.write('</fld-def>\n')

                    elemName = nodeKeys[2]
                    fout.write('<fld-def element=\"'+elemName+'\" dpm=\"'+nodeKeys[1]+'\">')
                    fout.write('<dpm>'+nodeKeys[1]+'</dpm>')
                    i=0
                    lbl=''
                    while i<len(nodeValList):
                        try:
                            lbl=nodelabels[i]
                        except:
                            lbl="unk-"+str(i)
                            
                        if len(nodeValList[i])>0:
                            fout.write('<'+lbl+'>' + nodeValList[i].replace('&','&amp;')+'</'+lbl+'>')
                        i += 1
                elif len(nodeKeys)>3:
                    attribute = nodeKeys[3][0]
                    qualifier = ''
                    if attribute =='C':
                        attribute="attr"
                        qualifier = nodeKeys[4].replace('\x01','|')
                    elif attribute == 'D':
                        attribute="doc"
                        qualifier='DOC-'+nodeKeys[3][1]
                    fout.write('<fld-attr attr-type=\"'+attribute+'\">')
                    fout.write('<attr-qual>'+qualifier+'</attr-qual>')
                    fout.write('<attr>'+self.escapedhtmString(nprNode)+'</attr></fld-attr>')
                    
            else: nodeFlag = 0
        if len(elemName)>0: fout.write('</fld-def>\n')
        while len(xmlnodes)>0:
            fout.write('</'+xmlnodes.pop()+'>\n')
        fout.write('</datadef>')
        fout.close()
        

    def fileReports(self):
#        global definitions, RPATH

        HDR_ELEMS = ['active','name','dpm','old-proc','dataseg','rptTitle','type',
                     'points','charsperLine','linesperInch','prtlinesperpage','seg-dpm',
                     'page-size','logical-name','page-trailer','rpt-header','rpt-trailer',
                     'detail','page-header','path','unk']

        reportKeyMap = {'F':'field', 'P':'picLine', 'AT':'audit', 'N':'footnote', 'FI':'fieldIndex',
                        'U':'update','T':'subscript','I':'rptIndex'}    
        fout = file(self.RPATH+'/'+'reports.xml','wb')
        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'reports.xsl" ?>\n\n')
    #    fout.write('<Reports>')

        xmlnodes = []
        statenames = {'IR':'Reports'}
        nodeFlag = 0
        nodeKeys = ''

        rptstate = ''
        rptname =''

        elementQ = ''
        nodeValList = []
        crflag = ''
        fieldname=''

        print len(self.definitions)
        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType == 'IR':
                nodeFlag = 1
                crflag = ''
                nodeKeys = nprNode[0]
                if nodeType == rptstate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                rptstate = nodeType
            elif nodeFlag==1 and nprNode[0].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                testKey = nodeKeys.split(chr(30))
                subkeys=[]
                if len(testKey)>2:
                    if testKey[2][:2] in ['AT','DC','FI','SE']:
                        self.convertQueuedString(testKey[2][2:],subkeys)
                        testKey[2]=testKey[2][:2]
                        testKey.append(subkeys[0])

                    elif testKey[2][0] in ['F','N','I','L','P','U','T']:
                        if len(testKey[2])>1:
                               self.convertQueuedString(testKey[2][1:],subkeys)
                               testKey[2]=testKey[2][:1]
                        else:  pass


                if len(testKey)>3:
                    if testKey[3] in ['CL','LC']:
                        if '\x01' in testKey[4]:
                            subkeys.append(testKey[4].split('\x01')[1])
                            testKey[4]=testKey[4].split('\x01')[0]
                        elif '\x02' in testKey[4]:
                            subkeys.append(testKey[4].split('\x02')[1])
                            testKey[4]=testKey[4].split('\x02')[0]
                        else:
                            testKey[4]=testKey[4][:3]
                nodeKeys = testKey
                    
                elementQ = ''
                if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                    elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ += nodeKeys[3][0]
#                if elementQ in ['F','FS','FC','L','LC','N','P','FI']:
#                    nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]

    #            nodeKeys = "|".join(nodeKeys)

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                nodeValList = []
                try:
                    if nodeKeys[2] in ['','DC','N','P']:
                        pass
                    elif nodeKeys[3] in ['C','CL','DA','DT']:
                        pass
                    else:
                        self.convertQueuedString(nprNode,nodeValList)
                        nprNode = '|'.join(nodeValList)
                except:
                        self.convertQueuedString(nprNode,nodeValList)
                        nprNode = '|'.join(nodeValList)
                    
                if rptname == nodeKeys[1]:
                    pass
                elif rptstate == 'IR':
                    if len(rptname)>0:
                        fout.write('</'+xmlnodes.pop()+'>\n')
                        
                    fout.write('<report name=\"'+nodeKeys[1]+'\">')
                    xmlnodes.append('report')
                    rptname = nodeKeys[1]
                else:
    #                if len(menuname)>0:
    #                    fout.write('</'+xmlnodes.pop()+'>\n')
                    print nodeType, nodeKeys, nprNode
                    fout.write('<unknown name=\"'+nodeKeys[2]+'\" appl=\"'+nodeKeys[1]+'\" active=\"'+nprNode[0]+'\" />')
                    menuname = ''
    #                xmlnodes.append('index')
                if len(nodeKeys)==2:
                    i = 0
                    irange = len(HDR_ELEMS)
                    hdrlabel=''
                    rankId=''
                    rank=i
                    for headerElement in nodeValList:
                        hdrlabel=HDR_ELEMS[i]
                        if hdrlabel=='unk':
                            rankId=' offset=\"'+str(rank)+'\"'
                        else:
                            rankId=""
                            
                        fout.write('<'+HDR_ELEMS[i]+rankId+'>'+self.escapedhtmString(headerElement)+'</'+HDR_ELEMS[i]+'>\n')
                        if i+1 < irange : i += 1
                        rank += 1
                elif len(nodeKeys)>2 or len(nodeKeys)==2 and len(subkeys)>0:
#                    nodekeylist = nodeKeys[2]
                    nodekeyQ = nodeKeys[2]
#                    if len(nodekeylist)>1: nodeId=nodekeylist[1]
#                    else: nodeId="NaN"
                    
                    if nodekeyQ=='FI':
                        op=False
                        try:
                            fout.write( '<fieldIndex row=\"'+subkeys[0]+'\" col=\"'+subkeys[2]+'\" >')
                            op=True
                            fout.write( '<length>'+nodeValList[0]+'</length>')
                            fout.write( '<field-num>'+nodeValList[1]+'</field-num>')
                        except:
                            pass
                        if op:
                            fout.write('</fieldIndex>')
                    elif nodekeyQ == 'F':
                        if len(nodeKeys)==3:
                            fout.write( '<field num=\"'+subkeys[0]+'\">')
                            fout.write( '<fldname>'+nodeValList[0]+'</fldname>')
                            fout.write( '<physAddr>'+nodeValList[1]+'</physAddr>')
                            fout.write('<linenum>'+nodeValList[len(nodeValList)-1]+'</linenum>')
                            fout.write('</field>\n')
                        elif len(nodeKeys)>3:
                            if len(subkeys)>0:
                                fout.write('<fldproperties num=\"'+subkeys[0]+'\">')
                            else:
                                fout.write('<fldproperties >')
    #                    fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>')
                            if nodeKeys[3] == 'C':
                                if len(nodeKeys)==4:
                                    fout.write('<attribute type=\"'+nodeKeys[4]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                            elif nodeKeys[3] == 'CL':
                                if len(nodeKeys)>4:
                                        fout.write('<attrib-index type=\"'+nodeKeys[4]+'\" rank=\"'+subkeys[1]+'\">')
                                        fout.write(self.escapedhtmString(nprNode)+'</attrib-index>')
                                else: pass
                                
                            elif nodeKeys[3] == 'DA':
                                fout.write('<appl-doc num=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                            elif nodeKeys[3] == 'DT':
                                fout.write('<tech-doc num=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                            elif len(nodeKeys)>4 and nodeKeys[4] == 'SE':
                                try:
                                    fout.write('<fld-select rank=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</attribute>\n')
                                except :
                                    pass
                            elif len(nodeKeys)>4 and nodeKeys[4][:2] == 'SE':
                                fout.write('<sortElement order=\"'+nodeKeys[3][1:]+'\">')
                                fout.write('<operator>'+nodeValList[0]+'</operator>')
                                fout.write('<selField>'+nodeValList[1]+'</selField>')
                                if len(nodeValList)>2:
                                    fout.write('<scrPrompt>'+nodeValList[2]+'</scrPrompt>')
                                fout.write('</sortElement>\n')
                            elif nodeKeys[3][:1] == 'S':
                                try:
                                    fout.write('<sortElement order=\"'+nodeKeys[4][3:]+'\">')
                                    fout.write('<operator>'+nodeValList[0]+'</operator>')
                                    fout.write('<selField>'+nodeValList[1]+'</selField>')
                                    if len(nodeValList)>2:
                                        fout.write('<scrPrompt>'+nodeValList[2]+'</scrPrompt>')
                                    fout.write('</sortElement>\n')
                                except:
                                    pass
                            else:
                                fout.write('<type>'+self.escapedhtmString('|'.join(nodeKeys))+'</type>')
                                fout.write('<values>' + self.escapedhtmString(nprNode)+'</values>')
                            fout.write('</fldproperties>\n')
                    elif nodekeyQ=='P':
                        fout.write( '<picLine num=\"'+subkeys[0]+'\">'+self.escapedhtmString(nprNode)+'</picLine>\n')
                    elif nodekeyQ=='N':
                        noteq=nprNode.split(' ')
                        fout.write( '<footnote num=\"'+subkeys[0]+'\" type=\"'+noteq[0]+'\">')
                        if len(noteq)>2:
                            fout.write('<qualifier>'+noteq[1]+'</qualifier>')
                            offs=(len(noteq[0])+len(noteq[1])+2)
                            fout.write(self.escapedhtmString(nprNode[offs:])+'</footnote>\n')
                        else:
                            fout.write(self.escapedhtmString(nprNode[2:])+'</footnote>\n')
                    elif nodekeyQ=='L':
                        if len(nodeKeys)==3:
                            fout.write( '<regLine num=\"'+subkeys[0]+'\">')
                            fout.write(self.escapedhtmString(nprNode)+'</regLine>\n')
                        elif len(nodeKeys)>3:
                            fout.write('<line-properties num=\"'+subkeys[0]+'\">')
    #                    fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>')
                            if nodeKeys[3] == 'C':
                                fout.write('<line-attribute type=\"'+nodeKeys[4]+'\">'+self.escapedhtmString(nprNode)+'</line-attribute>\n')
                            elif nodeKeys[3][:2] == 'CL':
                                fout.write('<line-attrib-len type=\"'+nodeKeys[4]+'\">'+self.escapedhtmString(nprNode)+'</line-attrib-len>\n')
                            else: pass
                            fout.write('</line-properties>')
                                
                    elif nodekeyQ == 'I':
                        fout.write( '<rptIndex num=\"'+subkeys[0]+'\">')
                        fout.write(self.escapedhtmString(nprNode)+'</rptIndex>\n')
                    elif nodekeyQ == 'T':
                        fout.write( '<select-temp rank=\"'+subkeys[0]+'\">')
                        fout.write('<nodeVal>'+self.escapedhtmString(nprNode)+'</nodeVal>                                   </select-temp>\n')
                    elif nodekeyQ == 'AT':
                        fout.write( '<audit-log log=\"'+subkeys[0]+'\">')
                        fout.write('<user>'+nodeValList[0]+'</user><act-event>'+nodeValList[1]+'</act-event></audit-log>\n')
                    else:
                        nodeKeys = '|'.join(nodeKeys).join(subkeys)
                        fout.write( '<nodeQ>'+self.escapedhtmString(nodekeyQ)+'</nodeQ>')
                        fout.write( '<nprKey>'+self.escapedhtmString(nodeKeys)+'</nprKey>')
#                        if ord(nprNode[0])<32:
#                            nnode=[]
#                            self.convertQueuedString(nprNode,nnode)
#                            nprNode="|".join(nnode)
                        fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>\n')
                    
                else:
                    nodeKeys = '|'.join(nodeKeys)
                    fout.write( '<nprKey>'+self.escapedhtmString(nodeKeys)+'</nprKey>')
                    fout.write('<nodeVal>' +self.escapedhtmString(nprNode)+'</nodeVal>\n')
            else: nodeFlag = 0
                   
        while len(xmlnodes)>0:
            fout.write('</'+xmlnodes.pop()+'>\n')
    #    fout.write('</Reports>')
        fout.close()

    def fileMenus(self):
#        global definitions, RPATH

        fout = file(self.RPATH+'/'+'menus.xml','wb')
        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'menus.xsl" ?>\n\n')
 #       fout.write('<menuList>')

        xmlnodes = []
        statenames = {'IM':'menus', 'IMI':'menuIndex'}
        nodeFlag = 0
        nodeKeys = ''

        elementQ = ''
        nodeValList = []
        crflag = ''

        menustate = ''
        menuname = ''

        for nprNode in self.definitions:
            nodeType = nprNode[0].split(chr(30))[0]
            if nodeType in ['IM','IMI']:
                nodeFlag = 1
                crflag = ''
                nodeKeys = nprNode[0]
                if nodeType == menustate: pass
                elif len(xmlnodes)>0 :
                    fout.write('</'+xmlnodes.pop()+'>\n')
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                else:
                    fout.write('<'+statenames.get(nodeType)+'>')
                    xmlnodes.append(statenames.get(nodeType))
                menustate = nodeType
                    
            elif nodeFlag==1 and nprNode[0].endswith('\n'):
                crflag += "".join(nprNode)
            elif nodeFlag==1:
                nodeFlag = 0

                nodeKeys = nodeKeys.split(chr(30))
                elementQ = ''
                if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                    elementQ = nodeKeys[2][0]
                if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                    elementQ += nodeKeys[3][0]
                if elementQ in ['O','P']:
                    nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]

                nodeKeys = "|".join(nodeKeys)

                nprNode = crflag + "".join(nprNode)
                crflag = ''
                if elementQ in ['','O']: 
                    nodeValList = []
                    self.convertQueuedString(nprNode,nodeValList)
    #                nprNode = '|'.join(nodeValList)
                    nprNode = nodeValList
                    
                nodeKeys = nodeKeys.split('|')
                if menuname == nodeKeys[1]:
                    pass
                elif menustate == 'IM':
                    if len(menuname)>0:
                        fout.write('</'+xmlnodes.pop()+'>\n')
                        
                    fout.write('<menu name=\"'+nodeKeys[1]+'\">')
                    xmlnodes.append('menu')
                    menuname = nodeKeys[1]
                else:

                    fout.write('<index name=\"'+nodeKeys[2]+'\" appl=\"'+nodeKeys[1]+'\" active=\"'+nprNode[0]+'\" />')
                    menuname = ''
    #                xmlnodes.append('index')
                if elementQ =='P':
    #                print('<picLine linenum=\"'+str(nodeKeys)+'\">'+nprNode+'</picLine>')
                    fout.write('<picLine linenum=\"'+nodeKeys[3]+'\">'+self.escapedhtmString(nprNode)+'</picLine>')
                elif elementQ == 'O':
                    fout.write('<routine rlink=\"'+nodeKeys[3]+'\">')
                    fout.write('<title>'+self.escapedhtmString(nprNode[0])+'</title><proc>'+nprNode[1]+'</proc>')
                    fout.write('<menu-proc>'+nprNode[2]+'</menu-proc>')
                    fout.write('<proc-args>'+self.escapedhtmString(nprNode[3])+'</proc-args>')
                    fout.write('<piclink>'+nprNode[5]+'</piclink>')
                    fout.write('</routine>')
                elif elementQ == '':
                    fout.write('<appl access=\"'+nprNode[3]+'\">'+nprNode[0]+'</appl><name>'+nprNode[1]+'</name>')
                    fout.write('<responsible>'+nprNode[2]+'</responsible>')
                    fout.write('<description>'+self.escapedhtmString(nprNode[6])+'</description>')
                    
                    
            else: nodeFlag = 0
        
        while len(xmlnodes)>0:
            fout.write('</'+xmlnodes.pop()+'>\n')
#        fout.write('</menuList>')
        fout.close()

    def fileScreens(self):
#        global definitions, RPATH, fout

        fout = file(self.RPATH+'/'+'screens.xml','wb')
        fout.write('<?xml version="1.0"?>\n\n')
        fout.write('<?xml-stylesheet type="text/xsl" href="'+self.home+'screens.xsl" ?>\n\n')
        fout.write('<screens>')

        self.addDpmList(fout)
        nodeFlag = 0
        nodeKeys = ''

        elementQ = ''
        nodeValList = []
        crflag = 0

        nodeTypeList = {"U":"unknown", 'P':"picLine", 'S':"section",'F':"field"}
        ROOT, PICTURE, SECTION, FIELD = ('U','P','S','F')
        scrname = ''
        scrattr=''
        nodeClass = ROOT
        lasttype = ROOT

        for nprNode in self.definitions:
           nodeType = nprNode[0].split(chr(30))[0]
           if nodeType == 'IS':
               nodeFlag = 1
               crflag = ''
               nodeKeys = nprNode[0]
           elif nodeFlag==1 and nprNode[0].endswith('\n'):
               crflag += "".join(nprNode)
           elif nodeFlag==1:
               nodeFlag = 0

               nodeKeys = nodeKeys.split(chr(30))
               elementQ = ''
               if len(nodeKeys)>2 and len(nodeKeys[2])>0:
                   elementQ = nodeKeys[2][0]
               if len(nodeKeys)>3 and len(nodeKeys[3])>0:
                   elementQ += nodeKeys[3][0]
               if len(nodeKeys)>4 and len(nodeKeys[4])>0:
                   elementQ += nodeKeys[4][0]
               if elementQ in ['P','PP','PF','PFC','PS','PM']:
                   nodeKeys[2] = nodeKeys[2][0:1] + '|' + nodeKeys[2][2:]
               if elementQ in ['PM']:
                   nodeKeys[3] = nodeKeys[3][0:2] + '|' + nodeKeys[3][3:]
               if elementQ in ['PF','PS','PFC','PP']:
                   nodeKeys[3] = nodeKeys[3][0] + '|' + nodeKeys[3][2:]
               if elementQ in ['PFC']:
                   if len(nodeKeys)>5:
                       if nodeKeys[5][:4]=='FCL0': nodeKeys[5] = 'SCL'
               nodeKeys = "|".join(nodeKeys)
               nodeKeys = nodeKeys.split('|')
               
               nprNode = crflag + "".join(nprNode)
               crflag = ''

               if elementQ in ['','P','PF','PM','PS']: 
                   nodeValList = []
                   self.convertQueuedString(nprNode,nodeValList)
                   nprNode = '|'.join(nodeValList)

               nprNode = nprNode.replace('>','&gt;') 
               nprNode = nprNode.replace('<','&lt;') 
               nprNode = nprNode.replace('&','&amp;').replace('"','&quot;') 
               if len(nodeKeys)==2:
                   if scrname==nodeKeys[1]:
                       print "Error in logic"
                   elif len(scrname)>0:
                       scrname = nodeKeys[1]
                       if nodeClass == ROOT: 
                           pass
                       else:
                           fout.write('</'+nodeTypeList[nodeClass]+'s>')
                       fout.write('</screen><screen>')
                       nodeClass = ROOT
                   else:
                       scrname = nodeKeys[1]
                       fout.write('<screen>')
                   fout.write(self.parseXML(['screen'],nprNode))
               elif len(nodeKeys)==4:
                   fout.write(self.parseXML(['title'],nprNode.strip('\n')))
               elif len(nodeKeys)==6:
                   if nodeKeys[4] in nodeTypeList.keys():
    #                   fout.write('<!--'+nodeClass+'; '+str(nodeKeys)+'-->')
                       element = nodeTypeList[nodeKeys[4]]
                       if nodeClass == FIELD:
                           fout.write('</'+nodeTypeList[nodeClass]+'>')
                       if nodeClass == nodeKeys[4]:
                           pass
                       else:
                           if nodeClass == ROOT: 
    #                           fout.write('<!--(new)'+nodeClass+'; '+ROOT+', '+str(nodeKeys)+'-->')
                               fout.write('<'+element+'s>')
                           else:
                               fout.write('</'+nodeTypeList[nodeClass]+'s><'+element+'s>')
                       fout.write('<'+element+'>'+self.parseXML(nodeKeys[4:],nprNode))
                       nodeClass = nodeKeys[4]
                       if not nodeClass == FIELD:
                           fout.write('</'+element+'>\n')
                   else:
                       pass
               elif len(nodeKeys)==8 and nodeClass == FIELD :
                   if nodeKeys[6]=='C':
                       fout.write('<attrib type=\"'+nodeKeys[7]+'\">'+nprNode+'</attrib>')
               else:
                   pass
                    
    #           fout.write( '{{'+nodeKeys+'}|{' + nprNode+'}}|\n')
           else: nodeFlag = 0
        if len(scrname)>0:
            if not nodeClass == ROOT:
                print nodeClass, nodeTypeList[nodeClass]
                fout.write('</'+nodeTypeList[nodeClass]+'s>\n')
            fout.write('</screen>')
            fout.write('</screens>')
        fout.close()
        
    def parseXML(self, fldtypes, vals):
#        global fout
        retStr = ''
        fldtype = fldtypes[0]
        if fldtype == 'F' :
            nvals = vals.split('|')
            if len(nvals)>4:
                retStr = '<name>'+nvals[0]+'</name><field-id>'+fldtypes[1]+'</field-id><row>'+nvals[3]+'</row>'
                retStr = retStr+'<column>'+nvals[4]+'</column><section>'+nvals[2]+'</section>'
        elif fldtype == 'screen' :
            nvals = vals.split('|')
            if len(nvals)>11:
                retStr = '<name active=\"'+nvals[0]+'\">'+nvals[3]+'</name><dpm idx=\"'+str(self.dpmNames.index(nvals[2])+1)+'\">'+nvals[2]+'</dpm><audit-name>'+nvals[1]+'</audit-name><screen-type>'+nvals[4]+'</screen-type>'
                retStr = retStr +'<dataseg>'+nvals[6]+'</dataseg><multi-page>'+nvals[7]+'</multi-page><fragment>'+nvals[11]+'</fragment>\n'
        elif fldtype == 'title' :
            nvals = vals.split('|')
            if len(nvals)>1:
                retStr = '<title>'+nvals[0]+'</title><file-prompt>'+nvals[1]+'</file-prompt>\n'
        else:
            if len(fldtypes) ==2: pass
            else: print type(fldtypes), fldtypes
            retStr = vals

        return retStr

    # __main__()

    def run(self):
        import time
        import sys
        import os
        from os import path, mkdir
        import xml.dom.minidom
        import xml.dom.NodeFilter
        FNAME=self.getfile()
        if FNAME !='':
           fa = file(FNAME,'rb')
           fb = file(path.dirname(FNAME)+'/'+'out.pkg.txt','wb')
#           self.openlogfile('XML style output: '+FNAME)

#           print self.logfile.tell()

           lpath=FNAME.split('.')
           
           self.RPATH = path.dirname(FNAME)
           if path.isdir(self.RPATH): pass
           else: os.mkdir(self.RPATH)

    #       print fb111
           ddefs, screens, reports = self.parseInput(fa.readlines())

#           self.fileDatadefs()
#           self.fileScreens()
#           self.fileReports()
#           self.fileMenus()
          
    #       print programNames
    
           for dpm in self.dpmNames:
              if False:
                  if path.isdir(self.RPATH+'/'+dpm): pass
                  else: mkdir(self.RPATH+'/'+dpm)
#                      self.writelog(str( dpm ))
# print datadefs
           for dd in ddefs.keys():
               self.makeTree
               x=MagicNode()
               x.setkeys(['datadefs'])
               self.makeTree(ddefs[dd],x,99999)
               dpm=self.finddpm(dd)
               fdef=self.RPATH+'/'+dpm+'/datadefs.xml'
               if path.isdir(self.RPATH+'/'+dpm):
                   pass
               elif path.isdir(self.RPATH+'/FSDICTS'):
                   fdef = self.RPATH+'/FSDICTS/'+ dpm.replace(".","_") + " datadefs.xml"
               else:
                   mkdir(self.RPATH+'/FSDICTS')
                   fdef = self.RPATH+'/FSDICTS/'+ dpm.replace(".","_") + " datadefs.xml"
               fs=file(fdef,'w')
               fs.write('<?xml version="1.0" ?>\n')
               fs.write('<?xml-stylesheet type="text/xsl" href="C:/Iatric/csdefs-ddef.xsl" ?>\n\n')
               sys.stdout = fs               
               x.printTreeXml()
#               print('</datadefs>\n')
               sys.stdout = sys.__stdout__
               fs.close()
               
# print screens
           for dd in screens.keys():
               self.makeTree
               x=MagicNode()
               x.setkeys(['screens'])
               self.makeTree(screens[dd],x,99999)
               dpm=self.finddpm(dd)
               if path.isdir(self.RPATH+'/'+dpm):
                   pass
               else:
                   mkdir(self.RPATH+'/'+dpm)

               fn=dd[dd.find(dpm)+len(dpm)+1:]
               fdef=self.RPATH+'/'+dpm+'/'+fn+'_S.xml'
               fs=file(fdef,'w')
               fs.write('<?xml version="1.0" ?>\n')
               fs.write('<?xml-stylesheet type="text/xsl" href="C:/Iatric/csdefs-scr.xsl" ?>\n\n')
               sys.stdout = fs               
               x.printTreeXml()
#               print('</datadefs>\n')
               sys.stdout = sys.__stdout__
               fs.close()
               
# print reports
           for dd in reports.keys():
               self.makeTree
               x=MagicNode()
               x.setkeys(['reports'])
               self.makeTree(reports[dd],x,99999)
               dpm=self.finddpm(dd)
               if path.isdir(self.RPATH+'/'+dpm):
                   pass
               else:
                   mkdir(self.RPATH+'/'+dpm)
               fn=dd[dd.find(dpm)+len(dpm)+1:]
               fdef=self.RPATH+'/'+dpm+'/'+fn+'_R.xml'
               fs=file(fdef,'w')
               fs.write('<?xml version="1.0" ?>\n')
               fs.write('<?xml-stylesheet type="text/xsl" href="C:/Iatric/csdefs-rpt.xsl" ?>\n\n')
               sys.stdout = fs               
               x.printTreeXml()
#               print('</datadefs>\n')
               sys.stdout = sys.__stdout__
               fs.close()

           fb.close()
           fa.close()
#           self.logfile.close()
           print 'Done'
        else:
           self.writelog( 'ABORTED BY USER','print')

    def finddpm(self,s):
        dpmx=s.split('.')
        dpm=[]
        for n in dpmx:
            if n.upper()==n: 
                dpm.append(n)
            else: 
                break
        #if len(dpm)>1:
        #    dpm.pop(0)
        return ".".join(dpm)  
