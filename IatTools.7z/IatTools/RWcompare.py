class RWcompare:
    
    def __init__(self, initargs=[]):
        if len(initargs)>0:
            self.top=initargs[0]
        if len(initargs)>1:
            self.tbox=initargs[1]
        self.initConstants()
        self.run()
        
    def initConstants(self):
        self.basedir='C:/Iatric Systems/Visual Smartboard/Targetted Solutions/RAC'
        pass

    def getfileorig(self, mask="*.rw"):
    #    global tmpname, alines, fmode, tname, _isCompressed
        from tkFileDialog import askopenfilename
        from os import path
    #    import _winreg
        defpath='C:/Iatric Systems/Visual Smartboard/Targetted Solutions/RAC/conversions/Fitzgibbon'
        FNAME = askopenfilename(initialdir=defpath, filetypes=[("", mask)])
        return FNAME

    def getfile(self,mask="*.rw"):
    #    global tmpname, alines, fmode, tname, _isCompressed
        from tkFileDialog import askopenfilename
        from os import path
        import _winreg
        FNAME=''
        
        if True:
            zt=_winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,"Software"),"ztools")
            ztm=_winreg.OpenKey(zt,"compares",0,_winreg.KEY_ALL_ACCESS)
            last =''
            lastfn='*'+mask
            try:
                last=_winreg.QueryValueEx(ztm,"LastCompRACReports")[0]
            except:
                print 'Error reading reg keys'
                
            if len(last)>0:
                self.basedir=last

            FNAME = askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", mask)])
#            self.writelog('Importing '+mask.split('.')[1]+' package: '+ FNAME)
#            print 'Importing',mask.split('.')[1],'package:', FNAME
            if FNAME != '':
                try :
                    pp = path.dirname(FNAME)
                    _winreg.SetValueEx(ztm,"LastCompRACReports",0,_winreg.REG_SZ, path.dirname(FNAME))
                except:
#                    self.writelog('Error writing keys')
                    print 'Error writing keys'
            _winreg.CloseKey(ztm)
            _winreg.CloseKey(zt)
        else:
            print 'Error Reading file or reg keys'
            pass

        
        return FNAME


    def prettyprint(self, s,fout=[]):
        if fout:
            fout.write(s+'\r\n')
        else:
            print s
            
    def headerseg(self, d, fb):
        from xml.dom import minidom
        elelist = ['Filename','mt','Hospital','MIS','Directory','User','Date',
                   'Segment','Description']

        dataseg = [1,2,3,4,5,6,7,8,9]
        i=0
        for t in elelist:
            dataseg[i]=''
            i+=1
            
        items = d.getElementsByTagName('hdrElement')
        for item in items:
            a=item.getAttribute('name')
            if item.hasChildNodes():
                dataseg[elelist.index(a)]=str(item.firstChild.nodeValue)
        dataseg.pop(0)
        s='^'.join(dataseg)
        self.prettyprint( s, fb)

    def procinfoseg(self,d, fb):
        from xml.dom import minidom
        dpm=''
        rpt=''
        elelist = ['DPM','Name','Responsible','Access','Active',
                   'Arguments','Menu Logic','translate-as','switch-appl']
    #               'interruptable','undef','source-ship']
        dataseg = range(len(elelist))
        i=0
        for t in elelist:
            dataseg[i]=''
            i+=1
            
            
        items = d.getElementsByTagName('secInfoItem')
        limit=False
        for item in items:
            a=item.getAttribute('name')
            try:
                if item.hasChildNodes() and not limit:
                    v=str(item.firstChild.nodeValue)
                    if v == '\n':
                        limit= True
                    else:
                        dataseg[elelist.index(a)]=v
            except:
                print 'Error', item.toxml()+'\n', d.toxml()
        s=self.self.writeQString(dataseg)
        self.prettyprint(s, fb)
    #    print d.toxml()
    #    print dataseg
    #    print s

    def macrolist(self, d, fb):
        from xml.dom import minidom
        
        items = d.getElementsByTagName('secInfoItem')
        dpm = ''
        pname = ''
        for item in items:
            a=item.getAttribute('name')
            if a == "DPM":
                if item.hasChildNodes():
                    dpm=str(item.firstChild.nodeValue)
            elif a == 'Name':
                if item.hasChildNodes():
                    pname=str(item.firstChild.nodeValue)
                
        if len(dpm)>0 and len(pname)>0:
            ml=os.listdir(FF+'/'+dpm)
            for m in ml:
                if path.isfile(FF+'/'+dpm+'/'+m) and m.startswith(pname) and m.endswith('.magic'):
                    f2=open(FF+'/'+dpm+'/'+m)
                    self.prettyprint('@@MACRO\r\n'+dpm+'.'+m[:len(m)-6], fb)
                    n=0
                    lines = f2.readlines()
                    for ln in lines:
                        self.prettyprint(str(n)+'\r\n'+ln.strip('\r\n'),fb)
                        n+=1
                    f2.close()


    def scrninfoseg(self, d, fb):
        from xml.dom import minidom
        dpm=''
        rpt=''
        elelist = ['active','Name','DPM','Procedure Name','Screen Type','scrn-refresh','scrn-dataseg',
                   "scrn-mult-pages","scrn-mult-page-no","scrn-window","scrn-graph-selects","scrn-fragment",
                   "scrn-rpt-sched","scrn-audit-trail","scrn-exit-show","scrn-exit-prompt","scrn-source-ship"]
    #               'unknown']
        dataseg = range(len(elelist))
        i=0
        for t in elelist:
            dataseg[i]=''
            i+=1
        dataseg=dataseg[:len(elelist)]
        limit = False
            
        items = d.getElementsByTagName('secInfoItem')
        for item in items:
            a=item.getAttribute('name')
            if item.hasChildNodes() and not limit:
                v = str(item.firstChild.nodeValue)
                if v == '\n':
                    limit=True
                else:
                    dataseg[elelist.index(a)]=str(item.firstChild.nodeValue)
        s=self.self.writeQString(dataseg)
        self.prettyprint( s, fb)
        items = d.getElementsByTagName('cs-seg')
        self.dataSegment(items)
        items = d.getElementsByTagName('line')
        self.dataSegment(items)

    def dataSegment(self, d, fb):
        from xml.dom import minidom
        for item in d:
            keyset=item.getElementsByTagName('key')
            valset=item.getElementsByTagName('values')
    #        print keyset, valset,
            if keyset[0].hasChildNodes():
    #            print keyset[0].toxml()
                s=str(keyset[0].firstChild.nodeValue).split('|')
                if len(s[1]) == 0:
                    s=s[0]
                else:
                    s=s[0]+self.self.writeQString(s[1:])
                self.prettyprint(s, fb)
    #            print s
                s=''
                if valset[0].hasChildNodes():
                    s=str(valset[0].firstChild.nodeValue).split('|')
                    s=self.self.writeQString(s)
                self.prettyprint(s, fb)
    #            print s

        

    def rptinfoseg(self, d, fb):
        from xml.dom import minidom
        dpm=''
        rpt=''
        knownTags = ['audits','compiles','rpt-docs','picLines','footnotes',
                     'usage-logs','sort-temps','line-attribs','fieldIndexs','fields']
        subscripts = {"fieldIndex":['row','col']}
        
        knownTagConstants = ['AT','CI','DC','P','N','U','T','L','FI','F']
        notQstring = ['DC','P','N','FC']
        elelist = ['Active','rptname','segDPM','detailSeg','title','hdrType','fontsize','lineWidth',
                   'lines-per-inch','pageHeight','oseg-dpm','pageSize','logical-name','hasPgTrailer',
                   'hasrptHdr','hasrptTrailer','hasDetail','hasPgHdr','acc-path','sort-modify','left-margin',
                   'rw.version','graph','report.convert.flag','report.translate.flag','report.pay.secure.fail',
                   'report.source.ship','unk']

        dataseg = range(len(elelist))
        i=0
        
        for t in elelist:
            dataseg[i]=''
            i+=1
    #    dataseg=dataseg[:len(elelist)]
            
        dc = d.childNodes
        orderedSubs = subscripts.keys()

        for ch in dc:
            if ch.hasChildNodes():
                tag = ch.tagName
    #            print tag
                limit = False
                if tag == 'sectionInfo':
                    items = ch.getElementsByTagName('secInfoItem')
                    for item in items:
                        a=item.getAttribute('name')
                        if item.hasChildNodes() and not limit:
                            v = str(item.firstChild.nodeValue)
                            if v == '\n':
                                limit=True
                            else:
                                dataseg[elelist.index(a)]=str(item.firstChild.nodeValue)
                                
                    s=self.self.writeQString(dataseg)
                    self.prettyprint( s, fb)
                elif tag in knownTags:
    #                print 'knowntags',tag

                    items = ch.getElementsByTagName(tag[:len(tag)-1])
                    ltrs = knownTagConstants[knownTags.index(tag)]
                    sltrs=ltrs
                    for item in items:
    #                    print item
                        anames=item.attributes
                        akeys=[]
                        aindex = 0
                        subarray = []
                        if item.tagName in orderedSubs:
                            subarray = subscripts[item.tagName]
                            akeys=range(len(subarray))
                        me=["","","","","","",'','','','','','','','','','','','','','','','','']
                        if anames.length>0:
                                
                            while aindex < anames.length:
                                a = anames.item(aindex)
                                if len(subarray)>0:
                                    akeys[subarray.index(a.name)]=str(a.nodeValue)
                                else:
                                    akeys.append(str(a.nodeValue))
                                aindex+=1
                            cnodes = item.childNodes
                            n = 0
                            prevTag =''
                            sltrs=ltrs
                            for c in cnodes:
                                if not c.nodeType == minidom.Node.ELEMENT_NODE:
                                    pass
                                elif c.tagName=='sortElement':
                                    self.prettyprint(ltrs+self.writeKeys(akeys),fb)
                                    self.prettyprint(self.self.writeQString(me[:n]), fb)
                                    akeys=akeys[:1]
                                    akeys.append('SE')
                                    akeys.append(str(c.getAttribute('seq')))
                                    me=''
                                    if c.hasChildNodes:
                                        me=str(c.firstChild.nodeValue).split('|')
                                    n=len(me)
    #                                print akeys, me, n
                                elif c.tagName=='attribute' :
    #                                print c.nextSibling, c.previousSibling
                                    if cnodes.index(c)==len(cnodes)-1:
    #                                    c.nextSibling.nodeType == minidom.Node.ELEMENT_NODE:
                                        pass
                                    elif not sltrs == 'FC':
                                        self.prettyprint( ltrs+self.writeKeys(akeys), fb)
                                        self.prettyprint( self.self.writeQString(me[:n]), fb)
                                    else:
                                        self.prettyprint( ltrs+self.writeKeys(akeys),fb)
                                        self.prettyprint( me[0], fb)
    #                                print 'a)',akeys, c.getAttribute('type')
                                        
                                    sltrs='FC'
                                    akeys=akeys[:1]
                                    akeys.append('C')
                                    akeys.append(str(c.getAttribute('type')))
                                    me=''
                                    if c.hasChildNodes():
    #                                    print 'b)',type(c)
                                        me=[str(c.firstChild.nodeValue)]
                                    n=1
                                    prevtag=c.tagName
    #                                print 'c)',akeys, c
    #                                print tag,akeys, me, len(me)
                                        
                                elif c.hasChildNodes():
    #                                print tag, c
    #                                print c.toxml()
                                    me[n]=str(c.firstChild.nodeValue)
                                    n+=1
                                    prevTag = c.tagName
                                else:
                                    n+=1
    #                            prevTag=c.tagName
    #                        print 'almost done', akeys, me, n
                            if n>0:
                                me=me[:n]
    #                        print 'done', akeys, me
    #                        print me
                        else:
                            subnodes = item.childNodes
                            me=[]
                            for nd in subnodes:
                                if nd.nodeType == minidom.Node.ELEMENT_NODE:
                                    if nd.tagName == 'key':
                                        akeys=str(nd.firstChild.nodeValue).split('|')
                                    elif nd.tagName == 'values':
                                        me=str(nd.firstChild.nodeValue).split('|')
                                    else:
                                        v=''
                                        if nd.hasChildNodes():
                                            v = str(nd.firstChild.nodeValue)
                                        me.append(v)
                            if len(akeys)>0: akeys.pop(0)
    #                        print akeys, me
                                
                        self.prettyprint( ltrs+self.writeKeys(akeys),fb)
    #                    +self.self.writeQString((a))
    #                    if not sltrs == ltrs:
                        if ltrs in notQstring or sltrs in notQstring:
                            self.prettyprint( me[0], fb)
                        else:
    #                        print 'production', akeys, me
                            self.prettyprint( self.self.writeQString(me), fb)



    def junk(self):
        from xml.dom import minidom
        items = d.getElementsByTagName('line')
        for item in items:
            if item.hasChildNodes():
                s=str(item.firstChild.nodeValue).split('}|{')
                keys=s[0][1:].split('|')
                vals=s[1][:len(s[1])-1].split('|')
                keys=chr(30).join(keys)
                s=self.self.writeQString(vals)
                self.prettyprint( self.writeKeys(keys)+'.',fb)
                self.prettyprint( s, fb)
                
    def writeKeys(self, s):
        v = ''
        for item in s:
            try:
                i=int(item)
                v=v+chr(len(item))+item
            except:
                v=v+chr(30)+item
        return v

    def unescapedHtml(self, s):
        if '&lt;' in s or '&gt;' in s or '&amp;' in s:
            s.replace('&lt;','<').replace('&gt;','>').replace('&amp;','&')
        return s

    def writeQString(self, s):
        v = ''
        for item in s:
            v=v+chr(len(item))+item
        return v

    def genreftable(self, xm,refarray):
        from xml.dom import minidom
        for sec in xm:
            if sec.hasAttribute("name") and sec.getAttribute("name") == 'reports':
                secItems=sec.getElementsByTagName('secInfoItem')
                rptname=''
                ref_fields={}
                ref_notes={}
                
                for secItem in secItems:
                    if len(rptname)> 0:
                        break
                    elif secItem.getAttribute('name')=='rptname':
                        try:
                            rptname = secItem.firstChild.nodeValue
                            print rptname
                        except:
                            pass
                try:
                    secItems=sec.getElementsByTagName('fields')[0]
                    secItems=secItems.getElementsByTagName('field')
                    print sec.getAttribute('name'), rptname, len(secItems)
                    for secItem in secItems:
                        fldattrs=[]
                        rank='0'
                        fldname=''
                        try:
                            rank=secItem.getAttribute('rank')
                            fld=secItem.getElementsByTagName('fldname')[0]
                            fldname=fld.firstChild.nodeValue               
                            attrs=secItem.getElementsByTagName('attribute')
                            for att in attrs:
                                fldattrs.append(att.getAttribute('type')+'='+att.firstChild.nodeValue)
                            
                        except:
                            pass
                        ref_fields[fldname]=fldattrs
                except IndexError:
                    pass

                try:
                    secItems=sec.getElementsByTagName('footnotes')[0]
                    secItems=secItems.getElementsByTagName('footnote')
                    for secItem in secItems:
                        fldattrs=[]
                        rank='0'
                        fldname=''
                        try:
                            note=secItem.getElementsByTagName('note')[0]
                            fld=note.firstChild.nodeValue.split(" ")
                            fldname=" ".join(fld[:2])
                            fldattrs.append([fldname," ".join(fld[2:])])
                        except:
                            pass
                        ref_notes[fldname]=fldattrs
                    print ref_notes
                except IndexError:
                    pass
                refarray.append((rptname,ref_fields,ref_notes))
        
    def run(self):
        from xml.dom import minidom
        from os import path
        import os
        import Tkinter
        from Tkinter import Listbox
        
        FNAME = self.getfile('*.xml')

        print type(self.tbox)
        if len(FNAME)<3:
            self.tbox.insert(Tkinter.END,'Exiting .. no source file identified')
            return

        xt=minidom.parse(FNAME)

        FF= path.basename(FNAME[:len(FNAME)-4].strip())

        #print FF, path.isdir(FF)

        fbname=FNAME.split('.')
        fbname='.'.join(fbname[:len(fbname)-1])
#        print fbname
        #fb=open(fbname+'.cmp.xml','wb')

        xtd=xt.getElementsByTagName('sections')
#        print xt,len(xtd)
        reffields=[]

        self.genreftable(xtd,reffields)


        fn2=self.getfile('*.xml')
        if len(fn2)<3:
            self.tbox.insert(Tkinter.END,'Exiting .. no target file identified')
            return
        
        FF2= path.basename(fn2[:len(fn2)-4].strip())
        FN= path.dirname(fn2)+'/diff '+FF+' vs. '+FF2+'.xml'
        fb=open(FN,'wb')

        xt=minidom.parse(fn2)

        xtd=xt.getElementsByTagName('sections')
        rptfields=[]

        self.genreftable(xtd,rptfields)

        rptlist=[]
        modlist=[]
        for item in rptfields:
            rptlist.append(item[0])


        fb.write('<?xml version="1.0" ?>\n') 
        fb.write('<?xml-stylesheet type="text/xsl" href="c:/iatric/rptw-diff.xsl" ?> \n\n')
        fb.write('<rwdiff>\n')
        fb.write('<ref-report>'+FF+'</ref-report>\n')
        fb.write('<cmp-report>'+FF2+'</cmp-report>\n')
        for item in rptfields:
            status='Deleted'
            rptstatus="Deleted"
            fb.write('<report>'+item[0])
            if item[0] in rptlist:
                modlist.append(item[0])
                rptstatus="Same"
                for refitem in reffields:
                    if item[0]==refitem[0]:
                        status='Same'
                        refitemlist=refitem[1].keys()
                        itemlist=item[1].keys()
                        for rk in refitemlist:
                            if not rk in itemlist: itemlist.append(rk)
                        fb.write('<fields>')
                        for k in itemlist:
                            reffld=[]
                            attrslist={}
                            if k not in refitemlist:
                                status='New'
                                for s in item[1][k]:
                                    attrval=s.split('=')
                                    attrslist[attrval[0]]=["",attrval[1]]
                            else:
                                reffld=refitem[1][k]
                                status="Same"
                                for sr in reffld:
                                    attrval=sr.split('=')
                                    attrslist[attrval[0]]= [attrval[1],'']
                                if k not in item[1]:
                                    status="Deleted"
                                else:
                                    for s in item[1][k]:
                                        attrval=s.split('=')
                                        if attrval[0] in attrslist:
                                            skv=attrslist[attrval[0]]
                                            skv[1]=attrval[1]
                                            attrslist[attrval[0]]=skv
                                        else:
                                            attrslist[attrval[0]]=["",attrval[1]]
                                            
                            fldstatus=status
                            if rptstatus=="Same" and not status=="Same":
                                rptstatus="Modified"
                            fldattr=''
                            for k1 in attrslist:
                                sk=attrslist[k1]
                                if sk[0]=='':
                                    fldstatus="New"
                                elif sk[1]=='':
                                    fldstatus="Deleted"
                                elif sk[0]==sk[1]:
                                    fldstatus="Same"
                                else:
                                    fldstatus="Modified"

                                fldattr=fldattr+'<attrib-fld fld-status=\"'+fldstatus+'\" type=\"'+k1+'\">'
                                if len(sk[1])>0:
                                    fldattr=fldattr+'<attrval>'+sk[1]+'</attrval>'
                                if len(sk[0])>0:
                                    fldattr=fldattr+'<attrib-ref>'+sk[0]+'</attrib-ref></attrib-fld>'
                                else:
                                    fldattr=fldattr+'</attrib-fld>'                            
                                
                                if not fldstatus =='Same' and status == 'Same':
                                    status="Modified"
                            fb.write('<field status=\"'+status+'\">'+k)
                            fb.write(fldattr)
                            fb.write('</field>\n')
                        fb.write('</fields>\n')
                        

        #Compare footnotes
                for refitem in reffields:
                    if item[0]==refitem[0]:
                        refitemlist=refitem[2].keys()
                        itemlist=item[2].keys()
                        for rk in refitemlist:
                            if not rk in itemlist: itemlist.append(rk)
                        fb.write('<footnotes>')
                        for k in itemlist:
                            reffld=[]
                            attrslist={}
                            if k not in refitemlist:
                                status='New'
                                for s in item[2][k]:
                                    attrval=s
                                    attrslist[attrval[0]]=["",attrval[1]]
                            else:
                                reffld=refitem[2][k]
                                status="Same"
                                for sr in reffld:
                                    attrval=sr
                                    attrslist[attrval[0]]= [attrval[1],'']
                                if k not in item[2]:
                                    status="Deleted"
                                else:
                                    for s in item[2][k]:
                                        attrval=s
                                        if attrval[0] in attrslist:
                                            skv=attrslist[attrval[0]]
                                            skv[1]=attrval[1]
                                            attrslist[attrval[0]]=skv
                                        else:
                                            attrslist[attrval[0]]=["",attrval[1]]
                                            
                            fldstatus=status
                            if rptstatus=="Same" and not status=="Same":
                                rptstatus="Modified"
                            fldattr=''
                            for k1 in attrslist:
                                sk=attrslist[k1]
                                if sk[0]=='':
                                    fldstatus="New"
                                elif sk[1]=='':
                                    fldstatus="Deleted"
                                elif sk[0]==sk[1]:
                                    fldstatus="Same"
                                else:
                                    fldstatus="Modified"

                                fldattr=fldattr+'<note fld-status=\"'+fldstatus+'\" type=\"'+k1+'\">'
                                if len(sk[1])>0:
                                    fldattr=fldattr+'<attrval>'+sk[1]+'</attrval>'
                                if len(sk[0])>0:
                                    fldattr=fldattr+'<note-ref>'+sk[0]+'</note-ref></note>'
                                else:
                                    fldattr=fldattr+'</note>'                            
                                
                                if not fldstatus =='Same' and status == 'Same':
                                    status="Modified"
                            fb.write('<footnote status=\"'+status+'\">')
                            fb.write(fldattr)
                            fb.write('</footnote>\n')
                        fb.write('</footnotes>\n')
                        
        #        status="Exists"
            fb.write('<report-comp status=\"'+rptstatus+'\" /></report>\n')
        for item in reffields:
            if item[0] not in modlist:
                fb.write('<report status=\"New\">')
                fb.write('</report>\n')

        fb.write('</rwdiff>\n')

                

        fb.close()
        self.tbox.insert(Tkinter.END,'Compare .. '+FF+' vs. '+FF2)

        xt=''
