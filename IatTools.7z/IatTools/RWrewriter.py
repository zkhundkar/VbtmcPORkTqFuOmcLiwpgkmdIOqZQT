class RWrewriter:
    
    def __init__(self, initargs=[]):
        if len(initargs)>0:
            self.top=initargs[0]
        self.initConstants()
        self.run()
        
    def initConstants(self):
        self.basedir='C:/Iatric Systems/Visual Smartboard/Targetted Solutions/RAC'
        pass

    def getfile(self,mask="*.rw"):
    #    global tmpname, alines, fmode, tname, _isCompressed
        from tkFileDialog import askopenfilename
        from os import path
        import _winreg
#        defpath='C:/Iatric Systems/Visual Smartboard/Targetted Solutions/RAC'
#        FNAME = askopenfilename(initialdir=defpath, filetypes=[("", mask)])
        if True:
            zt=_winreg.OpenKey(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,"Software"),"ztools")
            ztr=_winreg.OpenKey(zt,"reports")
            mode=_winreg.QueryValueEx(ztr,"LastArchiveType")[0]
            ztm=_winreg.OpenKey(ztr,mode,0,_winreg.KEY_ALL_ACCESS)
            last=_winreg.QueryValueEx(ztm,"LastDir")[0]
            lastfn=_winreg.QueryValueEx(ztm,"LastArchive")[0]
            lastfn=lastfn.split('.')
#            lastfn='*.'+lastfn[len(lastfn)-1]
            lastfn=mask

            if len(last)>0:
                self.basedir=last
#            getfile(base,lastfn)

#            FNAME = tkFileDialog.askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", "*.pkg")])
            FNAME = askopenfilename(initialdir=self.basedir, initialfile=lastfn, filetypes=[("", mask)])
#            self.writelog('Converting '+mask.split('.')[1]+' to npr rw package: '+ FNAME)
            if FNAME != '':
                try :
                    pp = path.dirname(FNAME)
                    newmode=mode[2:];
                    mode_ch=False
                    if "Iatriscan" in pp:
                        newmode="Iatriscan"
                        mode_ch = True
                    elif "Visual" in pp:
                        newmode="vsb"
                        mode_ch = True
                    if mode_ch:
#                        print "Closing ztr"
                        _winreg.CloseKey(ztr)
#                        print 'opening ztr for writing'
                        ztr=_winreg.OpenKey(zt,"reports",0,_winreg.KEY_WRITE)
#                        print 'updating lastarchivetype'
                        _winreg.SetValueEx(ztr,"LastArchiveType",0,_winreg.REG_SZ,newmode)
                        _winreg.CloseKey(ztm)
                        ztm = _winreg.OpenKey(ztr,newmode,0,_winreg.KEY_WRITE)

#                    print "Saving LastDir:", path.dirname(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastDir",0,_winreg.REG_SZ,pp)
#                     print "Saving LastArchive:",path.basename(FNAME),'to',ztm
                    _winreg.SetValueEx(ztm,"LastArchive",0,_winreg.REG_SZ,path.basename(FNAME))
                except:
#                    self.writelog('Error writing keys')
                    print 'Error writing keys'
            _winreg.CloseKey(ztm)
            _winreg.CloseKey(ztr)
            _winreg.CloseKey(zt)
        else:
            print 'Error Reading file or reg keys'
            pass

        
        return FNAME
        return FNAME


    def prettyprint(self,s,fout=[]):
        if fout:
            fout.write(s+'\r\n')
        else:
            print s
            
    def headerseg(self,d, fb):
        from xml.dom import minidom
        elelist = ['Filename','mt','Hospital','MIS','Directory','User','Date',
                   'Segment','Description']

        dataseg = [1,2,3,4,5,6,7,8,9]
        i=0
        for t in elelist:
            dataseg[i]=''
            i+=1
            
        items = d.getElementsByTagName('hdrElement')
        for item in items:
            a=item.getAttribute('name')
            if item.hasChildNodes():
                dataseg[elelist.index(a)]=str(item.firstChild.nodeValue)
        dataseg.pop(0)
        s='^'.join(dataseg)
        self.prettyprint( s, fb)

    def procinfoseg(self,d, fb):
        from xml.dom import minidom
        dpm=''
        rpt=''
        elelist = ['DPM','Name','Responsible','Access','Active',
                   'Arguments','Menu Logic','translate-as','switch-appl']
    #               'interruptable','undef','source-ship']
        dataseg = range(len(elelist))
        i=0
        for t in elelist:
            dataseg[i]=''
            i+=1
            
            
        items = d.getElementsByTagName('secInfoItem')
        limit=False
        for item in items:
            a=item.getAttribute('name')
            try:
                if item.hasChildNodes() and not limit:
                    v=str(item.firstChild.nodeValue)
                    if v == '\n':
                        limit= True
                    else:
                        dataseg[elelist.index(a)]=v
            except:
                print 'Error', item.toxml()+'\n', d.toxml()
        s=self.writeQString(dataseg)
        self.prettyprint(s, fb)
    #    print d.toxml()
    #    print dataseg
    #    print s

    def macrolist(self,d, FF, fb):
        from xml.dom import minidom
        import os
        import os.path as path
        
        items = d.getElementsByTagName('secInfoItem')
        dpm = ''
        pname = ''
        for item in items:
            a=item.getAttribute('name')
            if a == "DPM":
                if item.hasChildNodes():
                    dpm=str(item.firstChild.nodeValue)
            elif a == 'Name':
                if item.hasChildNodes():
                    pname=str(item.firstChild.nodeValue)
                
        if len(dpm)>0 and len(pname)>0:
            ml=os.listdir(FF+'/'+dpm)
            for m in ml:
                if path.isfile(FF+'/'+dpm+'/'+m) and m.startswith(pname) and m.endswith('.magic'):
                    f2=open(FF+'/'+dpm+'/'+m)
                    self.prettyprint('@@MACRO\r\n'+dpm+'.'+m[:len(m)-6], fb)
                    n=0
                    lines = f2.readlines()
                    for ln in lines:
                        self.prettyprint(str(n)+'\r\n'+ln.strip().strip('\r\n'),fb)
                        n+=1
                    f2.close()


    def scrninfoseg(self,d, fb):
        from xml.dom import minidom
        dpm=''
        rpt=''
        elelist = ['active','Name','DPM','Procedure Name','Screen Type','scrn-refresh','scrn-dataseg',
                   "scrn-mult-pages","scrn-mult-page-no","scrn-window","scrn-graph-selects","scrn-fragment",
                   "scrn-rpt-sched","scrn-audit-trail","scrn-exit-show","scrn-exit-prompt","scrn-source-ship"]
    #               'unknown']
        dataseg = range(len(elelist))
        i=0
        for t in elelist:
            dataseg[i]=''
            i+=1
        dataseg=dataseg[:len(elelist)]
        limit = False
            
        items = d.getElementsByTagName('secInfoItem')
        for item in items:
            a=item.getAttribute('name')
            if item.hasChildNodes() and not limit:
                v = str(item.firstChild.nodeValue)
                if v == '\n':
                    limit=True
                else:
                    dataseg[elelist.index(a)]=str(item.firstChild.nodeValue)
        s=self.writeQString(dataseg)
        self.prettyprint( s, fb)
        items = d.getElementsByTagName('cs-seg')
        self.dataSegment(items, fb)
        items = d.getElementsByTagName('line')
        self.dataSegment(items, fb)

    def dataSegment(self,d, fb):
        from xml.dom import minidom
        for item in d:
            keyset=item.getElementsByTagName('key')
            valset=item.getElementsByTagName('values')
    #        print keyset, valset,
            if keyset[0].hasChildNodes():
    #            print keyset[0].toxml()
                s=str(keyset[0].firstChild.nodeValue).split('|')
                if len(s[1]) == 0:
                    s=s[0]
                else:
                    s=s[0]+self.writeQString(s[1:])
                self.prettyprint(s, fb)
    #            print s
                s=''
                if valset[0].hasChildNodes():
                    s=str(valset[0].firstChild.nodeValue).split('|')
                    s=self.writeQString(s)
                self.prettyprint(s, fb)
    #            print s

        

    def rptinfoseg(self,d, fb):
        from xml.dom import minidom
        dpm=''
        rpt=''
        knownTags = ['audits','compiles','rpt-docs','picLines','footnotes',
                     'usage-logs','sort-temps','line-attribs','fieldIndexs','fields']
        subscripts = {"fieldIndex":['row','col']}
        
        knownTagConstants = ['AT','CI','DC','P','N','U','T','L','FI','F']
        notQstring = ['DC','P','N','FC']
        elelist = ['Active','rptname','segDPM','detailSeg','title','hdrType','fontsize','lineWidth',
                   'lines-per-inch','pageHeight','oseg-dpm','pageSize','logical-name','hasPgTrailer',
                   'hasrptHdr','hasrptTrailer','hasDetail','hasPgHdr','acc-path','sort-modify','left-margin',
                   'rw.version','graph','report.convert.flag','report.translate.flag','report.pay.secure.fail',
                   'report.source.ship','unk']

        dataseg = range(len(elelist))
        i=0
        
        for t in elelist:
            dataseg[i]=''
            i+=1
    #    dataseg=dataseg[:len(elelist)]
            
        dc = d.childNodes
        orderedSubs = subscripts.keys()

        for ch in dc:
            if ch.hasChildNodes():
                tag = ch.tagName
    #            print tag
                limit = False
                if tag == 'sectionInfo':
                    items = ch.getElementsByTagName('secInfoItem')
                    for item in items:
                        a=item.getAttribute('name')
                        if item.hasChildNodes() and not limit:
                            v = str(item.firstChild.nodeValue)
                            if v == '\n':
                                limit=True
                            else:
                                dataseg[elelist.index(a)]=str(item.firstChild.nodeValue)
                                
                    s=self.writeQString(dataseg)
                    self.prettyprint( s, fb)
                elif tag in knownTags:
    #                print 'knowntags',tag

                    items = ch.getElementsByTagName(tag[:len(tag)-1])
                    ltrs = knownTagConstants[knownTags.index(tag)]
                    sltrs=ltrs
                    for item in items:
    #                    print item
                        anames=item.attributes
                        akeys=[]
                        aindex = 0
                        subarray = []
                        if item.tagName in orderedSubs:
                            subarray = subscripts[item.tagName]
                            akeys=range(len(subarray))
                        me=["","","","","","",'','','','','','','','','','','','','','','','','']
                        if anames.length>0:
                                
                            while aindex < anames.length:
                                a = anames.item(aindex)
                                if len(subarray)>0:
                                    akeys[subarray.index(a.name)]=str(a.nodeValue)
                                else:
                                    akeys.append(str(a.nodeValue))
                                aindex+=1
                            cnodes = item.childNodes
                            n = 0
                            prevTag =''
                            sltrs=ltrs
                            for c in cnodes:
                                if not c.nodeType == minidom.Node.ELEMENT_NODE:
                                    pass
                                elif c.tagName=='sortElement':
                                    self.prettyprint(ltrs+self.writeKeys(akeys),fb)
                                    self.prettyprint(self.writeQString(me[:n]), fb)
                                    akeys=akeys[:1]
                                    akeys.append('SE')
                                    akeys.append(str(c.getAttribute('seq')))
                                    me=''
                                    if c.hasChildNodes:
                                        me=str(c.firstChild.nodeValue).split('|')
                                    n=len(me)
    #                                print akeys, me, n
                                elif c.tagName=='attribute' :
    #                                print c.nextSibling, c.previousSibling
                                    if cnodes.index(c)==len(cnodes)-1:
    #                                    c.nextSibling.nodeType == minidom.Node.ELEMENT_NODE:
                                        pass
                                    elif not sltrs == 'FC':
                                        self.prettyprint( ltrs+self.writeKeys(akeys), fb)
                                        self.prettyprint( self.writeQString(me[:n]), fb)
                                    else:
                                        self.prettyprint( ltrs+self.writeKeys(akeys),fb)
                                        self.prettyprint( me[0], fb)
    #                                print 'a)',akeys, c.getAttribute('type')
                                        
                                    sltrs='FC'
                                    akeys=akeys[:1]
                                    akeys.append('C')
                                    akeys.append(str(c.getAttribute('type')))
                                    me=''
                                    if c.hasChildNodes():
    #                                    print 'b)',type(c)
                                        me=[str(c.firstChild.nodeValue)]
                                    n=1
                                    prevtag=c.tagName
    #                                print 'c)',akeys, c
    #                                print tag,akeys, me, len(me)
                                        
                                elif c.hasChildNodes():
    #                                print tag, c
    #                                print c.toxml()
                                    me[n]=str(c.firstChild.nodeValue)
                                    n+=1
                                    prevTag = c.tagName
                                else:
                                    n+=1
    #                            prevTag=c.tagName
    #                        print 'almost done', akeys, me, n
                            if n>0:
                                me=me[:n]
    #                        print 'done', akeys, me
    #                        print me
                        else:
                            subnodes = item.childNodes
                            me=[]
                            for nd in subnodes:
                                if nd.nodeType == minidom.Node.ELEMENT_NODE:
                                    if nd.tagName == 'key':
                                        akeys=str(nd.firstChild.nodeValue).split('|')
                                    elif nd.tagName == 'values':
                                        me=str(nd.firstChild.nodeValue).split('|')
                                    else:
                                        v=''
                                        if nd.hasChildNodes():
                                            v = str(nd.firstChild.nodeValue)
                                        me.append(v)
                            if len(akeys)>0: akeys.pop(0)
    #                        print akeys, me
                                
                        self.prettyprint( ltrs+self.writeKeys(akeys),fb)
    #                    +self.writeQString((a))
    #                    if not sltrs == ltrs:
                        if ltrs in notQstring or sltrs in notQstring:
                            self.prettyprint( me[0], fb)
                        else:
    #                        print 'production', akeys, me
                            self.prettyprint( self.writeQString(me), fb)



    def junk(self):
        items = d.getElementsByTagName('line')
        for item in items:
            if item.hasChildNodes():
                s=str(item.firstChild.nodeValue).split('}|{')
                keys=s[0][1:].split('|')
                vals=s[1][:len(s[1])-1].split('|')
                keys=chr(30).join(keys)
                s=self.writeQString(vals)
                self.prettyprint( self.writeKeys(keys)+'.',fb)
                self.prettyprint( s, fb)
                
    def writeKeys(self,s):
        v = ''
        for item in s:
            try:
                i=int(item)
                v=v+chr(len(item))+item
            except:
                v=v+chr(30)+item
        return v

    def unescapedHtml(self,s):
        if '&lt;' in s:
            s.replace('&lt;','<')
        if '&gt;' in s:
            s.replace('&gt;','>')
        if '&amp;' in s:
            s.replace('&amp;','&')
        return s

    def writeQString(self,s):
        v = ''
        for item in s:
            v=v+chr(len(item))+item
        return v


    def run(self):
        from xml.dom import minidom
        from os import path
        import os

        FNAME = self.getfile('*.xml')

        xt=minidom.parse(FNAME)

        FF= path.dirname(FNAME)+'/'+path.basename(FNAME[:len(FNAME)-4].strip())

#        print FF, path.isdir(FF)

        fbname=FNAME.split('.')
        fbname='.'.join(fbname[:len(fbname)-1])
#        print fbname
        fb=open(fbname+'.npr','wb')

#        print type(fb)


        xtd=xt.getElementsByTagName('header')
        if len(xtd)>0:
            self.headerseg(xtd.item(0),fb)

        self.prettyprint( '@@VERSION:1',fb)

        xtd=xt.getElementsByTagName('procedure')
        proclist=[]
        for p in xtd:
            if p.hasChildNodes():
                pr=str(p.firstChild.nodeValue)
                proclist.append(pr)
                self.prettyprint( pr, fb)

        xtd=xt.getElementsByTagName('sections')

        prcount=len(proclist)
        for pr in proclist:
            self.prettyprint('@@PROC\r\n'+pr,fb)
        #    print pr
            n=proclist.index(pr)
            self.procinfoseg(xtd.item(n),fb)
            self.macrolist(xtd.item(n),FF,fb)

            try:
                scr=xtd.item(n+prcount)
                self.prettyprint('@@RPT',fb)
                self.rptinfoseg(scr,fb)
            except:
                pass
            try:
                scr=xtd.item(n+prcount+prcount)
                self.prettyprint( '@@SCRN',fb)
                self.scrninfoseg(scr,fb)
            except:
                pass
        print "Created ../"+path.basename(fb.name)
            
        fb.close()

        xt=''
