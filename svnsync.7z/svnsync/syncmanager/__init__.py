from flask import Flask, render_template, url_for, send_file, request
from flask_bootstrap import Bootstrap
from flask_flatpages import FlatPages
#import logging
try:
    if app:
        pass
except:
    app = Flask(__name__)
    app.config.from_object('config')
    Bootstrap(app)
    pages = FlatPages(app)
    
#    app.debug = True
#    app.static_folder="C:/iatric"
    from views import views

print app,"id=",id(app)
