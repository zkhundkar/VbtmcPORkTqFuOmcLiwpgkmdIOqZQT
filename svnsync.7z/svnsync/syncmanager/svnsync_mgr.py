from flask import Flask, render_template, url_for, send_file, request, flash, redirect, make_response
from flask_bootstrap import Bootstrap
from flask_flatpages import FlatPages

from forms import LoginForm, PostForm, DevSitesForm
import time, datetime, os
import json
import sqlite3

#import logging
try:
    if app:
        pass
except: 
    app = Flask(__name__)
    app.config.from_object('config')
    Bootstrap(app)
    pages = FlatPages(app)
#app.debug = True
#app.static_folder="C:/iatric"
#import views

# Setting up the ORM layer
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from svnsync_orm import DevSites, Repos, RunLog

from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()

engine = create_engine(app.config['SYNCDB'])
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
session = DBSession()
_is_active = dict([(a,"") for a in ('home','login','devsites','repos','apps', 'runlog')])

def _set_active(page):
    for a in _is_active:
        if a == page:
            _is_active[a] = "active"
        else:
            _is_active[a] = ""

def formattedtime(t):
    try:
        if isinstance(t, int) or isinstance(t, str) or isinstance(t, unicode):
            t1=float(t)
        else:
            t1=t
        if t1>1000000000:
            tl = list(time.localtime(t1))
            return "{1:0>2d}/{2:0>2d} {3:0>2d}:{4:0>2d}".format(*tl)
        else:
            return ''
    except:
        print type(t), t
        return t


@app.route('/')
#@app.route('/static/<path:path>')
#@app.route('/svnlink/<path:path>')
def svnlink(path=None):
    if not path or path == u'svnlink' or path == u'svnlink/':
        print(request.url, path)
        return send_file("svnlink/index.html")
        
    if request.url.startswith('/static'):
        prepath = "{}"
    elif path.startswith('svnlink'):
        prepath = "{}"
    else:
        prepath = "svnlink/{}"
    print(request.url, path, prepath)
    return send_file(prepath.format(path))

@app.route("/mainindex")
def homepage():
    print(request.url)
    title = "SVN Sync Manager"
    user = {'nickname': 'Jonahon'}  # fake user
    output = ''
    try:
        _set_active('home')
        return render_template("index.html", title=title, paragraph=output, user=user, sub_site="Home", active_pages=_is_active)
        
    except Error as e:
       print("error")
       return "There was an error: "+ type(e)

    return output if len(output)>0 else "Hello World!"

@app.route('/login')
@app.route('/login2', methods=['GET', 'POST'])
def mylogin():
    form = LoginForm()
    _set_active('login')
    print form
    if form.validate_on_submit():
        print("validating..")
        flash('Login requested for OpenID="%s", remember_me=%s' %
              (form.openid.data, str(form.remember_me.data)))
        return redirect('/index')   
    print("linking to login.html..")
    return render_template('login.html', 
                           title='Sign In',
                           form=form,
                           sub_site="Login", active_pages=_is_active,
                           providers=app.config['OPENID_PROVIDERS'])    
    
    
@app.route("/api/devsites", methods=['GET', 'POST'])
def dev_sites():
    print(request.url)
    title = "SVN Sync Manager"
    user = {'nickname': 'Jonahon'}  # fake user
    form = DevSitesForm(request.form)
    output = ''
    if request.method == 'POST':
        
        print("validating..", form)
        if form.validate_on_submit():
            tz_off = 3
            new_active = form.new_active.data
            print form.new_platform.data
            plat = "CS" if form.new_platform.data=="CS" else "M"
            proto = "ICS" if plat == "M" else "UCS"
            #print("Fields:", form.new_devsite.data, form.new_active.data, form.new_ip_addr.data, form.new_port.data, plat, proto)
                
            d = DevSites(dev_site=form.new_devsite.data, active=new_active, remote_port=form.new_port.data,
                     remote_ip=form.new_ip_addr.data, platform=plat, protocol=proto, tz_offset=int(3))
            #if session.query(DevSites).get(form.new_devsite):
            #    session.query(Devsites).filter(DevSites.dev_site = form.update
            session.merge(d)
            flash('Added/updated entry')
            session.commit()
        else:
            flash("Validate on submit returned false")        #return
        #flash('Login requested for OpenID="%s", remember_me=%s' %
        #      (form.openid.data, str(form.remember_me.data)))
    print("loading devsites.html..")    
    try:
        devs = session.query(DevSites).all()
        with open('devsite.json','w') as fp:
            dsites = []
            dnames=('dev_site', 'active', 'remote_port', 'remote_ip',
                    'platform', 'protocol', 'tz_offset')
            for row in devs:
                rr={}
                dsites.append(rr)
                for name in dnames:
                    if hasattr(row, name):
                        rr[name] = getattr(row,name)
                
            json.dump(dsites, fp)
        _set_active('devsites')
        form.reset()
        return render_template("devsites.html", title=title, form=form,
                               sitelist=devs, user=user, active_pages=_is_active,
                               sub_site="devsites")
        
    except Exception as e:
       print(e)
       return "There was an error: "+ type(e)

    return output if len(output)>0 else "Hello World!"

@app.route("/repos")
def app_branches():
    print(request.url)
    title = "SVN Sync Manager"
    user = {'nickname': 'Jonahon'}  # fake user
    output = ''
    try:
        r = session.query(Repos).all()
        with open('repos.json','w') as fp:
            dsites = []
            dnames=('app', 'dsite', 'branch_id', 'active', 'appl_db', 'server_seg',
                    'server_dir', 'server_hcis', 'server_ring', 'wc_root', 'wc_svn_rel',
                    'earliest', 'last_check', 'pull_freq')
            for row in r:
                rr={}
                dsites.append(rr)
                for name in dnames:
                    if hasattr(row, name):
                        rr[name] = getattr(row,name)
                
            json.dump(dsites, fp)
        h = dict([("/".join([x.app,x.dsite,x.branch_id]), x) for x in r])
        k=h.keys()
        k.sort()
        r = [h[kitems] for kitems in k]
        _set_active('repos')

        return render_template("repos.html", title=title, repolist=r, user=user, active_pages=_is_active,
                               tformat=formattedtime, sub_site="repos")
        
    except Exception as e:
       print("error")
       return "There was an error: %s" % e

    return output if len(output)>0 else "Hello World!"

@app.route("/apps")
def app_list():
    print(request.url)
    title = "SVN Sync Manager"
    user = {'nickname': 'Jonahon'}  # fake user
    output = ''
    try:
        r = session.query(Repos).order_by('app').filter(Repos.active == True)
        rapps = [x for x in r]
        #rapps.sort()
        _set_active('apps')

        return render_template("apps.html", title=title, repolist=r, user=user, active_pages=_is_active,
                               tformat=formattedtime, sub_site="apps")
        
    except Exception as e:
       #print("error")
       return "There was an error: %s " % e

    return output if len(output)>0 else "Hello World!"

@app.route("/runlog", methods=['GET', 'POST'])
#@app.route("/runlog/<int:page>", methods=['GET', 'POST'])
def get_run_log():
    print(request.url)
    title = "SVN Sync Manager"
    user = {'nickname': 'Jonahon'}  # fake user
    output = ''
    pgsz = app.config['LOG_LINES_PER_PAGE']
    #cnt = session.query(RunLog).count()
    #print(page, pgsz)
    r=[]
    r = session.query(RunLog).all()
    _set_active('runlog')

    return render_template("runlog.html", title=title, runlog=r, user=user, active_pages=_is_active,
                           tformat=formattedtime, sub_site="runlog")
        

    return output if len(output)>0 else "Hello World!"

@app.route("/api/devsites/<path>", methods=["GET", "POST"])
def api_devsite(path=None):
    if not path:
        db = sqlite3.connect('../_syncpar.db')
        columns = db.execute("PRAGMA TABLE_INFO(DEVSITES)").fetchall()
        coldata = db.execute("SELECT * FROM DEVSITES").fetchall()
        db.close()

        datas = []
        colnames = [str(x[1]) for x in columns]
        for row in coldata[-10:]:
            d = [_tsformat(x, columns[i][2]) for i,x in enumerate(row)]
            datas.append(dict(zip(colnames, d)))
        resp = make_response(json.dumps(datas), 200)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return resp

    elif request.method == "POST":
        print request.form
        resp = make_response('', 204)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return  resp

@app.route("/api/repos/<path>", methods=["GET", "POST"])
def api_repos(path=None):
    if not path:
        db = sqlite3.connect('../_syncpar.db')
        columns = db.execute("PRAGMA TABLE_INFO(REPOS)").fetchall()
        coldata = db.execute("SELECT * FROM REPOS").fetchall()
        db.close()

        datas = []
        colnames = [str(x[1]) for x in columns]
        for row in coldata[-10:]:
            d = [_tsformat(x, columns[i][2]) for i,x in enumerate(row)]
            datas.append(dict(zip(colnames, d)))
        resp = make_response(json.dumps(datas), 200)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return resp

    elif request.method == "POST":
        print request.form
        resp = make_response('', 204)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return  resp

@app.route("/api/apps/<path>", methods=["GET", "POST"])
def api_appl(path=None):
    print request.url, "path=", path
    if not path or path == 'all':
        db = sqlite3.connect('../_syncpar.db')
        columns = db.execute("PRAGMA TABLE_INFO(REPOS)").fetchall()
        coldata = db.execute("SELECT * FROM REPOS").fetchall()
        db.close()

        datas = []
        colnames = [str(x[1]) for x in columns]
        for row in coldata:
            d = [_tsformat(x, columns[i][2]) for i,x in enumerate(row) if i in (0, 1, 2, 3, 10) ]
            datas.append(dict(zip(colnames, d)))
        resp = make_response(json.dumps(datas), 200)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return resp

    else:
        return api_error('Unknown Selection {}'.format(path.split('/')[0]))

def api_error(msg):
    resp = make_response(msg,404)
    resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
    return  resp

@app.route("/api/apps/datadefs/<path:path>", methods=["GET", "POST"])
def api_appl_datadefs(path):
    if request.method == "POST":
        print request.form
        resp = make_response('', 204)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return resp
    else:
        pcs = path.split('/')
        data_store  = "../store/{}/{} svnsync.db".format(pcs[0],pcs[1]+" "+pcs[2])
        if os.path.isfile(data_store):
            db = sqlite3.connect(data_store)
            columns = db.execute("PRAGMA TABLE_INFO(APPLDEFS)").fetchall()

            coldata = db.execute("SELECT * FROM APPLDEFS ").fetchall()
            db.close()
            datas = []
            colnames = [str(x[1]) for x in columns]
            for row in coldata:
                d = [_tsformat(x, columns[i][2], colnames[i] == 'last_update') for i,x in enumerate(row) ]
                datas.append(dict(zip(colnames, d)))

            resp = make_response(json.dumps(datas), 200)
            resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
            return resp
        else:
            return api_error("Could not map data store for {}".format(path))

@app.route("/api/apps/updates/<path:path>", methods=["GET", "POST"])
def api_appl_updates(path):
    if request.method == "POST":
        print request.form
        resp = make_response('', 204)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return resp
    else:
        pcs = path.split('/')
        data_store  = "../store/{}/{} svnsync.db".format(pcs[0],pcs[1]+" "+pcs[2])
        if os.path.isfile(data_store):
            db = sqlite3.connect(data_store)
            columns = db.execute("PRAGMA TABLE_INFO(NPRUPDATES)").fetchall()
            cutoff = db.execute("SELECT max(last_update) as max_ts FROM NPRUPDATES where last_update < 1460000000").fetchall()[0]
            if isinstance(cutoff, tuple) and cutoff[0]>10000000:
                cutoff = cutoff[0] - (30*86401.0)
            else:
                cutoff = 0
            coldata = db.execute("SELECT * FROM NPRUPDATES WHERE last_update > '{}' ".format(int(cutoff))).fetchall()
            db.close()

            colnames = [str(x[1]) for x in columns]
            unique_changes = {}
            for row in coldata:
                d = [_tsformat(x, columns[i][2], colnames[i] == 'last_update') for i,x in enumerate(row) ]
                next_entry = dict(zip(colnames, d))
                unique_key = tuple([next_entry[k] for k in ('dpm', 'procedure', 'change_type', 'macro', 'last_update')])
                try:
                    unique_changes[unique_key] = next_entry
                except KeyError:
                    unique_changes[unique_key] = next_entry
            
            datas = [v for k, v in unique_changes.iteritems()]
            resp = make_response(json.dumps(datas), 200)
            resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
            return resp
        else:
            return api_error("Could not map data store for {}".format(path))

def _tsformat(t, _type, fix_epoch = False):
    EPOCH_OFFSET = 320745600
    if _type not in (u"REAL", u"INTEGER") or t == u"":
        return str(t)
    try:
        tt = t+EPOCH_OFFSET if fix_epoch else float(t)
    except TypeError:
        return t
    if tt > 1000000000.0:
        return datetime.datetime.fromtimestamp(float(tt)).strftime("%m-%d-%Y %H:%M:%S")
    else:
        return tt
    
@app.route("/api/runlog")
def api_runlog():
    print(request.url)
    title = "SVN Sync Manager"
    user = {'nickname': 'Jonahon'}  # fake user
    output = ''

        
    try:
        db = sqlite3.connect('../_syncpar.db')
        columns = db.execute("PRAGMA TABLE_INFO(RUNLOG)").fetchall()
        coldata = db.execute("SELECT * FROM RUNLOG").fetchall()
        db.close()
        #[(0, u'ts', u'REAL', 0, None, 1),
        # (1, u'event', u'TEXT', 0, None, 1),
        # (2, u'event_repo', u'TEXT', 0, None, 0),
        # (3, u'event_req', u'INTEGER', 0, None, 0),
        # (4, u'event_done', u'REAL', 0, None, 0),
        # (5, u'comment', u'TEXT', 0, None, 0)]
        datas = []
        colnames = [str(x[1]) for x in columns]
        for row in coldata[-10:]:
            d = [_tsformat(x, columns[i][2]) for i,x in enumerate(row)]
            datas.append(dict(zip(colnames, d)))
        resp = make_response(json.dumps(datas), 200)
        resp.headers["Access-Control-Allow-Origin"] = "http://localhost:8000"
        return resp
        
    except Exception as e:
       #print("error")
       return "There was an error: %s " % e

    return output if len(output)>0 else "Hello World!"


@app.route("/ialert/echo", methods=['GET', 'POST'])
@app.route("/ialert/echo/<path>", methods=['GET', 'POST'])
def test_ialert(path=None):
    print(request.url)
    print(request)
    print path
    #with open('grabandgo.json','wb') as fp:
    #    json.dump(request, fp)	
    title = "SVN Sync Manager"
    user = {'nickname': 'Jonahon'}  # fake user
    output = ''

    return "Hello world!"


if __name__ == "__main__":
    app.run(debug=True)
