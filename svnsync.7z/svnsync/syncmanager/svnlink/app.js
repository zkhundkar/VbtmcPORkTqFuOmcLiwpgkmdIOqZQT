'use strict';

// Declare app level module which depends on views, and components
var myApp = angular.module('myApp', [
  'ngRoute',
  'myApp.view1',
  'myApp.view2',
  'myApp.hello',
  'myApp.version'
])

.controller('AppCtrl',AppCtrl)

.config(['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider) {
  $locationProvider.hashPrefix('!');

$routeProvider
// Home
.when("/view3", {templateUrl: "partials/home.html", controller: "PageCtrl"})
// Pages
.when("/devsites", {templateUrl: "view2/view2.html", controller: "AppCtrl"})
.when("/repos", {templateUrl: "hello/hello.html"})
//.when("/apps", {templateUrl: "hello/hello.html"})
//.when("/alerts", {templateUrl: "hello/hello.html"})
/* etc… routes to other pages… */
  
  .otherwise({redirectTo: '/'});
}]);

function AppCtrl($scope, $location) {
	$scope.navitems = [
	{ name : "home", active : "active", ptext : "Home" },
	{ name : "devsites", active : "",  ptext : "Dev Sites" },
	{ name : "repos", active : "",  ptext : "Repos" },
	{ name : "apps", active : "",  ptext : "Applications" },
	{ name : "alerts", active : "",  ptext : "Alerts" }
	
	];
	$scope.isActive = function(currentpage) { if (currentpage == '/home') {return $location.path() == '/' } ;
	return currentpage == $location.path() };
};

