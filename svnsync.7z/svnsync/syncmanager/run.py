
from svnsync_mgr import *
print app,"id=",id(app)
import views

if __name__ == "__main__":
    app.run(debug=True)
    pass