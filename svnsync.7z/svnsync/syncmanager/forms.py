from flask.ext.wtf import Form
from wtforms import StringField, BooleanField, IntegerField, SelectField
from wtforms.validators import DataRequired

class LoginForm(Form):
    openid = StringField('openid', validators=[DataRequired()])
    remember_me = BooleanField('remember_me', default=False)
    
class PostForm(Form):
    post = StringField('post', validators=[DataRequired()])
    
class DevSitesForm(Form):
    #post = StringField('post', validators=[DataRequired()])
    new_devsite = StringField('new_devsite', validators=[DataRequired()])
    new_active = BooleanField('new_active', default=False)
    new_ip_addr = StringField('new_ip_addr', validators=[DataRequired()])
    new_port = IntegerField('new_port', validators=[DataRequired()], default="")
    new_platform = SelectField(choices = [('M', "Magic"), ('CS', "Client Server")], default="M")
    
    def reset(self):
        #new_devsite.data, form.new_active.data, form.new_ip_addr.data, \
        #            form.new_port.data, form.new_protocol = ["","","","",""]
        return

class RunLogForm(Form):
    #post = StringField('post', validators=[DataRequired()])
    pageno = IntegerField('pageno', default=1)
    totalpages = IntegerField('totalpages', default=1)
    perpage = IntegerField('perpage', default=10)
    
    def reset(self):
        #new_devsite.data, form.new_active.data, form.new_ip_addr.data, \
        #            form.new_port.data, form.new_protocol = ["","","","",""]
        return
