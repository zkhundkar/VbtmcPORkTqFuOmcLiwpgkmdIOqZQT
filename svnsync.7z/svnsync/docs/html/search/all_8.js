var searchData=
[
  ['svnsyncsvc',['SvnSyncSvc',['../classsvnsync_1_1svnsyncsvc_1_1_svn_sync_svc.html',1,'svnsync::svnsyncsvc']]],
  ['syncmanager',['SyncManager',['../classsvnsync_1_1ui_1_1syncmanager_1_1_sync_manager.html',1,'svnsync::ui::syncmanager']]]
];
