var searchData=
[
  ['cachehandler',['CacheHandler',['../classsvnsync_1_1manage__cache_1_1_cache_handler.html',1,'svnsync::manage_cache']]],
  ['check_5fconnection',['check_connection',['../classsvnsync_1_1utils_1_1dbfuncs_1_1_base_db_connect.html#a417e1dcfd5c21817f0d4237a5e1e6aba',1,'svnsync::utils::dbfuncs::BaseDbConnect']]],
  ['convertmagictoxml',['convertMagictoXml',['../classsvnsync_1_1utils_1_1_magic_xml_1_1_magic2_xml.html#adb2a0f2a2b5c9e6b8e5288a4a9d90a26',1,'svnsync::utils::MagicXml::Magic2Xml']]]
];
