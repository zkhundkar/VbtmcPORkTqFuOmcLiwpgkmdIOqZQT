var searchData=
[
  ['cachehandler',['CacheHandler',['../classsvnsync_1_1manage__cache_1_1_cache_handler.html',1,'svnsync::manage_cache']]]
];
