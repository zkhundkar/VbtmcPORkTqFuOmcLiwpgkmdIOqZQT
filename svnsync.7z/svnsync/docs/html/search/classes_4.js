var searchData=
[
  ['repos',['Repos',['../classsvnsync_1_1svnsync__orm_1_1_repos.html',1,'svnsync::svnsync_orm']]],
  ['runlog',['RunLog',['../classsvnsync_1_1svnsync__orm_1_1_run_log.html',1,'svnsync::svnsync_orm']]]
];
