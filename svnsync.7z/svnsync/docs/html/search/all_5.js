var searchData=
[
  ['openconnection',['openConnection',['../classsvnsync_1_1utils_1_1dbfuncs_1_1_base_db_connect.html#aed4338f8d9732a58ff150c82c273e03d',1,'svnsync::utils::dbfuncs::BaseDbConnect']]]
];
