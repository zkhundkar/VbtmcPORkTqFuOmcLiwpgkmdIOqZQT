#!/usr/bin/env python

from setuptools import setup

setup(
    name='svnsync',
    version='1.0.1.dev1',
    description='Magic-Subversion Sync Service',
    author='Z Khundkar',
    author_email='zeta.khundkar@iatric.com',
    # url='http://wiki.secondlife.com/wiki/Eventlet',
    packages=['svnsync'],
      long_description="""\
      svnsync is a custom Windows service/application for synchronizing
         a magic codebase with local subversion repositories    for source control
         ...
      """,
      
      classifiers=[
          "License :: Proprietary",
          "Programming Language :: Python",
          "Development Status :: 1 - Alpha",
          "Intended Audience :: Developers",
          "Topic :: Source Control",
      ],
      keywords='networking eventlet nonblocking internet',
      license='Commercial',
      install_requires=[
        'setuptools',
      ],
      
      data_files = [('.', ['iatric.ico',
                              'svnsync.ini'])
                       ]
      )

