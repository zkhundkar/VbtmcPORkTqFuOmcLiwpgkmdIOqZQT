
__VERSION__ = '1.0'

class iAlert():
r"""
 **************************************************************************
 Module      : iAlertModule
 Author      : Michael DeVoe
 Purpose     : Exposes iAlert calls to other modules
               To use iAlert, the following steps must be completed
               1. Call this module's initiAlert sub to create the iAlert
                  COM object.
               2. Call this module's ActivateiAlert function to instruct the
                  com object to connect to the server
               3. Send heartbeats or alerts using this module's
                  'SendHeartbeat' or 'SendAlert' functions.
               4. When finished, use the 'DestroyiAlert' sub to shutdown
                  and prevent memory leaks.
 **************************************************************************
"""

	#Private mOBJSEND As CiAlertClient
	#'local variable(s) to hold property value(s)
	#mvarpstrSystemDescription As String 'local copy
	#Private mvarpstrHeartbeatComments As String 'local copy
	#Private mvarpstrAlertType As String 'local copy
	#Private mvarpstrProgramVersion As String 'local copy
	#Private mvarpstrSystemID As String 'local copy
	#Private mvarpstrErrorCode As String 'local copy
	#Private mvarpstrErrorDescription As String 'local copy
	#Private mvarpstrErrorDetails As String 'local copy
	#Private mvarpstrAlertComments As String 'local copy

	#Private mvarpstriAlertHeartbeatFrequency As String
	#Private mvarplngtmrIDHeartBeat As Long
	#Private mvarplngtmrIDHDDriveSpace As Long


	# This constant was defined because the particular text string was used in several places.
	mstrRegKeyPath = "Software\Iatric Systems\iAlertTestApp"

	def sendheartbeat(self, strComments):
		r"""' *************************************************************************
' Function   : SendHeartBeat
' Author     : Michael DeVoe
' Purpose    : Sends an iAlert heartbeat
' Assumptions: Assumes iAlertModule:initiAlert and iAlertModule:ActivateiAlert
'              have already been called to create and activate the iAlert object.
' Inputs     : strComments: optional comments to be recorded by iAlert server or ""
' Returns    : 0 = success, nonzero = failed
' ************************************************************************
		"""
		try:
			return self.mOBJSEND.SendHeartbeat(strComments)
		except:
			print('LogGlobalError MODULE_NAME, Err.Description, Err.Number, Err.Source, Erl')

	def destroyiAlert(self):
		r"""' **************************************************************************
' Sub        : DestroyiAlert
' Author     : Michael DeVoe
' Purpose    : Destroys iAlert object to prevent memory leaks.  Should
'              should probably be called from main form's 'unload'
'              event.
' Assumptions: None
' **************************************************************************

		"""
		# close any open sockets and global resources
		return

Function SendAlert(ByVal lngAlertType As AlertType, _
    ByVal strErrorCode As String, _
    ByVal strErrorDesc As String, _
    ByVal strErrorDetails As String, _
    ByVal strComments As String) As Long

83  On Error GoTo ErrorHandler

85  SendAlert = mOBJSEND.SendAlert(lngAlertType, strErrorCode, strErrorDesc, strErrorDetails, strComments)

87  Exit Function
ErrorHandler:
'131 LogGlobalError MODULE_NAME, Err.Description, Err.Number, Err.Source, Erl
End Function


' *************************************************************************
' Function   : ActivateiAlert
' Author     : Michael DeVoe
' Purpose    : Instructs iAlert object to connect to the server.
' Assumptions: Assumes iAlertModule:initiAlert has already been called.
' Inputs     : lngSystemID: iAlert System ID
'               strVersion: String value representing your
'                          application version number.
'              strSystemDescription: Text description of app.
' Returns    : 0 = success, nonzero = failed
' *************************************************************************
Function ActivateiAlert() As Long

106 On Error GoTo ErrorHandler

108 ActivateiAlert = mOBJSEND.Init(CLng(mvarpstrSystemID), mvarpstrProgramVersion, mvarpstrSystemDescription, "ialert.iatric.com", 80)

110 Exit Function
ErrorHandler:
'LogGlobalError MODULE_NAME, Err.Description, Err.Number, Err.Source, Erl
End Function

' **************************************************************************
' Sub        : initiAlert
' Author     : Michael DeVoe
' Purpose    : Creates the iAlert object and associates it to a variable name
'              "mOBJSEND".  This must always be called prior to using iAlert.
' Assumptions: None
' **************************************************************************
Public Function InitiAlert() As Integer

124 On Error GoTo ErrorHandler
125 If (mOBJSEND Is Nothing) Then
126     Set mOBJSEND = New CiAlertClient
    End If
'Initialize properties
129 pstrSystemID = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtSystemID")
130 pstrProgramVersion = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtProgramVersion")
131 pstrSystemDescription = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtSystemDescription")

133 pstrHeartbeatComments = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtHeartbeatComments")
134 pstrAlertType = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "cboAlertType")
135 pstrErrorCode = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtErrorCode")
136 pstrErrorDescription = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtErrorDesc")
137 pstrErrorDetails = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtErrorDetails")
138 pstrAlertComments = RegReadString(HKEY_CURRENT_USER, mstrRegKeyPath, "txtAlertComments")

140 InitiAlert = 0

142 Exit Function
ErrorHandler:
'LogGlobalError MODULE_NAME, Err.Description, Err.Number, Err.Source, Erl
145 InitiAlert = 1
End Function

Public Property Let pstrAlertComments(ByVal vData As String)
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrAlertComments = 5
151 mvarpstrAlertComments = vData
End Property


Public Property Get pstrAlertComments() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrAlertComments
158 pstrAlertComments = mvarpstrAlertComments
End Property



Public Property Let pstrErrorDetails(ByVal vData As String)
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrErrorDetails = 5
166 mvarpstrErrorDetails = vData
End Property


Public Property Get pstrErrorDetails() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrErrorDetails
173 pstrErrorDetails = mvarpstrErrorDetails
End Property



Public Property Let pstrErrorDescription(ByVal vData As String)
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrErrorDescription = 5
181 mvarpstrErrorDescription = vData
End Property


Public Property Get pstrErrorDescription() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrErrorDescription
188 pstrErrorDescription = mvarpstrErrorDescription
End Property



Public Property Let pstrErrorCode(ByVal vData As String)
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrErrorCode = 5
196 mvarpstrErrorCode = vData
End Property


Public Property Get pstrErrorCode() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrErrorCode
203 pstrErrorCode = mvarpstrErrorCode
End Property



Public Property Let pstrSystemID(ByVal vData As String)
Attribute pstrSystemID.VB_Description = "iAlert Monitored System ID"
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrSystemID = 5
211 mvarpstrSystemID = vData
End Property


Public Property Get pstrSystemID() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrSystemID
218 pstrSystemID = mvarpstrSystemID
End Property

Public Property Let pstrProgramVersion(ByVal vData As String)
Attribute pstrProgramVersion.VB_Description = "iAlert Client Version?"
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrProgramVersion = 5
224 mvarpstrProgramVersion = vData
End Property


Public Property Get pstrProgramVersion() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrProgramVersion
231 pstrProgramVersion = mvarpstrProgramVersion
End Property



Public Property Let pstrAlertType(ByVal vData As String)
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrAlertType = 5
239 mvarpstrAlertType = vData
End Property


Public Property Get pstrAlertType() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrAlertType
246 pstrAlertType = mvarpstrAlertType
End Property



Public Property Let pstrHeartbeatComments(ByVal vData As String)
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrHeartbeatComments = 5
254 mvarpstrHeartbeatComments = vData
End Property


Public Property Get pstrHeartbeatComments() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrHeartbeatComments
261 pstrHeartbeatComments = mvarpstrHeartbeatComments
End Property

Public Property Let pstrSystemDescription(ByVal vData As String)
Attribute pstrSystemDescription.VB_Description = "iAlert System Description"
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrSystemDescription = 5
267 mvarpstrSystemDescription = vData
End Property
Public Property Get pstrSystemDescription() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrSystemDescription
272 pstrSystemDescription = mvarpstrSystemDescription
End Property
Public Property Let pstriAlertHeartbeatFrequency(ByVal vData As String)
'used when assigning a value to the property, on the left side of an assignment.
'Syntax: X.pstrSystemDescription = 5
277 mvarpstriAlertHeartbeatFrequency = vData
End Property


Public Property Get pstriAlertHeartbeatFrequency() As String
'used when retrieving value of a property, on the right side of an assignment.
'Syntax: Debug.Print X.pstrSystemDescription
284 pstriAlertHeartbeatFrequency = mvarpstriAlertHeartbeatFrequency
End Property

Public Sub Configure(pParenthwnd As Long)
    Dim f As New frmiAlert
289 f.Show vbModal
290 If gintEnableiAlertHeartbeats = 1 Then
291     StartHeartbeatTimer
292 Else
'Kill timer
294     KillHeartbeatTimer
    End If
296 If gintEnableHDSpaceCheck = 1 Then
297     StartHDSpaceCheckTimer
298 Else
'Kill Timer
300     KillHDSpaceCheckTimer
    End If
End Sub

Public Sub StartHeartbeatTimer()
    Dim TimerValue As Long ' Timer value is milliseconds
'Convert hours to min. then to seconds then to milliseconds
307 TimerValue = (((CLng(Mid(mvarpstriAlertHeartbeatFrequency, 1, 2)) * 60) _
        + CLng(Mid(mvarpstriAlertHeartbeatFrequency, 4, 2))) * 60) * 1000

310 mvarplngtmrIDHeartBeat = SetTimer(0, 0, TimerValue, AddressOf TimerProcHeartBeat)
End Sub
Public Sub KillHeartbeatTimer()
313 mvarplngtmrIDHeartBeat = KillTimer(0, mvarplngtmrIDHeartBeat)
End Sub
Public Sub StartHDSpaceCheckTimer()
    Dim TimerValue As Long ' Timer value is milliseconds
'Convert hours to min. then to seconds then to milliseconds
'Set it up for hourly....but TimerProcHDSpace set to check space only at 00:00 hour
'TimerValue = (((CLng(Mid(mvarpstriAlertHeartbeatFrequency, 1, 2)) * 60) _
320 + CLng(Mid(mvarpstriAlertHeartbeatFrequency, 4, 2))) * 60) * 1000

'Check every hour
'60 sec * 60 min = 3600sec/hr * 1000 = mSec/hr
'TimerValue = CLng(3600) * CLng(1000)

'Testing - 30 Sec
327 TimerValue = CLng(30) * CLng(1000)

329 mvarplngtmrIDHDDriveSpace = SetTimer(0, 0, TimerValue, AddressOf TimerProcHDSpace)
End Sub


Public Sub KillHDSpaceCheckTimer()
    Dim lngResult As Long
335 mvarplngtmrIDHDDriveSpace = KillTimer(0, mvarplngtmrIDHDDriveSpace)
336 If mvarplngtmrIDHDDriveSpace = 0 Then
337     lngResult = GetLastError()
338     Debug.Print "KillHDSpaceCheckTimer Error: " & lngResult
    End If
End Sub



Private Sub Class_Terminate()
345 mvarplngtmrIDHeartBeat = KillTimer(0, mvarplngtmrIDHeartBeat)
346 mvarplngtmrIDHDDriveSpace = KillTimer(0, mvarplngtmrIDHDDriveSpace)
End Sub


