import utils
import ui
import logging
import os, sys

m_cmdSet = {}
cs_cmdSet = {}
try:
    __file__ = sys.argv[0]
except:
    pass

import win32traceutil
import win32serviceutil
import win32service
import win32event
import win32api

def get_python_path():
    """ get_python_path() - returns the path to the python executable
    """

    pp = os.path.abspath('.').split('\\')
    exe_path = pp.pop(0)+'\\'
    for x in pp:
        exe_path = os.path.join(exe_path, x)
        if os.path.isfile(os.path.join(exe_path, "python.exe")):
            break
    return exe_path

PYDIR = get_python_path()

class SvnSyncSvc (win32serviceutil.ServiceFramework):
    _svc_name_ = "MagicSyncService"
    _svc_display_name_ = "Magic/SVN Sync Service"
    _svc_description_ = """Iatric Magic/SVN Sync Service"""

    def __init__(self, *args):

        win32serviceutil.ServiceFramework.__init__(self, *args)
        self.hWaitStop = win32event.CreateEvent(None,0,0,None)
        #self.stop_event = win32event.CreateEvent(None, 0, 0, None)

    #def sleep(self, sec):
    #    win32api.Sleep(sec*1000, True)
        
    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        print "Stopping service now"
        self.dbo_par.set_halt()
        self.halt_flag = True
        #win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self):
        #servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE,
        #                      servicemanager.PYS_SERVICE_STARTED,
        #                      (self._svc_name_,''))
        #self.main()
        import os, sys
        path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(path) # This should be the root directory of the svnsync package

        #self.known_commands = known_commands()
        import svnsync
        self.halt_flag = svnsync.HALT_FLAG
        print m_cmdSet.keys()
        
        self.ReportServiceStatus(win32service.SERVICE_START_PENDING)
        try:
            self.ReportServiceStatus(win32service.SERVICE_RUNNING)
            svnsync.read_config(svnsync.CFGFILE) # capture any side-effects of read_config, but don't need to keep the dictionary
            pardbname = os.path.join(svnsync.PARDBDIR, svnsync.PARDBNAME)
            self.dbo_par = svnsync.DBConnect(pardbname, branch=None, offset=None, logger=svnsync.main_logger)			
            #main_logger = logSetup()
            print self, self.dbo_par

            #self.log('start')
            #self.start()
            #self.log('wait')
            print svnsync.CFGFILE
            #print C.keys()
            #print "svnsync"
            #for k, v in globals().items():
            #    print k, v
            #print "Locals:"
            #for k, v in locals().items():
            #    print k, v
            print("Current path",os.path.abspath('.'))

            #print("\ndir\n", dir())
            #print("\nself\n", dir(self))

            svnsync.run_forever()
            #win32event.WaitForSingleObject(self.hWaitStop, win32event.INFINITE)
            #self.log('done')
        except ValueError as x:
            print('Service stopping on Exception : ', x)
            #self.SvcStop()
           
if __name__ == '__main__':
    if '__file__' in globals():
        print("file=",__file__)
    else:
        print ('No __file__ defined')
    print ("Install/start the service", sys.argv)
    # Enable the following line in order to update the service.
    # Use the Windows services panels to start/stop the service
    #win32serviceutil.HandleCommandLine(SvnSyncSvc)
