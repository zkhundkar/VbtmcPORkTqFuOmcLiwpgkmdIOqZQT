# readlines
""" Module to pretty print Magic code

    Author: Z. Khundkar
    Revised: 3/10/2016
"""

__version__ = '1.0.0'

OPEN_CHAR = ["{","`","\""," "]
CLOSE_CHAR = ["}","'",";"]

def next_indent(s, depth=0, indent=[]):
    s_opens = [[i for i, ch in enumerate(s) if ch == a] if a in s else None for a in OPEN_CHAR]
    s_close = [[i for i, ch in enumerate(s) if ch == a] if a in s else None for a in CLOSE_CHAR]
    if type(s_close[2]) is list and s_close[2][0] == 0:
        return (depth, indent)
    STRING = s_opens[2]
    if STRING is None:
        pass
    elif len(STRING) % 2 == 1:
        return(depth, indent)
    LIST_LITERAL = s_opens[1]
    C_LIST = s_close[1]
    COND = s_opens[0]
    C_COND = s_close[0]
    BRANCH = s_opens[3]
    C_BRANCH = s_close[2]
    S_END = len(s)
    if STRING is not None:
        x = [(STRING[i],STRING[i+1]) for i in range(0,len(STRING),2)]
        for b,c in x:
            for xx in [ab for ab in [LIST_LITERAL,COND,BRANCH] if ab is not None]:
                xx = [a for a in xx if a < b or a > c]

    if LIST_LITERAL is not None and BRANCH is not None:
        C_LIST.reverse()
        x = [(LIST_LITERAL[i],C_LIST[i]) for i in range(len(LIST_LITERAL))]
        for b,c in x:
            for xx in BRANCH:
                xx = [a for a in xx if a < b or a > c]
        
    c_index = []
        
    [c_index.extend(a) for a in [LIST_LITERAL,COND,BRANCH,C_LIST,C_COND,C_BRANCH] if a is not None]
    c_index.sort()
    BASE_INDENT = indent[0]
    if type(BASE_INDENT) is str:
        BASE_INDENT = int(BASE_INDENT[1:])
    for i in c_index:
        if LIST_LITERAL is not None and i in LIST_LITERAL:
            depth += 1
        elif BRANCH is not None and i in BRANCH:
            indent.insert(0,"B"+str(BASE_INDENT + i + 1))
        elif C_LIST is not None and i in C_LIST:
            depth -= 1
        elif COND is not None and i in COND:
            depth += 1
            indent.insert(0, BASE_INDENT + i + 1)
        elif C_COND is not None and i in C_COND:
            depth -= 1
            if type(indent.pop(0)) is str:
                indent.pop(0)
        elif C_BRANCH is not None and i in C_BRANCH:
            if type(indent[0]) is str:
                indent.pop(0)
            
    return (depth, indent)
    
def pprint(s):
    depth=0
    indent=[3]
    for l in s:
        if l.startswith(';'):
            print l.strip('\n').strip()
        else:
            ff = "{: <"+str(indent[0])+"s}"
            if type(indent[0]) is str:
                ff="{: <"+str(indent[0][1:])+"s}"
            print ff.format(" ")+l.strip('\n').strip(' ')
        depth, indent = next_indent(l.strip('\n').strip(), depth, indent)
        
             
test1 = """ @Translate.as.haltable,
           %Z.date.add(@.today,"-5")^CUTOFF,
           @.sn-(2*3600*24)^CUTOFF2,
           ^:.LOCK.P^LOCK,
           DO{>([LOCK,A],X)^A IF{A$7="Refresh";
           A$8="VSB PORT"}^CHK, 
           IF{CHK @CHECK.AND.REMOVE;
           X^/IG.LOCK[A]}}, 
           ^:.LOCK^LOCK,
           DO{>([LOCK,A],X)^A IF{A$7="Refresh";
           A$8="VSB PORT";
           X|0="Refresh"}^CHK, 
           IF{CHK @CHECK.AND.REMOVE}}, 
           "";
           
           CHECK.AND.REMOVE
           IF{IF{X|3?8N CUTOFF>(X|3);
           X|1?9N CUTOFF2>(X|1)} X^/REM.LOCK[A],
           IF{A$8="VSB PORT" K[""]([LOCK,A]);
           R([LOCK,A])};\nX^/SV.LOCK[A]}
        """

if __name__ == '__main__':
    tt=test1.split('\n')
    pprint(tt)