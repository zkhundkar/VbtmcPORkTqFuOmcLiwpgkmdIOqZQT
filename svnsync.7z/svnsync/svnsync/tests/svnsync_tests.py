# ----------- Testing ------------------

import logging
import os, sys
import pickle
import base64
import time
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(sys.argv[0])) )
#import __init__
#import utils
#import ui
import svnsync
from svnsync_orm import Repos

#os.chdir(os.path.dirname(os.path.dirname(sys.argv[0])))
#os.chdir('../')
print( os.path.abspath('.') )

TESTREPO = ('WAYNE-DEV', 'iim', 'dev')
TEST_CMDS = ["LOGIN", "VERSION"]
try:
    tlogger
except:
    tlogger = None
CAPTUREPATH = os.path.join(svnsync.BASEDIR,'svnsync/tests/capture/')
CACHEPATH = os.path.join(svnsync.BASEDIR,'svnsync/tests/.cache/capture/')
REPOPATH='c:/iatric systems/magicsvn/magictest/ics/Magic/trunk'
if not os.path.isdir(CAPTUREPATH):
    os.makedirs(CAPTUREPATH)

def setup_test_repo(testrepo = TESTREPO):
    global tlogger
    C = {'main': svnsync.read_config()['main'] }
    svnsync.LOGFILE = os.path.join(svnsync.BASEDIR, "test_svnsync.log")
    svnsync.LOGLEVEL = 'DEBUG'
    if not tlogger:
        tlogger = svnsync.main_logger = svnsync.log_setup()
    pardbname = os.path.join(svnsync.PARDBDIR,svnsync.PARDBNAME)
    dbo_par = svnsync.dbo_par = svnsync.DBConnect(pardbname, branch=None, offset=None, logger=tlogger)
    #test_repo = ('WAYNE-DEV', 'mmd', 'dev')
    try:
        repo_names = dbo_par.get_columns("REPOS")
        snames = dbo_par.get_columns("DEVSITES")
        sites = dbo_par.get_sites()
        sites = dict([(site[0], svnsync.table_to_dict(snames, site)) for site in sites])
        repos = dbo_par.get_repos() # returns only active 
        repos = dict([("/".join([r[1],r[0],r[2]]), svnsync.table_to_dict(repo_names, r)) for r in repos])
        
        test_repo = "/".join(testrepo)
        for r in sites:
            C[r] = sites[r]
        svnsync.select_repo_sql(C, test_repo, repos[test_repo])
        C["current"]["wc_root_true"] = C["current"]["wc_root"]        
        C["current"]["wc_root"] = os.path.join(svnsync.BASEDIR,'svnsync/tests')
        C["current"]["wc_svn_rel"] = 'capture'
        #os.makedirs(os.path.join(C["current"]["wc_root"],C["current"]["wc_svn_rel"]))
        repodbname = os.path.join(C["current"]["wc_root"],C["current"]["wc_svn_rel"],test_repo.replace('/','_')+" test svnsync.db")
        dbo_repo = svnsync.DBConnect(repodbname, branch=C["current"]["wc_svn_rel"], 
                             offset=None, dev_site=test_repo.split("/")[0], logger=tlogger)
        C["current"]['db'] = dbo_repo
        C['current']['testing'] = True
    except KeyError:
        tlogger.error("{!s} may not be an active repo".format(testrepo))
        return {}
        
    C['main_logger'] = tlogger
    C["pardb"] = dbo_par
    C['dbo_repo'] = dbo_repo
    B=svnsync.BaseHandler(None, C)
    C["current"]["hash_folder"] = B._get_cache_path()
    del(B)
    return C

#IP,PORT=WAYNE
def test_mgc_cmds(testrepo = TESTREPO, cmds = TEST_CMDS):

    C = setup_test_repo(testrepo)
    if len(C.keys())>0:
        svnsync.get_from_magic(C, cmds)
    else:
        print("Configuration or KeyError in parameters")
    #convert_npr_to_xml(C, dbo_par, logger=main_logger)
    #compare_cache_wcopy(C, dbo_par, test_repo, logger=main_logger)
    #print dbo_par.get_repos()
    #C['current']['db'].__del__()
    R=[]
    L=0
    return

def test_put_proc(testrepo = TESTREPO, dpm=None, proc=None, _type='A', _macro=None):
    C = setup_test_repo(testrepo)        

    _dpm = dpm if dpm else "IIM.MAP"
    _proc = proc if proc else "ee.code"
    
    P = C['current']['cmdset']['PUT PROC?']
    payload = []
    fnames = [x for x in os.listdir(CAPTUREPATH) if x.startswith(_dpm+' '+_proc)]
    print(fnames)
    r"""if _type in ('L', 'A'):
        for name in [x for x in fnames if x.endswith('.magic')]:
            fn = CAPTUREPATH+name
            _macro = name.split('.M.')[1].split('.magic')[0] if '.M.' in name else ""
            with open(fn,'rb') as fa:
                ll = fa.readlines()
                payload.append(["MACRO" if _macro else "LOGIC",_macro,ll])
        
    if _type in ('S', 'A'):
        for name in [x for x in fnames if x.endswith('_S.fsl')]:
            fn = CAPTUREPATH+name
            with open(fn, 'rb') as fp:
                pnodes = pickle.load(fp)
            pnodes = [map(base64.b64encode, node) for node in pnodes]
            payload.append(["S","",pnodes])
        
    if _type in ('R', 'A'):
        for name in [x for x in fnames if x.endswith('_R.fsl')]:
            fn = CAPTUREPATH+name
            with open(fn, 'rb') as fp:
                pnodes = pickle.load(fp)
            pnodes = [map(base64.b64encode, node) for node in pnodes]
            payload.append(["S","",pnodes])
    if _type in ('P', 'A'):
        for name in [x for x in fnames if x.endswith('_P.fsl')]:
            fn = CAPTUREPATH+name
            with open(fn, 'rb') as fp:
                pnodes = pickle.load(fp)
            pnodes = [map(base64.b64encode, node) for node in pnodes]
            payload.append(["P","",pnodes])
    print(fn, len(ll))
    """
    repl = {'DPM':_dpm, 'PROC':_proc, 'DEBUG':'1'}
    CMD = [x if x[0] not in repl else [x[0], repl[x[0]]] for x in P ]
    #CMD.append(payload)
    #print CMD
    #for x in P:
    #    if x[0]=='DPM': x[1]='CQM.BKG'
    #    elif x[0]=='PROC': x[1]='bkg.monitor'

    C['current']['cmdset']['PUT PROC'] = CMD
    svnsync.get_from_magic(C, ["LOGIN", "PUT PROC"], **repl)

    C['current']['cmdset']['PUT PROC'] = None
    del(CMD)
    L=0
    #parse_response(RCV[0],L,R)
    #HNDL=retrieve_handle(R)
    #print R, HNDL 
    return

def test_put_defs(testrepo = TESTREPO):

    def _encode(l):
        if isinstance(l, list):
            return [base64.b64encode(a) for a in l]
        else:
            return base64.b64encode(l)
    C = setup_test_repo(testrepo)        

    P = C['current']['cmdset']['PUT DEFS?']
    fn = os.path.abspath(CAPTUREPATH+'CQM.bkg datadef.fsl')
    with open(fn,'rb') as fa:
        ll = pickle.load(fa)
    print(fn, len(ll))
    payload = []
    payload.append(['DDEF',"",[[x[0].split(chr(30))[0]]+[_encode(xx) for xx in x] for x in ll]])
    repl = {}
    CMD = [x if x[0] not in repl else [x[0], repl[x[0]]] for x in P ]
    CMD.append(payload)

    C['current']['cmdset']['PUT DEFS'] = CMD
    svnsync.get_from_magic(C, ["LOGIN", "PUT DEFS"])

    C['current']['cmdset']['PUT DEFS'] = None
    del(CMD)
    del(C) 
    L=0
    #parse_response(RCV[0],L,R)
    #HNDL=retrieve_handle(R)
    #print R, HNDL 
    return

def test_put_dict(testrepo = TESTREPO, dpm=None, dump=False):

    if dump:      
        svnsync.RAWDUMP = dump
    C = setup_test_repo(testrepo)

    if not dpm:
        print("No dpm provided")
    CMD_PROC = C['current']['cmdset']['PUT DICT?']
    C['current']['cmdset']['PUT DICT'] = CMD_PROC
    
    fn = os.path.join(CACHEPATH,dpm+' dict.json')
    dsegs = {}
    with open(fn, 'r') as fp:
        dsegs = json.load(fp)
    
    if not len(dsegs.keys()) > 0:
        print "No datasegs to be pulled"
        return C

    for i, a in enumerate(CMD_PROC):
        if a[0] == 'DPM' and dpm:
            CMD_PROC[i][1] = dpm
        elif a[0] == 'APPDB':
            CMD_PROC[i][1] = dpm.split('.')[0] if dpm else testrepo[1].upper()
        elif a[0] == 'DATASEG':
            CMD_PROC[i] = [a[0], [[str(k).split('/')[1],"", [[str(knode), str(y)] for knode, y in v.iteritems()][:5]]\
                                    for k, v in dsegs.iteritems() if isinstance(v, dict)] ]
        elif a[0] == 'DEBUG':
            CMD_PROC[i][1] = '1'    

    print CMD_PROC

#    C['current']['cmdset']['GET DDEF'] = CMD_PROC
    svnsync.get_from_magic(C, ["LOGIN", 'PUT DICT'])
    if dump:
        svnsync.RAWDUMP = False
    return C

def test_get_proc(testrepo = TESTREPO, dpm=None,  proc=None, ptype="ALL"):
    C = setup_test_repo(testrepo)

    macro = None
    if not proc:
        proc = "zcus.zk.merc"
        dpm = "Z"
        appdb = "Z"
    else:
        appdb = dpm       
        if '.M.' in proc:
            proc, macro = proc.split('.M.')
            ptype = "MACRO"
        if proc.startswith(dpm):
            proc = proc[len(dpm):]

    CMD_PROC = C['current']['cmdset']['GET PROC?']
    for i, a in enumerate(CMD_PROC):
        if a[0] == 'DPM':
            CMD_PROC[i][1] = dpm
        elif a[0] == 'APPDB':
            CMD_PROC[i][1] = appdb
        elif a[0] == 'PROC':
            CMD_PROC[i][1] = proc
        elif a[0] == 'TYPE':
            CMD_PROC[i][1] = ptype
        elif a[0] == 'MACRO' and macro:
            CMD_PROC[i][1] = [['1', macro]]
        elif a[0] == 'DEBUG':
            CMD_PROC[i][1] = '1'

    C['current']['cmdset']['GET PROC'] = CMD_PROC
    svnsync.get_from_magic(C, ["LOGIN", "GET PROC"])
    R=[]
    L=0
    #parse_response(RCV[0],L,R)
    #HNDL=retrieve_handle(R)
    #print R, HNDL 
    return

def test_push_defs(testrepo = TESTREPO, dpm=None, dump=False):

    if dump:      
        svnsync.RAWDUMP = dump
    C = setup_test_repo(testrepo)
    if not dpm:
        return "No dpm specified"

    CMD_PROC = C['current']['cmdset']['PUT DEFS?']
    C['current']['cmdset']['PUT DEFS'] = CMD_PROC

    fn = os.path.join(CACHEPATH,dpm+' datadef.fsl')
    
    with open(fn,'rb') as fp:
        nodeset = pickle.load(fp)
    nodeset = [[base64.b64encode(y) for y in x] for x in nodeset][:10]
    for i, a in enumerate(CMD_PROC):
        if a[0] == 'DEFS':
            CMD_PROC[i] = [a[0], "", nodeset]
        elif a[0] == 'APPDB':
            CMD_PROC[i][1] = dpm.split('.')[0] 
        elif a[0] == 'DEBUG':
            CMD_PROC[i][1] = '1'    

#    C['current']['cmdset']['GET DDEF'] = CMD_PROC
    svnsync.get_from_magic(C, ["LOGIN", "PUT DEFS"])
    if dump:
        svnsync.RAWDUMP = False
    return

def test_bkup_plan(testrepo = TESTREPO, dpm=None, dump=False):

    if dump:      
        svnsync.RAWDUMP = dump
    C = setup_test_repo(testrepo)

    
    CMD_PROC = C['current']['cmdset']['GET BKUP PLAN']
    for i, a in enumerate(CMD_PROC):
        if a[0] == 'DPMS':
            CMD_PROC[i][1] = [['1', dpm]]
        elif a[0] == 'APPDB':
            CMD_PROC[i][1] = dpm.split('.')[0] if dpm else testrepo[1].upper()
        elif a[0] == 'DEBUG':
            CMD_PROC[i][1] = '1'    

#    C['current']['cmdset']['GET DDEF'] = CMD_PROC
    svnsync.get_from_magic(C, ["LOGIN", "GET BKUP PLAN"])
    if dump:
        svnsync.RAWDUMP = False
    return C

def test_get_dict(testrepo = TESTREPO, dpm=None, dump=False):

    if dump:      
        svnsync.RAWDUMP = dump
    C = setup_test_repo(testrepo)

    
    CMD_PROC = C['current']['cmdset']['GET DICT?']
    C['current']['cmdset']['GET DICT'] = CMD_PROC
    gg = C['dbo_repo'].get_monitored_dicts("/".join(testrepo))
    print gg
    dsegs = [x for x in gg] if len(gg)>0 else (testrepo[1].upper()+'.PARAM', 'main', '')
    if not len(dsegs) > 0:
        print "No datasegs to be pulled"
        return C
    dpm = dsegs[0][0]  # dpm of first row returned
    print testrepo, dsegs, dpm
    for i, a in enumerate(CMD_PROC):
        if a[0] == 'DPM' and dpm:
            CMD_PROC[i][1] = dpm
        elif a[0] == 'APPDB':
            CMD_PROC[i][1] = dpm.split('.')[0] if dpm else testrepo[1].upper()
        elif a[0] == 'DATASEG':
            CMD_PROC[i] = [a[0]] + [[j] + list(y[1:]) for j, y in enumerate([x for x in dsegs if x[0] == dpm])]
        elif a[0] == 'FORCE':
            CMD_PROC[i][1] = '1'
        elif a[0] == 'DEBUG':
            CMD_PROC[i][1] = '1'    

    print CMD_PROC

#    C['current']['cmdset']['GET DDEF'] = CMD_PROC
    svnsync.get_from_magic(C, ["LOGIN", 'GET DICT'])
    if dump:
        svnsync.RAWDUMP = False
    return C

def test_get_app_list(testrepo = TESTREPO, dump=False, **kw):

    if dump:      
        svnsync.RAWDUMP = dump
    C = setup_test_repo(testrepo)

    FUNC = 'GET APP LIST'
    CMD_PROC = C['current']['cmdset'][FUNC]
    C['current']['cmdset'][FUNC] = CMD_PROC

    for i, a in enumerate(CMD_PROC):
        if a[0] == 'APPMIS' and 'appmis' in kw:
            CMD_PROC[i][1] = kw['appmis']
        elif a[0] == 'SEG' and 'seg' in kw:
            CMD_PROC[i][1] = kw['seg'].upper()
        elif a[0] == 'DIR' and 'dir' in kw:
            CMD_PROC[i][1] = kw['dir'].upper()
        elif a[0] == 'DEBUG':
            CMD_PROC[i][1] = "1"            

    print CMD_PROC

    svnsync.get_from_magic(C, ["LOGIN", FUNC])
    if dump:
        svnsync.RAWDUMP = False
    return C

def test_cs_npr2xml(f):
    import utils
    from utils.MagicXml import MagicNodes, Magic2Xml, MagicXmlError
#    import pdb
    hfolder = os.path.dirname(f)
    M = Magic2Xml( logger = tlogger)
    F = []
    with open(f, 'rb') as fa:
        F = [" = ".join(x) for x in pickle.load(fa)]
    cls = None
    TRIM = False
    
    if ".S." in f or '_S.' in f:
        cls='screen'
    elif ".R." in f or '_R.' in f:
        cls = "report"
    elif "_M." in f:
        cls = "menu"
        TRIM = True
    elif "_P." in f:
        cls = "proc"
    elif "datadef" in f:
        cls = "ddef"
    try:
        if TRIM:
            m=len("".join(F[0].split(" = ")[0].split('\x1e')[:2]))+2
            F = [x[m:] if i>0 else x for i, x in enumerate(F)]
        FX=""
        M.convertMagictoXml(F, cls, hfolder)
        FX = os.path.join(hfolder, os.path.splitext(f.replace('.S.','_S.').replace('.R.','_R.'))[0]+".xml")
        #os.utime(FX, (os.path.getatime(FN), os.path.getmtime(f)))           
    except (TypeError, ValueError, NameError) as e:
        if tlogger:
            main_logger.exception("Conversion Error: %s", (hfolder, f, FX))
        else:
            print( e )
    
def add_repo(testdb="_syncpar.db", **kwargs):
    from svnsync_orm import Repos
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    Base = declarative_base()
    
    engine = create_engine('sqlite:///'+testdb)
    Base.metadata.bind = engine
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    new_r = kwargs
    if len(kwargs)==0:
        r"""    new_r = {'app':'CQM', 'dsite':'WAYNE-DEV', 'branch_id':'dev',
                 'active':0, 'appl_db':'CQM.IAT',
                 'server_hcis':'IATDEV', 'server_ring':'IATDEV',
                 'wc_root':"C:/Iatric Systems/MagicSVN/MagicTest",
                 'wc_svn_rel':"CQMExtract/CS60/trunk",
                 'earliest':20150901,
                 'pull_freq':1}
        """

        new_r = {'app':'ICC', 'dsite':'ELK-DEV', 'branch_id':'dev',
                 'active':0, 'appl_db':'ICC.SPA',
                 'server_seg':'C', 'server_dir':'IS.DEV.MIS',
                 'wc_root':"C:/Iatric Systems/MagicSVN/MagicTest",
                 'wc_svn_rel':"MagicSvnLink/ICC",
                 'earliest':20160401,
                 'pull_freq':1}    
    d = Repos(**new_r)
    #if session.query(DevSites).get(form.new_devsite):
    #    session.query(Devsites).filter(DevSites.dev_site = form.update
    session.merge(d)
    session.commit()
    session = None

def add_req_cmds(testdb="../_syncpar.db", **kwargs):
    from svnsync_orm import RunLog
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    Base = declarative_base()
    
    engine = create_engine('sqlite:///'+testdb)
    Base.metadata.bind = engine
    DBSession = sessionmaker(bind=engine)
    #session = DBSession()
    #new_r = kwargs
    if 'cmd' in kwargs:
        ts = time.time()
        repo = "/".join(TESTREPO) if 'repo' not in kwargs else kwargs['repo']

        new_r = {'ts' : ts, 'event' : kwargs['cmd'], 'event_repo': repo, 'event_req' : round(int(ts)),
                 'comment': "" if 'msg' not in kwargs else kwargs['msg']}
        print( new_r )
        d = RunLog(**new_r)
        
        #session.merge(d)
        #session.commit()
    #session = None
    return


# testsv 


if __name__ == '__main__':
    #test_cs_npr2xml(os.path.join(CACHEPATH,'CSF.SAND.BOX cmb.test_P.fsl'))
    #test_cs_npr2xml(os.path.join(CACHEPATH,'IIM.ADM.PAT datadef.fsl'))
    #test_mgc_cmds(('ELK-DEV','icc','dev'),["LOGIN", "GET DPMS"])
    #test_get_proc(TESTREPO, "IIM.PROCESS","view.messages","S")
    #test_ddef(TESTREPO,dpm="IIM.ADM.PAT",dump=True)
    #test_bkup_plan(('WAYNE-DEV','csf','dev'))
    #test_cs_npr2xml(os.path.join(REPOPATH,'main.menu_M.fsl'))
    #test_get_dict(('WAYNE-DEV','mmd','dev'))
    #test_put_dict(('WAYNE-DEV','mmd','dev'),"MMD.PARAM")
    #test_push_defs(('WAYNE-DEV','mmd','dev'),"MMD.STATUS")
    #test_put_proc(('WAYNE-DEV','mmd','dev'), "CQM.MEAS", "ee", "A")
    test_get_app_list(('ELK-DEV', 'ics', 'dev'))
    pass