import socket
import time
import pickle
import os, sys

TPATH = os.path.dirname(os.path.dirname(sys.argv[0]))
sys.path.insert(0,TPATH+'/utils')
#TPATH = os.path.dirname(os.path.dirname(sys.argv[0]))
sys.path.insert(0,TPATH)

from MagicXml import MagicNodes, Magic2Xml, MagicXmlError

import xml.etree.ElementTree as ET

def convert_npr_to_xml_test(hfolder, f):

    try:
        F = []
        FN = os.path.join(hfolder, f)
        with open(FN, 'rb') as fa:
            F = [" = ".join(x) for x in pickle.load(fa)]
        #F.pop(0)
        #F.pop(0)
        #m=len("".join(F[0].split(" = ")[0].split('\x1e')[:2]))+2
        #F = [x[m:] if i>0 else x for i, x in enumerate(F)]
        cls = None
        if ".S." in f:
            cls='screen'
        elif ".R." in f:
            cls = "report"
        if "_S." in f:
            cls='screen'
        elif "_R." in f:
            cls = "report"
        elif "_P." in f:
            cls = "proc"
        elif "_M." in f:
            cls = "menu"
        elif "datadef" in f:
            cls = "ddef"
        if not cls:
            print("Could not determine class")
            return
        M=Magic2Xml()
        FX=""
        M.convertMagictoXml(F, cls, hfolder)
        if cls:
            if cls == 'menu':
                expected_xml = os.path.splitext(f)[0].replace('_M',"")[4:] + ".xml"
            else:
                expected_xml = os.path.splitext(f)[0]+".xml"
            FX = os.path.join(hfolder, expected_xml)
        print("Expected output: %s" % FX)
        #FX = os.path.join(hfolder, os.path.splitext(f.replace('.S.','_S.').replace('.R.','_R.'))[0]+".xml")
        
        #FX = os.path.join(hfolder, os.path.splitext(f)[0],".xml")
        #os.utime(FX, (os.path.getatime(FN), os.path.getmtime(FN)))
            
    except Exception as e:
        print(e)
        
    return


os.chdir(sys.path[2])
FH = os.path.abspath('.cache/capture')

#FH = os.path.abspath("ztools/svnsync/svnsync/tests")
#FH = 'C:\Iatric Systems\MagicSVN\MagicTest\.cache\ICS\Magic\trunk'
#fn = "MMD.INF datadef.fsl"
#fn = "ICS.USER datadef.fsl"
#fn = 'IIM.alert.menu_M.fsl'
fn = 'ICC.FN get.proc_P.fsl'

if __name__ == "__main__":
    convert_npr_to_xml_test(FH, fn)
    pass