import os, sqlite3, utils
from utils.dbfuncs import BaseDbConnect
#BaseDbConnect = utils.BaseDBConnect.BaseDbConnect
#import logging

class DBConnect (BaseDbConnect):

    tables = {
                'DEVSITES':  """(dev_site TEXT PRIMARY KEY,  active BOOLEAN, remote_port INTEGER, remote_ip TEXT,
                                         platform TEXT, protocol TEXT, tz_offset INTEGER)""",
                'REPOS': """(app TEXT, dsite TEXT, branch_id TEXT, active BOOLEAN,
                                    appl_db TEXT, server_seg TEXT, server_dir TEXT, server_hcis TEXT, server_ring TEXT,
                                    wc_root TEXT, wc_svn_rel TEXT, earliest INTEGER, last_check INTEGER, pull_freq INTEGER,
                                    alt_top TEXT, init_sync TEXT, base_tag TEXT,
                                    PRIMARY KEY (app ASC, dsite ASC, branch_id ASC) )""",
                'RUNLOG': """(ts REAL, event TEXT, event_repo TEXT, event_req INTEGER, event_done REAL, comment TEXT, PRIMARY KEY (ts ASC, event ASC))""",
                'PARAMS': """(param_id TEXT, value_pairs TEXT, PRIMARY KEY (param_id ASC))""",
                'ALERTS': """(alert_id TEXT, alert_type TEXT, message TEXT, ialert BOOLEAN, ts REAL, PRIMARY KEY (alert_type ASC, ts ASC))""",
                
                'ACTLOG':  """(ts LONG PRIMARY KEY, 
                                repo TEXT, app TEXT, branch TEXT, func TEXT, resp INTEGER, errmsg TEXT)""",
                'APPLIDS':  "(id TEXT PRIMARY KEY, repo_active BOOLEAN, repo_location TEXT, last_checked INTEGER)",
                'APPLDEFS':  """(id TEXT, active BOOLEAN, dpm TEXT, dpm_active BOOLEAN, group_under TEXT, pull_defs BOOLEAN,
                                  folder TEXT(60), folder_type TEXT(10),
                                  PRIMARY KEY (id ASC, dpm ASC) )""",
                'APPLDICTS':  """(id TEXT, active BOOLEAN, prefix TEXT, dpm TEXT, dataseg TEXT, topsubs TEXT, group_under TEXT, pull_defs BOOLEAN,
                                  folder TEXT(60), folder_type TEXT(10), last_checked INTEGER,
                                  PRIMARY KEY (id ASC, prefix, dpm ASC, dataseg ASC, topsubs ASC) )""",
                #'APPUPDATE':  """(ts LONG PRIMARY KEY, 
                #                   app_id TEXT, lastupdate INTEGER, proc TEXT, proc_type TEXT, proc_ext TEXT,  
                #                   last_user TEXT, rev_id INTEGER, version TEXT, base_rev INTEGER)""",
                'NPRUPDATES': """(app_id TEXT, dpm TEXT, procedure TEXT, last_update INTEGER,  change_type TEXT, macro MNAME, user TEXT, log_time INTEGER)"""
                #'NPRDATA': """(app_id TEXT, dpm TEXT, procedure TEXT, type TEXT, keyset TEXT, keyvalue TEXT, last_update INTEGER, change_type TEXT)""",
                #dpm,proc,tstamp#.,ptype,mname,tstamp%.,epoch_offset
                #'LASTUPDATE': """(repo TEXT PRIMARY KEY, procedure TEXT PRIMARY KEY, 
                #                    updated integer PRIMARY KEY, change_type TEXT, user TEXT)""",
                #'NPRSEG_main': """(dpm TEXT, name TEXT, active TEXT, phy.file TEXT, phy.base TEXT, phy.root TEXT, parent.seg TEXT, purpose TEXT, map.seg TEXT, 
                #                         phy.constant TEXT, phy.subs.cnt TEXT, phy.local TEXT, logical.name TEXT, line.count TEXT, cust.rw.access TEXT, dr.access TEXT)""",
                #'NPRSEG_main_2': "(logical.x.val TEXT,   index.cond TEXT, phy.val.ele TEXT, index.segs TEXT)", 
                #'NPRSEG_child_segments': """(dpm TEXT, name TEXT, child TEXT)""",
                #'NPRSEG_phys_subs': """(dpm TEXT, name TEXT, sub.urn TEXT, sub.element TEXT, sub.address TEXT, sub.dpm TEXT)""",
                #'NPRSEG_index_segments': """(dpm TEXT, name TEXT, index_seg TEXT)""",
                #'NPRSEG_sort_elements': """(dpm TEXT, name TEXT, sort_ele TEXT, sort_ele_name TEXT)""",
                #'NPRSEG_tech_doc': """(dpm TEXT, name TEXT, tech_doc_index TEXT, tech_doc_text TEXT)""",
                #'NPRSEG_elements': """(dpm TEXT, ele.name TEXT, ele.pointer TEXT, ele.data.type TEXT, ele.offset TEXT, ele.phy.address TEXT, ele.local TEXT, ele.length TEXT, 
                #                               ele.justify TEXT, ele.seg TEXT, ele.sort.urn TEXT, ele.dr.access TEXT, )""",
                #'NPRSEG_attributes': """(dpm TEXT, ele.name TEXT, ele_attrib_index TEXT, ele_attribute TEXT)""",
                #'NPRSEG_description': """(dpm TEXT, ele.name TEXT, description_index TEXT, desc_text TEXT)""",
                #'NPRSEG_ele_tech_doc': """(dpm TEXT, ele.name TEXT, ele_techdoc_index TEXT, ele_techdoc_text TEXT)""",
                #'NPRSEG_attrib_length': """(dpm TEXT, ele.name TEXT, ele_atrib_name TEXT, ele_attrib_len_index TEXT, ele_attrib_len_value TEXT)""",
                #'NPRPROC_main': """(procedure.urn TEXT, procedure.dpm TEXT, procedure.name TEXT, procedure.responsible TEXT, procedure.access TEXT, 
                #                           procedure.active TEXT, procedure.arguments TEXT, procedure.menu.logic TEXT, procedure.translate.as TEXT, procedure.z.switch.appl TEXT, 
                #                           procedure.interruptable TEXT, proc_unk1 TEXT, procedure.source.ship TEXT )"""
                 }                                       
                                            
    def __init__(self, dbpath, branch, offset, **kwargs):
        #import pdb
        parpath = os.path.abspath('.')+'\\'
        logger = kwargs["logger"] if "logger" in kwargs else None
        dev_site = kwargs["dev_site"] if "dev_site" in kwargs else None
        #if branchbranch = kwargs["branch"] if "branch" in kwargs else None
        #try:
        #   parpath = os.path.dirname(os.path.dirname(utils.__path__[0]))+'\\'
        #except Exception:
        #    pass
        def init_params(self, logger):
            self.db = dbpath
            BaseDbConnect.__init__(self, self.db, logger)
            self.initTables(True)

            return
            
        def init_repodb(self, dev_site, logger):
        
            #self.db = os.path.dirname(dbpath) + '/.cache/' + branch+ '/svnsync.db'
            #dbfile = os.path.basename(dbpath).split(' ')
            #dbfile.insert(1, branch.lower()
            self.db = dbpath #os.path.join(os.path.dirname(dbpath), " ".join(+[branch.lower(),os.path.basename(dbpath)]))
            self.offset = offset
            BaseDbConnect.__init__(self, self.db, logger)
            self.initTables(False)
            return

        #pdb.set_trace()

        if branch:
            init_repodb(self, dev_site, logger)
        else:
            init_params(self, logger)
  
    def initTables(self, parTable = True, con = None, re_init=False):
        if parTable:
            tables = dict(zip(('DEVSITES', 'REPOS', 'RUNLOG', 'PARAMS', 'ALERTS'), (1,1,1,1,1)))
        else:
            tables = dict(zip(('ACTLOG', 'APPLIDS', 'APPLDEFS', 'NPRUPDATES', 'APPLDICTS'), (1, 1, 1, 1, 1)))

        tables = dict([(x, self.tables[x]) for x in filter(lambda x:x in tables, self.tables.keys())])
        self.createTables(con, tables, re_init)
        return 

    def get_run_log(self, **kwargs):
        import time
        logtime = int(time.time())
        s = ["SELECT","*","FROM RUNLOG","WHERE (event_done is NULL or event_done = '')",""]
        if 'mode' in kwargs:
            mode = kwargs['mode'].upper()
            if mode == "ALL":
                s[3] = ""
            elif mode == "SINCE":
                if 'since' in kwargs:
                    s[4] = "and ts > "+kwargs["since"]
                else:
                    s2 = " ".join([s[0],"max(ts)","from RUNLOG WHERE not",s[3].split("WHERE")[1]])
                    ts = self.getall(s2)[0][0]
                    pass
            elif mode in ('GET', 'HALT', 'UPDATE', 'FILE MAINT'):
                s[3] = s[3] + " and event = '"+mode+"' "
        if 'max' in kwargs:
            m = kwargs['max'].upper()
            if m == "TIME":
                s[1] = "MAX(ts)"
            elif m == "SCHED":
                s[1] = "MAX(event_req)"                  
        return self.getall(" ".join(s))
    
    def halt_requested(self):
        import time
        logtime = int(time.time())
        s = ["SELECT","*","FROM RUNLOG","WHERE event = 'HALT' ",""]
        res = self.getall(" ".join(s))
        #self.dblogger.info("Checking for halt request (%s) - %d received" % (s, len(res)))
        return len(res)>0

    def update_run_log(self, repo, evt="UPDATE", sched="", comment="") :
        import time
        ts = time.time()
        s = "INSERT INTO RUNLOG VALUES(?, ?, ?, ?, ?, ?) "
        g = [str(ts), evt, repo, sched, str(ts), comment]
        return self.set(s, g)
    
    def update_params(self, g) :
        import time
        ts = time.time()
        gg = self.getall("SELECT param_id FROM PARAMS")
        inserts=[]
        updates = []
        for x in g:
            if tuple(x[:1]) in gg:
                updates.append(x[::-1])
            else:
                inserts.append(x)
        if len(updates)>0:
            print("Updating {} key{}: {}".format(len(updates), 's' if len(updates)>1 else '' , [x[1] for x in updates]))
            self.setall("UPDATE PARAMS SET value_pairs = ? WHERE param_id = ? ", updates)
        if len(inserts)>0:
            print("Adding {} key{}: {}".format(len(inserts), 's' if len(inserts)>1 else '' , [x[0] for x in inserts]))
            self.setall("INSERT INTO PARAMS VALUES(?, ?) ", inserts)
        return #self.set(s, g)
    
    def clear_run_log(self, evt, ts=None):
        import time
        logtime = time.time()
        if not ts:
            ts = logtime
        s = ""
        if evt=="FILE MAINT":
            s="DELETE FROM RUNLOG WHERE ts < "+str(int(logtime) - 7*86400)
            self.set(s)
            ts = int(logtime)
        if evt=="HALTED":
            s="DELETE FROM RUNLOG WHERE event='HALT' "
            self.set(s)
        if self.getall("SELECT * FROM RUNLOG WHERE ts = '"+str(ts)+"' and event='"+evt+"' "):
            s = "UPDATE RUNLOG SET event_done='"+"{:14.3f}".format(logtime)+"' WHERE ts = '"+"{:14.3f}".format(ts)+"' and event='"+evt+"'"
        else:
            s = "INSERT INTO RUNLOG VALUES("+", ".join(["'"+x+"'" for x in ["{:14.3f}".format(ts), evt, "", "", "{:14.3f}".format(logtime), "DONE"]]) + ")"
        self.dblogger.debug(s)
        return self.set(s)

    def get_sites(self, site=None):
        s="SELECT * FROM DEVSITES"
        if site:
            s=s+" WHERE dev_site = '"+site+"'"
        return self.getall(s)

    def get_repos(self, site=None):
        ss=["SELECT * FROM REPOS", "WHERE active = 'Y' or active = 1", "", "ORDER BY dsite ASC"]
        if site:
            ss[1] = "and dsite = '"+site+"'"
        return self.getall(" ".join(ss))        

    def set_site(self, ss):
        self.set(ss)
        return

    def set_repo(self, ss):
        self.set(ss)
        return

    def set_halt(self):
        import time
        ts = time.time()
        evt = "HALT"
        ss = "INSERT INTO RUNLOG VALUES("+", ".join(["'"+x+"'" for x in [str(ts),evt, "", str(ts), str(ts), "HALT REQUESTED"]])+" )"
        if self.dblogger:
            self.dblogger.info("Requesting halt (%s) " % self)
        self.set(ss)

        return
        
    def set_event(self, evt, **kw):
        import time
        ts = str(int( time.time() ))
        comment = "" if "comment" not in kw else kw['comment']
        repo = "" if "repo" not in kw else kw['repo']
        ss = "INSERT INTO RUNLOG VALUES("+", ".join(["'"+x+"'" for x in [ts, evt, repo, ts, ts, comment]])+" )"
        self.set(ss)

        return
        
    def check_requests(self, events, **kw):
        import time
        ts = str(int( time.time() ))
        comment = "" if "comment" not in kw else kw['comment']
        repo = "" if "repo" not in kw else kw['repo']
        ss = self.getall("SELECT event_repo, event, comment FROM RUNLOG WHERE event not in ('STARTED', 'HALT', 'HALTED', 'UPDATE') and (event_done is null or length(event_done)=0) ORDER BY event_repo ASC, ts ASC")
        sd = events
        for x in ss:
            if not x[0] in sd:
                sd[x[0]] = {'cmds': []}
            else:
                sd[x[0]]['cmds'] = []
            sd[x[0]]['cmds'] = sd[x[0]]['cmds'] + list(x[1:])
        if len(sd.keys())>0:
            self.dblogger.info("New request: %s (id=%d)" % (sd, id(sd)))
            #events = sd
            return True
        else:
            return False

    def clear_requests(self, repo, evts):
        import time
        ts = time.time() 
        ss = self.getall("SELECT ts, event, event_repo FROM RUNLOG WHERE event_repo='{!s}' and event not in ('STARTED', 'HALT', 'HALTED', 'UPDATE') and (event_done is null or length(event_done)=0) ORDER BY ts ASC".format(repo))
        ss = [x[:1] for x in ss if x[0]>1000000000 and (x[1] in evts)]
        self.dblogger.debug("clear_requests for %s: (%s) keys =%s" % (repo, evts, ss))
        sss = "UPDATE RUNLOG SET event_done = {0:15.3f} WHERE event_repo ='{1!s}' and ts = ?".format(ts, repo)
        self.dblogger.debug("setall %s" % sss)
        self.setall(sss, ss)
        self.dblogger.debug("cleared requests at %15.3f" % ts)
        return 

    def update_app_list(self, repoinfo, appdbs):
        dsite, app, branch = repoinfo['alias'].split('/') # dsite/app/branch
        server_unv = repoinfo['server_unv'] if 'server_unv' in repoinfo else ""
        dsite = dsite.upper()
        s=["SELECT * FROM REPOS", "WHERE dsite = '" + dsite + "' ORDER BY app ASC"]

        # set up a connection and keep it alive
        conn = None
        known_repos = self.getall(" ".join(s), None, conn, True) # app, dsite, branch_id, active, appl_db, server_seg, server_dir,
        #       server_hcis, server_ring, wc_root, wc_svn_rel, earliest, last_check, pull_freq, alt_top, init_sync, base_tag
        known_apps = [(str(x[0].lower()),str(x[2].lower())) for x in known_repos if len(x)>0]
        keys = ['app', 'dsite', 'branch_id', 'active', 'appl_db', 'server_seg', 'server_dir',
                'server_hcis', 'server_ring', 'wc_root', 'wc_svn_rel', 'earliest', 'last_check', 'pull_freq',
                'alt_top', 'init_sync', 'base_tag']        
        new_apps =[[x[k] for k in keys] for x in appdbs if (x['app'], x['branch_id']) not in known_apps]
        if len(new_apps)>0 and False:
            try:
                #print appdbs[0]
                this_seg = appdbs[0][1][0]
                this_dir = appdbs[0][1][1]
            except KeyError:
                this_seg = ""
                this_dir = ""
            try:
                this_hcis = appdbs[0][2][0]
                this_ring = appdbs[0][2][1]
            except KeyError:
                this_hcis = ""
                this_ring = ""
            this_platform = appdbs[0][3]
            if this_platform == 'Magic':
                pass
            else:
                try:
                    this_platform += "{:.1f}".format(float(appsdb[0][4])).replace(".","")
                except TypeError as e:
                    pass
                except IndexError as e:
                    pass
            phys_branch = [this_seg,this_dir, this_hcis,this_ring]
            this_branch = this_dir.replace("MIS","").replace("IS","").replace("IAT","").replace(".","") + \
                                   + this_ring.replace("MIS","").replace("IS","").replace("IAT","").replace(".","")
            site_match = False
            repo_match = False
            br_rel_path = ""
            for x in known_apps:
                site_match = str(x[1]).upper() == dsite 
                repo_match = str(x[6]).upper() == this_dir.upper() or (str(x[8]).upper() == this_ring.upper())
                if site_match and repo_match and not br_rel_path:
                    br_rel_path = "/".join(x[10].split('/')[1:3]) 
                    break
                elif site_match and not br_rel_path:
                    br_rel_path = "/".join(x[10].split('/')[1:2])
            
            if len(br_rel_path)>0:
                if 'DEV' in this_dir or 'DEV' in this_ring:
                    br_rel_path += '/trunk'
                else:
                    br_rel_path += '/branches/'+this_branch
            else:
                br_rel_path = '/'.join([this_platform, 'branches', this_branch])
            earliest = 20160101
            new_apps = [[x.split('.')[0].lower(), dsite.upper(), branch, False, x]+ phys_branch +["", x.upper()+br_rel_path]+[earliest,"","1", "", "", ""] for x in new_apps]
        if False:
            print(len(new_apps), len(new_apps[0]))
            print([(x[1], x[4]) for x in new_apps])
            print(known_apps)
            print(new_apps[0])
        if len(new_apps)>0:

            s = "INSERT INTO REPOS VALUES("+", ".join(["?" for x in new_apps[0]]) + " )"
          
            self.setall(s, new_apps, conn)
        else:
            self.dblogger.debug("No new apps found")
        return

    def update_bkup_plan(self, repo, g):
        """ 
            This should be called with a list of dpms, datasegs and toplevel subscripts received from the GET RUI BKUP command as argument.
            This function updates the APPLDICTS table to reflect the current state. 
            If a new dpm is found, it is added, if one found missing, the dpm_active field is set to False
            
            repo - should be the alias for the repo, i.e., devsite/app/branch
            g    - should contain a simple list of dpms
            
        """
        import time

        logtime = int(time.time())
        if type(g) is tuple:
            g = list(g)
        user = ""
        gg = self.getall("SELECT dpm, prefix, dataseg from APPLDICTS where id = '"+repo+"'") 

        inserts = []
        updates = []
        reorder = [1,0,2] # Need to re-order the data flowing form NPR to match the table definition here
        g.sort()
        
        for x in g:
            if tuple(x[:3]) in gg:
                updates.append([1 if len(x)>3 and (x[-1] == 'Y') else 0]+ [x[p] for p in reorder if p<len(x)] )
            else:
                inserts.append([repo, 1 if len(x)>3 and (x[-1] == 'Y') else 0] + [x[p] for p in reorder if p<len(x)] + ["", "", 0, "", 'DICT', ""])
        # id TEXT, active BOOLEAN, prefix TEXT, dpm TEXT, dataseg TEXT, topsubs TEXT, group_under TEXT, pull_defs BOOLEAN,
        #           folder TEXT(60), folder_type TEXT(10), last_checked INTEGER
        if len(updates) > 0:
            self.setall("UPDATE APPLDICTS SET active = ? where id = '"+repo+"' and prefix = ? and dpm = ? and dataseg = ?", updates)
            #self.dblogger.info("Setting dpm_active flag to False - %s" % [uu[1] for uu in updates])
        if len(inserts) > 0:
            self.setall("INSERT INTO APPLDICTS VALUES( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )", inserts)
            self.dblogger.info("Adding {} new dpms - %s" % (len(inserts), str([uu[1] for uu in inserts])[:80]))
            
        #except sqlite3.Error as e:
        #    if self.dblogger: 
        #           self.dblogger..error('UPDATE APPLIDS %s %d' % (repo, logtime))
        #   else: print(e)
                    
        gg = None		
        return
        
    def get_monitored_dicts(self, repo):
        """ 
            This returns a list of dpms, datasegs and topsubs that are being monitored for changes (i.e., pulling appl dictionaries daily)
            
        """
        gg = [x for x in self.getall("SELECT dpm, dataseg, topsubs from APPLDICTS where id = '"+repo+"' and active = 1 ") if len(x[0])>0]

            
        #except sqlite3.Error as e:
        #    if self.dblogger: 
        #           self.dblogger..error('UPDATE APPLIDS %s %d' % (repo, logtime))
        #   else: print(e)
                    
        return gg

    def get_monitored_dpms(self, repo):
        """ 
            This returns a list of dpms that are being monitored (i.e., pulling datadefs daily and all routines)
            
        """
        gg = [x[0] for x in self.getall("SELECT dpm from APPLDEFS where id = '"+repo+"' and folder_type = 'DPM' and pull_defs = 1") if len(x[0])>0]

            
        #except sqlite3.Error as e:
        #    if self.dblogger: 
        #           self.dblogger..error('UPDATE APPLIDS %s %d' % (repo, logtime))
        #   else: print(e)
                    
        return gg

    def log_get_dpms(self, repo, g, local_repo = ""):
        """ 
            This should be called with a list of dpms received from the GET DPMS command as argument.
            This function updates the APPLDEFS table to reflect the current state. 
            If a new dpm is found, it is added, if one found missing, the dpm_active field is set to False
            
            repo - should be the alias for the repo, i.e., devsite/app/branch
            g    - should contain a simple list of dpms
            
        """
        import time

        logtime = int(time.time())
        if type(g) is tuple:
            g = list(g)
        user = ""
        gg = self.getall("SELECT id, active, dpm, dpm_active from APPLDEFS where id = '"+repo+"'") 

        inserts = []
        updates = []
        g.sort()
        for x in gg:
            if x[2] in g:
                pass
            else:
                updates.append(x[0:3:2])
        gg = [x[2] for x in gg]
        for x in g:
            if x in gg:
                pass
            else:
                inserts.append([repo, True, x, True, "", True, "", 'DPM'])
        if len(updates) > 0:
            self.setall("UPDATE APPLDEFS SET dpm_active = 0, folder_type = 'DPM', folder ='' where id = ? and dpm = ?", updates)
            self.dblogger.info("Setting dpm_active flag to False - %s" % [uu[1] for uu in updates])
        if len(inserts) > 0:
            self.setall("INSERT INTO APPLDEFS VALUES( ?, ?, ?, ?, ?, ?, ?, ? )", inserts)
            self.dblogger.info("Adding new dpms - %s" % [uu[1] for uu in inserts])
            
        #except sqlite3.Error as e:
        #    if self.dblogger: 
        #           self.dblogger..error('UPDATE APPLIDS %s %d' % (repo, logtime))
        #   else: print(e)
                    
        gg = None
        return
        
    def log_get_changes(self, repo, g, local_repo = ""):
        """ 
            This should be called with a list of changes received from the GET CHANGES command as argument.
            This function parses the time_stamp and add the epoch_offset before adding one transaction per 
            change entry into thte NPRUPDATES table
            
            repo - should be the alias for the repo, i.e., devsite/app/branch
            
        """
        import time

        logtime = int(time.time())
        if type(g) is tuple:
            g = list(g)
        user = ""
        gg = []
        for i, pc in enumerate(g):
            dpm, proc, tstamp, ptype, mname = pc
            try:
                tstamp = str(tstamp).split(".")
                tstamp, user = (int(tstamp[0] if len(tstamp[0])>0 else logtime), " ".join(tstamp[1:]))
            except ValueError as e:
                if hasattr(self,"dblogger"):
                    #self.logger.error(e.errstr)
                    self.dblogger.exception("Value Error: %s %s" % (str(tstamp), e))
                else:
                    print(e, tstamp)
            gg.append([dpm, proc, tstamp, ptype, mname, user, logtime])

        if len(gg) == 0:
            return # Do not update anything if no changes were received
        try:            
            self.setall( "INSERT INTO NPRUPDATES VALUES ('{!s}', ?, ?, ?, ?, ?, ?, ? )".format(repo), gg)
        except (sqlite3.Error, TypeError, sqlite3.InterfaceError) as e:
            if self.dblogger:
                #self.dblogger.error(e.errstr)
                self.dblogger.error(" %d (%d) %s" % (len(gg), len(gg[0]), gg[0]))
                self.dblogger.error("INSERT INTO NPRUPDATES VALUES ('" + repo + "', " +" %s )" )
                [self.dblogger.error(x) for x in gg]
            else:
                print( e )
            raise # this should be bubbled up so the main loop can process it appropriately
        #try:
        #    self.set('INSERT INTO APPLIDS VALUES (\"' + repo + "\", " + '\"\", \"\", ' + str(logtime) + ')')           
        #except sqlite3.Error as e:
        #    try:
        #        self.set('UPDATE APPLIDS SET last_checked  =  ?  where id = ? ', (logtime, repo))
        #    except sqlite3.Error as e:
        #        if self.dblogger: 
        #            self.dblogger.error('UPDATE APPLIDS %s %d' % (repo, logtime))
        #        else: print(e)
                    
        gg = None
        return
            
    def log_get_proc(self, repo, dpm, proc, proc_type, offset, g):
        """ 
            This should be called with g = list of NPR nodes received from the GET PROC command as argument.
            This function parses the time_stamp and add the epoch_offset before adding one transaction per 
            change entry into thte NPRDATA table
            
            repo - should be the alias for the repo, i.e., repo/app/branch
            
        """
        conDefined = False

          

        if type(g) is tuple:
            g = list(g)
        for i, pc in enumerate(g):
            dpm, proc, tstamp, ptype, mname = pc
            tstamp = tstamp.split(".")
            tstamp, user = (int(tstamp[0]), " ".join(tstamp[1:]))
            g[i] = [dpm, proc, tstamp, ptype, mname, user, logtime] 
            # how to handle repo
        #print repo+'\n', len(g), g[0]
        try:
            cur.executemany( "INSERT INTO NPRUPDATES VALUES ('{!s}', ?, ?, ?, ?, ?, ?, ? )".format(repo), g)
        except sqlite3.Error as e:
            self.dblogger.exception( "INSERT INTO NPRUPDATES VALUES ('{!s}', ?, ?, ?, ?, ?, ?, ? ) - {!s}".format(repo, e) )
        cur.close()
        con.commit()
        if not conDefined:
            con.close()
        return
            
    def log_npr_data(self, repo, dpm, proc, proc_type, offset, g):
        """ 
            This should be called with g = list of NPR nodes received from the GET PROC command as argument.
            This function parses the time_stamp and add the epoch_offset before adding one transaction per 
            change entry into thte NPRDATA table
            
            repo - should be the alias for the repo, i.e., repo/app/branch
            
        """
        import time
        logtime = int(time())
        
        try:
            in_db = self.getall('SELECT keyset, keyvalue, last_update, change_type FROM NPRDATA WHERE app_id = ? and dpm = ? and procedure = ?  and type = ?', (repo, dpm, proc, proc_type))
            BASE = {}
            for k, v, l_upd, ct in in_db:
                if k in BASE.keys():
                    if BASE[k][1] < l_upd:
                        BASE[k] = [str(v), l_upd, ct]
                else:
                    BASE[k] = [str(v), l_upd, ct]
            NEW = dict([(k, v) for k, v in g])
            MODS = {}
            #BASE = dict([(k, v) if v[2] == 1 for k, v in BASE])
            for k, v in BASE:
                if k in NEW.keys() :
                    if v[0] == NEW[k] and v[2] == 1:
                        NEW.pop(k)
                    else:
                        MODS[k] = (NEW[k], logtime, 1)
                        NEW.pop(k)
                else:
                    MODS[k] = (NEW[k], logtime, 0)
            self.setall('UPDATE NPRDATA (keyvalue, last_update, change_type) VALUES (?, ?, ?) where key = ?', [[v[0], v[1], v[2], k] for k, v in MODS])
            self.setall('INSERT INTO NPRDATA VALUES (repo, dpm, proc, type, ?, ?, ?, ?)', [[k, v, logtime, 1] for k, v in NEW])
            
        except sqlite3.Error as e:
            if self.dblogger: 
                self.dblogger.error('UPDATE APPLIDS %s %d' % (repo, logtime))
            else: print(e)
        
        return


    def log_get_rui_bkup(self, repo, g, local_repo = ""):

        return

    def get_last_update(self, alias, con = None):
        import time
        import pdb
        last_check = int(time.mktime([2016,1,1,0,0,0,3,1,0])) # default time for first check
        ss=["SELECT earliest, last_check FROM REPOS", "WHERE ", "", "ORDER BY dsite ASC"]
        
        if alias:
            dsite, app, br_id = alias.split('/')
            ss[2] = " and ".join([x[0]+"='"+x[1]+"'" for x in [("active", '1'), ("dsite",dsite), ("app",app), ("branch_id", br_id)]])
        lc = list(self.getall(" ".join(ss)))
        #pdb.set_trace()
        try:
            lc = lc[0]
        except:
            pass
        self.dblogger.debug("Last update for %s = %s" % (alias, str(lc)))
        #pdb.set_trace()
        try:
            if len(lc)>1 and isinstance(lc[1], int) and (lc[1]>last_check):
                return lc[1]
            elif isinstance(lc[0], int) and lc[0]>20151231:
                lc = str(lc[0]) # if earliest is defined, parse yyyymmdd to a blank time tuple
                return int(time.mktime([int(lc[:4]), int(lc[4:6]), int(lc[6:8]), 0,0,0,3,1,0]))
            else:
                return last_check
        except Exception as e:
            self.dblogger.exception("Could not retrieve valid time for last update (%s)" % e)
        return last_check

    def set_last_update(self, alias, TS = None):
        import time
        #last_check = "20150701"
        if TS is None:
            #TS = time.strftime("%Y%m%d",time.localtime())
            TS = time.time()
        s=["UPDATE REPOS SET last_check='" + str(int(TS)) + "' WHERE ",""]
        if alias:
            dsite, app, br_id = alias.split('/')
            s[1] = " and ".join([x[0]+"='"+x[1]+"'" for x in [("dsite",dsite), ("app",app), ("branch_id", br_id)]])
        lc = self.set(" ".join(s))
        return TS
            
    def proc_last_update(self, alias, dpm, proc, proc_type, offset, con = None, macro = ""):

        lastcheck = 0
        try:
            qualifier = " and change_type = "
            if proc_type in ('SCREEN', 'REPORT', 'PROCDATA', 'L', 'LOGIC'):
                qualifier  += "'"+proc_type[0]+"'"
            elif proc_type == 'MACRO':
                qualifier = qualifier + "'M' and macro = '"+macro+"'"
            else:
                qualifier = qualifer + "''"
            SQLSTR = "select max(last_update) FROM NPRUPDATES where app_id = '{!s}' and dpm = '{!s}' and procedure = '{!s}' {!s}".format(alias, dpm, proc, qualifier)
            lastcheck = self.getall(SQLSTR)[0][0]
            if isinstance(lastcheck, int) and lastcheck>1000000000:
                pass
            elif proc_type[0]=='P':
                SQLSTR = "select min(last_update) FROM NPRUPDATES where app_id = '{!s}' and dpm = '{!s}' and procedure = '{!s}'".format(alias, dpm, proc)
                lastcheck = self.getall(SQLSTR)[0][0]

            #tl = localtime(lastcheck)
            #lastcheck = "".join([str(eval('tl.time.struct_time.'+x)) for x in ('tm_year', 'tm_mon', 'tm_mday')])
        except sqlite3.Error:
            self.logger.warning("proc_last_date - {!s} ({!s})".format(SQLSTR, lastcheck))
            #raise
        except Error:
            self.logger.exception("Error in proc_last_update {!s}".format(".".join(dpm, proc, proc_type, macro, lastcheck)))
        
        return lastcheck
