import os
try:
    from . import utils
except ImportError:
    import utils
import utils.svnlink as svnlink

class CacheHandler():
    r"""
        class CacheHandler - compare files in cache folder to those in a working copy folder and a base folder.
                                base folder is optional and used for matching changes at a customer site
                                to a specific version (in tags)
                             if the files have the same content, remove the copy in the cache folder
                             if they are different, replace the working copy version
        currently, we are checking each code file line-by-line, suppressing leading/trailing spaces as false positives
        and each set of npr nodes by their xml representation. This adds a layer of complexity as the same set of npr nodes
        could result in a different xml file for algorithmic issues or changes to the nodemap. On the other hand, it is a
        lot simpler to check the differences between version when we have two text files (as in xml) to compare.

        In the deletion or replaeement steps, the .fsl file should be handled the same way as the xml file.
    """
   
    def __init__(self, autocommit, logger=None):
        self.logger = logger
        #self.changeset = {'new':[], 'deleted':[], 'modified': [] }
        self.autocommit = autocommit
        self.svnclient = svnlink.SvnConnect()
        return

    def replace(self, s, t, _base=None):
        """ replace(.., s, t) - replaces target file t with source file s if s and t are different
                  s is the name of th source file (including absolute path name (cache folder)
                  t is the target file name (typically in the working copy associated with the
                       dev site / app / branch
        """

        def _issame(ls, _base):
            _same = True
            lt = _openfile(_base)

            if not len(lt) == len(ls):
                _same = False
            else:
                for ii, ln in enumerate(lt):
                    try:
                        if ln != ls[ii]:
                            _same = False
                    except:
                        _same = False
                    finally:
                        if not _same:
                            break

            return _same

        def _openfile(fname):
            with open(s, 'r') as sf:
                if s.endswith('.fsl'):
                    ls = ["//".join(x) for x in pickle.load(sf)]                    
                else:
                    ls = sf.readlines()
            return ls
        same = True

        
        scompanion = s
        ls = _openfile(scompanion)
        if scompanion and False:
            if os.path.isfile(scompanion):
                tcompanion = t
            else:
                scompanion = os.path.dirname(s)+'/' + self.appmne +"."+os.path.basename(s)
                ls = _openfile(scompanion)
                if os.path.isfile(scompanion):
                    ls = _openfile(scompanion)
                    tcompanion = t
                else:
                    tcompanion = os.path.dirname(t)+'/'+os.path.basename(scompanion) # this should fail
            self.logger.debug("Companion files - src= %s; target= %s" % (scompanion, tcompanion))
        if os.path.isfile(t):
            same = _issame(ls, t)
        elif _base and os.path.isfile(_base):
            same = _issame(ls, _base)
                        #print('except', same)
                #print('checked', len(lt), len(ls), t, same)
        else:
            same = False # Target file does not exist
            #self.changeset['new'].append(t)
            tdir = os.path.dirname(t)
            if not os.path.isdir(tdir):
                os.makedirs(tdir)
                #self.changeset['new'].append(tdir)
            
        if same:
            # Files are same, so remove file and possibly the companion .fsl file as well
            os.remove(s)
            if self.logger:
                self.logger.debug("Remove %s (same)" % t)
            #try:
            #    os.remove(scompanion)
            #    if self.logger and os.path.isfile(scompanion):
            #        self.logger.debug("Remove %s .fsl (same)" % os.path.splitext(s)[0])
            #except WindowsError as e:
            #    if e.errno > 2:
            #        raise
        else:
            # Files are different, so replace target with source file
            if os.path.isfile(t):
                os.remove(t)
            os.rename(s,t)
            #self.changeset['modified'].append(t)

            if self.logger:
                self.logger.debug("Updated %s" % t)
            
            # Files are different, so replace target .fsl with source .fsl file as well
            #try:
            #    if os.path.isfile(tcompanion):
            #        os.remove(tcompanion)
                    #self.changeset['modified'].append(fsl+'.fsl')
                #else:
                    #self.changeset['new'].append(fsl+'.fsl')
            #except UnboundLocalError as e:
            #    self.logger.debug("tcompanion referenced before assignment: %s" % t)
            #except WindowsError as e:
            #    if e.errno > 2:
            #        raise
            #try:
            #    os.rename(scompanion, tcompanion)
            #    if self.logger and os.path.isfile(tcompanion):
            #        self.logger.debug("Updated %s .fsl" % tcompanion)
            #except UnboundLocalError as e:
            #    self.logger.debug("tcompanion referenced before assignment: %s" % t)
            #except WindowsError as e:
            #    if e.errno > 2:
            #        raise
        lt = ls = None
        return 0 if same else 1

    def mergecache(self, repo, limit = None, **kwargs):

        wcopy_fldr = repo["wc_root"] + '/' + repo['wc_svn_rel']
        
        try:
            base_fldr = '/'.join(repo['wc_root'],'tags',repo['base_tag'])
        except KeyError, TypeError as e:
            base_fldr = wcopy_fldr
        cache_fldr = repo["hash_folder"]
        self.repo_settings = repo
        self.appmne = repo['alias'].split('/')[1].upper()
        #for k in kwargs.keys():
        #    if getattr(self.mergecache, k):
        #        setattr(self, k, kwargs[k])
        if not os.path.isdir(cache_fldr):
            self.logger.error( "Cache folder not found: " + cache_fldr)
            return
        elif not os.path.isdir(wcopy_fldr):
            self.logger.error( "Working copy folder not found: " + wcopy_fldr)
            return
        elif not os.path.isdir(base_fldr):
            self.logger.error( "Base version folder not found: " + base_fldr)
            return
        l=[(x, x.split('.')[-1]) for x in os.listdir(cache_fldr) if x.split('.')[-1] in ('magic','xml','fsl')]
        if limit is not None:
            l = l[:limit]
        dpm=""
        f=""
        changes = 0
        for item, ext in l:
            try:
                dpm,f = item.split(' ')
            except:
                dpm=".".join([xi for xi in item.split('.') if xi == xi.upper() and ord(xi[0])>64])
                f=item[len(dpm)+1 if len(dpm)>0 else 0:]
            try:
                _fname = '/' + dpm + ('/' if dpm else "") + f
                changes += self.replace(cache_fldr + '/' + item, wcopy_fldr + _fname, base_fldr + _fname)
            except WindowsError:
                self.logger.exception("Error replacing target: {}, {} {} ({})".format(wcopy_fldr, dpm, f, base_fldr))

        svn = self.svnclient
        if not isinstance(svn, svnlink.SvnConnect):
            svn = svnlink.SvnConnect()

        for f in svn.unversioned(wcopy_fldr):
            svn.add_to_wcopy(f)
        changeset = svn.changes(wcopy_fldr)
        cnt = len(changeset)
                  
        if self.autocommit and cnt>0:
            svn.checkin(changeset, self.make_commit_message())
            self.logger.info("%d files reviewed; %d changes committed to %s" % (changes, cnt, self.repo_settings['alias']))
        elif changes > 0:
            self.logger.info("%d files reviewed; %d files changed" % (changes, cnt))
        
        svn.update_wcopy(wcopy_fldr)
        l = changeset = changes = cnt = cache_folder = wcopy_folder = None
        return
    
    def make_commit_message(self):
        import time
        dsite, app, br_type = self.repo_settings['alias'].split('/')
        appname, platform, br_id = self.repo_settings['wc_svn_rel'].split('/')
        branch = "DEV" if br_id == "trunk" else br_id.upper()
        msg = " ".join([app.upper(), platform, branch,":", "auto commit", time.ctime()])
        
        return msg
def makeNameValuePairs(l):
    # makes name value pairs using python dictionaries
    d={}
    if isinstance(l[0], list):
        return dict(l)
    else:
        L=[]
        for a in l[1:]:
            L.append(dict(a))
        d[l[0]]=L
    return d
    
def conv_to_list(s, head, L):
    r""" conv_to_list(str_conv, offset_head, L) - converts a magic-lite style list (external form) to a python list
           str_conv     - string to be converted
           offset_head  - offset to the current start position in the string to continue searching for 
                          remaining set of delimiters
           L            - list to append results to, can be empty
    """        

    pc=None # put here just in case we need a reference
    pc_ptr=head
    while head < len(s):
        if s[head] == '{':        # start of a new list item
            LR = [] # Set up empty list
            ho = head
            head, pc = conv_to_list(s, head+1, LR)
            pc_ptr = head+1
            
            if ho == 0:
                L.append(pc)     # handle the case of a list of lists
        elif s[head] == "}":     # End of list item currently being parsed
            if pc and pc_ptr == head:
                L.append(pc) # expand list and append to the end of it
                pc = None
            else:
                L.append(s[pc_ptr:head])
            return (head, L)
        elif s[head] == "|":
            if pc and pc_ptr==head:
                L.append(pc)
                pc = None
            else:
                L.append(s[pc_ptr:head])
#            pc=""
            pc_ptr = head+1
        else:
            pass
        head += 1
    # return the top node only as we added the top-level list to gather contents while parsing 
    return L[0]

