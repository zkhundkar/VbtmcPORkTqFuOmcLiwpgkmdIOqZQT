class BaseDbConnect ():
    """ Base database access class providing common functions for accessing a SQL data store
          All functions are currently based on sqlite3
    """
    
    def __init__(self, dbname, dblog=None):
        import os, os.path, sqlite3
        self.db = dbname
        self.dblogger = dblog
        if os.path.isfile(self.db):
            pass
        else:
            if self.dblogger:
                self.dblogger.debug("creating new db: %s", self.db)
            dpath = os.path.dirname(dbname)
            if not os.path.isdir(dpath) and dpath:
                os.makedirs(dpath)
        
        if dblog:
            self.dblogger.debug("Data stores %s" %(self.db))
            self.dblogger.debug("Initializing db connection " )
        else:
            print( self.db, dbname )
        con = sqlite3.connect(self.db)
        con.text_factory = str

        if dblog:
            self.dblogger.debug("Connection to opened" )
        # Likely don't need to explicitly set up a new db file as opening a connection does that automatically
        #if not con and self.db: # no database file yet, so need to create the file first
        #    f=open(self.db,'w')
        #    f.close()
        #    con = self.openConnection(self.db)
        self.createTables(con)
        self.cnn = con
        return

    def __del__(self):
        try:
            self.cnn.close()
        except Exception:
            pass
        self = None
        return
        
    def openConnection(self, db = None, con = None):
        r""" openConnection - self, db=None, conn=None
                               returns a connection
             if a connection is specified as one of the arguments, and it is open, the routine
                    will return that connection
             if a connection is NOT specified, this routine will open a new connection and
                    also save this as self.cnn if the exisiting self.cnn is no longer open
        """
        import sqlite3
        if db is None:
            db = self.db

        if self.dblogger:
            self.dblogger.debug('Verifying connection is still open (%s)',db)

        try:
            con = con if con else self.cnn
            con.execute("""SELECT Name from SQLITE_MASTER WHERE TYPE="table" LIMIT 1""")
        except sqlite3.ProgrammingError:
            con = self.cnn = sqlite3.connect(db)
            con.text_factory = str
            if self.dblogger:
                self.dblogger.info('Opened new connection to (%s)',db)
        #except sqlite3.OperationalError as e:
        #    self._except_message(e, 'openConnection')
                       
        return con

    def createTables(self, con = None, table = None, re_init=False):
        import sqlite3
        """ This method should be implemented in each application to initialize the 
              primary tables used by the aplication
              table - should be a dictionary strutured as {tablename1: "sql cmd to create", tablename2: "sql command to create"}
        """
        hasConn = False
        if con: hasConn = True
        else:
            try:
                con = self.openConnection(self.db)
            except:
                if self.dblogger:
                    self.dblogger.error('Could not open database (%s)', self.db)
                return
        cur = con.cursor()
        all = self.listTables(cur)
        #tables = [x for x in self.tables if x in ('ACTLOG', 'APPLIDS', 'NPRUPDATES')]
        if isinstance(table, dict):
            for t in table.keys():
                if t in all:
                    if re_init:
                        cur.execute("DROP TABLE "+t)
                    else:
                        # automatically handle the addition of new columns
                        tcols = [x.strip() for x in table[t].split(",")]
                        prim_key = [i for i, x in enumerate(tcols) if x.startswith("PRIMARY KEY")]
                        ncols = prim_key[0] if len(prim_key)>0 else len(tcols)
                        res=cur.execute("PRAGMA TABLE_INFO({})".format(t)).fetchall()
                        ocols=[x[1] for x in res if len(x[1])>0]
                        if ncols > len(ocols):
                            cur.execute("CREATE TEMPORARY TABLE  "+t+"temp "+table[t].strip("  "))
                            cur.execute("INSERT INTO "+t+"temp ("+", ".join(ocols)+") SELECT * FROM "+t)
                            cur.execute("DROP TABLE "+t)
                            cur.execute("CREATE TABLE  "+t+" AS SELECT * FROM "+t+"temp")
                            cur.execute("DROP TABLE "+t+"temp")                            
                        
                cur.execute("CREATE TABLE IF NOT EXISTS "+t+" "+table[t].strip("  "))

        cur.close()
        con.commit()
        return 

    def listTables(self, cur):
        import sqlite3
        l=cur.execute("""SELECT Name from SQLITE_MASTER WHERE TYPE="table" """).fetchall()

        l2=[str(x[0]) for x in l]
        return l2

    def get_columns(self, tname, con=None, keep_alive=None ):
        import sqlite3
        try:
            hasConn, con = self.check_connection(con)
            res=con.execute("PRAGMA TABLE_INFO({})".format(tname)).fetchall()
            res=[x[1] for x in res if len(x[1])>0]
            if self.dblogger:
                self.dblogger.debug("Column names (%s): %s" % (tname, res))
            #if keep_alive and hasConn:
            #    pass
            #elif not hasConn:
            #    con.close()
        except sqlite3.Error as e:
            self._except_message(e, "PRAGMA TABLE_INFO({})".format(tname))
            res = []
        return res

    def check_connection(self, conn):
        r""" check_connection (self, conn)
                       will verify that the connection in open, and open a new one if needed
                       It will also return True to indicate that a connection is open
        """
        import sqlite3
        con = self.openConnection(None,conn)
        return (True, con)
                
    def _except_message(self, e, in_str = ""):
        if self.dblogger:
            self.dblogger.error('DB Error: %s', e.args)
            if in_str:
                self.dblogger.error(' SQL: %s', in_str)

    def getall(self, s, g=None, con=None, keep_alive = False):
        import sqlite3
        """ Generic call to return all values from a sql query 
              TEXT variables are returned as non-unicode strings
        """
        res = []
        try:
            hasConn, con = self.check_connection(con)
            cur = con.cursor()
            if s.upper().startswith("SELECT"):
                if isinstance(g, list) or isinstance(g, tuple):
                    res = cur.execute(s, g).fetchall()
                else:
                    res = cur.execute(s).fetchall()
            cur.close()

        except sqlite3.Error as e:
            self._except_message(e, s)
            raise
        return res

    def set(self, s, g=None, con=None, keep_alive=False):
        import sqlite3
        """ Generic call to set values in database based of a sql query 
          TEXT variables are returned as non-unicode strings
        """
        try:
            hasConn, con = self.check_connection(con)
            con.text_factory = str
            cur = con.cursor()
            if isinstance(g, list) or isinstance(g, tuple):
                cur.execute(s, g)
            else:
                cur.execute(s)
            cur.close()
            #if keep_alive:
            #    return con 
            #elif not hasConn:
            con.commit()
            #    con.close()
            #return
        except sqlite3.Error as e:
            self._except_message(e, s)
            raise
        return

    def setall(self, s, g, con=None, keep_alive=False):
        import sqlite3
        """ Generic call to set values in database based of a sql query 
          TEXT variables are returned as non-unicode strings
        """
        try:
            hasConn, con = self.check_connection(con)
            self.dblogger.debug("Connection @ %s (self.con = %s)" % (con, self.cnn))
            con.text_factory = str
            cur = con.cursor()
            self.dblogger.debug("Execute many %s, %s" % (s,g))
            cur.executemany(s, g)
            self.dblogger.debug("SQL done ")
            cur.close()
            self.dblogger.debug("SQL commit ")
            con.commit()
            #if keep_alive:
            #    return con 
            #elif not hasConn:
            #    con.close()
        except sqlite3.Error as e:
            self.dblogger.error("setall (%s) - %s" % (s, e))
            
            self._except_message(e, s)
            raise

        return
