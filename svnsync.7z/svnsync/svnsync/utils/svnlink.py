import pysvn
import os

class SvnConnect():
    r""" class SvnConnect - helper class to automate updating a remote subversion repository

        The functions and comments have been adapted from the pysvn programmer guide
        http://pysvn.stage.tigris.org/docs/pysvn_prog_guide.html

        Author: Z Khundkar
        Date:   4/6/2016
    """      
        
    def __init__(self, **kwargs):
        #print 'init svnconnect'
        self.client = pysvn.Client()
        self.client.callback_get_login = self._remote_login
        self.client.callback_ssl_server_trust_prompt = self.ssl_server_trust_prompt
        
        for k in kwargs:
            setattr(self, k, kwargs[j])

    def ssl_server_trust_prompt(self, trust_dict ):
        #print "ssl server prompt"
        #print trust_dict
        r"""{'valid_until': 'Sat, 06 Jan 2018 23:58:39 GMT',
             'hostname': 'svn.iatric.com', 'realm': 'https://svn.iatric.com:8443',
             'finger_print': 'a7:db:d7:66:f0:02:6b:14:ab:4b:0b:d8:87:8f:26:11:3d:f7:f5:be',
             'valid_from': 'Tue, 06 Jan 2015 23:58:39 GMT',
             'issuer_dname': 'http://certs.godaddy.com/repository/, GoDaddy.com, Inc., Scottsdale, Arizona, US',
             'failures': 8}
        """
        retcode = True
        accepted_failures = min(10, trust_dict['failures'])
        save = True
        return retcode, accepted_failures, save
    
    def _get_url(self, fpath):
        r""" Determining the repository URL from the folder of the working copy
        """
        entry = self.client.info(fpath)
        return entry.url

    def _remote_login(*args):
        r"""
        """
        print('remote login', args)
        save=True
        password = 'Iatricis#1'
        username = 'IDOMAIN\Zeta.Khundkar'
        retcode=True
        return (retcode, username, password, save)
    
    def checkout(self, remote, local, rev=None):
        #Check out a working copy
        #check out the current version of the pysvn project
        r"""This example creates a working copy of the example project
             in the <local> directory.
             remote - url of repository, e.g. http://localhost/example/trunk
             local - path (folder) to create/update - working ocpy,
                     e.g., ./examples/pysvn
        """

        if os.path.isdir(remote):
            remote = self._get_url(remote)
        if rev:
            #check out revision 11 of the pysvn project
            revision=pysvn.Revision(pysvn.opt_revision_kind.number, rev)
            client.checkout(remote, local, revision)
        else:
            self.client.checkout(remote, local)

    def add_to_wcopy(self, filename):
        r""" Add a file or directory to the repository 
             the working copy will now track <filename> as a scheduled change
             filename - the folder in which the file is located
                        should have already been created and linked to the
                        remote repository
        """
        self.client.add(filename)

    def checkin(self, fileset, commit_message):
        r""" committing the change actually adds the file to the repository
             This adds the list of files in fileset to the repository.
             Note that the Client.import_() command does the addition and commit in a single step.
             Most applications, however, queue up multiple changes and commit them together at a later time.
        """
        self.client.checkin(fileset, commit_message)

    def update_wcopy(self, local_folder):
        r"""Update the working copy
            Updating gets any changes other users have committed to the repository
            and applies them to your working copy. Most applications do this on a
            regular basis to prevent conflicts.
        """
        if isinstance(local_folder, str):
            self.client.update(local_folder, recurse=True)
        elif isinstance(local_folder, list):
            fldr = [x for x in local_folder if os.path.isdir(str(x))]
            for x in fldr:
                self.client.update(x, recurse=True)
    


    def revert(self, fileset):
        r""" Discard changes in the working copy
             This discards any uncommitted changes in the working copy and restores a file or directory
             to its unedited state (most recent update from the repository).

             Files that are scheduled for addition or removal remain unversioned or are restored to the 
             working copy, respectively.
        """
        if isinstance(fileset, str):
            self.client.revert(fileset)
        elif isinstance(fileset, list):
            [self.client.revert(x) for x in fileset]
        else:
            pass
            # Add an exception
        return

    def _move(self, fileset, log_message=None):
        r"""Rename or move a file

            fileset should be a list of tuples.
              Each tuple should be (src, target)
            Moving or renaming a file removes the file under the old path or name and adds
            it in the new location while preserving information about previous versions.

            In this example, we passed both filenames to Client.checkin().
            Passing the parent directory would also have been effective.

            The move and checkin can be done in a single step on the server side;
            see the example in the Respository Tasks section.
        """
        #rename the file client side
        for src, target in fileset:
            self.client.move(src, target)
            
        #checkin the change removes the file from the repository
        if log_message:
            self.checkin(fileset, log_message)

    def remove(self, fileset, change_message):
        r""" Remove a file or directory from the repository
             the files in fileset will be removed from the working copy
             
             Some people confuse removing a file or directory from the repository with purging it completely.
             The file still exists in previous versions and can be retrieved by checking out or otherwise
             examining the contents of a previous revision.

             Files are typically removed from the working copy immediately, while directories usually remain
             in the working copy until the removal is committed.
        """
        [self.client.remove(x) for x in fileset] #schedule the removal 
        #committing the change removes the file from the repository
        self.client.checkin(fileset, change_message)


    def unversioned(self, folder):
        r""" list of onversioned folders and files in folder
        """        
        changes = self.client.status(folder)
        return [f.path for f in changes if f.text_status == pysvn.wc_status_kind.unversioned]

    def changes(self, folder):
        r"""Determine pending changes
        """

        def _filter(x):
            r""" files to be added, removed, or those that have changed
                    print 'files with merge conflicts:'
                    print [f.path for f in changes if f.text_status == pysvn.wc_status_kind.conflicted]
                    print 'unversioned files:'
                    print [f.path for f in changes if f.text_status == pysvn.wc_status_kind.unversioned]
            """
            return (x.text_status == pysvn.wc_status_kind.added) or \
                   (x.text_status == pysvn.wc_status_kind.deleted) or \
                   (x.text_status == pysvn.wc_status_kind.modified) 
                           
        changes = self.client.status(folder)
        return [f.path for f in filter(lambda x:_filter(x), changes)]
                



    def make_diff(self, folder, prefix):
        r"""
                  Generating a diff or patch
        """
        return self.client.diff(prefix, folder)

    def not_done(self):
        r"""Repository Tasks
        This section shows examples of tasks that manipulate or examine the repository. While the common tasks schedule changes through a local working copy, these tasks affect the repository directly.

        List the contents of a repository directory
        import pysvn
        client = pysvn.Client()
        entry_list = client.ls('.')
        Get the contents of a file from the repository
        import pysvn
        client = pysvn.Client()
        file_content = client.cat('file.txt')
        Create a branch or tag
        import pysvn
        client = pysvn.Client()
        log_message = "reason for change"
        def get_log_message():
            return True, log_message
        client.callback_get_log_message = get_log_message
        client.copy('http://svnrepo.com/svn/trunk', 'http://svnrepo.com/svn/tag/%s' % tag_name )
        Move or rename files in the repository
        import pysvn
        client = pysvn.Client()
        client.move( 'file_old.txt', 'file_new.txt' )
        """


F='C:/Iatric Systems/MagicSVN/MagicTest/CSF/CS60/trunk'
def test_changes(S, fpath=F):
    import pdb
    ss = S.changes(fpath)
    #sd = [x for x in ss if os.path.isdir(str(x))]
    #pdb.set_trace()
    #print("Checkin", sd[0])
    if len(ss)>0:
        print(S.checkin(ss,"CSF CS60 - change folder name to app.dpm"))
        print("Updating", ss[:1], S.update_wcopy(ss))
    else:
        print("No changes to commit")

    
if __name__ == '__main__':
    pass
    S = SvnConnect()
    print(hasattr(S,'client'))
    test_changes(S,F)
    
