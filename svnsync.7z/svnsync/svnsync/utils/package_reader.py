#---------------------------------------------------------------

import logging
import sys
import os
import logging
import pickle

class PkgReader:
#    from zipfile import *

    SECTION_DEL = chr(255)
    SEGMENT_DEL = chr(254)
    KEY_DEL = chr(30)


    def __init__(self, settings, **kwargs):
        #import pdb
        self.settings = settings
        self.pkgfile = kwargs['pkg'] if 'pkg' in kwargs else ""
        if 'logger' in settings:
            self.logger = settings['logger']
        elif 'logger' in kwargs:
            self.logger = kwargs['logger']
        try:
            tag = kwargs['tagname'] # This should be a folder where the components are to be extracted
            self.extract_components(tag)
        except KeyError as e:
            self.logger.info('Missing tag name')
            raise


    def get_dpm_name(self, s):
        return ".".join([xi for xi in s.split('.M.')[0].split('.') if xi == xi.upper() and ord(xi[0])>64])
    
    def extract_nprdata(self, targetfolder, rafdata):
    
        def _saveNodes(targetfolder, t, n, nodes):
            if t in ('screen', 'report', 'procdata'):
                dpm = self.get_dpm_name(n)
                fname = n[len(dpm)+1:]
                if len(nodes)>0:
                    if not os.path.isdir(targetfolder+dpm):
                        os.mkdirs(targetfolder+dpm)
                    with open(targetfolder+dpm+'/'+n+'_'+t[0].upper()+ '.fsl', 'rb') as fp:
                        pickle.dump(nodes, fp, pickle.HIGHEST_PROTOCOL)
            elif t in ('menu'):
                if not os.path.isdir(targetfolder):
                    os.mkdirs(targetfolder)
                with open(targetfolder+n[4:]+'_'+t[0].upper() + '.fsl', 'rb') as fp:
                    pickle.dump(nodes, fp, pickle.HIGHEST_PROTOCOL)
            elif t == 'datadef':
                if not os.path.isdir(targetfolder+n):
                    os.mkdirs(targetfolder+n)               
                with open(targetfolder+n+'/datadef.fsl', 'rb') as fp:
                    pickle.dump(nodes, fp, pickle.HIGHEST_PROTOCOL)
            return
            
        name = ptype = ''
        datadefs = {}
        segments = {}
        node_list = []
        for i, nprkey in enumerate(rafdata[::2]):
            nodevalue = rafdata[i*2 + 1]
            keynodes =  nprkey.split(self.KEY_DEL)
            _name = keynodes[1]
            if keynodes[0] == 'IS':
                _type = 'screen'
            elif keynodes[0] == 'IR':
                _type = 'report'
            elif keynodes[0] == 'IP':
                _type='procdata'
            elif keynodes[0] == 'IE':
                _type = 'datadef'
            elif keynodes[0] == 'IEE':
                _type = 'dataseg'
            elif keynodes[0] == 'IM':
                _type = 'menu'
            else:
                _type = 'ignore'
                
            if ptype and ptype != _type:
                _saveNodes(targetfolder, ptype, name, node_list)
                ptype = _type
                node_list = []
            elif _type == 'datadef' and name != _name:
                node_list = datadefs[_name] = []
            elif _type == 'dataseg' and name != _name:
                node_list = segments[_name] = []
            elif ptype == _type and name != _name:
                _saveNodes(targetfolder, ptype, name, node_list)
                name, ptype, node_list = _name, _type, {}
            
            node_list.append([nprkey, nodevalue])
        if len(datadefs.keys())>0:
            for k, v in datadefs:
                segs = segments[k] if k in segments else []
                self.save_nodes(targetfolder, 'datadef', k, v+segs)

    def extract_source(self, dpm, targetfile, lines):
        if not os.path.isdir(dpm):
            os.mkdirs(dpm)
        with open(dpm+'/'+targetfile+'.magic','w') as fp:
            fp.write('\n'.join(lines))


    def extract_components(self, target):
        r""" Extract source files and NPR data into target folder
            COMMENT,
            @COPY.APP,
            @COPY.MENUS, list o fmenus<SECTION_DEL>,
            @COPY.DPMS, list of dpms<SECTION_DEL>
            @COPY.PROCEDURES,list of procedures<SECTION_DEL>
            @npr.raf data 
                app, dpms, datadefs, screens, reports <SECTION_DEL>
                the entire section is set up as a long sequence of nodekey <SEGMENT_DEL> nodevalue <SEGMENT_DEL>
                the first entry is typically a null
            PROC<SECTION_DEL>,
            ..
            PROC<SECTION_DEL>
        """        

        if self.pkgfile and target:
            if os.path.isdir(target): pass
            else: os.mkdirs(target)
            segments = []
            with open(self.pkgfile, 'rb') as fp:
                segments = fp.read().split(self.SECTION_DEL)
            seg = segments[0].split(chr(254))
            pkg_comment, app, pkg_info = seg[:3]
            menus_list = [x for x in seg[3:] if x]
            dpms_list = [x for x in segments[1].split(self.SEGMENT_DEL) if x]
            proc_list = [x for x in segments[2].split(self.SEGMENT_DEL) if x]
            npr_data = [x for x in segments[3].split(self.SEGMENT_DEL) if x]
            npr_data.pop(0)

            TGTF = target+'/'
            for proc in segments[3:]:
                proc_comps = proc.split(self.SEGMENT_DEL)
                pname = proc_comps[1]
                dpm = self.get_dpm_name(pname)
                self.extract_source(TGTF+dpm, pname[len(dpm)+1:], proc_comps[1:])

            self.extract_nprdata(TGTF, npr_data)
            return True

        else:
            self.logger.info( 'No package file specified')

