def smtpexample():
    import smtplib

    SERVER = "localhost"

    FROM = "zeta.khundkar@iatric.com"
    TO = ["zeta.khundkar@iatric.com"] # must be a list

    SUBJECT = "Hello! Testing email alerts"

    TEXT = "This message was sent with Python's smtplib."

    # Prepare actual message

    message = """\
    From: %s
    To: %s
    Subject: %s

    %s
    """ % (FROM, ", ".join(TO), SUBJECT, TEXT)

    # Send the mail

    server = smtplib.SMTP(SERVER)
    server.sendmail(FROM, TO, message)
    server.quit()

	
import win32com.client
from win32com.client import Dispatch, constants

const=win32com.client.constants
olMailItem = 0x0
obj = win32com.client.Dispatch("Outlook.Application")
newMail = obj.CreateItem(olMailItem)
newMail.Subject = "I AM SUBJECT!!"
newMail.Body = "I AM IN THE BODY\nSO AM I!!!"
newMail.To = "zeta.khundkar@iatric.com"
#attachment1 = r"E:\test\logo.png"
 
#newMail.Attachments.Add(Source=attachment1)
#newMail.display()
 
newMail.Send()