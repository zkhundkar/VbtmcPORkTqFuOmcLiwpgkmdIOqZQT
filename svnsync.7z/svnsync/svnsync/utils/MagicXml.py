#!ztools/IatTools

class MagicXmlError(Exception):
    def __init__(self, expr, msg):
        self.expr = expr
        self.message = msg
        
class MagicNodes:
    r""" class MagicNodes
            Singleton class with structures (dictionaries) for mapping selected types of magic nodes to xml
            using propprietary schema

            Known top-level entries - menu, pdata, ddef, screen, report

            Each entry should have the following keys:
               name - this is used for the toplevel tag if a toplevel key is not specified in segmentKeys
               xslt - path/name of xslt file to embed in xml output
               segmentKeys - tuple of 2 elements
                   element 0 - list of NPR subscripts to match for the data degment. * is a wildcard
                   element 1 - list or tuple of other segmentKeys keys that are considered children or None
               print - dictionary of tags to be output to the xml file
                   key - tagname, value - number of wildcard keys to match
               container-tags - can be an empty dictionary
               keySize - each key is the number of NPR "subscripts" to match and corresponding value is a list of
                         segments (keys in segmentKeys). Child segments are sperated by /
            Additionally, for each item in the set of values defined in keySize, there should be an entry, e.g., routine in menu
            The value for such a key should be a tuple of 2 elements
               element 0 - list of tags for the NPR subscripts ("*" in segmentKeys element 0)
                        There should be one entry for each variable subscript 
                        a '.' as the first character of the sub-element will encode the subscript as an attribute value of the xml element
                          otherwise the subscript will be encoded as a child of the current xml element
                        "" as an element will skip coding the subscript
                        
                       None as the value of element 0 will skip encoding all subscripts for this segment
               element 1 - list of tags for the pieces of a queued list or VALUE
    """
    menu = {"name":"menu",
            "xslt":"../menus.xsl",

            "menu":([".urn"],["appl",".name",'responsible','linkable','active','unk','title']),

            "horiz-grid":([".item-row", '.item-col'],["item-routine-no"]),
            "vert-grid":([".vert-row", '.vert-col'],["vert-routine-no"]),
            "routine":([".rlink"],["title","proc","menu-proc","proc-args"]),
            "log-text-yn":([""], "VALUE"),
            "row": (None, "VALUE"),
            "col":(None, "VALUE"),
            "icon":(None, "VALUE"),
            "popup":(None, "VALUE"),
            "dt-last-update":(None, "VALUE"),
            "pc-date-time":(None, "VALUE"),
            "cas-last-update":(None, "VALUE"),
            "menu-access":(None, "VALUE"),
            "menu-access-tran":(None, "VALUE"),
            "picLine":([".linenum"],"VALUE"),
            "updated": (None, "VALUE"),
            "segmentKeys":{"toplevel": ("menu"),
                           "menu":(["IM","*"],('routine, picLine, horiz-grid')),
                           #, 'updated', 'pc-date-time', 'dt-last-update',
                           #                    'cas-last-update', 'menu-access', 'menu-access-tran')),
                           "horiz-grid":(["HGI","*", "*"], None),
                           "vert-grid":(["VGI","*", "*"], None),
                           "log-text-yn":(["L"], None),
                           "row": (["R"], None),
                           "col":(["C"], None),
                           "icon":(["I"], None),
                           "popup":(["P"], None),
                           "pc-date-time":(["PC"], None),
                           "dt-last-update":(["UD"], None),
                           "cas-last-update":(["UC"], None),
                           "menu-access": (["MA"],None),
                           "menu-access-tran": (["MAT"],None),
                           "updated": (["UPD"],None),
                           "routine":(["O","*"],('attribute','attrib-map','appl-doc','tech-doc','log-text', 'row','col','icon','popup')),
                           "picLine":(["P","*"],None)},

            "print" : {'Menus':0, 'menu':1, 'routine':1, 'picLine':1, 'horiz-grid':2, 'vert-grid':2,
                       "log-text-yn":2, "row": 2, "col":2, "icon":2, "popup":2, "updated":1,
                       "pc-date-time":1, "dt-last-update":1, "cas-last-update":1, 'menu-access':1 },
            "container-tags":{'updated':'other', 'pc-date-time':'other', 'dt-last-update':'other',
                              'cas-last-update':'other', 'menu-access':'other', 'menu-access-tran':'other'},

            "keySize" : {"2":["routine","picLine","log-text-yn","row","col","icon", "popup"],
                         "1":["pc-date-time", "dt-last-update", "cas-last-update",
                              "updated", "menu-access", "menu-access-tran"],
                         "3":['horiz-grid', 'vert-grid']} }

    pdata = {"name":"procdata",
             "xslt":"../../procdata.xsl",
             "main":([".urn"],['dpm', 'name','responsible', 'access', 'active',
                                    'arguments', 'menu-logic', 'translate-as', 'z-switch-appl',
                                    'interruptable', 'source-ship']),
             "cust-notes": (['.note-urn'], "VALUE"),
             "pc-date-time": (None, "VALUE"),
             "xlated-mlogic": (None, "VALUE"),
             "chksum": (None,"VALUE"),
             "doc-info": (None,["external-name"]),
             "description": ([".line-no"], "VALUE"),
             "parse-errors": ([".err-section",".err-seq*"], ['err-type', 'err-message']),
             "parse-sections": ([".par-section"], ["dr-disable","dr-disable-comment", "dr.disable.device"]),
             "parse-segments": ([".par-dpm", ".par-segment"], ["inc-children","segment-type", "segment-slash","last-line"]),
             #"parse-warnings-top": (["SW","*"], None),
             "parse-warnings": ([".warn-section",".warn-id"], ['warn-message', 'warn-effect-dr', 'warn-count']),

             "segmentKeys": {"toplevel": ("main"),
                             "main":(["IP","*"],('pc-date-time', 'xlated-mlogic', 'chksum', 'doc-info','cust-notes',
                                                    'description', 'parse-sections', 'parse-errors', 'parse-warnings')),
                             "parse-sections": (["S","*"], ('parse-segments')),
                             "parse-segments": (["*", "*"], None),
                             "parse-errors": (["SE","*","*"], None),
                             "parse-warnings": (["SW","*","*"], None),
                             "pc-date-time": (["PC"], None),
                             "xlated-mlogic": (["ML"], None),
                             "chksum": (["CHK"], None),
                             "doc-info": (["D"], None),
                             "cust-notes": (["RN",'*'], None),
                             "description": (["D","*"], None)
                             },
        
            "print" : {"main":1, 'doc-info':2, "xlated-mlogic":2},
            "container-tags":{'root':"pdata", 'main':"main"},

            "keySize" : {"2":["main"],
                         "3":["main/pc-date-time", "main/xlated-mlogic", "main/chksum", "main/doc-info"],
                         "4":["main/description", "main/parse-sections", "main/cust-notes"],
                         "5":['main/parse-errors', 'main/parse-warnings'],
                         "6":['main/parse-sections/parse-segments']}
        
        }

    ddef = {"name":"datadef",
            "xslt":"../../datadefs_v2.xsl",
            
            "segment":(['dpm',"name"],["active","dpmLetters",'physBase','physRoot','parent','segType',
                                        'mapsTo','constant','localSubscripts','pc9','pc10','elemCount']),
            "dpmList":(['name'],['dpm-active', "detail",'letters','dict']),
            "dpm-apps":([".app"],"VALUE"),
            "dpm-desc":([".num"],"doc"),
            "dpm-resp":([".resp"],"VALUE"),
            "seg-value":(None,'segment-value'),

            "field":([".rank"],"fldName"),
            "subscript":([".rank"],["fldname","physName","proc-args"]),
            "index":([".rank"],"VALUE"),
            "child":([".rank"],["title","menu-proc","proc-args"]),

            'fld-def': ([".dpm",".element"],['Pointer','DataType','offset','physName','localName','length','jfy','.dataseg','rank']),
            "fld-attrib":([".type"],"VALUE"),
            "fld-attrib-map":([".type",".num"],"VALUE"),
            "segmentKeys":{"toplevel": ("dpmList"),
                           "dpmList":(["IF","*"],['dpm-apps', 'dpm-desc', 'dpm-resp']),
                           "dpm-apps":(["A","*"],None),
                           "dpm-desc":(["D","*"],None),
                           "dpm-resp":(["U","*"],None),

                           "segment":(["IE","*","*"],('field','subscript','index','child','seg-value')),
                           "seg-value":(["V"],None),
                           "fld-def":(["IEE","*","*"],('fld-attrib','fld-attrib-map')),
                           "fld-attrib":(["C","*"],None),
                           "fld-attrib-map":(["CL","*","*"],None),

                           "field":(["E","*"],None),
                           "subscript":(["S","*"],None),
                           "index":(["I","*"],None),
                           "child":(["C","*"],None),
                           "picLine":(["P","*"],None)},
        

            "print" : {"Datadefs":0, "dpmList":1, 'dpm-apps':2, 'dataSegments':1, 'segment':2, 'seg-value':3, 'field':3, 'subscript':3,
                       'index':3, 'child':3, 'elements':1, 'fld-def':2, 'fld-attrib':3, 'fld-attrib-map':4},
            "container-tags":{"segment":"dataSegments", "fld-def":"elements"},

            "keySize" : {"2":["dpm", "dpmList", "dpm-resp"],
                         "3":["segment","fld-def"],
                         "4":["segment/seg-value", "dpmList/dpm-apps", "dpmList/dpm-desc", "dpmList/dpm-resp"],
                         "5":["segment/field", "segment/subscript", 'segment/index', 'segment/child', 'fld-def/fld-attrib'],
                         "6":['fld-def/fld-attrib-map']} }

    report={"name":"report",
            "xslt":"../../reports_v2.xsl",
            "index":([".urn"],["name","dpm"]),
            "report":(None,[".active","name","dpm","procedure","type","refresh","data-seg","mult-pages","mult-page-no",
                          "window","graph-selects","fragment","rpt-sched","audit-trail","exit-show","exit-prompt",
                          "source-ship","cms-dictionary","repeat-cust"]),

            "doc-text":([".num"],"VALUE"),
            "field":([".num"],["field-ele-name","field-ele-dpm","row","marker","length","justify","fld-name"]),
            "fld-index":(["row","col"],["fld-length","fld-field"]),
            "fld-select":([".num"],["oper","value-1","value-2","sel-ele-name","sel-ele-dpm",".sel-scrn","prompt","default"]),
            "select":([".num"],["sel-oper","sel-value-1","sel-value-2","tsel-ele-name","tsel-ele-dpm",".scrn",
                                "sel-prompt","sel-default","sel-field"]),
            "sort-temp":([".num"],["sort-ele-name","sort-ele-dpm",".header",".trailer",".renumber","order"]),

            "footnote":([".num"],"VALUE"),
            "line":([".num"],[".region",".pg-break"]),

            "appl-doc":([".num"],"VALUE"),

            "tech-doc":([".num"],"VALUE"),
            "line-attrib":([".type"],"VALUE"),
            "attribute":([".type"],"VALUE"),
            "attrib-map":([".type",".num"],"VALUE"),
            "line-attrib-map":([".type",".num"],"VALUE"),
            "phi":(None,"VALUE"),
            "picLine":([".num"],"VALUE"),
            "section":([".id"],["sect-id","sect-rows-per-entry","sect-top-row","sect-visible-cnt","sect-table-name",
                             "sect-fields","sect-id-repeat"]),
            "segmentKeys":{"toplevel": ("report","picLine"),
                           "report":(["IR","*"], None),
                           "field":(["F","*"],('attribute','attrib-map','appl-doc','tech-doc',"fld-select")),
                           "fld-index":(["FI","*","*"],None),
                           "fld-select":(["SE","*"],None),
                           "footnote":(["N","*"],None),
                           "index":(["I","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "line":(["L","*"],("line-attrib",'line-attrib-map')),
                           "phi":(["PHI"],None),
                           "picLine":(["P","*"],None),
                           "select":(["SE","*"],None),
                           "appl-doc":(["DA","*"],None),
                           "tech-doc":(["DT","*"],None),
                           "doc-text":(["DC","*"],None),
                           "sort-temp":(["T","*"],None),
                           "attribute":(["C","*"],("attrib-map")),
                           "attrib-map":(["CL","*"],None),
                           "line-attrib":(["C","*"],None),
                           "line-attrib-map":(["CL","*","*"],None)},

            "print" : {'Reports':0, 'report':1, 'field':2, 'attribute':3,  'attrib-map':4, 
                       'footnote':2, 'line':2, 'line-attrib':3, 'line-attrib-map':4, 'picLine':2, 'section':2},
            "container-tags":{},
            "keySize" : {"1":["phi"],
                         "2":["doc-text","field","footnote","index","picLine","select","sort-temp",
                              "line"],
                         "3":["fld-index"],
                         "4":["line/line-attrib","field/attribute","field/appl-doc","field/tech-doc",
                              "field/fld-select"],
                         "5":["line/line-attrib-map"],
                         "6":["field/attribute/attrib-map"]} }


    screen={"name":"screen",
            "xslt":"../../screens_v2.xsl",
            "screen":(None,[".active","name","dpm","procedure","type","refresh","data-seg","mult-pages","mult-page-no",
                          "window","graph-selects","fragment","rpt-sched","audit-trail","exit-show","exit-prompt",
                          "source-ship","cms-dictionary","repeat-cust"]),
            "chk-sum":(None,['orig-cs','alt-cs']),
            "page":([".num"],["page-title","page-ok-prompt","page-exit-logic"]),
            "field":([".num"],["field-ele-name","field-ele-dpm","field-section","row","column","physical",
                           "length","pre-edit","justify","required","help","phy-base","mult-access-type",
                           "default-value","data-def-seg","data-def-ele","display-override","int-to-ext",
                           "ext-to-int","id-lookup"]),
            "appl-doc":([".num"],"VALUE"),
            "tech-doc":([".num"],"VALUE"),
            "attribute":([".type"],"VALUE"),
            "attrib-map":([".type",".num"],"VALUE"),
            "blocks":(None,["main-wd","flds-done"]),
            "block": ([".blk-urn"], ["blk-row", "blk-force", "blk-lock","blk-extend", "blk-width", "blk-height",
                                     "blk-header", "blk-row-hdr", "blk-head"]),
            "block-field": ([".blk-fld-urn"], "VALUE"),
            "picLine":([".num"],"VALUE"),
            "section":([".id"],["sect-control","sect-rows-per-entry","sect-top-row","sect-visible-cnt","sect-table-name",
                             "sect-fields","sect-repeat"]),
            "segmentKeys":{"toplevel": ("screen"),
                           "screen":(["IS","*"], None),
                           "chk-sum":(["CS"], None),
                           "page":(["P","*"],("field","picLine","section", "blocks")),
                           "blocks":(["B"],("block")),
                           "block":(["B","*"], ("block-field")),
                           "block-field": (["F","*"], None),
                           "field":(["F","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "picLine":(["P","*"],None),
                           "section":(["S","*"],None),
                           "appl-doc":(["DA","*"],None),
                           "tech-doc":(["DT","*"],None),
                           "attribute":(["C","*"],None),
                           "attrib-map":(["CL","*","*"],None)},
            "print" : {'Screens':0, 'screen':1, 'page':2, 'field':3,'attribute':4,'attrib-map':5, 'chk-sum':2,
                       'block':3, 'block-field':4,
                       'picLine':3, 'section':3, 'sect-fields':4},
            "container-tags":{},

            "keySize" : {"1":["chk-sum"],
                         "2":["page"],
                         "3":["page/blocks"],
                         "4":["page/field","page/picLine","page/section", "page/blocks/block"],
                         "6":["page/field/attribute","page/field/appl-doc","page/field/tech-doc", "page/blocks/block/block-field"],                         
                         "7":["page/field/attrib-map"]} }

    screen_cs={"name":"screen",
            "xslt":"../../screens_v2.xsl",
            "screen":(None,[".active","name","dpm","procedure","type","refresh","data-seg","mult-pages","mult-page-no",
                          "window","graph-selects","fragment","rpt-sched","audit-trail","exit-show","exit-prompt",
                          "source-ship","cms-dictionary","repeat-cust"]),
            "chk-sum":(None,['orig-cs','alt-cs']),
            "page":([".num"],["page-title","page-ok-prompt","page-exit-logic"]),
            "field":([".num"],["field-ele-name","field-ele-dpm","field-section","row","column","physical",
                           "length","pre-edit","justify","required","help","phy-base","mult-access-type",
                           "default-value","data-def-seg","data-def-ele","display-override","int-to-ext",
                           "ext-to-int","id-lookup"]),
            "appl-doc":([".num"],"VALUE"),
            "tech-doc":([".num"],"VALUE"),
            "attribute":([".type"],"VALUE"),
            "attrib-map":([".type",".num"],"VALUE"),
            "blocks":(None,["main-wd","flds-done"]),
            "block": ([".blk-urn"], ["blk-row", "blk-force", "blk-lock","blk-extend", "blk-width", "blk-height",
                                     "blk-header", "blk-row-hdr", "blk-head"]),
            "block-field": ([".blk-fld-urn"], "VALUE"),
            "picLine":([".num"],"VALUE"),
            "section":([".id"],["sect-control","sect-rows-per-entry","sect-top-row","sect-visible-cnt","sect-table-name",
                             "sect-fields","sect-repeat"]),
            "segmentKeys":{"toplevel": ("screen"),
                           "screen":(["IS","*"], None),
                           "chk-sum":(["CS"], None),
                           "page":(["P","*"],("field","picLine","section", "blocks")),
                           "blocks":(["B"],("block")),
                           "block":(["B","*"], ("block-field")),
                           "block-field": (["F","*"], None),
                           "field":(["F","*"],('attribute','attrib-map','appl-doc','tech-doc')),
                           "picLine":(["P","*"],None),
                           "section":(["S","*"],None),
                           "appl-doc":(["DA","*"],None),
                           "tech-doc":(["DT","*"],None),
                           "attribute":(["C","*"],None),
                           "attrib-map":(["CL","*","*"],None)},
            "print" : {'Screens':0, 'screen':1, 'page':2, 'field':3,'attribute':4,'attrib-map':5, 'chk-sum':2,
                       'block':3, 'block-field':4,
                       'picLine':3, 'section':3, 'sect-fields':4},
            "container-tags":{},

            "keySize" : {"1":["chk-sum"],
                         "2":["page"],
                         "3":["page/blocks"],
                         "4":["page/field","page/picLine","page/section", "page/blocks/block"],
                         "6":["page/field/attribute","page/field/appl-doc","page/field/tech-doc", "page/blocks/block/block-field"],
                         "7":["page/field/attrib-map"]} }                    

    nsets={"menu":menu, "screen":screen, "report":report, "ddef":ddef, "proc":pdata,
           "IM":menu, "IS":screen, "IR":report, "IF":ddef, "IP":pdata }
           
    def __init__(self):
        return

class Magic2Xml:
    r""" class Magic2Xml
            Singleton class with methods to convert magic nodes from a package to xml using proprietary schema
            
                convertMagictoXml(self, filename, P, PATH) - is the method to use to convert a file or list of strings
                
                toXml - internal function
    """
    global ET
    import xml.etree.ElementTree as ET
    import sys
    import logging
    
    ESC_HTML = dict([('&', '&amp;'), ('<', '&lt;'), ('>', '&gt;'), ("'", '&apos;')])
    def __init__(self, **kwargs):
        self.nodemap=MagicNodes().nsets
        for k in kwargs:
            setattr(self, k, kwargs[k])
        self.logging = False if not hasattr(self, "logger") else self.logger 
        self.settings = {} if not hasattr(self, "settings") else self.settings 
        
        return
    
    def log(self, f, msg, level = logging.INFO):
        if f == 'print':
            print(msg)
        elif f:
            self.logger.log(level, msg)
        else:
            pass
        
    def queuedStringToList(self,s):
        subX=[]
        try:
            while len(s)>0:
                l=ord(s[0])
                subX.append(s[1:l+1])
                s=s[l+1:]
        except:
            pass
        return subX

    def escapedhtmString(self, s):
        return "".join(map(lambda x: self.ESC_HTML[x] if x in self.ESC_HTML else x, s))

    def _deduce_class_from_name(self, f):
        
        cls = None
        TRIM = False
        if "_S." in f:
            cls='screen'
        elif "_M." in f:
            cls='menu'
            TRIM = True
        elif "_R." in f:
            cls = "report"
        elif "_P." in f:
            cls = "proc"            
        elif "datadef" in f:
            cls = "ddef"

        return cls, TRIM

    def _dataseg_to_xml(self, tag, key, value, xmap, xt, ctags):
        global ET

        klist,vlist=xmap
        myparent=xt
        if tag in ctags.keys():
            ttag=ctags[tag]
            myparent=xt.find(ttag)
            if myparent is None:
                myparent=ET.Element(ttag)
                xt.append(myparent)
        else: pass
        e=ET.Element(tag)
        if klist is not None and isinstance(key, list):
            for k in klist:
                subs = key.pop(0)
                if k.startswith('.'): e.attrib[k[1:]]=subs
                elif k=="": pass
                else:

                    x=ET.Element(k)
                    x.text=subs
                    e.append(x)
        if type(vlist) is list:
            v2=self.queuedStringToList(value)
            #print klist, vlist, '\n',v2
            for v in vlist:
                if len(v2)>0:
                    subs = v2.pop(0)
                    if v.startswith('.'): e.attrib[v[1:]]=subs
                    else:
                        x=ET.Element(v)
                        x.text=subs
                        e.append(x)

        elif not vlist=="VALUE":
            x=ET.Element(vlist)
            x.text=value
            e.append(x)
        else: e.text=value
        myparent.append(e)
        return e

    def convertMagictoXml(self, f, P=None, PATH=""):
        r""" convertMagictoXml(self, f_in, P [=None], PATH [=""])
                         function to convert a file or list of strings (Magic key/value pairs - see below for format) 
                           to its corresponding xml format
                f       = filename (fully qualified, including path) or a list of strings that would be obtained with 
                            readlines() each entry in the list (or each line in the file) should be:
                            <magic node subscript set> = <magic node value>
                            There should be exactly one space before and after the '=' character. 
                P       = type of nodeset, can be one of screen, report, menu or ddef. P should have a value if the f argument 
                            supplies a list of node value pair strings. If f is a filename, P should be set to None
                PATH    = directory in which the xml output file is to be written. If this is not supplied, and the 
                            value of f provided is a filename the program will attempt to save the output in the same 
                            folder as the source file
        """
        global ET
        import os
        fs=""
        fn = None
        if P:
            k=self.formKey(f[0].split('=')[0].strip(' '))
            if isinstance(k, list) and len(k)<2:
                xt=None
                P = 'unknown'
                fs=[]
                fn = self._output_fn(PATH, "_".join(k) +'.xml-dump')
                self.logger.error("First node in {!s} is invalid: {!s}".format(P.upper(), f[0]))
                raise MagicXmlError("Invalid first node", "Could not convert fsl" )
                return
                
            elif P in ('screen', 'report', 'proc', 'procdata'):
                name=k[1].split('.')
                dpm=[]
                ucase=True
                for i in range(len(name)):
                    if ucase and name[i]==name[i].upper() and ord(name[i][0])>60: dpm.append(name[i])
                    else:
                        ucase=False
                        
                        
                dpm=".".join(dpm)
                fn = self._output_fn(PATH, dpm+"/"+k[1][len(dpm)+1:]+"_"+P[0].upper()+".xml")
            elif P == 'menu':
                fn = self._output_fn(PATH, ".".join(k[1].split('.')[1:])+'.xml')
            elif P == 'datadef' or P=='ddef':
                fn = self._output_fn(PATH, k[1]+'/datadef.xml')
            
            PP=self.nodemap[P]["print"]
            if not P:
                raise MagicXmlError("", "Could not determine nodeset class")
            elif len(PP)==0:
                raise MagicXmlError("", "{!s is not a known nodeset class}".format(P))
            fs=f

        elif not os.path.isfile(f):
            raise MagicXmlError(f,"Not a valid file name")
            return
        else:
            fa=open(f,"r")
            fs=fa.readlines()
            ord(ff[0][0])
            fn=".".join(f.split(".")[:-1])+".xml"
            if ".S" in f :
                P = 'screen'
                PP=self.nodemap['screen']["print"]
            elif ".R." in f:
                P = 'report'
                PP=self.nodemap['report']["print"]
            elif "datadef." in f:
                P = 'datadef'
                PP=self.nodemap['ddef']["print"]
            if len(PATH)>0:
                pass
            elif os.path.isfile(f):
                PATH = os.path.dirname(f)
            
        #print (P, len(fs))
        if not P:
            raise MagicXmlError(f, "{Could not determine nodeset class for !s}".format(f))

        self.output_fn = os.path.splitext(os.path.basename(fn))[0] if fn else None
        try:
            self.xslt = self.nodemap[P]["xslt"]
            xt=self.toXml(fs, len(fs))
            if 'XSLHOME' in self.settings:
                self.xslt=os.path.join(self.settings['XSLHOME'],os.path.basename(self.xslt))
            elif 'current' not in self.settings or self.settings['current']['wc_svn_rel'].endswith('capture'):
                pass
            else:
                self.xslt = self.settings['current']['wc_svn_rel'] + '/' + self.xslt
                self.xslt = "/".join(['..' for x in os.path.dirname(self.xslt).split('/')]) + '/' + os.path.basename(self.xslt)
        except KeyError as e:
            self.log(self.logging, "%s: while processing %s from %s" % (e, P, f))
            raise
        except AttributeError as e:
            if xt is None:
                with open(fn,"w") as fa:
                    fa.write('<?xml version=\"1.0\"?>\n')
                    fa.write('<?xml-stylesheet type=\"text/xsl\" href=\"'+self.xslt+'\" ?>\n')

                raise MagicXmlError("Null xml tree", "Could not convert %s" % fn)
                return
            else:
                #self.xslt=os.path.join(
                pass

        with open(fn,"w") as fa:
            fa.write('<?xml version=\"1.0\"?>\n')
            try:
                fa.write('<?xml-stylesheet type=\"text/xsl\" href=\"'+self.xslt+'\" ?>\n')
                self.printTree("",xt,ET,fa,PP)
            except: 
                self.logging.warning("Error (%s) producing tree for ({0!s}): {1!s}".format(type(xt), P, fn) )
                #raise MagicXmlError("", "Error producing tree for ({0!s}): {1!s}".format(P, fn))
        xt = None
        self.output_fn = None
        return
    
    def _output_fn(self, fpath, fname):
        import os
        
        fn = fpath+'/'+fname
        if os.path.isdir(os.path.dirname(fn)):
            pass
        else:
            fn=fpath+'/'+fname.replace('/', " ")
        return fn
        
    def formKey(self,k,ev=False, pfx_offset=0):
        if ev:
            k=eval(k)
        return [x if i>0 else x[pfx_offset:] for i, x in enumerate(self.parseKeys(k.strip(' ')))]
    
    def formValue(self,v,ev=False):
        if ev:
            v=eval(v)
        return v.rstrip(' ')

    def toXml(self,ll,limit=None):
        global ET
        import sys
        if limit: pass
        else: limit=len(ll)
#        classes={"IS":(screen,"screen"),"IR":(report,"report")}
        ln=topnode=ll.pop(0)
        n=ln.index('=')
        NPRPFX = 0
        k=self.formKey(ln[:n].strip(' '), False, NPRPFX)
        v=self.formValue(ln[n+2:])
        if k[0].startswith('&'):
            if ord(k[0][1])>64<96:
                NPRPFX=1
            elif len(k[0])>5 and ord(k[0][4])>64<96:
                NPRPFX=4
        k[0] = k[0][NPRPFX:]
        xt=None
#        print k, v
        if k[0] in self.nodemap.keys():
            segmap=self.nodemap[k[0]]
            topseg=segmap["segmentKeys"]["toplevel"]
            if type(topseg) is tuple or type(topseg) is list:
                topseg=topseg[0]
            
    #        print segmap["name"], topseg
            try:
                xt= ET.Element(segmap["container-tags"]["root"])
            except KeyError:
                xt= ET.Element(segmap["name"].title()+'s')
            nodepath=[xt]
            key_top=None
            if segmap[topseg]:
                key_top=k
            
            cnode=self._dataseg_to_xml(topseg,key_top,v,segmap[topseg],xt,segmap["container-tags"])
            parentNodes={"root":(topseg,"",xt)}
            segs=segmap["segmentKeys"]
            if segs[topseg][1]:
                parentNodes[topseg] = (topseg,[k[iix] for iix, xxp in enumerate(segmap[topseg][0]) ], xt)
            keySize=segmap["keySize"]
            if isinstance(segs[topseg][1], list) and len(segs[topseg][1])>0 and False:
                lastparent=(topseg,k)
                parentNodes[topseg]=(topseg,k,cnode)            
            lncnt=0
            lastparent=(None,None,None)
            for ln in ll[:limit]:
                lncnt+=1
                #print(ln)
                if '=' in ln:
                    n = ln.index('=')
                else:
                    n = len(ln)
                #n=ln.index('=')
                k=self.formKey(ln[:n].strip(' '), False, NPRPFX)
                v=self.formValue(ln[n+2:])
                isChild=False
                if str(len(k)) in keySize :
                    keySet=keySize[str(len(k))]
                    match=False
                    keyseg=""
                    for keyS in keySet:
                        if match:
                           break
                        kmatch=True
                        key_PP=[]
                        dseg=keyS
                        if "/" in keyS:
                            for kxx in keyS.split('/'):
                                key_PP.extend(segs[kxx][0])
                                dseg=kxx

                        else: key_PP=segs[keyS][0]

                       # sys.stdout.write(keyS+" "+str(key_PP)+" "+str(k)+': ')
                        for i, keyP in enumerate(key_PP):
                            #keyP=key_PP[i]
                            if i< len(k) :
                                if keyP=="*" : pass

                                elif k[i]==keyP: pass
                                elif i==0 and k[i].endswith(keyP): pass
                                else:
                                    kmatch=False
                                    break

                            else:
                                kmatch=False
                                break
                        if kmatch:
                            match=True
         #                   sys.stdout.write(" "+str(match))
                            n=0
                            if "/" in keyS:
                                dk=segs[dseg][0]
                                n=-1
                                if dk[0] == "*": n=0-len(dk)
                                else: n=1-len(dk)
                                #k=k[n:]
                            else: pass
                            ptag,pk,cnode=parentNodes["root"]
                            ii=0
                            subKeys=keyS.split('/')
                            dseg=subKeys[-1]
                            subKeys=subKeys[:-1]
                            try:
                                keycount=0
                                while ii < len(subKeys):
                                    dk=segs[subKeys[ii]][0]
                                    dkk = [k[ik+keycount] for ik, kkp in enumerate(dk) if kkp=='*']
                                    keycount+=len(dk)
                                    if "/".join(subKeys[:ii+1]) not in parentNodes.keys():                                        
                                        # Add node for first level missing parent
                                        parentNodes["/".join(subKeys[:ii+1])] = (subKeys[ii], dkk, self._dataseg_to_xml(subKeys[ii], [kkp for kkp in dkk], [], segmap[subKeys[ii]], cnode, segmap['container-tags']))
                                    ptag,pk,pnode=parentNodes["/".join(subKeys[:ii+1])]
                                    if pk == dkk:
                                        cnode=pnode
                                    ii+=1
                                   # sys.stdout.write("\n\t"+ptag+" "+str(ii)+" "+str(k)+" ?= "+str(pk)+", "+str(cnode))
                            except KeyError:
                                if self.logging:
                                    self.logging.warning("{!s}: not in parents list. k = {!s} ".format(self.output_fn, k))
                                else:
                                    sys.stdout.write("not in parents list. k = %s " % k)

                           # sys.stdout.write("\n  "+str(k[n:])+" "+keyS+" "+str(k)+", "+ptag+str(pk)+" -> "+str(cnode)+'\n')
                            cx=self._dataseg_to_xml(dseg,[kpp for kpp in k[n:]],v,segmap[dseg],cnode,segmap['container-tags'])
                            kd = [k[ik+keycount] for ik, kkp in enumerate(segs[dseg][0]) if kkp=='*']
                            lastparent=(keyS,kd)
                            parentNodes[keyS]=(dseg,kd,cx)

                            break
                        else: pass
    #                        sys.stdout.write(" "+str(match)+'\n')
                else:
                    if self.logging:
                        self.logging.info("{!s}: key not matched {!s} ({!r})".format(self.output_fn, k, ln))
                    pass
                    #basher()
            ll.insert(0,topnode)

        return xt

    def printTree(self,top,e,M,fout=sys.stdout, P=None):
        global ET
        if M: pass
        else: M=ET
        s=M.tostring(e)
        sout=""
        tab=""

        sout=sout+self.printSub(P,s,tab)

        fout.write(sout)
        return

    def printSub(self,P,s,tab):
        for item in P.keys():
            i1=i2=-1
            tag='<'+item+' />'
            tag1="<"+item+">"
            tag2="<"+item+" "
            tc="</"+item+">"
            if tag1 in s : tag=tag1
            elif tag2 in s : tag=tag2
            else: tc=""
            sout=""

            while tag in s:
                i1=s.index(tag)
#                sout=sout+s[:i1]+'\n'+tab+tag
                sout=sout+s[:i1]+'\n'+"".join([" " for ii in range(3*P[item])])+tag
                s=s[i1+len(tag):]
                pass
            s=sout+s
        return s

    def parseKeys(self,s):
        p1=s.split('\x1e')
        p2=[]
        for x in p1:
            self.parseKey2(x,p2)
        return p2

    def parseKey2(self,x,p2):
        i=0
        pc=''
        while len(x)>0:
            xx,x=(x[0],x[1:])
            pp=ord(xx)
            if pp<31:
                p2.append(pc)
                pc=x[:pp]
                x=x[pp:]
                if pp==0:
                    p2.append(pc)
                    pc=''
                
            else:
                pc=pc+xx
        if len(pc)>0: p2.append(pc)
        return

