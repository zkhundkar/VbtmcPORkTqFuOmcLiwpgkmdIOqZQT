from pysimplesoap.simplexml import SimpleXMLElement
from pysimplesoap.client import SoapClient
import base64
import datetime
import time

class iAlert(object):
    alerts = { 'HEARTBEAT': {'name':'Heartbeat', "AuthCode":None, 'ClientType':None, 'ClientVersion':None, 'SystemID':None,
                      'LocalSystemTime':None },
               'ALERT': {'name':'Alert', "AuthCode":None, 'ClientType':None, 'ClientVersion':None, 'SystemID':None,
                         'LocalSystemTime':None, 'AlertType':0, 'ErrorCode':None, 'ErrorCodeDescription':None,
                         'ErrorDetails':None },
               'SERVERLOOKUP': {'name':'siWebServiceServerLookup', "AuthCode":None },
               'VERSION': {'name':'GetVersion', "AuthCode":None },
               'SNOOZEON' : {'name':'siSnoozeOn', "SystemID":None, "AuthCode":None, "SnoozeStart":'',
                             'SnoozeLength':'60'},
               'SNOOZEOFF': {'name':"siSnoozeOff", "SystemID":None, "AuthCode":None}
               }

    _HOST_ = "HTTP://ialert2.iatric.com/ialert/ialert.asmx"
    _LOCALHOST_ = "HTTP://127.0.0.1:8008/"
    _AUTHCODE_ = 'RzU4ZXo5Mkk0SXo2Zm9aNTNeUnpVNFpYbzVNa2swU1hvMlptOWFOVE09'
    _TRACE_ = False
    _ALERT_TYPES_ = { "INFO": 0, "WARNING": 1, "CRITICAL":2, "DEVELOPER":10, "CLIENT":20}
    _AGGREGATORS_ = {'HEARTBEAT':600, "INFO": 6*3600, "WARNING": 4*3600, "CRITICAL": 2*3600, "DEVELOPER":0}
    _ATTRIBS_ =  {'ClientType':'2', 'ClientVersion':'5.66', 'SystemID':'5499'}

    def __init__(self):
        self.lastAlerts = dict([(k,0) for k in self._AGGREGATORS_])
        return
    
    def send_alert(self, alert_type, **kw):
        try:
            alert_type = alert_type.upper()
            if alert_type in self._ALERT_TYPES_:
                _alertType = 'ALERT'
            else:
                _alertType = alert_type
            
            if alert_type in self._AGGREGATORS_ and self._AGGREGATORS_[alert_type]>0:
                if self.lastAlerts[alert_type] + self._AGGREGATORS_[alert_type] > time.time():
                    return "{} aggregated".format(alert_type)
            
            _action = iAlert.alerts[_alertType]['name']
            args = [k for k in iAlert.alerts[_alertType].keys() if k != 'name' and k in kw] # list of available args
            
            attrib = dict([(x, base64.b64encode(kw[x])) for x in args])
            attrib['LocalSystemTime'] = base64.b64encode(datetime.datetime.now().strftime("%Y/%m/%d %H:%M"))
            attrib["AuthCode"] = self._AUTHCODE_
            for k,v in self._ATTRIBS_.iteritems():
                if k in attrib and len(attrib[k])>0:
                    pass
                else:
                    attrib[k] = base64.b64encode(v)
                
            if alert_type != _alertType:
                attrib['AlertType'] = base64.b64encode( self._ALERT_TYPES_[alert_type] )
                
            # Check for missing keys
            missing = [k for k in iAlert.alerts[_alertType].keys() if k != 'name' and k not in attrib]
            if len(missing)>0:
                raise KeyError("Missing required info: {}".format(missing))
                

            lh = kw['host'] if 'host' in kw else iAlert._HOST_
            client = self.init_ialert('~/iAlert', lh)

            # Log the time alert was sent
            self.lastAlerts[alert_type] = time.time()

            res = client.call(_action, **attrib)
            return base64.b64decode( str(res.__getAttribute(_action+"Result")) )
        except KeyError as e:
            raise
        return attrib

    def send_hbeat(self, **kw):
        try:
            res=""
            last = self.lastAlerts["HEARTBEAT"]
            if last+self._AGGREGATORS_["HEARTBEAT"]<time.time():
                res = self.send_alert('HEARTBEAT', **kw)
                self.lastAlerts["HEARTBEAT"] = time.time()
            else:
#                print("Heartbeats are sent no more than every {}s by default".format(self._AGGREGATORS_["HEARTBEAT"]))
                return "Heartbeats are sent no more than every {}s by default".format(self._AGGREGATORS_["HEARTBEAT"])
        except KeyError:
            res = self.send_alert('HEARTBEAT', **kw)
            self.lastAlerts["HEARTBEAT"] = time.time()
        except AttributeError:
            res = self.send_alert('HEARTBEAT', **kw)
            self.lastAlerts = {"HEARTBEAT" : time.time()}
 #       if res:
 #           print( base64.b64decode( str( res.HeartbeatResult) ))
        return res
            
    def init_ialert(self, application='~/iAlert', host=_HOST_):
        c = SoapClient(location=host, action='/'.join([application, ""]), trace=True, namespace='/'.join([application, ""]) )
        return c
    

def test_getversion():
    al=iAlert()
    res = al.send_alert('VERSION')
    assert base64.b64decode( str(res.GetVersionResult) ) == 'Success', 'GetVersion test failed: {}'.format( base64.b64decode( str(res.GetVersionResult) ) )
    return res

def test_heartbeat():
    a=iAlert()
    res=a.send_alert('HEARTBEAT', ClientType='2', ClientVersion='5.66', SystemID='5499', LocalSystemTime='')
    assert base64.b64decode( str( res.HeartbeatResult) ) == 'Success', 'Heartbeat test failed: {}'.format(base64.b64decode( str( res.HeartbeatResult) ))
    print( base64.b64decode( str( res.HeartbeatResult) ) )
    return a

def test_warning():
    a=iAlert()
    # Alert Category (0=Informational,1=Warning,2=Critical)
    res=a.send_alert('ALERT', ClientType='2', ClientVersion='5.66', SystemID='5499', LocalSystemTime='', AlertType='0', ErrorCode='03', ErrorCodeDescription='Testing', ErrorDetails='more information can go here')
    #assert base64.b64decode( str(res.AlertResult) ) == 'Success'
    return res    
