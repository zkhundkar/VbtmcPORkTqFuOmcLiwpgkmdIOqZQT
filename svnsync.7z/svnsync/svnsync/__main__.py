import utils
import ui
import logging
import os

m_cmdSet = {}
cs_cmdSet = {}
if os.path.isdir('svnsync'):
    pass
else:
    os.chdir('./ztools/svnsync')

import socket
import time

#DELSTART = chr(1)
#DELEND = chr(2)
#DELDEL = chr(3)
#APPLIST = {}
#REPOLOCN = ""
#EPOCH_OFFSET = 320745600
#EPOCH_OFFSET =  int(time.mktime([1980,3,1,0,0,0,3,1,0]))
#LAST_EDIT = {}
#ICCCFG = None
#PARDB = "_syncpar.db"
#CFGFILE = "svnsync.ini"
#__CHANGES__ = 0

#m_cmdSet = {}
#cs_cmdSet = {}

def run():
    r"""Entry point for the application to run as a script"""
    import svnsync
    
    #known_commands()
    svnsync.run_forever()
    return

def main():

    import argparse
    import sys

    parser = argparse.ArgumentParser(description='svnsync Functions')

    parser.add_argument('-r',
                        help='register service (not implemented)')

    parser.add_argument('-o', type=str,
                        help='server, manager')

    parser.add_argument('-c',
                        help='Run As a Service')

    #parser.add_argument('install',
    #                    help='Run As a Service')
    #parser.add_argument('start',
    #                    help='Starts the servvice')
    args = parser.parse_args()



    if args.r and False:
        print "moving from ",os.path.abspath('.')
        os.chdir(args.r.strip(' ').strip())
        print "to", os.path.abspath('.')

    if args.o == 'server' :
        print 'starting server'
        #a=IatScanServer()
        run()
        print "exiting main()"
        
    elif args.o == 'manager':
        print "starting manager"
        #run_manager()
        print 'manager done'

    else:
        print("cmd line", sys.argv )
        print("Unknown option", args,'\n' )
        parser.print_help()
    
# ---------------------------------------------------------------------------------------------------------------------

main()