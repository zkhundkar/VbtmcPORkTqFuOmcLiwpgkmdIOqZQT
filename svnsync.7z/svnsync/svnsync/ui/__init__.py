import Tkinter
from Tkinter import Tk, Listbox, Menu, Toplevel
import ttk
import tkMessageBox
import os, subprocess
from baseapp import BaseApp, BaseDialog
#from .syncmanager import SyncManager