from baseapp import BaseApp, BaseDialog
import Tkinter
from Tkinter import Tk, Listbox, Menu, Toplevel
import ttk
import tkMessageBox

from svnsync.dbaccess import DBConnect
#DBConnect = dbaccess.DBConnect 

class SyncManager(BaseApp):
    settings = {}

    def __init__(self, parent, cmdargs=[]):
        BaseApp.__init__(self, parent, cmdargs)
        self.dbo = DBConnect(dbpath=None, branch=None, offset=None)
        self.resize(cmdargs)
        self.read_settings()

    def resize(self, initargs):
        import os
        self.status = self.parent
        
        self.top.title('SVN Sync Manager')
        self.pid=os.getpid()

        self.top.wm_resizable(width=400, height=520)

        #self.bind("<Escape>", self.destroy)            

        return  


    def writeTbox(self,s):
        self.tbox.insert(Tkinter.END,s)
        return
   

    def read_settings(self):
        def table_to_dict(n, ss):
            yy = [(n[i], x) for i, x in enumerate(ss)]
            return dict(yy)
                               
        self.repo_names = [str(x[1]) for x in self.dbo.get_columns("REPOS")]
        self.site_names = [str(x[1]) for x in self.dbo.get_columns("DEVSITES")]
        sites = self.dbo.get_sites()
        self.siteList = dict([(site[0], table_to_dict(self.site_names, site)) for site in sites])
        repos = self.dbo.get_repos()
        self.repoList = dict([("/".join([r[1],r[0],r[2]]), table_to_dict(self.repo_names, r)) for r in repos])
        return 

    def saveSettings(self):
        return

    def setupMenu(self):
        s = 'setupmenu'
#Create our Python menu
        self.connlist = Menu(self.menubar, tearoff=0)
        self.activeConnections = Menu(self.menubar, tearoff=0)
#Add our Menu to the Base Menu
        self.menubar.add_cascade(label="SVN Sync", menu=self.connlist)
#        self.menubar.add_cascade(label="Active", menu=self.activeConnections, state=DISABLED)
#        self.activeConnections.add_cascade(label="Refresh", command='self.checkActives')
#        self.activeConnections.add_cascade(label="Reload", command='self.reloadConnections')
#        self.activeConnections.add_separator()
        self.connlist.add_cascade(label="Start",command=self.startServer )
        self.connlist.add_cascade(label="Halt",command=self.stopServer )
        self.connlist.add_separator()
        self.connlist.add_command(label="Setup",command=self.setupSites)
        self.connlist.add_separator()
        self.connlist.add_command(label="Clear Manager Log",command=self.clearTbox )
#        self.connlist.add_command(label="Version",command=self.getVersion )
#       self.connlist.add_command(label="Statistics",command=self.getStats )
#        self.connlist.add_command(label="Debug On",command=lambda x=True: self.setDebug(x) )
#        self.connlist.add_command(label="Debug Off",command=lambda x=False: self.setDebug(x) )
        self.connlist.add_separator()
        self.connlist.add_command(label="Exit",command=self.destroy)
        
#        i=0
#        keyset=self.allConnections.keys()
#        keyset.sort()
#        for c in keyset:
#            self.connlist.add_command(label=c, command= lambda x=c: self.addConnection(x) )
#            i+=1
    def clearTbox(self):
        self.tbox.delete(0, Tkinter.END)

    def _checkServer(self):
        # to do
        return False

    
    def startServer(self):
        import subprocess as sp
        if self._checkServer():
            self.writeTbox("Server already listening " )
            return
        pid=sp.Popen([os.path.join(PYDIR,"python.exe"),
                      "svnsync", "-o server"])
        time.sleep(0.5)
        if pid.poll():
            tkMessageBox.showwarning("Start","Could not start server")
        else:
            self.writeTbox("Server running .. [%s] " % pid)
        return
    
    def stopServer(self):

        if True:
            self.dbo.set_halt()
            self.writeTbox("Server shutdown .. ")
            
        else:
            tkMessageBox.showwarning("Stop Server","Could not shutdown")
            return
            
        return

    def setDebug(self,state=False):
        #to do
        return

    def getVersion(self):
        #to do
        return

    def getStats(self):
        # to do
        return
            
        return

    def setupSites(self):
        ManagerSetup(self,"Server Settings")
        #        settings=self.settings["SERVER"]
        #tkMessageBox.showwarning("Setup Server","Not implemented")

        #self.writeTbox("debug %s level %s" % (settings['debug'],
        #                                      settings['detaillogging']))
        return


class ManagerSetup(BaseDialog):

    def __init__(self, parent, title=None):

        Toplevel.__init__(self, parent)
        self.transient(parent)

        if title:
            self.title(title)
        self.parent = parent
        self.settings = parent.settings
        ttk.Style().theme_use('alt')
        st=ttk.Style()
        st.theme_use('winnative')
        st.configure('.', font='verdana 11')
        
        body = ttk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        self.grab_set()

        if not self.initial_focus:
            self.initial_focus = self

        self.protocol("WM_DELETE_WINDOW", self.cancel)

        self.geometry("+%d+%d" % (parent.winfo_rootx()+50,
                                  parent.winfo_rooty()+50))

        self.initial_focus.focus_set()

        self.wait_window(self)

    #
    # construction hooks

    def body(self, master):
        # create dialog body.  return widget that should have
        # initial focus.  this method should be overridden

        def update_select(self, elements, s):
            ss = elements[0]
            try:
                sval = ss.get()
            except:
                pass
            for i, e in enumerate(elements):
                e.delete(0, Tkinter.END)
                e.insert(0, s[self.site_names[i]])
            return
        ttk.Label(master, text="Dev Site:").grid(row=0, sticky=Tkinter.E)
        ttk.Label(master, text="Active:").grid(row=1, sticky=Tkinter.E)
        ttk.Label(master, text="Remote IP:").grid(row=2, sticky=Tkinter.E)
        ttk.Label(master, text="Remote Port:").grid(row=3, sticky=Tkinter.E)
        ttk.Label(master, text="Platform:").grid(row=4, sticky=Tkinter.E)
        ttk.Label(master, text="Protocol:").grid(row=5, sticky=Tkinter.E)
        ttk.Label(master, text="Time Zone Offset:").grid(row=6, sticky=Tkinter.E)
        #st.configure('TButton', font=('verdana',12))
        #st.configure('TEntry', font='verdana 10')
        
        #s.reverse()
        self.debug=Tkinter.IntVar()
        self.debug.set(0)
        #ipaddrs.reverse()
        self.e1 = ttk.Entry(master,width=30 )
        self.e2 = ttk.Combobox(master,values=("Y","N"),width=20)
        self.e3 = ttk.Entry(master,width=30 )
        self.e4 = ttk.Entry(master,width=30 )
        self.e5 = ttk.Combobox(master, values=("CS", "M"), width=30 )
        self.e6 = ttk.Combobox(master, values=("UCS", "ICS"), width=30 )
        self.e7 = ttk.Combobox(master, values=(1,2,3), width=30 )
        db_ele = [self.e1, self.e2, self.e3, self.e4,self.e5,self.e6, self.e7]
#        self.e2.insert(0,'7500')
        self.e1.grid(row=0, column=1, sticky=Tkinter.EW)
        self.e2.grid(row=1, column=1, sticky=Tkinter.EW)
        self.e3.grid(row=2, column=1, sticky=Tkinter.EW)
        self.e4.grid(row=3, column=1, sticky=Tkinter.EW)
        self.e5.grid(row=4, column=1, sticky=Tkinter.EW)
        self.e6.grid(row=5, column=1, sticky=Tkinter.EW)
        self.e7.grid(row=6, column=1, sticky=Tkinter.EW)
        debuglevels=['CRITICAL','ERROR','WARN','INFO','DEBUG','NONE']
        debuglevels.reverse()
        self.debuglevels=debuglevels
        self.cb = ttk.Checkbutton(master, text="Debug?", variable=self.debug, onvalue=True, offvalue=False)
        self.dbl = ttk.Combobox(master,values=tuple(debuglevels))
        print self.parent, self
        update_select(self.parent, db_ele, self.parent.siteList[self.parent.siteList.keys()[0]])
        if False:
            # find and set debug level
            if self.settings["SERVER"]["bindto"].strip() in s:
                ip=self.settings["SERVER"]["bindto"].strip()
            else:
                ip=s[0]
            self.settings["SERVER"]["bindto"] = ip
            self.e1.set(ip)
            self.e2.insert(0,self.settings["SERVER"]["port"])
            csr= self.parent._checkServer()
            self.e3.config(state="active")
            if csr:
                self.e3.insert(0,"Server is running")
            else:
                print "check returned nothing"
                self.e3.delete(0)
            self.e3.config(state="disabled")
            self.e4.insert(0,self.settings["SERVER"]["workingdir"])
            lvl=0
            try:
                lvl=int(self.settings["SERVER"]["detaillogging"])
            except: pass
            if lvl in range(6): pass
            else: lvl=0
            self.dbl.set(debuglevels[lvl])
            if lvl>0:
                self.debug.set(1)
            else: self.debug.set(0)
#        except: pass
        
        self.cb.grid(row=8, column=0, sticky=Tkinter.W)
        self.dbl.grid(row=8, column=1)


        pass

    def buttonbox(self):
        # add standard button box. override if you don't want the
        # standard buttons

        box = ttk.Frame(self)

        w = ttk.Button(box, text="OK", width=10, command=self.ok, default=Tkinter.ACTIVE)
        w.pack(side=Tkinter.LEFT, padx=5, pady=5)
        w = ttk.Button(box, text="Cancel", width=10, command=self.cancel)
        w.pack(side=Tkinter.LEFT, padx=5, pady=5)

        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)
        box.pack()

    #
    # standard button semantics

    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set() # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        self.apply()

        self.cancel()

    def cancel(self, event=None):

        # put focus back to the parent window
        self.parent.focus_set()
        
        self.destroy()

    #
    # command hooks

    def validate(self):
        return 1 # override

    def apply(self):

        self.parent.saveSettings()

        pass # override


def manage_server(p,s):
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect(('127.0.0.1',p))
    s.send("%s \x00" % s)
    print s.recv(512)
def set_as_service(svcname,svcpath,svcargs=None):
    import _winreg
    # check if service already exists
    h2=None
    hk=_winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Services")
    try:
        hk2=_winreg.OpenKey(hk,svcname)
        # service is already set up
        pass
    except:
        pass
    if hk2: _winreg.CloseKey(hk2)
    _winreg.CloseKey(hk)
    """
    Step 1: 
    Download and install Windows Resource Kit. 
    Which was found in my box: C:\Program Files (x86)\Windows Resource Kits\Tools\srvany.exe . 

    Then open command prompt and hit

    sc create "[YourService]" binPath="C:\Program Files (x86)\Windows Resource Kits
    \Tools\srvany.exe" start=auto DisplayName="[YourService Monitor]"

    [SC] CreateService SUCCESS


    Step 2: make a file.reg with following contents and double click on it
    [HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\[YourService]\Parameters]
    "Application"="C:\\[YourService Executable].exe"

     """
    return
    
"""
if __name__ == '__main__':

    import argparse, utils, os, logging

    parser = argparse.ArgumentParser(description='Iatrican Server Functions')
    parser.add_argument('-ip',
                       help='ip address for server')

    parser.add_argument('-p', type=int, 
                       help='port for server')

    parser.add_argument('-r', 
                       help='root directory')

    parser.add_argument('-o', type=str, 
                       help='manager, server, shutdown, setdebug, nodebug')
    args = parser.parse_args()
    if args.o:
        args.o=args.o.strip('\r\n').strip(" ")
    print  args.ip,args.p,args.o,args.r

    if args.r and False:
        print "moving from ",os.path.abspath('.')
        os.chdir(args.r.strip(' ').strip())
        print "to", os.path.abspath('.')

    if args.o == 'server':
        print 'starting server'
        a=IatScanServer()
        a=None
        print "exiting main()"
    elif args.o == 'manager':
        print "starting manager"
        app=ServerManager(None)
        app.mainloop()
        print 'manager done'

    elif args.p and args.o:
        print "manage server"
        manage_server(args.p, args.o.upper())
    elif True:
        app=SyncManager(None).mainloop()
    
    else:
        print "Unknown option", args
"""