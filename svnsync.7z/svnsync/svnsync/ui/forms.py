class ManagerSetup(ui.Toplevel):

    def __init__(self, parent, title=None):

        Toplevel.__init__(self, parent)
        self.transient(parent)

        if title:
            self.title(title)
        self.parent = parent
        self.settings = parent.settings
        ttk.Style().theme_use('alt')
        st=ttk.Style()
        st.theme_use('winnative')
        st.configure('.', font='verdana 11')
        
        body = ttk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        self.grab_set()

        if not self.initial_focus:
            self.initial_focus = self

        self.protocol("WM_DELETE_WINDOW", self.cancel)

        self.geometry("+%d+%d" % (parent.winfo_rootx()+50,
                                  parent.winfo_rooty()+50))

        self.initial_focus.focus_set()

        self.wait_window(self)

    #
    # construction hooks

    def body(self, master):
        # create dialog body.  return widget that should have
        # initial focus.  this method should be overridden
        
        ttk.Label(master, text="Address:").grid(row=0, sticky=ui.E)
        ttk.Label(master, text="Port:").grid(row=1, sticky=ui.E)
        ttk.Label(master, text="Status:").grid(row=2, sticky=ui.E)
        #st.configure('TButton', font=('verdana',12))
        #st.configure('TEntry', font='verdana 10')
        
        s=socket.gethostbyname_ex(socket.gethostname())[2]
        s.extend(['127.0.0.1'])
        port='2240'
        ip=s[0]
        #s.reverse()
        self.debug=IntVar()
        self.debug.set(0)
        #ipaddrs.reverse()
        self.e1 = ttk.Combobox(master,values=tuple(s),width=20)
        self.e2 = ttk.Entry(master,width=22 )
        self.e3 = ttk.Entry(master,width=22, state=ui.ACTIVE )
        self.e4 = ttk.Entry(master,width=30 )
        self.e2.delete(0,END)
#        self.e2.insert(0,'7500')
        self.e1.grid(row=0, column=1, sticky=ui.EW)
        self.e2.grid(row=1, column=1, sticky=ui.EW)
        self.e3.grid(row=2, column=1, sticky=ui.EW)
        self.e4.grid(row=3, column=1, sticky=ui.EW)
        debuglevels=['CRITICAL','ERROR','WARN','INFO','DEBUG','NONE']
        debuglevels.reverse()
        self.debuglevels=debuglevels
        self.cb = ttk.Checkbutton(master, text="Debug?", variable=self.debug, onvalue=True, offvalue=False)
        self.dbl = ttk.Combobox(master,values=tuple(debuglevels))
        if True:
            
            if self.settings["SERVER"]["bindto"].strip() in s:
                ip=self.settings["SERVER"]["bindto"].strip()
            else:
                ip=s[0]
            self.settings["SERVER"]["bindto"] = ip
            self.e1.set(ip)
            self.e2.insert(0,self.settings["SERVER"]["port"])
            csr= self.parent._checkServer()
            self.e3.config(state="active")
            if csr:
                self.e3.insert(0,"Server is running")
            else:
                print "check returned nothing"
                self.e3.delete(0)
            self.e3.config(state="disabled")
            self.e4.insert(0,self.settings["SERVER"]["workingdir"])
            lvl=0
            try:
                lvl=int(self.settings["SERVER"]["detaillogging"])
            except: pass
            if lvl in range(6): pass
            else: lvl=0
            self.dbl.set(debuglevels[lvl])
            if lvl>0:
                self.debug.set(1)
            else: self.debug.set(0)
#        except: pass
        
        self.cb.grid(row=5, column=0, sticky=W)
        self.dbl.grid(row=5, column=1)


        pass

    def buttonbox(self):
        # add standard button box. override if you don't want the
        # standard buttons

        box = ttk.Frame(self)

        w = ttk.Button(box, text="OK", width=10, command=self.ok, default=ui.ACTIVE)
        w.pack(side=ui.LEFT, padx=5, pady=5)
        w = ttk.Button(box, text="Cancel", width=10, command=self.cancel)
        w.pack(side=ui.LEFT, padx=5, pady=5)

        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)
        box.pack()

    #
    # standard button semantics

    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set() # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        self.apply()

        self.cancel()

    def cancel(self, event=None):

        # put focus back to the parent window
        self.parent.focus_set()
        
        self.destroy()

    #
    # command hooks

    def validate(self):
        return 1 # override

    def apply(self):
        self.settings["SERVER"]['bindto']=self.e1.get()
        self.settings["SERVER"]['port']= self.e2.get()
        #self.settings["SERVER"]['port']= self.e2.get()
        self.settings["SERVER"]['workingdir']=self.e4.get()
        self.settings["SERVER"]['detaillogging']=0
        try:
            self.settings["SERVER"]['detaillogging']=self.debuglevels.index(self.dbl.get())
        except: pass
        self.parent.saveSettings()

        pass # override

