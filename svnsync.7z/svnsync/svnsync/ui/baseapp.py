
import Tkinter
from Tkinter import Tk, Listbox, Menu, Toplevel
import ttk
import tkMessageBox
import os, subprocess
    
class BaseApp(Tk):

    settings = {}
    tearoffs=[]

    def __init__(self, parent, cmdargs=[]):
        
        self.top = self
        Tk.__init__(self,parent)
        self.parent=parent
        #self.configfile='svnsync.ini'
        #self.settings=self.readSettings()
        self.initialize(cmdargs)

    def initialize(self, initargs):
        self.status = self.parent
        
        self.top.title('Base Application')
        self.pid=os.getpid()

        for item in initargs:
            pass
        st=ttk.Style()
        st.theme_use('winnative')
        st.configure('.', font='verdana 12')
        if True:
            
            self.frame = ttk.Frame(self, borderwidth=1)
            self.frame.pack(fill=Tkinter.BOTH,expand=5)

            self.cfm = ttk.Frame(self.frame)
            self.yscrlbr = ttk.Scrollbar(self.cfm)
            self.yscrlbr.pack(side=Tkinter.RIGHT, fill=Tkinter.Y)
            self.xscrlbr = ttk.Scrollbar(self.cfm, orient=Tkinter.HORIZONTAL)
            self.xscrlbr.pack(side=Tkinter.BOTTOM, fill=Tkinter.X)
            self.tbox = Listbox(self.cfm,relief=Tkinter.GROOVE, height=10,width=60, yscrollcommand=self.yscrlbr, xscrollcommand=self.xscrlbr)
            #self.tbox.config(font=('verdana 10')
            self.yscrlbr.config(command=self.tbox.yview)
            self.xscrlbr.config(command=self.tbox.xview)
            self.tbox.pack(side=Tkinter.LEFT,fill=Tkinter.BOTH, expand=5)
            self.cfm.pack(fill=Tkinter.BOTH,expand=5)
            
        # display the menu
            self.menubar=Menu(self.top)
            self.setupMenu()
            self.top.config(menu=self.menubar)
            self.top.wm_resizable(width=200, height=120)

        #self.bind("<Escape>", self.destroy)            

        return  


    def writeTbox(self,s):
        self.tbox.insert(END,s)
        return
   

    def readSettings(self):
        import ConfigParser
        c=ConfigParser.SafeConfigParser()
        c.read(self.configfile)
        C=dict([(a,dict(c.items(a)) ) for a in c.sections()])
        # set up the first available ip address as the default address
        svr_defaults = {"bindto":socket.gethostbyname_ex(socket.gethostname())[2][0],
                        "port":'5555', "loglevel":"WARNING", "logfile":'svnsync.log',
                        "workingdir":os.path.abspath('../scanwork'),
                        "rootdir":os.path.abspath('.')}
        if "SERVER" not in C:
            C["SERVER"]=svr_defaults
        else:
            for k in svr_defaults.keys():
                if k not in C["SERVER"]:
                    C["SERVER"][k]=svr_defaults[k]
        c=None
        return C

    def saveSettings(self):
        cfg=open(self.configfile,'w')
        for section in self.settings.keys():
            cfg.write("[%s]\n" % section)
            for k in self.settings[section].keys():
                if k == "handler-class": pass
                else:
                    cfg.write("%s= %s\n" % (k.upper(),self.settings[section][k]) )
            cfg.write('\n')
        cfg.flush()
        cfg.close()

        

    def setupMenu(self):
        s = 'setupmenu'
#Create our Python menu
        self.topmenu = Menu(self.menubar, tearoff=0)
        self.svcmenu = Menu(self.menubar, tearoff=0)
#Add our Menu to the Base Menu
        self.menubar.add_cascade(label="Options", menu=self.topmenu)
        for x in self.tearoffs:
            self.menubar.add_cascade(label=x[0], menu=x[1])
        self.svcmenu.add_separator()
        self.topmenu.add_command(label="Exit",command=self.destroy)
        
    def clearTbox(self):
        self.tbox.delete(0,END)

    def setupServer(self):
        ManagerSetup(self,"Server Settings")
        settings=self.settings["SERVER"]
        #tkMessageBox.showwarning("Setup Server","Not implemented")
        self.writeTbox("server %s: port %s" % (settings["bindto"],
                                               settings['port']))
        self.writeTbox("debug %s level %s" % (settings['debug'],
                                              settings['detaillogging']))
        return

    
class BaseDialog(Toplevel):

    def __init__(self, parent, title=None):

        Toplevel.__init__(self, parent)
        self.transient(parent)

        if title:
            self.title(title)
        self.parent = parent
        self.settings = parent.settings
        ttk.Style().theme_use('alt')
        st=ttk.Style()
        st.theme_use('winnative')
        st.configure('.', font='verdana 11')
        
        body = ttk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        self.grab_set()

        if not self.initial_focus:
            self.initial_focus = self

        self.protocol("WM_DELETE_WINDOW", self.cancel)

        self.geometry("+%d+%d" % (parent.winfo_rootx()+50,
                                  parent.winfo_rooty()+50))

        self.initial_focus.focus_set()

        self.wait_window(self)

    #
    # construction hooks

    def body(self, master):
        # create dialog body.  return widget that should have
        # initial focus.  this method should be overridden
        


        pass

    def buttonbox(self):
        # add standard button box. override if you don't want the
        # standard buttons

        box = ttk.Frame(self)

        w = ttk.Button(box, text="OK", width=10, command=self.ok, default=ui.ACTIVE)
        w.pack(side=ui.LEFT, padx=5, pady=5)
        w = ttk.Button(box, text="Cancel", width=10, command=self.cancel)
        w.pack(side=ui.LEFT, padx=5, pady=5)

        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)
        box.pack()

    #
    # standard button semantics

    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set() # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        self.apply()

        self.cancel()

    def cancel(self, event=None):

        # put focus back to the parent window
        self.parent.focus_set()
        
        self.destroy()

    #
    # command hooks

    def validate(self):
        return 1 # override

    def apply(self):
        self.parent.saveSettings()

        pass # override


if __name__ == '__main__':

    if True:
        app=BaseApp(None).mainloop()
    
    else:
        print "Unknown option"
