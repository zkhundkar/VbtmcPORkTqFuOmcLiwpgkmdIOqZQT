#!ztools/svnsync/svnsync

r""" Master module for source version control of magic code through subversion
 Enable source version control for Magic

 Service utilizes ICS (classic Magic platform) and UCS (CS NPR platforms) - need to add rev#
  
Designed to pull codebase and NPR data (for screen, report, datadefs and procedure data) once a day to a local directory 
The pull for datadefs pulls everything, compares to the existing structures and discards segments that have had no changes
The pull for other data only pulls procedures ad data that has changed since the last pull (can be overriden) as 
 recorded in the NPR Audit indexes
     
A second utility routine compares procedures and data to the comparable resource in the directory under version control 
and discards the changes if there is no recognizable difference. This avoids us updating a resource that was simply retranslated
in Magic since we are not tracking 'object' codebase

When a resource is updated, the last modified time of the file is changed to the date/time in the NPR audit log
     
USAGE:
    The package can be run in a windows shell (current directory needs to be where the svnsync package directory is) using:
    python -m syncmanager -o server
    
TO DO:
    OK - Unit test GET PROC - first pass
    OK - Add database class and logic to update fields in appropriate tables
    OK - Add storing GET CHANGES result to svncache.db (one per app/branch )
    OK - Add local store of GET PROC procedure files in .cache directory (per app/branch) 
    OK - integrate routine to merge files in .cache folder (i.e., check and discard unchanged files)
    OK - integrate routine to convert NPR data to xml
    OK - Add reque function to GET CHANGES
    
    OK - CS version of LOGIN, GET CHANGES, GET PROC, GET DDEF
    OK - utility to auto-commit changes
    OK - authentication scheme for auto-commit utility
    OK - set up as local service
    
    OK - Match xml representation of cs screens, reports and datadefs - 

    PUSH routines
    package patch routine

    Unit test GET PROC - full
    Unit test GET CHANGES with reque and GET PROC

    Web App for utility and repo manager
    
    create changesets??
    mark procedures with revision #
    
    package creation utility (magic only)
    
    
"""

import socket
import time
import pickle
import os, sqlite3, shutil, filecmp, gc, sys
import logging
import logging.handlers

import utils
from utils.ialerts import iAlert
from utils.MagicXml import MagicNodes, Magic2Xml, MagicXmlError
from manage_cache import CacheHandler
#from utils.dbaccess import DBConnect as DBConnect
import base64
import xml.etree.ElementTree as ET



if '__file__' in locals():
    print(__file__)
elif os.path.isfile(sys.argv[0]):
    __file__ = os.path.abspath(sys.argv[0])
    print(__file__)
elif os.path.isdir('svnsync'):
    __file__ = os.path.abspath('svnsync/svnsync.py')
else:
    __file__ = None
    print("Trouble finding root path", os.path.abspath('.'))

if __file__ :
    os.chdir(os.path.dirname(os.path.abspath(__file__))) # this should be the main svnsync folder
#    os.chdir('../') # and then the parent folder where the default storage locations should be

try:
    import dbaccess
except:
    print("Could not import dbaccess")

DBConnect = dbaccess.DBConnect

# module variables
BUFSIZ = 65384
HNDL = "1321"
EPOCH_OFFSET =  int(time.mktime((1980,3,1,0,0,0,3,1,0)))

LOGFILE= 'svnsync.log'
# LOGLEVEL should be oneof the known logging levels - DEBUG, INFO, WARNING, ERROR, CRITICAL
LOGLEVEL= 'INFO'
LOGSIZE= 2
MAXLOGFILES= 5

BASEDIR= os.path.dirname(os.path.dirname(__file__))
PARDBDIR= BASEDIR
PARDBNAME = '_syncpar.db'
REPODBDIR= os.path.join(BASEDIR, 'store')
REPODBNAME= 'svnsync.db'
CFGFILE = os.path.join(BASEDIR,"svnsync","svnsync.ini")
WCOPYROOT=''
PYVERSION3 = True if sys.version_info > (3, 0) else False

main_logger = None
HALT_FLAG = False
MEMPROFILE = True
RAWDUMP = False
m_cmdSet = {}
cs_cmdSet = {}

#-------------------------------------------------= None--------------------------

class MagicICSError(Exception):
    def __init__(self, msg):
        self.err_type = "Error"
        self.message = msg

    def err_str(self, repo=None):
        if repo:
            return "ICS Error (!s): {!s} - {!s}".format(repo, self.err_type, self.message)
        else:
            return "ICS Error : {!s} - {!s}".format(self.err_type, self.message)            

class MagicICSLoginError(MagicICSError):
    def __init__(self, err_type, msg):
        super(MagicICSError, self).__init__(msg)
        self.err_type = err_type

class MagicICSReceiveError(MagicICSError):
    def __init__(self, err_type, msg):
        super(MagicICSError, self).__init__(msg)
        self.err_type = err_type

class MagicICSHaltError(MagicICSError):
    def __init__(self, err_type, msg):
        super(MagicICSError, self).__init__(msg)
        self.err_type = err_type

class BaseHandler() :

    DELSTART = chr(1)
    DELEND = chr(2)
    DELSEP = chr(3)
    DELMSGEND = chr(255)
    BUFSIZ = BUFSIZ
    extrepr = {DELSTART:'{', DELEND:'}', DELSEP:"|"}
    
    def __init__(self, sock, settings):
        self.sock = sock
        self.settings = settings
        self.handle = settings['current']['handle']
        self.db = settings['current']['db']
        self.dbo_par = settings['pardb']
        self.logger = settings["main_logger"]
        self.repo = settings["current"]['alias']
        return
        
    def parse_response(self, s, head, l, r):
    #    print "parse_response",l,s,r
#    print "parse_response",l,s,r
        rr = []
        ss = ""
        LEVEL = l
        i = head
        EXIT = False
        ct = 0
        pc_start = head
        LS = ""
        #print "START",LEVEL,head,len(s)

        while i < len(s) and not EXIT:
            if s[i] == self.DELSTART:
                LEVEL += 1
                k, ss, LEVEL, LS = self.parse_response(s, i+1, LEVEL, rr)
                #            print "OPEN-END",LEVEL,head,k, len(LS)
                i = k
                if k+1 < len(s) and s[k+1] == '\x03': pass
                elif LEVEL > 0:
                    rr.append(LS)
                    pc_start = i+1
                else:
                    rr = LS
                    pc_start = i

        #            rr.append(LS)
                   
            elif s[i] == self.DELEND:
                LEVEL -= 1
#            print "LIST END",LEVEL,head,pc_start,i, len(s)
                if s[max(head-1, 0)] == self.DELSTART and False: pass
                else:
                    if pc_start < i:
                        rr.append(s[pc_start:i])
#            print head, pc_start, i, rr
                #    r.append(rr)
                return (i,s[:i], LEVEL, rr)
            elif s[i] == self.DELSEP:
                #            print "MID",LEVEL,head,pc_start,i,len(s)
                pc = s[pc_start : i]
                if len(pc) > 0 and pc[0] == self.DELSTART: rr.append(LS)
                else: rr.append(pc)
                pc_start = i+1
            else: pass
            i += 1
        if len(rr) > 0: r.append(rr)
        #    print "END",i+1,s[:i],LEVEL
        return (i, s[:i], LEVEL, rr)
        
    def send(self, message = ''):
        global PYVERSION3
        self.logger.debug("SEND: %s" % self._tostr(message[:180]))
        if PYVERSION3:
            self.sock.send(str(message + self.DELMSGEND).encode()) # this is also valid in 2.7
        else:
            self.sock.send(message + self.DELMSGEND)
        return
    
    def process_request(self, s = ""):
        r""" process_request(self, s = "") - receives streamed data from remote port and
                         breaks it up into a list structure that parallels a magiclite list
        """

        global RAWDUMP
        DONE = False
        msg = ""
        try:
            while not DONE:
                d=self.sock.recv(self.BUFSIZ)
                msg += d.decode() if PYVERSION3 else d
                left = len(msg.split(self.DELSTART))
                right = len(msg.split(self.DELEND))
                if left == right:
                    DONE = True
        except socket.error as e:
            if len(msg)>0:
                self.logger.warning("%s : received stream may be corrupt %s" % (e, self._tostr(msg[:80])))
        #self.rcv.append(msg)
        self.msg = msg
        self.logger.info("RCVD: %d bytes %s" % (len(msg), self._tostr(msg[:80])))
        if RAWDUMP:
            with open(self._get_cache_path()+'/'+str(self).split('.')[-1].split(' ')[0]+' stream.raw','wb') as fb:
                fb.write(msg)
                      
        if len(msg) == 0:
            raise MagicICSReceiveError("Receive Error","0 bytes received")
            return False
        L=0
        R=[]
        S = self.parse_response(self.msg, 0, L, R)
        return self.process_response(S) or False

    def _get_cache_path(self):
        if "wc_root" in self.settings['current'].keys():
            fpath = self.settings["current"]["wc_root"]+'/.cache/'+self.settings['current']['wc_svn_rel']
        else:
            fpath = self.settings["current"]["WCROOT"]+'/.cache/'+self.settings['current']['BR_PATH']        #APPLIST[REPOLOCN]["cache"]
        if os.path.isdir(fpath) is False:
            os.makedirs(fpath)
        return fpath
    
    def _get_repo_path(self):
        if "wc_root" in self.settings['current'].keys():
            fpath = self.settings["current"]["wc_root"]+'/'+self.settings['current']['wc_svn_rel']
        else:
            fpath = self.settings["current"]["WCROOT"]+'/'+self.settings['current']['BR_PATH']        #APPLIST[REPOLOCN]["cache"]
        if os.path.isdir(fpath) is False:
            os.makedirs(fpath)
        return fpath
                      
    def convertfsl(self, ss, add_root = False):
        rs=[[base64.b64decode(x) if isinstance(x, str) else "".join(map(base64.b64decode, x)) for x in xx[1:] ] for xx in ss if len(xx)>1]
        if add_root:
            rootnode = rs[0][0]
            rs = [x if x[0].startswith(rootnode) else [rootnode+chr(30)+x[0],x[1]] for x in rs]
        return rs
        #return rs

    def get_dpm_list(self):
        return self.dbo_par.get_monitored_dpms()
    
    def _replace(self, key):
        key_map = {"APPDB":'appl_db', "SEG":'server_seg', "DIR":'server_dir', "RING":'server_ring', "HCIS":'server_hcis'}
        if key in self.settings['current']:

            return str(self.settings['current'][key])
        else:
            k = key
            if k in key_map:
                k = key_map[k]
                if k in self.settings["current"]:
                    return self.settings["current"][k]
            else:
                return ""
    def _tostr(self, s):
        return "".join(map(lambda x: self.extrepr[x] if x in self.extrepr.keys() else x, s))
            
    def dbfunction(self, f, dbo=None):
    #  f - name of a method of the DBConnect class that takes repo as its only argument.
    #       This function will run the method it finds and return its value, or return nill
    #
    # In the cmd-string, clauses like {{function}} will cause this method to be executed
    #
        try:
            _m = getattr(dbo if dbo else self.db, f)
            return _m(self.settings['current']['alias'])
        except:
            return ""
            
    def getcmdstr(self, cmd, handle):
        r""" getcmdstr(self, cmd, handle)
               cmd    - list of tuples to be merged into a string to be passed to the ICS/UCS listener
               handle - integer identifying the session id for the current connection. This is usually set up through a
                        LOGIN command
                        
               return - string to be passed to ICS/UCS listener (includes all message delimiters EXCEPT the global message start and end)
               
               This also replaces some items in the command string template :
                     <X>    - replaced by string returned by a call to self._replace(X)
                     {{X}}  - replaced by string returned by a call to self.dbfunction(X)
                     
                     Examples:
                       [("LOGIN", "ICS", "<HNDL>"), ("USERMNE", "ISCWEBSVC"), ("PASSWORD", "ISCWEB"), ("CLIENT", os.environ["COMPUTERNAME"])]
                       
                       returns a string with <HNDL> replaced by the value of the session handle (see _replace in BaseHandler)
                       
                       [("GET CHANGES", "ICC", "<HNDL>"), ["APPDB","<APPDB>"],  ["DIR", "<DIR>"], ["SEG", "<SEG>"], 
                                              ["DEBUG", "<DEBUG>"], ["SINCE", "{{get_last_update}}"]]       
        """
        
        def _getcmdstr(ll, h):

            ss=""
            if isinstance(ll, tuple) or isinstance(ll, list):
                ss = ss+self.DELSTART
                for pc in ll:
                    ss = ss + _getcmdstr(pc,h) + self.DELSEP
                if len(ss) > 1:
                    ss = ss[:-1]

                ss = ss + self.DELEND
            elif ll == '<HNDL>':
                ss = ss + str(self.handle)
            elif isinstance(ll, int):
                ss = ss + str(ll)
                self.logger.debug("Integer argument converted to string %s (%s)" %(ll, ss))
            elif ll.startswith('<'):
                ss = ss + self._replace( ll[1:-1] )
            elif ll.startswith('{{'):
                res = self.dbfunction(ll[2:-2])
                if len(res) == 0:
                    res = self.dbfunction(ll[2:-2], self.dbo_par)
                ss = ss + _getcmdstr(res, h)
                a = 1
            elif ll.startswith('%') and hasattr(self, ll[1:-1]):
                fnc = getattr(self, ll[1:-1]).strip()
                self.logger.info("Invoking handler method %s on (%s) " % (ll, ss[-10:]))
                ss = ss + _getcmdstr(fnc(self), h)
                a = 1
            else:
                ss = ss + str(ll)

            return ss
            
            
        return _getcmdstr(cmd, self.handle)

    def is_same(self, src, dest):
        if os.path.isfile(src) and os.path.isfile(dest):
            return filecmp.cmp(src, dest)
        else:
            return False

    def process_response(self, S):
        S
        return S
        
    def reque(self, t):

        return
        
    def __del__(self):
        # maybe clean up db connections - none right now
        return
        
class do_login(BaseHandler):

    def __init__(self, sock, settings):
        BaseHandler.__init__(self, sock, settings)

    def process_response(self, S):
    #def retrieve_handle(self, S):
       
        s = S[3]
        H= ""
        #print('process_response', S)
        for a in s:
            try:
                if a.startswith("HNDL"):
                    self.handle = H = a.split(self.DELSEP)[1]
            except: pass
            try:
                if len(H)>0: pass
                else:
                    if a[0] == "HNDL":
                        self.handle = H = a[1]
            except: pass
        if self.settings['current']['platform'].lower() == 'cs':
            pass
        elif self.handle != H:
            raise MagicICSLoginError("LoginError", str(S))
        else:
            self.settings['current']['handle'] = self.handle
        #print("HANDLE", H)
        return False

class do_get_ddef(BaseHandler):

    def process_response(self, S):
        import os
    #def _getdefs(self, S):
        #print(len(S), len(S[3]))
        if (not len(S[-1]) > 1) or (S[-1] == S[0]):
            self.logger.info("No datadefs returned")
            #print('Nothing returned', S)
            return False
        # The response should look like
        #  {{GET DDEF|OK|HNDL}|
        #       {dpmname|segname|{{Root Node, e.g., IF, IE or IEE|b64 encoded key| b64 encoded value}|
        #                         {Root node|encoded key| encoded value}|
        #                         {Root node|encoded key|encoded value}}}|
        #       {dpmname|segname| {{..}}}|
        #  }
        dpm = S[-1][1][0]  # S[-1][1] should be {dpmname|segname|{{..}}}

        fpath = self._get_cache_path()
        self.logger.info("Received %s " % str(S)[:80])
        self.logger.debug("Received %d nodesets" % len(S[-1][1:]))
        dpms = set([x[0] for x in S[-1][1:] if len(x[0])>0])
        self.logger.debug("Received defs for %d dpms" % len(dpms))
        #print(S[-1][1])
        for dpm in dpms:
            mm = {'IF': [], "IE": [], "IEE":[] }
            for x in S[-1][1:]: # list of {dpm|segment|{nodes}}
                if x[0]==dpm:
                    for xx in x[2]:
                        try:
                            mm[xx[0]] += [xx]
                        except KeyError:
                            self.logger.debug("Key Error while parsing ddef %s" % xx)
            rr = mm['IF'] + mm['IE'] + mm['IEE']
            self.logger.debug("Received %d nodesets for %s" % (len(rr), dpm))
            #FNAME = fpath+'/'+dpm+" datadef"+'.rawfsl'
            #with open(FNAME, 'wb') as fa:
            #    pickle.dump(rr, fa, -1)
            if len(rr) == 0:
                break
            X = self.convertfsl(rr)
            FNAME = fpath+'/'+dpm+" datadef"+'.fsl'
            with open(FNAME, 'wb') as fa:
                pickle.dump(X, fa, -1)
            #[fa.write(" = ".join([repr(xx) for xx in x2])+'\n') for x2 in  X]
            #self.db.log_npr_data(X, self.repo, dpm, "datadef")
            #print(dpm, rr[1])
        return False

class do_put_ddef(BaseHandler):

    def process_response(self, S):
        import os
    #def _getdefs(self, S):
        #print(len(S), len(S[3]))
        if (not len(S[-1]) > 1) or (S[-1] == S[0]):
            self.logger.info("No datadefs returned")
            #print('Nothing returned', S)
            return False
        # The response should look like
        #  {{GET DDEF|OK|HNDL}|
        #       {dpmname|segname|{{Root Node, e.g., IF, IE or IEE|b64 encoded key| b64 encoded value}|
        #                         {Root node|encoded key| encoded value}|
        #                         {Root node|encoded key|encoded value}}}|
        #       {dpmname|segname| {{..}}}|
        #  }
        dpm = S[-1][1][0]  # S[-1][1] should be {dpmname|segname|{{..}}}

        fpath = self._get_cache_path()
        self.logger.info("Received %s " % str(S)[:80])
        self.logger.debug("Received %d nodesets" % len(S[-1][1:]))
        dpms = set([x[0] for x in S[-1][1:] if len(x[0])>0])
        self.logger.debug("Received defs for %d dpms" % len(dpms))
        #print(S[-1][1])
        for dpm in dpms:
            mm = {'IF': [], "IE": [], "IEE":[] }
            for x in S[-1][1:]: # list of {dpm|segment|{nodes}}
                if x[0]==dpm:
                    for xx in x[2]:
                        try:
                            mm[xx[0]] += [xx]
                        except KeyError:
                            self.logger.debug("Key Error while parsing ddef %s" % xx)
            rr = mm['IF'] + mm['IE'] + mm['IEE']
            self.logger.debug("Received %d nodesets for %s" % (len(rr), dpm))
            #FNAME = fpath+'/'+dpm+" datadef"+'.rawfsl'
            #with open(FNAME, 'wb') as fa:
            #    pickle.dump(rr, fa, -1)
            if len(rr) == 0:
                break
            X = self.convertfsl(rr)
            FNAME = fpath+'/'+dpm+" datadef"+'.fsl'
            with open(FNAME, 'wb') as fa:
                pickle.dump(X, fa, -1)
            #[fa.write(" = ".join([repr(xx) for xx in x2])+'\n') for x2 in  X]
            #self.db.log_npr_data(X, self.repo, dpm, "datadef")
            #print(dpm, rr[1])
        return False

class do_put_dict(BaseHandler):

    def process_response(self, S):
        import os
    #def _getdefs(self, S):
        #print(len(S), len(S[3]))
        if (not len(S[-1]) > 1) or (S[-1] == S[0]):
            self.logger.info("No datadefs returned")
            #print('Nothing returned', S)
            return False
        # The response should look like
        #  {{GET DDEF|OK|HNDL}|
        #       {dpmname|segname|{{Root Node, e.g., IF, IE or IEE|b64 encoded key| b64 encoded value}|
        #                         {Root node|encoded key| encoded value}|
        #                         {Root node|encoded key|encoded value}}}|
        #       {dpmname|segname| {{..}}}|
        #  }
        dpm = S[-1][1][0]  # S[-1][1] should be {dpmname|segname|{{..}}}

        fpath = self._get_cache_path()
        self.logger.info("Received %s " % str(S)[:80])
        self.logger.debug("Received %d nodesets" % len(S[-1][1:]))
        dpms = set([x[0] for x in S[-1][1:] if len(x[0])>0])
        self.logger.debug("Received defs for %d dpms" % len(dpms))
        #print(S[-1][1])
        for dpm in dpms:
            mm = {'IF': [], "IE": [], "IEE":[] }
            for x in S[-1][1:]: # list of {dpm|segment|{nodes}}
                if x[0]==dpm:
                    for xx in x[2]:
                        try:
                            mm[xx[0]] += [xx]
                        except KeyError:
                            self.logger.debug("Key Error while parsing ddef %s" % xx)
            rr = mm['IF'] + mm['IE'] + mm['IEE']
            self.logger.debug("Received %d nodesets for %s" % (len(rr), dpm))
            #FNAME = fpath+'/'+dpm+" datadef"+'.rawfsl'
            #with open(FNAME, 'wb') as fa:
            #    pickle.dump(rr, fa, -1)
            if len(rr) == 0:
                break
            X = self.convertfsl(rr)
            FNAME = fpath+'/'+dpm+" datadef"+'.fsl'
            with open(FNAME, 'wb') as fa:
                pickle.dump(X, fa, -1)
            #[fa.write(" = ".join([repr(xx) for xx in x2])+'\n') for x2 in  X]
            #self.db.log_npr_data(X, self.repo, dpm, "datadef")
            #print(dpm, rr[1])
        return False

class do_get_app_list(BaseHandler):

    def _map_to_repo_(self, params, appdb):
        platform = self.settings['current']['platform']

        # appdb should be a list with 4 elements - ['APPDB', 'VSB.SPA', 'Visual Smartboard *LIVE*', '20161121']
        default_keys = ['app', 'dsite', 'branch_id', 'appl_db', 'server_seg', 'server_dir',
                        'server_hcis', 'server_ring', 'wc_root'] 
        defaults = dict([(k, params[k]) for k in default_keys])

        defaults['app'] =appdb[1].split('.')[0].lower()
        defaults['appl_db'] = appdb[1]
        defaults['active'], defaults['last_check'], defaults['pull_freq'], defaults['init_sync'], defaults['base_tag'] = [0, 0, 1, '', '']

        for k in ('seg', 'dir', 'hcis', 'ring'):
            if k in params.keys():
                defaults['server_'+k] = params[k]
            
        defaults['alt_top'] = params['appmis'] if 'appmis' in params.keys() else params['alt_top']
        defaults['earliest'] = appdb[3] if len(appdb)>3 else 0

        if 'testing' in params and 'wc_root_true' in params:
            defaults['wc_root'] = params['wc_root_true']

      
        _d = defaults['server_dir'].lower()
        if len(_d) == 0:
            _d = defaults['server_ring']
        if 'dev' in _d:
            defaults['branch_id'] = 'dev'
            _dsite = 'trunk'
        elif 'qc2' in _d:
            defaults['branch_id'] = 'qc2'
            _dsite = 'branches/qc2'
        elif 'qc' in _d:
            defaults['branch_id'] = 'qc'
            _dsite = 'branches/qc'
        else:
            defaults['branch_id'] = params['dsite'].lower()
            _dsite = '/'.join(['branches'] + [f.upper() for f in params['dsite'].split('-')])
            pass
        if 'DEV' in _d or 'QC' in _d:
            defaults['init_sync'] = 'DPMS, PROCS'          
        
        defaults['wc_svn_rel'] = '/'.join([appdb[1].split('.')[0].upper(),
                                           platform if platform[:2]=='CS' else 'Magic',
                                           _dsite ])
        
        return defaults
    
    def process_response(self, S):
        import os
    #def _getdefs(self, S):
        #print(len(S), len(S[3]))
        if not len(S[3]) > 1:
            #print('Nothing returned', S)
            return False

        nprdb = S[-1][1]
        #print S[-1]
        #pc = [["",""],["",""], , nprdb[3] if len(nprdb>3) else ""]
        #print(S[-1][1])
        appdbs = [self._map_to_repo_( self.settings['current'], x)  for x in S[-1][2] if len(x)>1]
        try:
            self.settings['pardb'].update_app_list(self.settings['current'], appdbs)
            
        except KeyError as e:
            self.logger.warning("No access to parameters db - list of apps not updated")
        #print appdbs    
        self.logger.debug("List of apps %s " % str([x['appl_db'].split('.')[0] for x in appdbs]))

        #self.db.log_get_dpms(self.settings['current']['alias'], dpms)
        return False

class do_get_bkup_plan(BaseHandler):

    def process_response(self, S):
        import os
    #def _getdefs(self, S):
        #print(len(S), len(S[3]))
        if not len(S[3]) > 1:
            #print('Nothing returned', S)
            return False

        appdb = S[-1][1][0][2] #   S[-1][1] should be {{"APPL"|app|appdb}|{0|0|0}}
        pc = [["",""],["",""]]
        try:
            pc[0] = (self.settings['current']['server_seg'], self.settings['current']['server_dir'])
        except KeyError:
            pass
        try:
            pc[1] = (self.settings['current']['server_hcis'], self.settings['current']['server_ring'])
        except KeyError:
            pass
        #print(S[-1][1])
        try:            
            appdbs = [x  for x in S[-1][2] if isinstance(x, list) and len(x)>2] # each list x should be [DPM, "DICT", segname, active]
            self.db.update_bkup_plan(self.settings['current']['alias'], appdbs)
            #print(self.settings['pardb'], self.db)
            self.logger.debug("RUI backup plans %s " % str([x[0] for x in appdbs]))

        except KeyError as e:
            self.logger.warning("No access to parameters db - list of apps not updated")
        except IndexError as e: # no dpms to log
            pass
        with open('bbkup_plan.pkl','w') as fp:
            pickle.dump(S[-1],fp)
            #print appdbs    

        #self.db.log_get_dpms(self.settings['current']['alias'], dpms)
        return False

class do_get_dict(BaseHandler):

    def process_response(self, S):
        import json

        self.logger.info("Received %s " % str(S)[:80])
        if not len(S[-1]) > 2:
            return False

        # The response should look like
        #  {{GET DICT|OK|HNDL}|{APPDB|appdb}|{
        #       {{dpmname|segname|TOPSUB}|CHKSUM|{
        #                            {.|NodeKey|NodeValue}| # Root Node, e.g., IF, IE or IEE|b64 encoded key| b64 encoded value
        #                            {.|NodeKey|NodeValue}| 
        #                         }}
        #       {{dpmname|segname|TOPSUB}|Checksum|{{..}}}|
        #  }
        #dpm = S[-1][1][0]  # S[-1][1] should be {dpmname|segname|{{..}}}

        fpath = self._get_cache_path()
        self.logger.debug("Received %d dict nodesets" % len(S[-1][2]))
        dpms = set([x[0][0] for x in S[-1][2] if len(x[0])>0]) # Should be only one dpm per call
        self.logger.debug("Received defs for %d dpm(s)" % len(dpms))
        #print(S[-1][1])
        for dpm in dpms:
            X = {}
            for x in S[-1][2]: # list of {{dpm|segment|topsub}|Checksum|{nodeset}}
                if x[0][0]==dpm:
                    dataseg = '/'.join(x[0])
                    if len(x)>2:
                        X[dataseg] = dict([(xnode,xval) for _,xnode,xval in x[2]])
                    else:
                        X[dataseg] = ''

            FNAME = fpath+'/'+dpm+" dict"+'.json'
            with open(FNAME, 'wb') as fa:
                json.dump(X, fa)

        #self.db.log_get_dpms(self.settings['current']['alias'], dpms)
        return False

class do_get_menu(BaseHandler):

    def process_response(self, S):
        import os
    #def _getdefs(self, S):
        #print(len(S), len(S[3]))
        if not len(S[3]) > 1:
            #print('Nothing returned', S)
            return False
        # The response should look like
        #  {{GET DDEF|OK|HNDL}|
        #       {"MENU"|MENUNAME|{{Root Node, e.g., IF, IE or IEE|b64 encoded key| b64 encoded value}|
        #                         {Root node|encoded key| encoded value}|
        #                         {Root node|encoded key|encoded value}}}|
        #       {"MENU"|MENUNAME| {{..}}}|
        #  }

        fpath = self._get_cache_path()
        #self.logger.debug("Received %d menu defs" % len(S[-1][1:]))
        menus = set([x[1] for x in S[-1][1:]])
        self.logger.info("Received defs for %d menus" % len(menus))
        #print(S[-1][1])
        for name in menus:
            rr = []
            for x in S[-1][1:]:
                if x[1]==name:
                    rr += x[2]
            self.logger.debug("Received %d nodesets for %s" % (len(rr), name))
            X = self.convertfsl(rr)
            MISSING_KEY = len([1 for xx in X if len(xx)<2 or len(xx[0])<3])
            FNAME = fpath+'/'+name+"_M"+'.fsl'
            with open(FNAME, 'wb') as fa:
                pickle.dump(X, fa, -1)
            if MISSING_KEY:
                with open(FNAME+"-dump", 'wb') as fb:
                    pickle.dump(S[-1][1:], fb, -1)
            #[fa.write(" = ".join([repr(xx) for xx in x2])+'\n') for x2 in  X]
            #self.db.log_npr_data(X, self.repo, dpm, "datadef")
            #print(dpm, rr[1])
        return False

class do_get_dpms(BaseHandler):

    def process_response(self, S):
        import os
    #def _getdefs(self, S):
        #print(len(S), len(S[3]))
        if not len(S[3]) > 1:
            #print('Nothing returned', S)
            return False

        dpm = S[-1][1][0]
        r"""fpath = self.settings["current"]["WCROOT"]+'/.cache/'+self.settings['current']['BR_PATH']        #APPLIST[REPOLOCN]["cache"]
        ;if os.path.isdir(fpath) is False:
        ;    os.makedirs(fpath)
   
        FNAME = fpath+'/'+dpm+" datadef"+'.fsl'
        fa = open(FNAME,'wb')
        """
        all_dpms = [x[1] for x in S[-1][2] if len(x)>1]
        dpms_changed = [x[1] for x in S[-1][2] if (len(x)>2 and len(x[2])>1)]
        self.logger.info("{:0d} dpms found, {} changed".format(len(all_dpms), len(dpms_changed)))

            #[fa.write(" = ".join([repr(xx) for xx in x2])+'\n') for x2 in  X]
        self.db.log_get_dpms(self.settings['current']['alias'], all_dpms)
            #print(dpm, rr[1])
        self.reque_items = [x for x in self.db.get_monitored_dpms(self.settings['current']['alias']) if x in dpms_changed]
        return True

    def reque(self, t):
        for dpm in self.reque_items:
            #LAST_EDIT[dpm+" "+proc] = int(tstamp.split('.')[0])
            cmdSet = self.settings['current']['cmdset']
            cc = cmdSet["GET DDEF?"]
            ccnew = []
            #if "GET PROC?" in cmdSet.keys(): pass
            #cmdSet["GET PROC?"] = ccnew
            # for each proc, we will need to spell out the arguments 
            #["DPM", "CQM.MEAS"], ["PROC","<>"], ["TYPE","A"], ["MACRO",[[1,"in.use"]]], 
            ccnew = [[x[0],[['1',dpm]]]+x[2:] if x[0] == 'DPMS' else x for x in cc]
                    
            #if ptype in ["S","R","L","M"]: ccnew.append(["TYPE", ptype])
            #else: ccnew.append(["TYPE", "A"])
            t.append(("GET DDEF", "", ccnew)) 
        self.reque_items = None
        return
        
class do_get_changes(BaseHandler):

    def process_response(self, S):
        import pdb
    #def _getchanges(self, S):

        proclist = self.reque_items = []
        log_time = int(time.time())
        platform = self.settings[self.settings['current']['dsite']]['platform'][0].lower()
            
        if len(S[-1]) > 2:
            for rr in S[-1][2]:
                rsp=rr #if platform == 'm' else rr.split(self.DELSEP)
                self.logger.debug(self._tostr(rsp))                                    
                
                if len(rsp) == 0: 
                    pass
                else:
                    mname = muser = ""
                    pname = rsp[0]
                    dpm = []
                    for x in pname.split("."):
                        if x.upper() == x and len(x)>0 and ord(x[0]) > 64: 
                            dpm.append(x)
                        else: 
                            break
                    dpm = ".".join(dpm)
                    pname = pname[len(dpm) + 1:]
                    m = len(pname)
                    change_type = "L"
                    #if len(rsp[2]>0): 
                    #    change_type = rsp[2][0]

                    try:
                        m = min(m, pname.index(".M"))
                        mname = rsp[3]
                        change_type = "M"
                    except: 
                        pass
                    try: 
                        m = min(m, pname.index(".S"))
                        change_type = "S"
                    except: 
                        pass
                    try: 
                        m = min(m,pname.index(".R"))
                        change_type = "R"
                    except:
                        pass
                    try: 
                        m = min(m,pname.index(".P"))
                        change_type = "P"
                    except:
                        pass
                    pname = pname[:m]
                    #print("QUE",dpm,pname,rsp[1],rsp[2],mname)
                    if True:
                        tstamp = rsp[1]
                    else:
                        tstamp, muser = rsp[1].split('.')
                    if len(dpm)>0 and len(pname)>0:
                        proclist.append((dpm, pname, tstamp, change_type, mname))
        APP = self.settings['current']['alias'].split('/')[1]
        try:
            self.db.log_get_changes(self.settings['current']['alias'], proclist, self.settings["current"]["wc_root"]+'/' + self.settings["current"]["wc_svn_rel"])
        except sqlite3.Error:
            raise
            return False # If there was a problem updating the database, do not attempt to reque 
        return True
        
    def reque(self, t):
        def r_map(c, d, pt, pr, mn):
            if c[0] == "DPM":
                return [c[0],d]
            elif c[0] == "TYPE":
                return [c[0], pt]
            elif c[0] == "PROC":
                return [c[0], pr]
            elif ccx[0] == "MACRO" :
                if pt == "M":
                    return [c[0], [['1', mn]]]
                else:
                    return [c[0], ""]
            else:
                return c
            
        for proc_item in self.reque_items:
            self.logger.debug(str(proc_item))
            dpm,proc,tstamp,ptype, mname = proc_item
            #LAST_EDIT[dpm+" "+proc] = int(tstamp.split('.')[0])
            cmdSet = self.settings['current']['cmdset']
            cc = cmdSet["GET PROC?"]
            ccnew = []
            #if "GET PROC?" in cmdSet.keys(): pass
            #cmdSet["GET PROC?"] = ccnew
            # for each proc, we will need to spell out the arguments 
            #["DPM", "CQM.MEAS"], ["PROC","<>"], ["TYPE","A"], ["MACRO",[[1,"in.use"]]], 
            ccnew = [r_map(ccx, dpm, ptype, proc, mname) for i, ccx in enumerate(cc)]
            #if ptype in ["S","R","L","M"]: ccnew.append(["TYPE", ptype])
            #else: ccnew.append(["TYPE", "A"])
            t.append(("GET PROC", "", ccnew)) 
        self.reque_items = None
        return

do_get_appl = do_get_changes
class do_get_proc(BaseHandler):

    def process_response(self, S):
        r""" do_get_proc.process_response(self, response) - handles the response of a GET PROC command from ICS/UCS 
        
            response S[-1] is a multi-part message. 
               header   = [0]   = ["GET PROC", "OK"]
               name     = [1]   = {<dpm>, <procedure name>]
               body     = [2]   
                  item  = [2][n] = ["LOGIC", "",[line1, line2, .., line_n]]
                                   ["MACRO", <macro_name>, [line1, line2, .., line_n]]
                                   ["SCREEN", "", [<key_1>, <value_1>, <key_2>, <value_2>, .., <key_n>, <value_n>]]
        """
        import os

        if len(S[-1]) < 3: pass
        else:
            dpm,proc = S[-1][1]
            fpath = self.settings["current"]["wc_root"]+'/.cache/'+self.settings['current']['wc_svn_rel']
            hash_folder = fpath 
            if 'hash_folder' in self.settings.keys():
                # if the hash_folder has been set up in the main run loop, then received files are stored in the hashfolder
                # Otherwise, they are stored in the top-level folder of <site>/.cache/<branch_path>
                # This can be useful for testing, or if we someday decide to save the changsets so we can easily revert to an earlier copy
                # in the day locally and have one commit to the main repository rather than have multiple commits during the day
                # It can also be useful if we want to switch bac to having each developer comit their own changes
                hash_folder = fpath + '/'+self.settings['hash_folder']       #APPLIST[REPOLOCN]["cache"]
            self.settings["current"]["hash_folder"] = hash_folder
            FNAME = hash_folder+'/'+dpm+" "+proc+'.magic'
            M_FNAME = fpath+'/'+dpm+" "+proc+'.magic'
            if os.path.isdir(fpath) is False:
                os.makedirs(fpath)
            if os.path.isdir(hash_folder) is False:
                os.makedirs(hash_folder)
            nprupdates = []
            for rr in S[-1][2]:
                rsp = rr
                TS = 0
                PROCTYPE = "L"
                MACRO = ""
                file_pickled = False
                if len(rsp) < 3: pass
                else:
                    change_type = rsp[0]
                    self.logger.debug(rr)
                    if rsp[0] in ['SCREEN', 'REPORT', 'PROCDATA', 'MENU']:
                        FNAME = hash_folder + '/' + dpm + " " + proc + '_' + rsp[0][0] + '.fsl'
                        M_FNAME = fpath + '/' + dpm + " " + proc + '_' + rsp[0][0] + '.fsl'
                        PROCTYPE = rsp[0]
                        #with open(FNAME+'raw', 'wb') as fa:
                        #    pickle.dump(rr[2], fa, -1)
                        rr[2] = self.convertfsl(rr[2])
                        fa = open(FNAME, 'wb')
                        pickle.dump(rr[2], fa, -1)
                        fa.close()
                        file_pickled = True
                        #self.db.log_get_proc(self.settings['current']['alias'], dpm, proc, PROCTYPE, self.settings['current']['epoch_offset'], rr[2])
                    elif len(rsp[1]) > 0 and rsp[1] != '..':
                        PROCTYPE = 'MACRO'
                        MACRO = rsp[1]
                        FNAME = hash_folder + '/' + dpm + " " + proc + '.M.' + rsp[1] + '.magic'
                        M_FNAME = fpath + '/' + dpm + " " + proc + '.M.' + rsp[1] + '.magic'
                    if file_pickled:
                        pass
                    elif rsp[0].startswith('L') or rsp[0].startswith('M'):
                        try:
                            with open(FNAME, 'w') as fa:
                                #print fpath + '/' + dpm + " " + proc
                                for l in rr[2]:
                                    if '\n' in l:
                                        fa.write(l)
                                    else:
                                        fa.write(l+'\n')
                                fa.flush()
                        except Exception as e:
                            self.logger.error("{!s} : saving {!s} as logic file {!s}\n\t {!s}".format(e, rsp[0], os.path.basename(FNAME), l))
                            with open(FNAME+'-dump', 'wb') as fa:
                                pickle.dump(S, fa, -1)
                    else:
                        self.logger.warning("Unknown section {!s} in response saved to {!s}".format(rr[:1], os.path.basename(FNAME)))
                        with open(FNAME+'-dump', 'wb') as fa:
                            pickle.dump(S, fa, -1)
                            
                    time.sleep(0.5)
                    self.logger.debug("Wrote to file: %s" % (FNAME))
                    try:
                    #"need to fix"
                        if TS == 0:
                            TS = self.db.proc_last_update(self.settings['current']['alias'], dpm, proc, PROCTYPE, self.settings['current']['epoch_offset'], macro = MACRO)
                            if isinstance(TS, int):
                                TS = TS + self.settings['current']['epoch_offset']
                            else:
                                TS = 0
                                self.logger.info("Update time not an integer for %s - %d (%s)" % ( FNAME, TS, type(TS)) )
                                
                        if TS > 1000000000:
                            os.utime(FNAME, (TS, TS))
                        else:
                            self.logger.info("Bad update time for %s - %d (%s)" % ( FNAME, TS, type(TS)) )
                    except TypeError as e:
                        self.logger.exception("Type Error %s\n %s" % (FNAME, e) )
                    except:
                        self.logger.warning( "Could not update last modified time - %s (%s %s %s %d)" % (FNAME, dpm, proc, PROCTYPE, TS) )
#                if self.is_same(FNAME, M_FNAME):
#                    os.remove(FNAME)
#                else:
#                    shutil.copy2(FNAME, M_FNAME)
                    #nprupdates.append([fpath, TS, proc, change_type, rsp[2]])
#            print nprupdates
            #updateTable(nprupdates, APP[REPOLOCN]["dbname"])
        return False

class do_put_proc(BaseHandler):

    def load_data(self, cmd, **kw):
        r""" do_get_proc.process_response(self, response) - handles the response of a GET PROC command from ICS/UCS 
        
            response S[-1] is a multi-part message. 
               header   = [0]   = ["GET PROC", "OK"]
               name     = [1]   = {<dpm>, <procedure name>]
               body     = [2]   
                  item  = [2][n] = ["LOGIC", "",[line1, line2, .., line_n]]
                                   ["MACRO", <macro_name>, [line1, line2, .., line_n]]
                                   ["SCREEN", "", [<key_1>, <value_1>, <key_2>, <value_2>, .., <key_n>, <value_n>]]
        """
        import os

        try:
            dpm, proc = [kw[k] for k in ('DPM', 'PROC') if k.upper() in kw]
            self.settings['current']['dpm'] = dpm
            self.settings['current']['proc'] = proc
        except:
            self.logger.debug("Missing dpm or proc name ")
            
            return
        

        fpath = "/".join([self.settings["current"]["wc_root"],self.settings['current']['wc_svn_rel']])
        hash_folder = fpath 
        if 'hash_folder' in self.settings.keys():
            # if the hash_folder has been set up in the main run loop, then received files are stored in the hashfolder
            # Otherwise, they are stored in the top-level folder of <site>/.cache/<branch_path>
            # This can be useful for testing, or if we someday decide to save the changsets so we can easily revert to an earlier copy
            # in the day locally and have one commit to the main repository rather than have multiple commits during the day
            # It can also be useful if we want to switch bac to having each developer comit their own changes
            hash_folder = fpath + '/'+self.settings['hash_folder']       #APPLIST[REPOLOCN]["cache"]
        self.settings["current"]["hash_folder"] = hash_folder
        if 'testing' in self.settings["current"]:
            hfolder = hash_folder
            fnames = ["/".join([hfolder,x]) for x in os.listdir(hfolder) if x.startswith(dpm+' '+proc) and os.path.isfile(hfolder+'/'+x)]
        else:
            hfolder = hash_folder +'/'+dpm
            fnames = ["/".join([hfolder,x]) for x in os.listdir(hfolder) if x.startswith(proc) and os.path.isfile(hfolder+'/'+x)]
        ffilt = {"_S.fsl":("S","IS"), "_R.fsl":("R","IR"), "_P.fsl":("P","IP")}
        payload = []
        for name in fnames:
            if '.M.' in name and name.endswith('.magic'):
                _macro=name.split('.M.')[1].split('.magic')[0]
                with open(name,'r') as fp:
                    payload.append(["MACRO",_macro,[x.strip()+'\r\n' for x in fp.readlines()]])
            elif name.endswith('.magic'):
                with open(name,'r') as fp:
                    payload.append(["LOGIC","",[x.strip()+'\r\n' for x in fp.readlines()]])
            elif name.endswith('.fsl'):
                _type = [ffilt[x] for x in ffilt if name.endswith(x)][0]
                with open(name, 'rb') as fp:
                    PL = pickle.load(fp)
                    payload.append( [_type[0],"",[map(base64.b64encode, x) for x in PL]] )
            #updateTable(nprupdates, APP[REPOLOCN]["dbname"])
        if len(payload)>0:
            cmd.append(payload)
        return


def get_from_magic(settings, t, H=HNDL, **kw):
    r""" get_from_magic(settings, testscript, handle) - routine to complete a single pass of fetching recent changes 
                                                           from the magic server 
         
         settings   - settings for current repository
         t - list of commands to run
         handle     - (optional) session handle if available
    """

#    HOST = ''
#    BUFSIZ = 8192
    ADDR = None
    NODES = []

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket.setdefaulttimeout(30)
    
    if 'current' in settings and settings['current'] is not None:
        
        repo_name = settings['current']['alias'].split('/')[0]
        repo = settings[repo_name]
        active_set = settings['current']
        ADDR = (repo['remote_ip'], int(repo['remote_port']) )
        
        #print("Connected", ADDR, repo_name, active_set['alias'])
        sock.connect(ADDR)
       
#        print tZZZ
        proclist=[]

        while len(t) > 0:
            handler = None
            item = t.pop(0)
            cmd = ""
            args = None
            if isinstance(item, tuple):
                item, handler, args = item
            if args is None:
                cmd = [x for x in active_set['cmdset'][item]]
            else:
                cmd = args
            cmdHandler = None
            if isinstance(handler, BaseHandler):
                pass
            #elif type(handler) is class:
            #    cmdHandler = handler(sock)
            else:
                mclass = 'do_' + item.strip().replace(' ', '_').lower()
                if mclass in locals(): 
                    mclass = locals()[mclass]
                elif mclass in globals(): 
                    mclass = globals()[mclass]  
                try:
                    cmdHandler = mclass(sock, settings)
                except:
                    cmdHandler = BaseHandler(sock, settings)
            try:
                _load_args = cmdHandler.load_data
                _load_args(cmd, **kw)
            except AttributeError as e:
                # no variables to load dynamically from local wcopy
                pass
            s = cmdHandler.getcmdstr(cmd, H)
            #print("SEND>", item, s.replace(cmdHandler.DELSTART, '{').replace(cmdHandler.DELEND, '}').replace(cmdHandler.DELSEP, '|'))
            cmdHandler.send(s)
            
            if cmdHandler.process_request():
            
                cmdHandler.reque(t)
            time.sleep(1)

        # close the ICS/UCS session - ICS needs to be closed to allow its bkg job to manage any logs maintained in magic
        cmdHandler = BaseHandler(sock, settings)
        s = cmdHandler.getcmdstr(active_set['cmdset']['CLOSE'], H)
        cmdHandler.send(s)
        cmdHandler.process_request()
        cmdHandler = None
            
    else: 
        pass

    sock.close()

    return

def setup_commands(cfg=CFGFILE):
    """
    templates of all known implemented ICS/UCS function, one set for each are set up in the ini file
    If the CFGFILE has been read already, the results should be [assed in as cfg.
    Otherwise, this will read the default config file again

    The m_cmds and cs_cmds will be stored in the globals m_cmdSet and cs_cmdSet
    
    """
    global m_cmdSet, cs_cmdSet

    if cfg == CFGFILE or os.path.isfile(cfg):
        try:
            from ConfigParser import SafeConfigParser
        except ImportError:
            from configparser import ConfigParser, SafeConfigParser
        c = SafeConfigParser()
        c.read(cfg)
        C = dict([(a, dict(c.items(a))) for a in c.sections()])        
    else:
        C = cfg
        
    m_cmdSet = dict([(k.upper(), eval(v)) for k, v in C['m_cmds'].items()])
    cs_cmdSet = dict([(k.upper(), eval(v)) for k, v in C['cs_cmds'].items()])

    return

def read_config(configfile=CFGFILE):
    r""" read_config([configfile]) - parses an ini file to pull in parameters identifying the location(s) of repositories to monitor
                                    and other paths in the local environment.
                                    
         The repository information in the ini file will be used as a secondary information store. If the application
         cannot find the _syncpar.db sqlite3 file in the expected path, it will create a new one and populate the base tables with the 
         informaton contained in the ini file. If the _syncpar.db file is found, the application will use the site and repository info
         from the db file instead
    """
    try:
        from ConfigParser import SafeConfigParser
    except ImportError:
        from configparser import ConfigParser, SafeConfigParser
    global LOGLEVEL, LOGSIZE, MAXLOGFILES, m_cmdSet, cs_cmdSet

    def get_repo_params(s, r_type):
        # ; name= appl.db, [segment, directory], root of working copy (for .cache folder), relative path to working copy
        labels = ('appdb', 'seg', 'dir', 'wcroot', 'br_path', 'lastcheck')
        if r_type == 'UCS':
            labels = ('appdb', 'hcis', 'ring', 'wcroot', 'br_path', 'lastcheck')
        b = [a.strip() for a in s.split(",")]
        return dict([(l, b[i]) if i < len(b) else (l, None) for i, l in enumerate(labels)])

    c = SafeConfigParser()
    c.read(configfile)
    C=dict([(a, dict(c.items(a))) for a in c.sections()])
    for k in ['LOGLEVEL', 'LOGSIZE', 'MAXLOGFILES']:
        if k.lower() in C['main'].keys():
            try:
                v = eval(C['main'][k.lower()])
            except NameError:
                v = C['main'][k.lower()]
            if v:
                globals()[k] = v
        
    m_cmdSet = dict([(k.upper(), eval(v)) for k, v in C['m_cmds'].items()])
    cs_cmdSet = dict([(k.upper(), eval(v)) for k, v in C['cs_cmds'].items()])
    return C

def select_repo(settings, r):
    # r should be a tuple of (server, app, branch)
    #import time
    try:
        x = settings[r[0]]['repos'][r[1].lower()][r[2].lower()]
        settings['current'] = dict( [(a.upper(), x[a]) for a in x] )
        settings["current"]['alias'] = '/'.join(r)
        settings['current']['cmdset'] = m_cmdSet
        
        settings['current']['epoch_offset'] = EPOCH_OFFSET - (int(settings[r[0]]["tz_offset"]) * 3600)
        if settings[r[0]]['platform'][:2] == 'CS':
            settings['current']['cmdset'] = cs_cmdSet
        try:
            db = settings["current"]["db"]
        except KeyError:
            pass
        repo = settings["current"]    
        settings["current"]["db"] = DBConnect(repo["WCROOT"], repo["BR_PATH"], repo['epoch_offset'])
        settings["current"]["base_version"] = repo['base_tag']
    except KeyError:
        settings['current'] = None
    return

def select_repo_sql(settings, r, rr):
    # r should be the alias dev_site/app/branch_id
    #import time
    global EPOCH_OFFSET
    import pdb
    
    try:
        #x = settings[r[0]]['repos'][r[1].lower()][r[2].lower()]
        #print x
        site, app, branch_id = r.split('/')
        settings['current'] = rr  #settings['current'] = dict( [(a.upper(), x[a]) for a in x] )
        settings["current"]['alias'] = r  # settings["current"]['alias'] = '/'.join(r)
        settings['current']['cmdset'] = m_cmdSet
        
        if isinstance(EPOCH_OFFSET, int):
            pass
        else:
            EPOCH_OFFSET =  int(time.mktime((1980,3,1,0,0,0,3,1,0))) # subtract this from python time in seconds to get magic time in seconds
        settings['current']['epoch_offset'] = EPOCH_OFFSET - (int(settings[site]["tz_offset"]) * 3600)
        if settings[site]['platform'][:2].lower() == 'cs':
            settings['current']['cmdset'] = cs_cmdSet
        try:
            db = settings["current"]["db"]
        except KeyError:
            pass
        settings['current']['handle']= ""
        repo = settings["current"]
        repo['platform'] = settings[site]['platform']
        repo["hash_folder"] = repo["wc_root"]+'/.cache/'+repo['wc_svn_rel']
        repo["wcopy_folder"] = repo["wc_root"]+'/'+repo['wc_svn_rel']
        if not os.path.isdir(repo["wcopy_folder"]):
            os.makedirs(repo["wcopy_folder"])        
        # Data retrieved from the magic server will be stored in the top-level folder of <site>/.cache/<branch_path>
        # If needed, we can add an additional subfolder here to keep data from different runs separate. 
        # This can be useful for testing, or if we someday decide to save the changsets so we can easily revert to a copy
        # saved earlier in the day locally and have one commit to the main repository rather than have multiple commits during the day
        # It can also be useful if we want to switch back to having each developer commit their own changes
    except KeyError:
        settings['current'] = None
    return

def update_from_config(settings, sites):
    dbo = DBConnect(dbpath=None, branch=None, offset=None)
    ex_sites = dbo.get_sites()
    ex_sites = [x[0] for x in ex_sites]
    k = ["remote_port", "remote_ip", "platform", "protocol", "tz_offset"]
    for site in sites:
        try:
            x = settings[site]
            s=""
            if site in ex_sites:
                s="UPDATE DEVSITES SET " + ", ".join([xx+"=\""+x[xx]+"\"" for xx in k]) + " WHERE dev_site = \""+site+"\" "
            else:
                s = "INSERT INTO DEVSITES VALUES( \"" +site+"\", \"Y\", "+ ", ".join(["\""+x[xx]+"\"" for xx in k]) +")"
            if s:
                dbo.set(s)
        except Exception as e:
            print( e )
    # configure repos
    ex_repos = dbo.get_repos()
    if ex_repos:
        ex_repos = [tuple(x[0:2]) for x in ex_repos]
    else:
        ex_repos = []
    k = "appl_db,server_seg,server_dir,wc_root,wc_svn_rel,earliest"
    k = [x.strip() for x in k.split(",")]
    for site in sites:
        try:
            r = settings[site]
            for app in r.keys():
                branch_dict = settings['.'+r[app]]
                for br in branch_dict:
                    pkey = ("app", "dsite", "branch_id")
                    repo = (app, site.split("/")[0], br)
                    kv = [x.strip() for x in branch_dict[br].split(",")]
                    #kv = dict([(x, kv[i]) for i, x in enumerate(k)])
                    if repo in ex_repos:
                        s="UPDATE REPOS SET " + ", ".join([xx+"=\""+kv[i]+"\"" for i, xx in enumerate(k)]) + " WHERE "+ ", ".join([xx+"=\""+repo[i]+"\"" for i, xx in enumerate(pkey)])
                    else:
                        s = "INSERT INTO REPOS ( "+", ".join(pkey) + ", active, " + ", ".join(k)
                        s = s + " ) VALUES( " +", ".join(["\""+xx+"\"" for xx in repo])+", \"Y\", "+ ", ".join(["\""+kv[i]+"\"" for i in range(len(kv))]) +")"
                    if s:
                        dbo.set(s)
        except Exception as e:
            print( e )

    return

def convert_npr_to_xml(settings, par_db, logger):
    import pdb
    #pdb.set_trace()
    dbo_repo = settings["current"]["db"]
    hfolder = settings["current"]["hash_folder"]
    #try:
    #    int(hfolder)
    #    hfolder = os.path.join(settings["current"]["wc_root"], ".cache", settings["current"]["wc_svn_rel"], hfolder)
    #except TypeError:
    #    logger.info(hfolder)
    if os.path.isdir(hfolder):
        pass
    else:
        os.makedirs(hfolder)
        self.logger.debug("Created new folder: " + hfolder)
    files_to_convert = filter(lambda x: os.path.splitext(x)[1]==".fsl", os.listdir(hfolder))
    #settings["current"]["last_check"] = dbo_par.get_last_update(settings["current"]['alias'])
    logger.info("Converting %d files in %s " % (len(files_to_convert), hfolder))
    M = Magic2Xml(settings = settings, logger = main_logger)
    for f in files_to_convert:
        F = []
        FN = os.path.join(hfolder, f)

        try:
            with open(FN, 'rb') as fa:
                F = [" = ".join(x) for x in pickle.load(fa)]
            cls, TRIM = M._deduce_class_from_name(f)
            if TRIM:
                m=len("".join(F[0].split(" = ")[0].split('\x1e')[:2]))+2
                F = [x[m:] if i>0 else x for i, x in enumerate(F)]
            FX=""
            #pdb.set_trace()
            tt=time.time()
            M.convertMagictoXml(F, cls, hfolder)
            logger.debug("  ..  %s (%6.3f secs)" % (f, time.time()-tt))
            if cls:
                if cls == 'menu':
                    expected_xml = os.path.splitext(f)[0].replace('_M',"").split('.') + ["xml"]
                    expected_xml=".".join(expected_xml[1:])
                else:
                    expected_xml = os.path.splitext(f)[0]+".xml"
                FX = os.path.join(hfolder, expected_xml)
                os.utime(FX, (os.path.getatime(FN), os.path.getmtime(FN)))
            else:
                main_logger.info("Unknown class fsl file %s" % f)
        except (TypeError, ValueError, MagicXmlError, EOFError ) as e:
            main_logger.exception("Conversion Error: %s", (hfolder, f, FX))
            settings["current"]["error"] = e.message
        # ---------- clean up code ----------------------------------------
        files_to_convert = None
        expected_xml = None
        FX = None
    tt = cls = TIME = F = hfolder = f = e = None
    return
    
def compare_cache_wcopy(settings, par_db, repo, logger):
    try:
        C = settings['cachehandler']
    except KeyError as e:
        C = settings['cachehandler'] = CacheHandler(settings['main']['autocommit'], logger)
    C.mergecache(settings["current"])
    return

def pytime_to_date(t=None, hrmin=False):
    r""" pytime_to_magic(t) - returns magic style date/time YYYYMMDDHHMM or YYYYMMDD if hrmin is False
             t = time tuple (usually from time.localtime()
    """
    t = t if t else time.localtime()
    if hrmin:
        return int('{:04d}{:02d}{:02d}{:02d}{:02d}'.format(t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min))
    else:
        return int('{:04d}{:02d}{:02d}'.format(t.tm_year, t.tm_mon, t.tm_mday))
    
def table_to_dict(names, onerow):
    return dict([(names[i], x) for i, x in enumerate(onerow)])
        
def log_setup ():
    global LOGSIZE, LOGLEVEL, MAXLOGFILES
#        filename = "svnsync.log"
    filename = os.path.join(BASEDIR, LOGFILE)
    LOGSIZE = 2 # each log file will be limited to LOGSIZE MB

    logger = logging.getLogger (__file__)
    l=LOGLEVEL
    try:
        #lnum = int(kwargs['detaillogging'].strip()) *10
        if hasattr(logging, l):
            logger.setLevel(getattr(logging,l))
        else:
            logger.setLevel (logging.WARNING)
            l = 20
        print("Logging level set to %s" % logging.getLevelName(logger.getEffectiveLevel()))
    except:
        logger.setLevel (logging.WARNING)
        print("Logging level set to WARNING")
    if filename:
        handler = logging.handlers.RotatingFileHandler (filename,
                                                        maxBytes=(LOGSIZE*(1<<20)),
                                                        backupCount=MAXLOGFILES)
    fmt = logging.Formatter ("[%(asctime)-12s] %(threadName)s %(levelname)-8s: %(message)s")
#                                 "%Y-%m-%d %H:%M:%S"
#                                 "%(levelname)-8s {%(name)s %(threadName)s}"
#                                 " %(message)s" )
    handler.setFormatter (fmt)
        
    logger.addHandler (handler)
    #self.logger = logger
    return logger

def raise_halt():
    raise MagicICSHaltError("Halt Request","Halt flag set")
    return

#@run.once
def run_forever(loops=None):
    global main_logger, HALT_FLAG
    import pdb
    cls_alert = iAlert()
    if MEMPROFILE:
        from pympler import muppy, summary
        all_objects = muppy.get_objects()
        TRACKER = True
        summary.print_(summary.summarize(all_objects))
        all_objects = None
    else:
        TRACKER = None
    YESTERDAY = 0
    pardbname = os.path.join(PARDBDIR,PARDBNAME)
    if not main_logger:
        main_logger = log_setup()
    settings = {}
    settings['main'] = read_config()['main']
    #setup_commands()
    dbo_par = DBConnect(pardbname, branch=None, offset=None, logger=main_logger)
    main_logger.info("\n\n * ====================== Starting server ================================\n * \n")
    dbo_par.clear_run_log("STARTED")
    #setup_Commands()
    #C = read_config(CFGFILE)
    should_halt = HALT_FLAG = False
    repo_names = dbo_par.get_columns("REPOS")
    snames = dbo_par.get_columns("DEVSITES")
    main_logger.debug("Column names for repos: %s" % repo_names)
    #run_date = pytime_to_date(time.localtime(0))
    sites = dbo_par.get_sites()
    sites = dict([(site[0], table_to_dict(snames, site)) for site in sites])

    for r in sites:
        settings[r] = sites[r]
    settings['main_logger'] = main_logger
    settings["pardb"] = dbo_par
    next_run_time = {}
    #do_events = {}
    
    while not should_halt:

        # First loop checks to see if a request to stop has been entered. If not
        # checks the next scheduled time and sets the flag to run if there is one that
        # should be checked now
        #
        # The "service" will always do a check when it starts up
        time_to_run = False
        do_events = {}
        now = time.time()
        #res=cls_alert.send_hbeat( ClientType='2', ClientVersion='5.66', SystemID='5499', LocalSystemTime='')
        #main_logger.debug("checking at the top of the loop")
        if dbo_par.halt_requested():
            main_logger.info("Halt request received")
            should_halt = True
        elif should_halt:
            main_logger.info("Halt flag set - ending .. ")
            break;
        elif dbo_par.check_requests(do_events):
            main_logger.info('Requests for %s:' % do_events.keys())
            time_to_run = True
        elif len(next_run_time.keys())>0:
            next_time = min([v for k, v in next_run_time.items()])
            if now > next_time:
                gc.collect() # Collecting garbage 
                
                main_logger.info("\n\n")
                main_logger.info("* ======================================================================================================= ")
                main_logger.debug("Starting next cycle now=%15.3f, next=%15.3f" % (now, next_time ))
                time_to_run = True
            else:
                #main_logger.info("Not time to run yet %d (%s) " % (int(time.time()), next_run_time))
                time.sleep(10) #sleep 10 s before checking
        else:
            time_to_run = True

        if time_to_run:
            repos = dbo_par.get_repos() # returns only active 
            repos = dict([("/".join([r[1],r[0],r[2]]), table_to_dict(repo_names, r)) for r in repos])
            
            main_logger.info(" %d Dev Sites to monitor, %d  repositories being watched \n" % (len(sites), len(repos)))
            count=0
            #should_halt = False if not pdb else True
            #run_date = pytime_to_date()
            now_struct = list(time.localtime())
            TODAY = int(pytime_to_date(time.localtime(now)))
            no_errors = ""

            o_repolist = repos.keys()
            o_repolist.sort()
            for next_repo in o_repolist:
                # looping over all repos - one repo here is one combination of dev site, appl and branch,
                #   e.g., ELK-DEV/CQM/DEV
                _errors = ""
                if should_halt:
                    main_logger.debug("Halt flag set - breaking out of main loop at the top" )
                    break
                main_logger.debug("Repo settings for %s in %s \n %s" % (next_repo, repos.keys(), repos[next_repo].keys()))
                select_repo_sql(settings, next_repo, repos[next_repo]) 
                main_logger.debug(" Checking %s (%s, %d)" % tuple([next_repo]+[settings[next_repo.split('/')[0]][x] for x in ['remote_ip', 'remote_port']]))
                repo_branch = settings["current"]["wc_svn_rel"].split('/')
                repodbname =  os.path.join(REPODBDIR, repo_branch[0], " ".join(repo_branch[1:]+[REPODBNAME]))
                #self.db = dbpath #os.path.join(os.path.dirname(dbpath), " ".join(+[branch.lower(),os.path.basename(dbpath)]))

                dbo_repo = DBConnect(repodbname, branch=settings["current"]["wc_svn_rel"], 
                                     offset=None, dev_site=next_repo.split("/")[0], logger=main_logger)
                #pdb.set_trace()
                settings["current"]['db'] = dbo_repo
                next_run = 0
                event_req = next_repo in do_events
                if next_repo in next_run_time:
                    next_run = next_run_time[next_repo]
                if int(now) > next_run or event_req:
                    main_logger.debug(" Query %s (%s, %d)" % tuple([next_repo]+[settings[next_repo.split('/')[0]][x] for x in ['remote_ip', 'remote_port']]))
                    r = next_repo
                    start_time = time.time()
                    local_tm = start_time if next_run == 0 else next_run
                    settings["current"]['db'] = dbo_repo
                    LASTCHECK = dbo_par.get_last_update(settings["current"]['alias'])
                    settings["current"]["last_check"] = LASTCHECK - int(settings["current"]["epoch_offset"])
                    main_logger.debug("Today=%d, Last check for %s - %d (EPOCH=%s)" %(TODAY, r, pytime_to_date(time.localtime(LASTCHECK)), settings["current"]["last_check"]))
                    if event_req:
                        run_cmds = ["LOGIN"] + do_events[next_repo]['cmds']
                        main_logger.info('Requests for %s: %s' % (r, run_cmds))                        
                        #event_req=True
                    elif TODAY > pytime_to_date(time.localtime(LASTCHECK)):
                        run_cmds = ["LOGIN", "GET DPMS", "GET MENU", "GET CHANGES", "GET BKUP PLAN"]
                    else:
                        run_cmds = ["LOGIN", "GET CHANGES"]

                    if len(os.listdir(settings["current"]["wcopy_folder"])) == 0 and not event_req:
                        run_cmds = ["LOGIN", "GET APPL"]
                        main_logger.warning("Queueing request to pull whole application for %s" % r )
                    try:
                        get_from_magic(settings, run_cmds) # Add commands to get DDEFS and MENUS as well
                        convert_npr_to_xml(settings, dbo_par, logger=main_logger)
                        compare_cache_wcopy(settings, dbo_par, r, logger=main_logger)
                        if event_req:
                            main_logger.info("Clearing requests for %s" % r)
                            dbo_par.clear_requests(r, do_events[r]['cmds'])
                            do_events.pop(r)
                        else:
                            dbo_par.set_last_update(settings["current"]['alias'], local_tm)
                        if "error" in settings['current']:
                            _errors = settings['current']['error']
                        #dbo_par.update_run_log(next_repo, "UPDATE", local_tm, comment=_errors)                     
                    except MagicICSHaltError as e:
                        _errors = " - ICS halt request"
                        main_logger.info(e.err_str(r))
                    except MagicICSError as e:
                        _errors = " - ICS error"
                        main_logger.critical(e.err_str (r))
                    except sqlite3.Error as e:
                        _errors = " - with database errors"
                        main_logger.error("Database error on %s - %s" % (r, e))
                    except socket.error as e:
                        _errors = " - with connection errors"
                        main_logger.error("Socket error on %s - %s" % (r, e))
                    except KeyError as e:
                        _errors = " - with config errors"
                        main_logger.exception("Key error on %s - %s" % (r, e.message))
                    except Exception as e:
                        main_logger.exception("Other Exception - %s" % e)            
                    finally:
                        dbo_repo.__del__()
                        main_logger.info("Retrieved %s in %6.1f s - %s (sleeping)" % (next_repo, time.time() - start_time, _errors))
                    if should_halt:
                        main_logger.debug("Halt flag set - after end of extract: %s" % r )
                        break # in case the halt flag was set

                    # Calculate the next time to re-extract this repo
                    reps = repos[next_repo]['pull_freq']
                    hrs = [int(round(x*(24/reps))) for x in range(reps)]
                    t = [0 for x in range(reps)]
                    just_now = int(time.time())
                    for i, a in enumerate(hrs):
                        now_struct[3] = a # set hour
                        now_struct[4] = 0 # set minutes to zero
                        x = time.mktime(now_struct)
                        if x < just_now:
                            x += 86400.0
                        t[i]=x
                    next_run_time[next_repo] = min([x for x in t if x>now])

                res=cls_alert.send_hbeat(ClientType='2', ClientVersion='5.66', SystemID='5499', LocalSystemTime='')

                DELAY = int(settings['main']['REPO_SLEEP']) if 'REPO_SLEEP' in settings['main'] else 30
                main_logger.debug("Sleeping for {} s between repos".format(DELAY))
                time.sleep(DELAY) # sleep 30 s between repos
                # finished one loop over all repositories being watched
            # -------------------   CLEAN UP -------------------------------------------------
            o_repolist = repos = hrs = t = reps = just_now = pardbname = None
            LASTCHECK = run_cmds = dbo_repo = None
            main_logger.info("Collecting garbage - (%d) unreachable objects (0)" % gc.collect())
            
            if TRACKER:
                print('\n\n', time.localtime())
                all_objects = muppy.get_objects()
                summary.print_(summary.summarize(all_objects))
                all_lists = [(muppy.get_size(x), id(x), len(x)) for x in all_objects if isinstance(x, list) and id(x) != id(all_objects)]
                all_lists.sort()
                all_lists = all_lists[::-1]
                print('\n %d lists with total size of %d' % (len(all_lists), sum([x[0] for x in all_lists])))
                for x in all_lists[:10]:
                    print(x)
                all_objects = all_lists = None
            main_logger.info("Sleeping .. ")
            #count += 1
            if loops is None:
                pass
            elif loops>0:
                loops -= 1
            else:
                should_halt = True
    #print( "halting..")
    dbo_par.clear_run_log("HALTED")
    #pdb.set_trace()
    main_logger.info("* ========= Completed =============================================== ")
    


def testpkg():
    run_forever()
    return


  
if __name__ == '__main__':
    #print(os.path.abspath('.'))
    #run_forever()
#   test_login()
    a = 1

