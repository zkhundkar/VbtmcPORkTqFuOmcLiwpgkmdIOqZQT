"""
 ORM mapper classes for svnsync project
 
 Run this module to set up an empty database with all the definitions necessary for 
 us to use this with the web app
 
 """

import sys

from sqlalchemy import Column, ForeignKey, Integer, String, Boolean, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine

Base = declarative_base()

class DevSites(Base):

    __tablename__ = 'devsites'

    dev_site = Column(String(30), primary_key = True)
    active = Column(Boolean, nullable = False)
    remote_port = Column(Integer)
    remote_ip = Column(String(20))
    platform = Column(String(6), nullable = False)
    protocol = Column(String(6), nullable = False)
    tz_offset = Column(Integer, nullable = False)


class Repos(Base):
    __tablename__ = 'repos'

    app = Column(String(6), primary_key = True)
    dsite = Column(String(30), ForeignKey("devsites.dev_site"), primary_key = True)
    branch_id = Column(String(10), primary_key = True)

    active = Column(Boolean, nullable = False)
    appl_db = Column(String(15), nullable = False)
    server_seg = Column(String(6), nullable = False)
    server_dir = Column(String(15), nullable = False)
    server_seg = Column(String(6), nullable = False)
    server_hcis = Column(String(15), nullable = False)
    server_ring = Column(String(6), nullable = False)
    wc_root = Column(String(60))
    wc_svn_rel = Column(String(60))
    earliest = Column(Integer, nullable = False)
    last_check = Column(Integer)
    pull_freq = Column(Integer)
	
    dev_site = relationship(DevSites)
    
class RunLog(Base):
    __tablename__ = 'runlog'
    ts = Column(Integer, primary_key = True)
    event = Column(String(30), nullable = False)
    event_repo = Column(String(30))
    event_req = Column(Integer)
    event_done = Column(Float)
    comment = Column(String(60))

r"""
class ApplIds(Base):
    __tablename__ = 'applids'

    id = Column(String(30), primary_key=True)
    repo_location = Column(String(80))
    last_checked = Column(Integer)
    
class NprUpdates(Base):
    __tablename__ = 'nprupdates'

    app_id = Column(String(30))
    dpm = Column(String(30))
    procedure = Column(String(60))
    last_update = Column(Integer)
    change_type = Column(String(10))
    macro = Column(String(60))
    user = Column(String(60))
    log_time = Column(Integer)
"""

# -------------- set up the empty database
engine = create_engine('sqlite:///_syncpar.db')
Base.metadata.create_all(engine)


