var sqlite3 = require('sqlite3');
var db = new sqlite3.Database('../../svnsync/syncmanager/_syncpar.db');
var check;

function REST_ROUTER(router,connection,md5) {
    var self = this;
    self.handleRoutes(router,connection,md5);
}

REST_ROUTER.prototype.handleRoutes= function(router,connection,md5) {
    router.get("/",function(req,res){
        var query = "SELECT dev_site as id, remote_ip as ip from DEVSITES";
        var table = ["user_login","user_email","user_password",req.body.email,md5(req.body.password)];
        //query = mysql.format(query,table);
        //connection.query(query,function(err,rows){
        db.all(query,function(err,rows){
            if(err) {
                res.json({"Error" : true, "Message" : "Error executing MySQL query"});
            } else {
                res.json({"Error" : false, "Message" : "success", "devsites": rows});
            }
          })
		});
    router.post("/users",function(req,res){
        var query = "SELECT dev_site as id, remote_ip as ip from DEVSITES";
        var table = ["user_login","user_email","user_password",req.body.email,md5(req.body.password)];
        //query = mysql.format(query,table);
        //connection.query(query,function(err,rows){
        db.all(query,function(err,rows){
            if(err) {
                res.json({"Error" : true, "Message" : "Error executing MySQL query"});
            } else {
                res.json({"Error" : false, "Message" : "Success", "devsites":rows});
            }
        });
    });
}

module.exports = REST_ROUTER;


/*Perform SELECT Operation
db.all("SELECT * from DEVSITES");

//Perform INSERT operation.
db.run("INSERT into table_name(col1,col2,col3) VALUES (val1,val2,val3)");

//Perform DELETE operation
db.run("DELETE * from table_name where condition");

//Perform UPDATE operation
db.run("UPDATE table_name where condition");
*/