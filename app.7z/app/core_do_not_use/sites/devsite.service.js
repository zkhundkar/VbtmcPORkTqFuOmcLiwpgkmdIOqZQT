angular.
  module('core.sites').
  factory('DevSite', ['$resource',
    function($resource) {
      return $resource('/core/sites/:phoneId.json', {}, {
        query: {
          method: 'GET',
          params: {phoneId: 'phones'},
          isArray: true
        }
      });
    }
  ]);