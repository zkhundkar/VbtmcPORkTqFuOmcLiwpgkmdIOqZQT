'use strict';


syncApp

.controller('AlertsCtrl', AlertsControl)
.config(['$routeProvider', function($routeProvider) {
	$locationProvider.hashPrefix('!');

	$routeProvider

	.when("/alerts", {templateUrl: "alerts/alerts.html"})
	//.when("/alerts", {templateUrl: "hello/hello.html"})
	/* etc… routes to other pages… */
	  
	  .otherwise({redirectTo: '/'});
	}]);

