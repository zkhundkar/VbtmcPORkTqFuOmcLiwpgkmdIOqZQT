'use strict';

angular.module('myApp.hello', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/hello', {
    templateUrl: 'hello/hello.html',
    controller: 'helloCtrl'
  });
}])

.controller('helloCtrl', ["$scope", function($scope, repo) {
        $scope.repoApp = repo.app;
        $scope.repoSite = repo.dsite;
        $scope.repoBranch = repo.branch_id;	
		$scope.value = 1;

		$scope.isBold = function () { return $scope.value % 2 == 0; };
		$scope.isItalic = function () { return $scope.value % 3 == 0; };
		$scope.isUnderlined = function () { return $scope.value % 5 == 0; };
		
}]);