'use strict';

angular.module('syncManager')

  .component('repoList', {
		templateUrl: 'repos/repo.html',
		
		controller: ['$http',
		    function RepoListCtrl($http) {
				var self = this;
				self.sort = '-app';
				self.query = 'WAYNE';
				self.pagesize=10;
				self.isactive = function(active) {
					if (active) { return 'active'} else return "inactive"};
				self.selectrow = function(repo) {
					self.sel = repo;
					if (self.sel.active) { self.sel.active="Y"};					
				};
				self.search;
				self.search_active="";
				self.setItemCount = function(pager) { 
					// filter
					var items = [];
					var _include = true;
					for (var item in self.repos) 
					{ if (self.search_active && !self.repos[item].active) {}
					  else { _include = self.search ? false : true;
							for (var ele in self.repos[item]) {
								if (_include) {break;}
								else { try {
									_include = self.repos[item][ele].includes(self.search);
									}
									catch (e) {};
								}
							};
							if (_include) { items.push(item) };
						}
					};
					self.itemcount = items.length;
					if (pager) {
						pager.setPage(1, self.itemcount, Number(self.pagesize)) } // should reset pager.pager and items list
					};
			self.clear_form = function()
            {
                self.sel = null
            };
			self.add_new = function()
            {
                self.sel = {'app':'new', 'active':1 }
            };			
			self.submit_form = function()
            {	if (self.sel) {
                $http({
                        url: "http://localhost:5000/api/devsites/" + self.sel.dev_site,
                        method: "POST",
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        data: self.sel
                    }).success(function(data, status, headers, config) {
                        self.sel = null;
                    }).error(function(data, status, headers, config) {
                        self.status = status;
                    });
				}	
            };				
			$http.get('repos/repos.json').then(function(response) {
					self.repos = response.data;
					self.itemcount = self.repos.length
					});
			}]
		
  });

  