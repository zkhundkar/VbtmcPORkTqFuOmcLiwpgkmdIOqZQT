'use strict';

angular.module('syncManager')

  .component('devsitesList', {
		templateUrl: 'sites/devsite.html',		
		
		controller: function DevsiteListCtrl($http) {
			self = this;
			self.ip = 'remote_ip';
			self.devsiteIp = 'John';
			self.setSelection = function (repo) {
					self.sel = repo;
				};
			self.clear_form = function()
            {
                self.sel = null
            };
			self.submit_form = function()
            {	if (self.sel) {
                $http({
                        url: "http://localhost:5000/api/devsites/" + self.sel.dev_site,
                        method: "POST",
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        data: self.sel
                    }).success(function(data, status, headers, config) {
                        self.sel = null;
                    }).error(function(data, status, headers, config) {
                        self.status = status;
                    });
				}	
            };
			$http.get('sites/devsite.json').then(function(response) {
			self.sites = response.data 
		})}
  });
  
function DevsiteDetail($routeParams) {
	if ($routeParams) {	
		self = this;
		self.ip = 'remote_ip';
	};
};
  
