'use strict';
//var Set = require("collections/set");

angular.module('syncManager')

  .component('appSelect', {
		templateUrl: 'appls/magicapps.html',		
		
		controller: function AppSelectCtrl($http) {
			self = this;
			self.appsort = 'app';
			self.subpage;
			self.selectApp;
			self.selectRepo;
			self.applUpdates;
			self.run_filter = function() {
				if (self.subpage != 'Datadefs') {
					return};
				var filter=true;
				for (var item in self.applUpdates) {
					_filter = self.active_ddefs && (self.applUpdates[item].dpm_active==0) ? false : true;
					_filter = self.pull_defs && (self.applUpdates[item].pull_defs==0) ? false : _filter;

					self.applUpdates[item].include = _filter;
				};
			};
			self.get_more = function(page)
            {
                if (self.selectApp &&self.selectRepo && (self.selectRepo.toLowerCase().startsWith(self.selectApp))) 
				{
                self.subpage = page;
                $http({
                        url: "http://localhost:5000/api/apps/" + page.toLowerCase() + "/" + self.selectRepo,
                        method: "GET",
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        data: self.selectRepo
                    }).success(function(data, status, headers, config) {
                        self.applUpdates = data;
						for (var item in self.applUpdates) {
							self.applUpdates[item].include=1};
                    }).error(function(data, status, headers, config) {
                        self.status = status;
                    });					
				}
				
            };
			self.isActive = function(page)
            {
                if (self.sel && (self.subpage==page)) {return "active"}
            };			
			
			self.clear_form = function()
            {
                self.sel = null
            };
			self.submit_form = function()
            {	if (self.sel) {
                $http({
                        url: "http://localhost:5000/api/devsites/" + self.sel.dev_site,
                        method: "POST",
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        data: self.sel
                    }).success(function(data, status, headers, config) {
                        self.sel = null;
                    }).error(function(data, status, headers, config) {
                        self.status = status;
                    });
				}	
            };			
			$http.get("http://localhost:5000/api/apps/all").then(function(response) {
			self.applist = response.data;
			var s = new Set();
			var i=0;
			for (i = 0; i < self.applist.length; i++) 
			{
				s.add(self.applist[i].app);
			};
			self.apps = Array.from(s)
			})}
		
  })
  .filter('ddefactive', ['input', 'param1', function(input, param1) {
	  function ddefactiveFilter(input, param1) {
		  if (param1) {return input.include==1;};
		  return input.include == 1;
	  }
	  return ddefactiveFilter;
  }]);