#!/usr/bin/env python

from setuptools import setup

setup(
    name='iscanserver',
    version='2.0.19',
    description='Iatriscan Import Service',
    author='Z Khundkar',
    author_email='lkhundkar@yahoo.com',
    # url='http://wiki.secondlife.com/wiki/Eventlet',
    packages=['iscanserver'],
      long_description="""\
      iscanserver is a custom Windows service/applcation for importing files into Iatriscan ...
      """,
	  
      classifiers=[
          "License :: Proprietary",
          "Programming Language :: Python",
          "Development Status :: 4 - Beta",
          "Intended Audience :: Developers",
          "Topic :: Internet",
      ],
      keywords='networking eventlet nonblocking internet',
      license='Commercial',
      install_requires=[
        'setuptools',
      ],
	  
	  data_files = [('.', ['iatric.ico',
	                          'scansvr.ini', 'ScanServer Report.txt', 'test.bat'])
					   ]
      )

