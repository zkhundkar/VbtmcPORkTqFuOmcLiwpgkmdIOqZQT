# -*- coding: cp1252 -*-
__vb_code__= '2.0.19'

__doc__ = r"""               **************************************************************************
			Module      : iscanserver
			Author      : Lutfur Khundkar
			Purpose     : Multi-threaded server for proprietary image/document storage and retrieval system
            Copyright   : 			Exposes iAlert calls to other modules
				To use iAlert, the following steps must be completed
               1. Call this module's initiAlert sub to create the iAlert
                  COM object.
               2. Call this module's ActivateiAlert function to instruct the
                  com object to connect to the server
               3. Send heartbeats or alerts using this module's
                  'SendHeartbeat' or 'SendAlert' functions.
               4. When finished, use the 'DestroyiAlert' sub to shutdown
                  and prevent memory leaks.
			************************************************************************** """

import BaseHTTPServer, select, socket, SocketServer, urlparse
import logging
import logging.handlers
import getopt
import sys
import os
import signal
import threading, Queue
#from types import FrameType, CodeType
import time
import ftplib
import zlib
import traceback
import ctypes
import ctypes.wintypes

from Tkinter import *
import ttk
import tkMessageBox

import mmap
WIN32_FIND_DATA = ctypes.wintypes.WIN32_FIND_DATAW

__version__ = '2.0.19'


def convertIIFtoTif(pFilename):

    fa=open(pFilename,'rb')
    # read first 12 bytes
    f12=fa.read(12)
    if f12[6:].startswith("II*"):  # IIF style tiff
        fa.write(f12[6:]+f12[:6])
    else:
        fa.write(f12)  #normal tiff format
    f12=None
    return

class IatScanRequestHandler(SocketServer.StreamRequestHandler):

    responses = {
        100: ('Continue', 'Request received, please continue'),
        101: ('Switching Protocols',
              'Switching to new protocol; obey Upgrade header'),

        200: ('OK', 'Request fulfilled, document follows'),
        201: ('Created', 'Document created, URL follows'),
        202: ('Accepted',
              'Request accepted, processing continues off-line'),
        203: ('Non-Authoritative Information', 'Request fulfilled from cache'),
        204: ('No Content', 'Request fulfilled, nothing follows'),
        205: ('Reset Content', 'Clear input form for further input.'),
        206: ('Partial Content', 'Partial content follows.'),

        400: ('ERROR|UNKNOWN ERROR',
              'Bad request syntax or unsupported method'),
        401: ('Unauthorized',
              'No permission -- see authorization schemes'),
        402: ("ERROR|FILE NOT FOUND"),
        33:  ("ERROR: CORRUPT FILE - FILE NOT SAVED"),
        476: ("ERROR|DELETE FAILED OR NOT PERMITTED"),

        }
    

#    def __init__(self, request, client_addr, server, logger=None):
#        SocketServer.StreamRequestHandler.__init__(self, request, client_addr, server)
    def setLogger(self, logger=None):
        self.logger=logger
        if self.logger: pass
        elif self.server.logger:
            self.logger=self.server.logger
        self.logger.info( "%s","Handling connection .. IatScanRequestHander constructor")
        self.message_end_delim=chr(0)
        return
    
    def parse_request(self, rbuf):
#        print "%s" % ("Read "+rbuf)
#        self.logger( "%s" , ("Read "+rbuf))
        
        if len(rbuf)>0:
            self.raw_requestline = self.raw_requestline + rbuf
            if self.message_end_delim in rbuf:
                return self.raw_requestline.split(self.message_end_delim)[0]
            elif len(self.raw_requestline)>1024:
                raise IOError
            else: return False
        else:
            raise socket.error
            
        return False

    def handle_one_request(self):
        try:
            self.close_connection = 0
            self.raw_requestline = ""
            self.streamdata=""
            done=False
            CIP=self.client_address[0]
            while not done:
                done=self.parse_request(self.request.recv(1024))
            self.logger.debug("(%s) IN>  STATUS=%s RAW: %s",CIP, bool(done), self.raw_requestline[:1024])
            if done:
#               len(self.raw_requestline) > 65536:
                self.requestline = done
                self.request_version = ''
                self.command = done.split(' ')[0]
                self.logger.info("(%s) IN>  %s",CIP,self.requestline)
                x=self.raw_requestline
                self.streamdata=x[x.index(self.message_end_delim)+1:]
                self.raw_requestline
                    
            if not self.raw_requestline and not self.command:
                self.close_connection = 1
                print "No request received in first 1024 bytes"
                print self.command,'.'+self.raw_requestline+'.'
                self.logger.errors("(%s) SVR> %s No request received after connect",CIP,self.raw_requestline)
                return
            # process admin commands
            if self.command in ('SHUTDOWN','SETDEBUGON','NODEBUG','VERSION','STATS'):
                self.close_connection=1
                self.logger.critical("%s","(%s) ADMIN> %s received" % (CIP,self.command))
                if CIP == '127.0.0.1' or CIP == self.server.server_address[0]:
                    pass
                else:
                    #print "ERROR|COMMAND REMOTE INVOCATION", self.command
                    #print "request",self.command,'received from remote:',CIP #,"(server=",self.server.server_address[0],')'
                    self.logger.critical("(%s) ADMIN> %s received from remote",CIP,self.command)
                    self.send_ok("ERROR|COMMAND INVOKED FROM REMOTE")
                    return
                #print "ready to handle commnd"
                #print "client=",CIP,'.'+self.command+"."
                if self.command=="SHUTDOWN":
                    self.send_ok("OK|SHUTDOWN")
                    self.server._stop_()
                elif self.command=="SETDEBUGON":
                    self.send_ok("OK|SETDEBUGON")
                    self.server._setdebug("ON")
                elif self.command=="NODEBUG":
                    self.send_ok("OK|NODEBUG")
                    self.server._setdebug("OFF")
                elif self.command=="VERSION":
                    print "OK|"+__version__
                    self.send_ok("OK|"+__version__)
                elif self.command=="STATS":
                    self.logger.debug("Found command %s",self.command)
                    rsp="OK|THREAD COUNT="+str(threading.activeCount()-1)
                    try:
                        rsp="%s; TXNS=%d of %d" % (rsp,
                                                   IatScanServer.request_count,
                                                   IatScanServer.request_complete)
                    except:
                        self.logger.debug("%s","Error getting txn counts")
                    #print rsp                    
                    self.send_ok(rsp)
                return
                
            self.logger.debug("SVR> Handling command %s",self.command)
            mclass = 'do' + self.command.strip()
            if mclass in locals(): mclass = locals()[mclass]
            elif mclass in globals(): mclass = globals()[mclass]
            else:
                self.send_error(501, "ERROR|UNKNOWN COMMAND (%s)" % self.command)
                return
            self.logger.debug("SVR> Found %s handler class",self.command)
            try:
                mclass(self)
            except:
                self.logger.error("%s", "\n\t".join([str(x) for x in sys.exc_info()]))

                self.send_error("ERROR|On Server")
            self.wfile.flush() #actually send the response if not already done.
            mclass=None # mark for gc
        except socket.timeout, e:
            #a read or a write timed out.  Discard this connection
            self.log_error("SVR> Request timed out: %s", self.raw_requestline)
            self.close_connection = 1
            return
        except socket.error, e:
            #a read or a write timed out.  Discard this connection
            self.logger.debug("SVR> Request connection was closed: %s", CIP)
            self.close_connection = 1
            return
        except IOError, e:
            #a read or a write timed out.  Discard this connection
			if len(self.raw_requestline)>0: 
				self.log_warning("(%s) SVR> IO Error: (no message end delimiter in first 1024 bytes) %s", CIP,self.raw_requestline)
            else: 
				self.logger.debug("SVR> Request connection closed by peer [%s]", CIP)
			self.close_connection = 1
            return
        except :
            #a read or a write timed out.  Discard this connection
            self.logger.exception("SVR> Exception")
            self.close_connection = 1
            return

        return
    def handle(self):
        """Handle multiple requests if necessary."""
        self.close_connection = 0
        #print "IatScanRQH: handle()"
        self.setLogger()
        while not self.close_connection:
            self.handle_one_request()
                

    def send_error(self, code, message=None):
        """Send and log an error reply.

        Arguments are the error code, and a detailed message.
        The detailed message defaults to the short entry matching the
        response code.

        This sends an error response (so it must be called before any
        output has been generated), logs the error, and finally sends
        a piece of HTML explaining the error to the user.

        """

        try:
            short, long = self.responses[code]
        except KeyError:
            short, long = '???', '???'
        if message is None:
            message = short
        explain = long
        if message.startswith('ERROR'): pass
        else: message="ERROR|"+message
        message=message+self.message_end_delim
        self.log_error("OUT> %s", message)
        
        
        # using _quote_html to prevent Cross Site Scripting attacks (see bug #1100201)
        #content = (self.error_message_format %
        #           {'code': code, 'message': _quote_html(message), 'explain': explain})
        self.send_response(message,False)
        return

    error_message_format = "ERROR|UNKNOWN ERROR"
#    error_content_type = DEFAULT_ERROR_CONTENT_TYPE

    def send_ok(self, message="OK|"):
        """Send and log an ok reply.

        """
        
        if message.startswith('OK'): pass
        else: message="OK|"+message

        message=message+self.message_end_delim
        try:
            self.logger.debug("(send_ok) %s",message)
        except:
            pass
        self.send_response(message)
        

    def send_response(self, message='ERROR|UNKNOWN ERROR',log=True):
        """Send the response header and log the response code.

        Also send two standard headers with the server software
        version and the current date.

        """
        if log: self.log_response("(%s) OUT> %s" ,self.client_address[0],  message)
#        print "SENT>", message
        self.wfile.write(message)
            # print (self.protocol_version, code, message)


    def log_request(self):
        """Log an accepted request.

        This is called by send_response().

        """
        self.messagetype="info"
        self.log_message('(%s) OUT> %s' , self.client_address[0],self.requestline)

    def log_response(self, fmt, *args):
        """Log a response (for debugging)

        Arguments are the same as for log_message().

        """
        self.messagetype="info"
        self.log_message(fmt % args)

    def log_error(self, fmt, *args):
        """Log an error.

        This is called when a request cannot be fulfilled.  By
        default it passes the message on to log_message().

        Arguments are the same as for log_message().

        XXX This should go to the separate error log.

        """
        self.messagetype="error"
        self.log_message(fmt % args)

    def log_message(self, msg):
        """Log an arbitrary message.

        This is used by all other logging functions.  Override
        it if you have specific logging wishes.

        The first argument, FORMAT, is a format string for the
        message to be logged.  If the format string contains
        any % escapes requiring parameters, they should be
        specified as subsequent arguments (it's just like
        printf!).

        The client ip address and current date/time are prefixed to every
        message.

        """

        if self.logger:
            loglevel=10
            try:
                loglevel=getattr(self.logger,self.messagetype)
                loglevel(msg)
            except:
                self.logger.info(msg)
#            self.logger.log(loglevel, msg)
        else:
            sys.stderr.write("%s - - [%s] %s\n" % (self.client_address[0], self.log_date_time_string(), format%args))
        return

class IatScanCmd:
#class IatScanRequestHandler2(SocketServer.StreamRequestHandler):

    # The Python system version, truncated to its first component.
    sys_version = "Python/" + sys.version.split()[0]

    # The server software version.  You may want to override this.
    # The format is multiple whitespace-separated strings,
    # where each string is of the form name[/version].
    server_version = "IatScanSvr/" + __version__

    tmpFile=""

    known_responses=["OK|FILE MOVED", "OK|FILE COPIED", "OK|FILE DELETED",
                     "OK|NOT EXISTS", "OK|EXISTS", "OK|BAD DIR", "OK|BAD CALL",
                     "OK-LOCKED\t"+tmpFile, "OK\tSTREAM"+tmpFile,
                     "OK\t"+tmpFile]

    # The default request version.  This only affects responses up until
    # the point where the request line is parsed, so it mainly decides what
    # the client gets back when sending a malformed request line.
    # Most web servers default to HTTP 0.9, i.e. don't send a status line.
    default_request_version = "IatScan/0.9"

    message_end_delim = chr(0)

    def __init__(self, reqhandler):
        self.request=reqhandler
        self.path=None
        self.target=None
        self.command=None
        self.filesize=None
        self.working=None
        self.server=reqhandler.server
		self.lockHandler = reqhandler.server.lockHandler
        if self.getargs():
            self.processCommand()
            self.cleanup()

    def processCommand(self):
        self.request.send_ok("OK|ECHO %s NOT IMPLEMENTED" % self.command)
        return
        

    def parse_quoted_strings(self,s):
        r=""
        quoted=False
        for i in range(len(s)):
            a=s[i]
            if a == " ":
                if not quoted: a=chr(255)
            elif a == '\"':
                quoted = not quoted
            r=r+a
        return r.split(chr(255))


    def getargs(self):
        """Parse a request (internal).

        The request should be stored in self.raw_requestline; the results
        are in self.command, self.path, self.request_version and
        self.headers.

        Return True for success, False for failure; on failure, an
        error is sent back.

        """
        
        self.command = None  # set in case of error on the first line
        self.request_version = version = self.default_request_version
        requestline = self.request.raw_requestline
        OPEN_STREAM = False
        words=[]
        EOM=self.request.message_end_delim
        if EOM in requestline:
            requestline=requestline.split(EOM)[0]
        if '\"' in requestline:
            words=self.parse_quoted_strings(requestline)
        else:
            words=requestline.split(" ")
            
        self.requestline = requestline
        command = None
        path = None
        target = None
        filesize = None
        workdir = None
        if len(words) > 1:
            command = words[0].strip(" ")
            path = words[1].strip(" ")
            try:
                target=words[2].strip(" ")
                workdir=words[3].strip(" ")
                try:
                    filesize = int(workdir)
                    workdir=self.server.working
                except TypeError:
                    pass
            except:
                pass
        elif len(words) < 2:
            command = words[0].strip(" ")
            self.request.send_error(400,"ERROR|MISSING ARGUMENT(S)")
            return False
        elif not words:
            self.request.send_error(400,"ERROR|INVALID ARGUMENT(S)")
            return False
        else:
            self.send_error(400, "Bad request syntax (%s)" % requestline)
            return False
        self.words=words
        try:
            if path.startswith('\"'):
                path=path[1:-1]        
            if target.startswith('\"'):
                target=target[1:-1]
            if workdir.startswith('\"'):
                workdir=workdir[1:-1]
            if workdir[-1]=='\\':
                workdir=workdir[:-1]
        except: pass
        
            
        self.command, self.path, self.target, self.filesize, self.working = (command, path, target, filesize, workdir)
        

        # Examine the headers and look for a Connection directive
        return True

    def cleanup(self):
        """ Cleanup routine - override in any implemented class as necessary """
        pass
    
    def validatePFN(self,path):
        import os.path
        if os.path.isfile(path) or os.path.isdir(path):
            return 2
        elif os.path.isdir(os.path.dirname(path)):
            return 1
        else:
            return 0

    def translatePath(self,path):

        try:
            if path.startswith("\""):
                return path[1:-1]
        except: pass
        
        return path

    def check_locks(self):

        isLocked=""
        try:

            shouldLock = self.check_lock
            if shouldLock:
                isLocked = "LOCKED"
                isLocked = self.LockHandler.lock(self.path)
        except:
            pass
        return isLocked

    def release_lock(self):
        try:
            shouldLock = self.check_lock
            if shouldLock:
                self.LockHandler.release(self.path)
        except:
            pass
        return
    
    def filecopy(self,s,d,rename=False,makepath=True, overwrite=False):
        import shutil, os, os.path
        try:
            if os.path.isfile(d):
                if overwrite:
                    os.remove(d)
                else:
                    return False
            elif not(os.path.isdir(os.path.dirname(d))) and makepath:
                os.mkdirs(os.path.dirname(d))
            if rename:
                os.rename(s,d)
            else:
                shutil.copyfile(s,d)
            return True
        except:
            return False
    
    def filedelete(self,s):
        import os, os.path
        try:
            if os.path.isfile(s):
                os.remove(s)              
        except:
            pass
        return not os.path.isfile(s)

class doGET(IatScanCmd):
    """ Implements GET, GET-LOCK, WEBGET and WEBGET-LOCK commands
        Only the GET function has been implemented so far"""

    def processCommand(self):
        fpn = self.translatePath(self.path)
        t=None
        try:
            t = self.translatePath(self.target)
            if t[-1] == '\\':
                t= t[:-1]
            self.starget=self.target.strip()
        except :
            pass
        tempfile = ""
        tempfileName=""
		isLocked = ""
		stdtif=False
        if not self.validatePFN(fpn):
            # not exists
            self.request.send_error(400, "ERROR|INVALID SOURCE FILE NAME (%s)" % self.path)
            return
        elif self.target is None:
            # Invalid option - scanwork folder or STREAM not specified
            self.request.send_error(403,"ERROR: BAD WORKING PATH")
            return
        else:
            #standard - write file out to scanwork folder
            #SocketTracking(Val(lblConnectionNum.Caption)).SocketFile = pa(3)
            stdtif=sefl.command.startswith("WEBGET") or fpn.split('.')[-1].upper()=="IIF"
            self.request.logger.debug("%s", str((fpn, self.target)))
            if self.target == "STREAM":
                wdir=self.server.working
                self.request.logger.debug("%s", str((fpn, self.target, wdir)))
                if len(wdir):
                    tempfile = self.server.generateOID(wdir)
                    self.request.logger.debug("%s", str((wdir,tempfile)))
                    #should this include the extension?
                    tempfileName=tempfile.split("\\")[-1]
                
            elif os.path.isdir(t): # target path is a valid directory
                tempfile = self.server.generateOID(t)
                #should this include the extension?
                tempfileName=tempfile.split("\\")[-1]

            else:
                self.request.send_error(404,"ERROR: BAD TARGET PATH "+t)
                return
            isLocked = ""
            if self.check_locks() == "LOCKED" :
			# check_locks will set a lock if possible for the GET-LOCK command
				isLocked="-LOCKED"
                #self.request.send_ok("OK-LOCKED\t"+tempfileName)
                #return
            if self.target=="STREAM":
                # apparently when a file is streamed, it is converted into tiff before streaming
                # file should be locked at this point so we can send the correct one
                filelen = os.path.getsize(fpn)
                self.request.send_ok("OK"+isLocked+"\t"+str(filelen))
                fa=open(fpn,'rb')
                # Maybe convert to standard tif header
                stdTif=False
                if fpn.split('.')[-1].upper() == 'IIF':
                    stdTif = True

				if stdtif:
                    f12=fa.read(12)
                    if f12[6:].startswith("*II"):
                        self.request.wfile.write(f12[6:]+f12[:6])
                    else:
                        self.request.wfile.write(f12)
                    f12=None
                else: pass
                #self.send_response(200,fa.read(),"")
                self.request.wfile.write(fa.read())
                self.request.wfile.flush()
                self.request.close_connection = 1
                self.request.send_ok("\x00OK\t\x00\x00")
                fa.close()
                return
            #print "GET",fpn,tempfile
            self.filecopy(fpn, tempfile)
            #ReturnToLibrary = tempfile
            if not self.validatePFN(tempfile):
                self.request.send_error(405,"ERROR:COULD NOT CREATE TARGET tempfile "+tempfile)
                self.release_lock()
                return
            else:
                self.request.send_ok("OK"+isLocked+"\t"+tempfileName)

        return
        
class doWEBGET(IatScanCmd):
    def processCommand(self):
        s= self.translatePath(self.path)
        if not self.validatePFN(s) == 2:
             self.send_error(400,"ERROR| FILE NOT FOUND")
             return
        elif self.target is None:
            # Invalid option - scanwork folder or STREAM not specified
            self.send_error(403,"ERROR: BAD WORKING PATH")
            return
        else:
            self.target=self.translatePath(self.target)
            #standard - write file out to scanwork folder
            #SocketTracking(Val(lblConnectionNum.Caption)).SocketFile = pa(3)
            tempfile = self.server.generateOID(self.target)
            #should this include the extension?
            tempfileName=tempfile.split("\\")[-1]
        return

        """
            241         If pa$(3) = "STREAM" Then
            'Get a new filename and store a copy of the origianl there.
            'tempfile$ = FileSerial(pa(2), TempFileNameOnly)
            244             TempFile$ = FileSerial("\\" & ComputerName & "\SCANWORK\", TempFileNameOnly)
            245             If ValidatePFN(TempFile) = 2 Then Kill TempFile
            246             FileCopy pa(2), TempFile
            'Convert file if necessary
            248             If UCase(Right(pa$(2), InStr(StrReverse(pa$(2)), ".") - 1)) = UCase("iif") Then
            249                 ConvertIIFtoTif TempFile
                            End If
            'Stream file to Magic
            252             ffNum = FreeFile
            253             Open TempFile For Binary Access Read As #ffNum
            254             junk$ = "OK" & Chr(9) & CStr(LOF(ffNum)) & Chr(0)
            255             TCP1Send junk$
            256             DoEvents
            257             Tcp1.Send Input(LOF(ffNum), #ffNum)
            258             Close #ffNum
            259             If pa$(1) = "WEBGET-LOCK" Then
            260                 If FileIsLocked(pa$(3)) Then
            261                     TCP1Send "OK-LOCKED" & Chr(9) & TempFileNameOnly & Chr(0)
            262                 Else
            263                     SocketTracking(Val(lblConnectionNum.Caption)).Locked = True
            264                     TCP1Send "OK" & Chr(9) & "STREAM" & Chr(0)
                                End If
            266             Else
            267                 SocketTracking(Val(lblConnectionNum.Caption)).Locked = False
            268                 TCP1Send "OK" & Chr(9) & TempFileNameOnly & Chr(0)
                            End If

            'Delete tempfile
            272             Kill TempFile

            274             Exit Sub

            275         Else
            276             i% = ValidatePFN(pa(3))
                            Select Case i%
                                Case 2
            279                     Kill pa(3)
                                Case 0
            281                     SeparatePathAndFileName pa(3), PathPart, FileNamePart
            282                     If MakePath(PathPart) = False Then
            283                         TCP1Send "ERROR| INVALID TARGET PATH" & Chr(0)
            284                         Log Tcp1.RemoteAddress & " PUT Command failed. Invalid Target Path - " & pa(2)
            285                         Exit Sub
                                    End If
                            End Select
            #'------------------

            #'Get image file name
            299             pa$(3) = TranslatePath(pa$(3))
            300             If pa(3) = "" Then
            301                 TCP1Send "ERROR| BAD WORKING PATH" & Chr(0)
            302                 Log Tcp1.RemoteAddress & " WEBGET Command failed.  Bad working path specified."
            303                 Exit Sub
                            End If
            305             SocketTracking(Val(lblConnectionNum.Caption)).SocketFile = pa(4)
            'get a new filename nd store a copy of the origianl there.
            307             TempFile$ = FileSerial(pa$(3), TempFileNameOnly)
            308             If ValidatePFN(TempFile) = 2 Then Kill TempFile
            309             FileCopy pa(2), TempFile
            310             ReturnToLibrary = TempFile
            311             If ValidatePFN(TempFile) <> 2 Then
            312                 TCP1Send "ERROR|COPY FILE ERROR" & Chr(0)
            313                 Log Tcp1.RemoteAddress & " WEBGET Command failed. Could not copy file " & pa(2) & " to " & TempFile
                            End If

            'Convert file if necessary
            317             If UCase(Right(pa$(2), InStr(StrReverse(pa$(2)), ".") - 1)) = UCase("iif") Then
            318                 ConvertIIFtoTif TempFile
                            End If

            321             If pa$(1) = "WEBGET-LOCK" Then
            322                 If FileIsLocked(pa$(4)) Then
            323                     TCP1Send "OK-LOCKED" & Chr(9) & TempFileNameOnly & Chr(0)
            324                 Else
            325                     SocketTracking(Val(lblConnectionNum.Caption)).Locked = True
            326                     TCP1Send "OK" & Chr(9) & TempFileNameOnly & Chr(0)
                                End If
            328             Else
            329                 SocketTracking(Val(lblConnectionNum.Caption)).Locked = False
            330                 TCP1Send "OK" & Chr(9) & TempFileNameOnly & Chr(0)
                            End If

            333             Debug.Print "Saved " & pa$(3)
            'Kill "\\Iatricdev\scanwork\convert.tif"
            335             Exit Sub
                        End If
                    """

class doPUT(IatScanCmd):
    """ Handler for PUT command
        Expected format of command/args
        PUT <srcfile> <tgtfile>chr(0) -> <srcfile> should exist in a reachable folder,
                                        typically the working directory
            In case of a failure, should the server delete the src file or does the client do the cleanup

        PUT STREAM <tgtfile> <size>chr(0)<bytestream>
            S
    """
    def processCommand(self):
        if not self.target:
            self.request.send_error(400,"ERROR: TARGET PATH NOT FOUND")
            return
        wdir=self.working
        if self.path=="STREAM":
            try:
                if self.filesize>99999999:
                    self.request.send_error(400,"ERROR|SIZE OF STREAMED FILE EXCEEDS 100MB")
                    return
            except TypeError:
                self.request.send_error(400,"Invalid size of bytestream in PUT STREAM ("+str(self.filesize)+")")
                return
            tmpfile=self.server.generateoid(wdir)
            s=os.path.join(wdir,tmpfile)
            bytes_recv=nbytes=len(self.datastream)
            fa=open(s,'wb')
            if nbytes>0:
                fa.write(self.datastream)
            # this will block until self.filesize bytes have been read from the socket
            # we may need to set up a "time out" for this
            # If there weren't enough bytes read, do we just trash what was received?
            fa.write(self.request.rfile.read(self.filesize-nbytes))
            fa.flush()
            fa.close()
        s= self.translatePath(self.path)
        if not self.validatePFN(s) == 2:
            self.request.send_error(400,"ERROR| SOURCE FILE NOT FOUND")
            return
        elif os.path.getsize(s)<128:
            self.request.send_error(400,"ERROR| SOURCE FILE < 100 bytes (may be corrupt)")
            return
            
        t=self.translatePath(self.target)
        t_status=self.validatePFN(t)
        if t_status == 1:
            # Normal - target file doesn't exist, but path does
            self.filecopy(s,t,"True")
        elif t_status == 2:
            # Delete existing target file
            self.filedelete(t)
            self.filecopy(s,t,"True")
        elif t_status == 0:
            try:
                os.makedirs(os.path.dirname(t))
                self.filecopy(s,t,"True")
                
            except:
                # could not create target directory
                self.request.send_error(400,"ERROR: TARGET PATH ("+str(t)+") COULD NOT BE CREATED" )
                # may be delete source file if it is in the working directory
                return
        else:
            self.request.send_error(400,"ERROR| UNKNOWN CONDITION (%d %s)" % (t_status,t))
            return
        #verify that the file was correctly copied over    
        if self.validatePFN(t) == 2:
            self.request.send_ok("OK")
        else:
            self.request.send_error(400,"ERROR|COULD NOT VERIFY PUT")
        return
            
    def cleanup(self):
        """ TO DO - clean up source file in working directory """
        return
            
class doFILECOPY(IatScanCmd):
    def processCommand(self):
        src = self.translatePath(self.path)
        tgt = self.translatePath(self.target)
        if len(src)==0:
            self.request.send_error(400, "ERROR|SOURCE FILE PARAMETER MISSING")
            return
            
        if len(tgt)==0:
            self.request.send_error(400,"ERROR|TARGET FILE PARAMETER MISSING")
            return
            
        if self.validatePFN(src) == 2:
            if self.command == "FILEMOVE" :
                if self.filecopy(src,tgt,True):
                    self.request.send_ok("OK|FILE MOVED")
                else:
                    self.request.send_error(405,"ERROR|FILE COULD NOT BE RENAMED")
            elif self.filecopy(src,tgt):
                self.request.send_ok("OK|FILE COPIED" )
            else:
                self.request.send_error(405,"ERROR|FILE COULD NOT BE COPIED")
                
        else:
            self.request.send_error(400,"ERROR|SOURCE DOESN'T EXIST")
        return

doFILEMOVE = doFILECOPY
doGET-LOCK = doGET
doWEBGET-LOCK = doWEBGET
doPUT-LOCK = doPUT

class doFILEDELETE(IatScanCmd):
    def processCommand(self):
        src=self.translatePath(self.path)
        
        if self.validatePFN(src) == 2:
            if self.filedelete(src):
                self.request.send_ok("OK|FILE DELETED")
            else:
                self.request.send_error(400,"ERROR|DELETE FAILED OR NOT PERMITTED")
        else:
            self.request.send_error(400,"ERROR|FILE NOT FOUND")
        return

        """
        ProcessError:
        '480 TCP1Send "ERROR: UNKOWN ERROR" & Chr(0)
        'V2.14 Send back error message
        480 TCP1Send "ERROR: On Server" & Chr(0)
        Log "ERROR: On Server - " & Err.Number & " " & Err.Description
        481 Log Tcp1.RemoteAddress & " UNKNOWN ERROR while processing - " & Cmd$, 1
        482 Log "    ADDITIONAL INFO PA(1)=" & pa(1) & " PA(2)=" & pa(2) & " PA(3)=" & pa(3), 1
        483 Exit Sub

                """

class doFILEVERIFY(IatScanCmd):
    def processCommand(self):
        src=self.translatePath(self.path)
        r=["BAD DIR","NOT EXISTS","EXISTS","BAD CALL"]
        try:
            r=r[self.validatePFN(src)]
        except:
            r="BAD CALL"
        self.request.send_ok("OK|%s" % r)
        
        vb_code = """
                Case "FILEVERIFY"
                    Select Case ValidatePFN(pa(2))
                        Case 1
        163                 TCP1Send "OK|NOT EXISTS" & Chr(0)
                        Case 2
        165                 TCP1Send "OK|EXISTS" & Chr(0)
                        Case 0
        167                 TCP1Send "OK|BAD DIR" & Chr(0)
                        Case -1
        169                 TCP1Send "OK|BAD CALL" & Chr(0)
                    End Select
        171         Exit Sub
        """
        return

class doRETURN(IatScanCmd):
        """
        Case "RETURN"
        173         pa$(2) = TranslatePath(pa$(2))
        174         pa$(3) = TranslatePath(pa$(3))
        175         If ValidatePFN(pa(2)) <> 2 Then ' not exists
        176             Exit Sub
                End If
        178         If ValidatePFN(pa(3)) <> 2 Then
        179             Name pa(2) As pa(3)
            End If
        """
        pass

class doVERIFY(IatScanCmd):
    def processCommand(self):
        s=self.translatePath(self.path)
        if self.validatePFN(s) == 2:
			# non-standard response, but client will hang if this is not just "OK"
            self.request.send_ok("OK")
        else:
            self.request.send_error(400,"ERROR: SOURCE FILE NOT FOUND")
        return

class doSIZE(IatScanCmd):
    def processCommand(self):
        import ctypes
        a,btotal,bfree=[ctypes.c_ulonglong() for x in range(3)]
        fun=ctypes.windll.kernel32.GetDiskFreeSpaceExA
        if sys.version_info >= (3,):
            fun=ctypes.windll.kernel32.GetDiskFreeSpaceExW
        r=fun('c:',ctypes.byref(a), ctypes.byref(b), ctypes.byref(c))
        pc_free=float(bfree.value*100)/float(btotal.value)
        gb_free=float(bfree.value)/(2**30)
        return

class doFILENAMES(IatScanCmd):
    """
            'Command format - "FILENAMES FOLDERNAME MASK COUNT"
            'FOLDERNAME and file mask in standard windows format, e.g., \\IATRICS\INB\*.tif
            'FOLDERNAME can use UNC or local path
            'Determine drive letter
            
            strDriveLetter = strUnQuoteString(pa$(2))
            
            If pa$(0) = 3 Then 'Number of files to return is specified
                intFilenameCounter = CInt(pa$(3))
    """
    def processCommand(self):
        s=self.translatePath(self.path)
        if not s:
            self.request.send_error(400,"ERROR|FOLDERNAME MISSING")
            return
        elif not os.path.isdir(os.path.dirname(s)):
            self.request.send_error(400,"ERROR|FOLDER IS NOT A VALID FOLDER (%s)" % os.path.dirname(s))
            return
        mask=self.target
        if "*" in mask: pass
        else:
            self.request.send_error(400,"ERROR|INVALID FILE SEARCH MASK (%s)" % mask)
        # Get the next set of files
        cnt=10
        try:
            cnt=int(self.filesize)
        except TypeError:
            pass
        if os.path.isdir(s):
            s=os.path.join(s,mask)
        l = self.getSetOfFiles(s,cnt)
        #print "<filenames>",len(l),l
        self.request.send_ok("OK|FILENAMES|"+"*".join(l))
        return

    def getSetOfFiles(self,path,count):
        #from ctypes.wintypes import WIN32_FIND_DATAW as WIN32_FIND_DATA
        _FindFirstFile = ctypes.windll.kernel32.FindFirstFileW
        _FindNextFile = ctypes.windll.kernel32.FindNextFileW
        _FindClose = ctypes.windll.kernel32.FindClose
        _GetLastError = ctypes.windll.kernel32.GetLastError
        wfd = WIN32_FIND_DATA()

        mask = unicode(path, sys.getfilesystemencoding())
        sHndl = _FindFirstFile(mask, ctypes.byref(wfd))
        filelist=[]
        
        if sHndl != -1:
            newfile=str(wfd.cFileName)
            fnd=0
            if newfile == '.' or newfile == '..': pass
            else:
                filelist.append(newfile)
                fnd+=1            
            while fnd<count and _FindNextFile(sHndl, ctypes.byref(wfd)):
                newfile=str(wfd.cFileName)
                if newfile == '.' or newfile == '..': pass
                else:
                    filelist.append(newfile)
                    fnd+=1
            _FindClose(sHndl)
        return filelist

class doINDEXFILES(IatScanCmd):
    def processCommands(self):
        """ 'Perform an action
                    For intCounter = 2 To CInt(pa$(0)) 'Counter starts at 2 to offset past "INDEXFILES"
                        Parse pa$(intCounter), "|", arrParams, 20
                        If arrParams(0) > 0 Then
                            Select Case arrParams(1)
                                Case "GETFILECOUNT"
                                    If arrParams(2) = "Y" Then
                                    End If
                                'Send back foldername and number of files
                                'e.g FOLDERNAME|SUBFOLDERNAME NUMBEROFFILES|FileCount
                                Case "GETSUBFOLDERNAMES"
                                
                            End Select
                        End If
                    Next
                    """
        return

class doFOLDERNAMES(IatScanCmd):
    """       'Command format - "FOLDERNAMES ROOTFOLDERNAME"
            'ROOTFOLDERNAME can use UNC or local path
    """
    def processCommand(self):
        if not self.path:
            self.request.send_error(400,"ERROR| NO ROOTFOLDER GIVEN")
            return

        s=self.translatePath(self.path)
        if not os.path.isdir(s):
            self.request.send_error(400,"ERROR| FOLDER NOT FOUND")
            return
        dd=os.walk(s).next()[1]
        self.request.send_ok("OK|FOLDERNAMES|"+"*".join(dd))
    
        return

class LockManager():
	__init__(self):
		self.locks_lock=threading.Semaphore()
		self.lockedFiles={}
	
	def _lock(self,setLock,f):
		self.locks_lock.acquire()
		retval=False
		try:
			if setLock:
				if f not in self.lockedFiles:
					self.lockedFiles[f]=time.time()
					retval = True
		except:
			pass
		self.locks_lock.release()
		if setLock: return retval
		return

	def lock(self,a):
		return self._lock(True,a)
		
	def unlock(self,a):
		self._lock(False,a)
		return
		
class IatScanThreadingMixIn:
    """Mix-in class to handle each request in a new thread."""

    # Decides how threads will act upon termination of the
    # main process
    daemon_threads = False

    def process_request_thread(self, request, client_address):
        """Same as in BaseServer but as a thread.

        In addition, exception handling is done here.

        """
        try:
            self.logger.debug("(%s) %s",client_address[0],"processing request ")
            self.finish_request(request, client_address)
            self.logger.debug("%s","process request thread: finished request")
            self.shutdown_request(request)
        except TypeError, e:
            print e
        except:
            self.handle_error(request, client_address)
            self.shutdown_request(request)

    def process_request(self, request, client_address):
        """Start a new thread to process the request.
            override in ThreadPoolMixIn
        """
        self.logger.debug("%s","IatScanThreadingMixin process request")
        t = threading.Thread(target = self.process_request_thread,
                             args = (request, client_address))
 #       t.name="iatscan_thr_"+str(t)
        t.daemon = self.daemon_threads
        t.start()

class ThreadPoolMixIn(IatScanThreadingMixIn):
    """
    use a thread pool instead of a new thread on every request
    """
    maxQueueLen = maxThreads = 25
    minThreads = 4
    pool_timeout = 10
    allow_reuse_address = True  # seems to fix socket.error on server restart

    def updatePoolStats(self,latest):
        
        """ Use this to set up and manage a set of worker threads in pool 
            so that we can expand or shrink the pool in times of high or low demand """
            
        # Need to make the following logic thread-safely
        # add current time and update running average of last 10 reqs
        locked=False
        try:
            locked=self.poolLock.acquire()
            self.logger.debug("%s","Pool is locked for updates")
            if len(self.pool_stats)+1>10:
                oldest,latency=self.pool_stats.pop(0)
            IatScanServer.request_complete+=1
            self.logger.debug("Qued %15.3f, wait %5.3f", latest,time.time()-latest)
            self.pool_stats.append((latest,time.time()-latest))
            self.poolLock.release()
            self.logger.debug("%s","Pool is open for updates")
        except: 
            if locked: 
                self.poolLock.release()
                self.logger.debug("%s","Pool is locked for updates")
        return
        
    def managePool(self,new_request=None):
        locked=False
        try:
            if len(self.pool_stats)>1:
                delay=0
                locked=self.poolLock.acquire()
                self.logger.debug("%s","Pool is locked for management by "+str(self))
                if new_request:
                    if IatScanServer.request_count:
                        IatScanServer.request_count+=1
                    else:
                        IatScanServer.request_count=1
                    self.logger.debug("%s","Added new request - # "+str(IatScanServer.request_count))
                n=len(self.pool_stats)
                for a in self.pool_stats:
                    delay+=a[1]
                self.poolLock.release()
                delay=delay/float(n)
                self.logger.debug("%s","Pool is open after management")
                self.logger.debug("Average delay = %6.3f",delay)
                if delay>2.0:
                    if threading.activeCount() < maxThreads:
                        # start a few more
                        pass
                if delay < 0.25 and (threading.activeCount()>minThreads):
                        # end a fe threads
                    pass
        except:
            if locked:
                self.poolLock.release()
                self.logger.debug("%s","Pool is open (after except) after management")
        #print "Number of active thread %d" % threading.active_count()

        return

    def __init__(self):
        """
        Initialize Queue and start up a small block of threads to handle requests
        
        We can add or remove threads based on traffic.
        The maximum number of threads will be limited to maxThreads so we don't overwhelm
        the machine
        """
        # set up the threadpool
        self.logger.debug("Setting up threadpool")
        try:
            nthr = int(self.settings["SERVER"]["minthreads"])
            mthr = int(self.settings["SERVER"]["maxthreads"])
            nreq = int(self.settings["SERVER"]["maxrequest"])
            nto = float(self.settings["SERVER"]["pool-timeout"])

            if mth > self.minTheads:
                self.maxThreads = mth
            
            if nth > self.minThreads and nth < self.maxThreads:
                self.minThreads = nth

            if nreq > 10:
                self.maxQueueLen = nreq

            if nto > 1.0:
                self.pool_timeout = nto
            alow_reuse_address = bool(self.settings["SERVER"]["reuse-address"])
            
        except:
            pass

        self.request_pool = Queue.Queue(self.maxQueueLen)
        self._shutdown_event = threading.Event()
        self.pool_stats=[]
        self.poolLock=threading.Semaphore()

        for x in range(self.minThreads):
            t = threading.Thread(target = self.process_request_thread)
            t.setDaemon(1)
            t.name="_thr_"+str(x+1).rjust(3,"0")
            t.start()
        self.logger.debug("%s threads",str(self.minThreads))
            
    def process_request_thread(self):
        """
        obtain request from queue instead of directly from server socket
        """
        while True:
            try:
                self.logger.debug("%s","Blocked waiting for request ")
                request, client_address, que_time = self.request_pool.get(self.pool_timeout, self.pool_timeout)
                self.updatePoolStats(que_time)
                IatScanThreadingMixIn.process_request_thread(self, request, client_address)
                self.logger.debug("(%s) %s",client_address[0],"processing request complete")
                self.request_pool.task_done()
            except Queue.Empty:
                self.logger.debug("%s","ThreadPoolMixin get request - empty queue")
                sys.exc_clear()
                self.managePool()
                if self._shutdown_event.isSet():
                    self.logger.warning("%s", "Shutting down ")
                    return
            
    def process_request(self, request, client_address):
        """Start a new thread to process the request."""
        self.logger.debug("%s","IatScanThreadingMixin process request")
        # if all threads are busy, start 3 new ones
        self.managePool(1)
        # otherwise, just place the request in the pool
        self.request_pool.put((request, client_address,time.time()))
        return

    def join2(self):
        """
        Wait on the pool to clear and shut down the worker threads.
            # A nicer place for this would be shutdown(), but this being a mixin,
            # that method can't safely do anything with that method, thus we add
            # an extra method explicitly for clearing the queue and shutting
            # down the workers.
        """

        self.request_pool.join()
        self._shutdown_event.set()

class IatScanServer (ThreadPoolMixIn,
                           SocketServer.TCPServer):
    request_count=0
    request_complete=0
    last_oid=0
    def __init__ (self, server_address, RequestHandlerClass, logger=None,start=True):
        SocketServer.TCPServer.__init__ (self, server_address,
                                            RequestHandlerClass,start)
        settings = {"server-ip":'127.0.0.1',"port":'2347',"debug":False,"logfile":'IatscanServer.log',
                    "rootpath":'C:/Iatric/Scansvr',"handler-class":IatScanRequestHandler}
        self.logger = self.logSetup(settings)
        self.serve_forever()

    def __init__ (self):
        self.configfile='scansvr.ini'
        
        self.settings=self.__readConfig()
        settings=self.settings["SERVER"]

        SocketServer.TCPServer.__init__(self, None, None,False)
        #ThreadPoolMixIn.__init__(self)
        self.logger = self.logSetup(settings)
        self.server_address=(settings['bindto'],int(settings['port']))
        self.RequestHandlerClass = settings["handler-class"]
        self.socket = socket.socket(self.address_family,
                                    self.socket_type)
        self.logger.info("%s","\n\n")
        sep="".join(["=" for x in range(30)])
        self.logger.critical("%s",sep+"\tStarting up .. \t"+sep)
        self.working=self.settings["SERVER"]["workingdir"]		
		self.lockHandler = LockManager()
        ThreadPoolMixIn.__init__(self)

        # set up mmap file to dynamically share last processed transaction in thread
        #fm = open('Iscansvr txns.log','wb')
        #self.mm = mmap.mmap(fm.fileno(),0)
        #try:
        #    self.mm.seek(self.mm.find("thread"))
        #    r=self.mm.readline()
        #    if len(r)>0:
        #        mm.write('0')
        #except:
        #    pass
        try:
            self.server_bind()
            self.logger.critical( "SVR> %s","Bound to: "+str(self.server_address)+" .. Listening")
            self.server_activate()
            self.serve_forever()
        except:
            self.logger.info( "SVR> Could not start server on %s: %d",self.server_address[0],
                              self.server_address[1])
            self.server_close()
            raise

    def _setdebug(self,level):
        if level == "ON":
            self.logger.setLevel(10) #DEBUG
        else:
            self.logger.setLevel(30) #WARNING
                              
                              
        return

    def __readConfig(self):
        import ConfigParser
        c=ConfigParser.SafeConfigParser()
        c.read(self.configfile)
        C=dict([(a,dict(c.items(a)) ) for a in c.sections()])
        # set up the first available ip address as the default address
        svr_defaults = {"bindto":socket.gethostbyname_ex(socket.gethostname())[2][0],
                        "port":'2240', "loglevel":"WARNING", "logfile":'IatscanServer.log',
                        "workingdir":os.path.abspath('../scanwork'),
                        "rootdir":os.path.abspath('.'),
                        "minthreads":'4', "maxthreads":'12', "maxrequest":'20',"pool-timeout":"10",
                        "handler-class":IatScanRequestHandler}
        if "SERVER" not in C:
            C["SERVER"]=svr_defaults
        else:
            for k in svr_defaults.keys():
                if k not in C["SERVER"]:
                    C["SERVER"][k]=svr_defaults[k]
        c=None
        return C
        
	def __lock(self,toLock,e):
		# toLock is True is entity is to be locked, False to unlock
		isLocked=False
		
		return isLocked
    def generateOID(self,tpath):
#        import os.path, os
#        import time
        oid=self.last_oid+1
        tf=os.path.join(tpath,str(oid).rjust(8,"0")+".tmp")
        max_tries=100
        while os.path.isfile(tf) and max_tries>0:
            #check if old enough to delete currently 5 min
            if time.time()-os.path.getctime(tf)>300:
                os.remove(tf)
            else:
                oid+=1
                tf=os.path.join(tpath,str(oid).rjust(8,"0")+".tmp")
                max_tries+=-1
        self.last_oid=oid
        return tf
				
    def _start_(self, *args):
        """ This function should read a config file for initial parameters and create an instance of the server
        """
        settings=defaults
        logger=self.logSetup(settings)
        IatScanServer(server, settings["handler-class"],logger)
        return

    def _stop_(self,*args):

        self._shutdown_event.set()
        self.logger.warning("%s", "Shutdown flags set")
        self.shutdown()

        return
    allow_reuse_address = 1    # Seems to make sense in testing environment

    def server_bind(self):
        """Override server_bind to store the server name."""
        SocketServer.TCPServer.server_bind(self)
        host, port = self.socket.getsockname()[:2]
        self.server_name = socket.getfqdn(host)
        self.server_port = port
      
    def logSetup (self, kwargs):
#        filename = "IatscanServer.log"
        filename = None
        log_size = 2
        daemon=None
        try:
            filename = kwargs['logfile']
            if kwargs["clearlogfile"] and filename:
                fa=open(filename,'w')
                fa.write('')
                fa.flush()
                fa.close()
        except: pass
            
#        try: 
#            log_size=int(kwargs['log-size'])
#        except: pass

        logger = logging.getLogger ("IatscanServer")
        l=kwargs['loglevel']
        try:
            lnum = int(kwargs['detaillogging'].strip()) *10
            if lnum in range(10,51,10):
                l=lnum
            logger.setLevel (logging.getLevelName(l))
        except:
            logger.setLevel (logging.WARNING)
        if not filename:
            if not daemon:
                # display to the screen
                handler = logging.StreamHandler ()
            else:
                handler = logging.handlers.RotatingFileHandler (DEFAULT_LOG_FILENAME,
                                                                maxBytes=(log_size*(1<<20)),
                                                                backupCount=5)
        else:
            handler = logging.handlers.RotatingFileHandler (filename,
                                                            maxBytes=(log_size*(1<<20)),
                                                            backupCount=5)
        fmt = logging.Formatter ("[%(asctime)-12s] %(threadName)s %(levelname)-8s: %(message)s")
#                                 "%Y-%m-%d %H:%M:%S"
#                                 "%(levelname)-8s {%(name)s %(threadName)s}"
#                                 " %(message)s" )
        handler.setFormatter (fmt)
            
        logger.addHandler (handler)
        #self.logger = logger
        return logger

class ServerManager(Tk):
    settings = {}

    def __init__(self, parent, cmdargs=[]):
        
        self.top = self
        Tk.__init__(self,parent)
        self.parent=parent
        self.configfile='scansvr.ini'
        self.settings=self.readSettings()
        self.initialize(cmdargs)

    def initialize(self, initargs):
        self.status = self.parent
        
        self.top.title('Iscan Server Manager')
        self.pid=os.getpid()

        for item in initargs:
            pass
        st=ttk.Style()
        st.theme_use('winnative')
        st.configure('.', font='verdana 12')
        if True:
            
            self.frame = ttk.Frame(self, borderwidth=1)
            self.frame.pack(fill=BOTH,expand=5)

            self.cfm = ttk.Frame(self.frame)
            self.yscrlbr = ttk.Scrollbar(self.cfm)
            self.yscrlbr.pack(side=RIGHT, fill=Y)
            self.xscrlbr = ttk.Scrollbar(self.cfm, orient=HORIZONTAL)
            self.xscrlbr.pack(side=BOTTOM, fill=X)
            self.tbox = Listbox(self.cfm,relief=GROOVE, height=10,width=60, yscrollcommand=self.yscrlbr, xscrollcommand=self.xscrlbr)
            #self.tbox.config(font=('verdana 10')
            self.yscrlbr.config(command=self.tbox.yview)
            self.xscrlbr.config(command=self.tbox.xview)
            self.tbox.pack(side=LEFT,fill=BOTH, expand=5)
            self.cfm.pack(fill=BOTH,expand=5)
            
        # display the menu
            self.menubar=Menu(self.top)
            self.setupMenu()
            self.top.config(menu=self.menubar)
            self.top.wm_resizable(width=200, height=120)

        #self.bind("<Escape>", self.destroy)            

        return  


    def writeTbox(self,s):
        self.tbox.insert(END,s)
        return
   

    def readSettings(self):
        import ConfigParser
        c=ConfigParser.SafeConfigParser()
        c.read(self.configfile)
        C=dict([(a,dict(c.items(a)) ) for a in c.sections()])
        # set up the first available ip address as the default address
        svr_defaults = {"bindto":socket.gethostbyname_ex(socket.gethostname())[2][0],
                        "port":'2240', "loglevel":"WARNING", "logfile":'IatscanServer.log',
                        "workingdir":os.path.abspath('../scanwork'),
                        "rootdir":os.path.abspath('.'),
                        "minthreads":'4', "maxthreads":'12', "maxrequest":'20',"pool-timeout":"10",
                        "handler-class":IatScanRequestHandler}
        if "SERVER" not in C:
            C["SERVER"]=svr_defaults
        else:
            for k in svr_defaults.keys():
                if k not in C["SERVER"]:
                    C["SERVER"][k]=svr_defaults[k]
        c=None
        return C

    def saveSettings(self):
        cfg=open(self.configfile,'w')
        for section in self.settings.keys():
            cfg.write("[%s]\n" % section)
            for k in self.settings[section].keys():
                if k == "handler-class": pass
                else:
                    cfg.write("%s= %s\n" % (k.upper(),self.settings[section][k]) )
            cfg.write('\n')
        cfg.flush()
        cfg.close()

        

    def setupMenu(self):
        s = 'setupmenu'
#Create our Python menu
        self.connlist = Menu(self.menubar, tearoff=0)
        self.activeConnections = Menu(self.menubar, tearoff=0)
#Add our Menu to the Base Menu
        self.menubar.add_cascade(label="Server", menu=self.connlist)
#        self.menubar.add_cascade(label="Active", menu=self.activeConnections, state=DISABLED)
#        self.activeConnections.add_cascade(label="Refresh", command='self.checkActives')
#        self.activeConnections.add_cascade(label="Reload", command='self.reloadConnections')
#        self.activeConnections.add_separator()
        self.connlist.add_cascade(label="Start",command=self.startServer )
        self.connlist.add_cascade(label="Halt",command=self.stopServer )
        self.connlist.add_separator()
        self.connlist.add_command(label="Setup",command=self.setupServer)
        self.connlist.add_separator()
        self.connlist.add_command(label="Clear Manager Log",command=self.clearTbox )
        self.connlist.add_command(label="Version",command=self.getVersion )
        self.connlist.add_command(label="Statistics",command=self.getStats )
        self.connlist.add_command(label="Debug On",command=lambda x=True: self.setDebug(x) )
        self.connlist.add_command(label="Debug Off",command=lambda x=False: self.setDebug(x) )
        self.connlist.add_separator()
        self.connlist.add_command(label="Exit",command=self.destroy)
        
#        i=0
#        keyset=self.allConnections.keys()
#        keyset.sort()
#        for c in keyset:
#            self.connlist.add_command(label=c, command= lambda x=c: self.addConnection(x) )
#            i+=1
    def clearTbox(self):
        self.tbox.delete(0,END)

    def _checkServer(self):
        import subprocess as sp
        port = self.settings["SERVER"]["port"].strip()
        p=sp.Popen(["netstat","-ao"],stdout=sp.PIPE)
        s=p.communicate()
        ss=[x for x in s[0].split('\n') if port in x]
        if len(ss)>0:
            return "Server listening: %s" % '\n'.join(ss[0])

    
    def startServer(self):
        import subprocess as sp
        if self._checkServer():
            self.writeTbox("Server already listening on %s" % self.settings["SERVER"]["port"].strip())
            return
        pid=sp.Popen([os.path.join(self.settings["SERVER"]["pydir"],"python.exe"),
                      os.path.join(self.settings["SERVER"]["rootdir"],"iscansvr.py"),
                      "-o server"])
        time.sleep(0.5)
        if pid.poll():
            tkMessageBox.showwarning("Start","Could not start server")
        else:
            self.writeTbox("Server running .. [%s]:%s " % (self.settings["SERVER"]["bindto"],
                                                         self.settings["SERVER"]["port"]))
        return
    
    def stopServer(self):
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            svr=self.settings["SERVER"]["bindto"]
            s.connect((svr,int(self.settings["SERVER"]["port"])))
        except:
            tkMessageBox.showwarning("Stop Server","Could not connect")
            return
        try:
            ret = s.send("SHUTDOWN\x00")
            ret=s.recv(128)
            self.writeTbox("Server shutdown .. %s" %  ret.strip('\x00'))
            
        except:
            tkMessageBox.showwarning("Stop Server","Could not shutdown")
            return
            
        return

    def setDebug(self,state=False):
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            svr=self.settings["SERVER"]["bindto"]
            s.connect((svr,int(self.settings["SERVER"]["port"])))
        except:
            tkMessageBox.showwarning("Stop Server","Could not connect")
            return
        try:
            ret=""
            if state:
                ret = s.send("SETDEBUGON\x00")
                ret=s.recv(128)
            else:
                ret = s.send("NODEBUG\x00")
                ret=s.recv(128)
            self.writeTbox("Debug .. " + ret.strip('\x00'))
            
        except:
            pass            
        return

    def getVersion(self):
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            svr=self.settings["SERVER"]["bindto"]
            s.connect((svr,int(self.settings["SERVER"]["port"])))
        except:
            tkMessageBox.showwarning("Stop Server","Could not connect")
            return
        try:
            ret = s.send("VERSION\x00")
            ret=s.recv(128)
            self.writeTbox("Version .. " + ret.strip('\x00'))
            
        except:
            pass            
        return

    def getStats(self):
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            svr=self.settings["SERVER"]["bindto"]
            s.connect((svr,int(self.settings["SERVER"]["port"])))
        except:
            tkMessageBox.showwarning("Stop Server","Could not connect")
            return
        try:
            ret = s.send("STATS\x00")
            ret=s.recv(128)
            self.writeTbox("Stats .. %s" % ret.strip('\x00'))
            
        except:
            tkMessageBox.showwarning("Get Stats","Could not get stats")
            return
            
        return
    def setupServer(self):
        ManagerSetup(self,"Server Settings")
        settings=self.settings["SERVER"]
        #tkMessageBox.showwarning("Setup Server","Not implemented")
        self.writeTbox("server %s: port %s" % (settings["bindto"],
                                               settings['port']))
        self.writeTbox("debug %s level %s" % (settings['debug'],
                                              settings['detaillogging']))
        return

class ManagerSetup(Toplevel):

    def __init__(self, parent, title=None):

        Toplevel.__init__(self, parent)
        self.transient(parent)

        if title:
            self.title(title)
        self.parent = parent
        self.settings = parent.settings
        ttk.Style().theme_use('alt')
        st=ttk.Style()
        st.theme_use('winnative')
        st.configure('.', font='verdana 11')
        
        body = ttk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        self.grab_set()

        if not self.initial_focus:
            self.initial_focus = self

        self.protocol("WM_DELETE_WINDOW", self.cancel)

        self.geometry("+%d+%d" % (parent.winfo_rootx()+50,
                                  parent.winfo_rooty()+50))

        self.initial_focus.focus_set()

        self.wait_window(self)

    #
    # construction hooks

    def body(self, master):
        # create dialog body.  return widget that should have
        # initial focus.  this method should be overridden
        
        ttk.Label(master, text="Address:").grid(row=0, sticky=E)
        ttk.Label(master, text="Port:").grid(row=1, sticky=E)
        ttk.Label(master, text="Status:").grid(row=2, sticky=E)
        #st.configure('TButton', font=('verdana',12))
        #st.configure('TEntry', font='verdana 10')
        
        s=socket.gethostbyname_ex(socket.gethostname())[2]
        s.extend(['127.0.0.1'])
        port='2240'
        ip=s[0]
        #s.reverse()
        self.debug=IntVar()
        self.debug.set(0)
        #ipaddrs.reverse()
        self.e1 = ttk.Combobox(master,values=tuple(s),width=20)
        self.e2 = ttk.Entry(master,width=22 )
        self.e3 = ttk.Entry(master,width=22, state=ACTIVE )
        self.e4 = ttk.Entry(master,width=30 )
        self.e2.delete(0,END)
#        self.e2.insert(0,'7500')
        self.e1.grid(row=0, column=1, sticky=EW)
        self.e2.grid(row=1, column=1, sticky=EW)
        self.e3.grid(row=2, column=1, sticky=EW)
        self.e4.grid(row=3, column=1, sticky=EW)
        debuglevels=['CRITICAL','ERROR','WARN','INFO','DEBUG','NONE']
        debuglevels.reverse()
        self.debuglevels=debuglevels
        self.cb = ttk.Checkbutton(master, text="Debug?", variable=self.debug, onvalue=True, offvalue=False)
        self.dbl = ttk.Combobox(master,values=tuple(debuglevels))
        if True:
            
            if self.settings["SERVER"]["bindto"].strip() in s:
                ip=self.settings["SERVER"]["bindto"].strip()
            else:
                ip=s[0]
            self.settings["SERVER"]["bindto"] = ip
            self.e1.set(ip)
            self.e2.insert(0,self.settings["SERVER"]["port"])
            csr= self.parent._checkServer()
            self.e3.config(state="active")
            if csr:
                self.e3.insert(0,"Server is running")
            else:
                print "check returned nothing"
                self.e3.delete(0)
            self.e3.config(state="disabled")
            self.e4.insert(0,self.settings["SERVER"]["workingdir"])
            lvl=0
            try:
                lvl=int(self.settings["SERVER"]["detaillogging"])
            except: pass
            if lvl in range(6): pass
            else: lvl=0
            self.dbl.set(debuglevels[lvl])
            if lvl>0:
                self.debug.set(1)
            else: self.debug.set(0)
#        except: pass
        
        self.cb.grid(row=5, column=0, sticky=W)
        self.dbl.grid(row=5, column=1)


        pass

    def buttonbox(self):
        # add standard button box. override if you don't want the
        # standard buttons

        box = ttk.Frame(self)

        w = ttk.Button(box, text="OK", width=10, command=self.ok, default=ACTIVE)
        w.pack(side=LEFT, padx=5, pady=5)
        w = ttk.Button(box, text="Cancel", width=10, command=self.cancel)
        w.pack(side=LEFT, padx=5, pady=5)

        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)
        box.pack()

    #
    # standard button semantics

    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set() # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        self.apply()

        self.cancel()

    def cancel(self, event=None):

        # put focus back to the parent window
        self.parent.focus_set()
        
        self.destroy()

    #
    # command hooks

    def validate(self):
        return 1 # override

    def apply(self):
        self.settings["SERVER"]['bindto']=self.e1.get()
        self.settings["SERVER"]['port']= self.e2.get()
        #self.settings["SERVER"]['port']= self.e2.get()
        self.settings["SERVER"]['workingdir']=self.e4.get()
        self.settings["SERVER"]['detaillogging']=0
        try:
            self.settings["SERVER"]['detaillogging']=self.debuglevels.index(self.dbl.get())
        except: pass
        self.parent.saveSettings()

        pass # override

def manage_server(p,s):
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect(('127.0.0.1',p))
    s.send("%s \x00" % s)
    print s.recv(512)
def set_as_service(svcname,svcpath,svcargs=None):
    import _winreg
    # check if service already exists
    h2=None
    hk=_winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Services")
    try:
        hk2=_winreg.OpenKey(hk,svcname)
        # service is already set up
        pass
    except:
        pass
    if hk2: _winreg.CloseKey(hk2)
    _winreg.CloseKey(hk)
    """
    Step 1: 
    Download and install Windows Resource Kit. 
    Which was found in my box: C:\Program Files (x86)\Windows Resource Kits\Tools\srvany.exe . 

    Then open command prompt and hit

    sc create "[YourService]" binPath="C:\Program Files (x86)\Windows Resource Kits
    \Tools\srvany.exe" start=auto DisplayName="[YourService Monitor]"

    [SC] CreateService SUCCESS


    Step 2: make a file.reg with following contents and double click on it
    [HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\[YourService]\Parameters]
    "Application"="C:\\[YourService Executable].exe"

     """
    return
    
if __name__ == '__main__':

    import argparse

    parser = argparse.ArgumentParser(description='Iatrican Server Functions')
    parser.add_argument('-ip',
                       help='ip address for server')

    parser.add_argument('-p', type=int, 
                       help='port for server')

    parser.add_argument('-r', 
                       help='root directory')

    parser.add_argument('-o', type=str, 
                       help='manager, server, shutdown, setdebug, nodebug')
    args = parser.parse_args()
    if args.o:
        args.o=args.o.strip('\r\n').strip(" ")
    print  args.ip,args.p,args.o,args.r

    if args.r and False:
        print "moving from ",os.path.abspath('.')
        os.chdir(args.r.strip(' ').strip())
        print "to", os.path.abspath('.')

    if args.o == 'server':
        print 'starting server'
        #a=IatScanServer()
        a=None
        print "exiting main()"
    elif args.o == 'manager':
        print "starting manager"
        app=ServerManager(None)
        app.mainloop()
        print 'manager done'

    elif args.p and args.o:
        print "manage server"
        manage_server(args.p, args.o.upper())
    elif False:
		print 'start server'
        app=ServerManager(None).mainloop()
    
    else:
        print "Unknown option", args
